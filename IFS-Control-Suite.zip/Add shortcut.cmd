@echo off
rem Put IFS Control Suite on the desktop and in the Start menu.
rem No administrator rights, no installer, nothing written outside this user's profile.
setlocal
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

if not exist "%HERE%\runtime\pythonw.exe" (
  echo This folder is incomplete - runtime\pythonw.exe is missing.
  echo Unzip the whole IFS Control Suite folder, then run this again.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$h='%HERE%';" ^
  "$s=New-Object -ComObject WScript.Shell;" ^
  "foreach($p in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))){" ^
  "  $l=$s.CreateShortcut((Join-Path $p 'IFS Control Suite.lnk'));" ^
  "  $l.TargetPath=(Join-Path $h 'runtime\pythonw.exe');" ^
  "  $l.Arguments='\"'+(Join-Path $h 'ifs-launch.pyw')+'\"';" ^
  "  $l.WorkingDirectory=$h;" ^
  "  $l.IconLocation=(Join-Path $h 'ifs.ico')+',0';" ^
  "  $l.Description='IFS Control Suite - IonField Systems';" ^
  "  $l.Save() }"

if errorlevel 1 (
  echo Could not create the shortcuts.
  pause
  exit /b 1
)
echo.
echo Done. IFS Control Suite is on your desktop and in the Start menu.
echo.
pause
