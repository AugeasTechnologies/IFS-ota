IFS Control Suite
IonField Systems - software by Augeas Technologies

WHAT THIS IS
This folder is the whole application. It carries its own Python runtime, so there is
nothing to install and nothing to download: it runs on a machine that has never had
Python on it and has no internet connection.

TO USE IT
  1. Copy this folder anywhere you like - your desktop, Documents, a USB stick.
  2. Double-click "Add shortcut.cmd".
     That puts IFS Control Suite on your desktop and in the Start menu.
  3. Open it from that shortcut.

Nothing needs administrator rights and nothing is written outside your own user profile.

IF WINDOWS BLOCKS AN INSTALLER
It will not block this one. The program Windows actually runs here is python.exe from
python.org, signed by the Python Software Foundation - a program Windows already trusts.
That is why this folder works on machines where a packaged .exe is refused by Smart App
Control.

TO REMOVE IT
Delete the shortcuts and delete this folder. Nothing else is left behind except your own
settings, in:
  %APPDATA%\IonField\IFS
