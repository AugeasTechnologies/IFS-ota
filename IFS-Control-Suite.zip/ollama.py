# -*- coding: utf-8 -*-
"""IFS AI against a model on your own network.

A plasma station in a lab often has no internet, and a customer who does have internet may still
not be allowed to send anything out of it. A model running on a box in the same building answers
both: nothing leaves the site, there is no per-question cost, and the feature works on an air
gapped bench.

The trade is capability. A 35B model on one GPU is not Opus, and the place that shows is
multi-step work: it will query, but it gives up and answers sooner, and it is likelier to state a
number it did not read. The system prompt leans harder on "query before you answer" because of it.

Two things learned the hard way and encoded here:

  think must be FALSE. The qwen3 family returns an empty content field when thinking is left on
  through this endpoint, so the answer arrives blank and nothing says why.

  Ollama's wire format is not Anthropic's. Tool results come back as role "tool" messages rather
  than content blocks, so a conversation cannot be moved between the two providers mid-thread.
  Switching provider clears the thread rather than sending the model a shape it cannot read.
"""

import json
import urllib.error
import urllib.request

DEFAULT_URL = "http://127.0.0.1:11434"
DEFAULT_MODEL = "qwen3.6:35b"
TIMEOUT = 300.0          # a 35B model on a busy GPU is not fast; this is not a hung request

# How long the host keeps the model in VRAM after a request. Measured on a 35B: 6.6s of a 9.4s
# answer was the model being loaded, because the default eviction is five minutes and a bench is
# quiet for longer than that between questions. Warm, the same answer took 0.60s.
KEEP_ALIVE = "30m"


def _post(base, path, body, timeout=TIMEOUT, stream=False):
    req = urllib.request.Request(
        base.rstrip("/") + path,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST")
    return urllib.request.urlopen(req, timeout=timeout)


def models(base):
    """What this host can run. Used to fill the picker rather than making anyone type a tag."""
    try:
        req = urllib.request.Request(base.rstrip("/") + "/api/tags")
        with urllib.request.urlopen(req, timeout=8) as r:
            d = json.loads(r.read().decode("utf-8"))
        return [m.get("name", "") for m in d.get("models", []) if m.get("name")], ""
    except urllib.error.URLError as e:
        return [], "Could not reach %s (%s)." % (base, getattr(e, "reason", e))
    except Exception as e:
        return [], str(e)


def _as_ollama_tools(tools):
    """Anthropic tool definitions to Ollama's function shape. Only our own tools cross over -
    an mcp_toolset entry is a server-side Anthropic feature and has no meaning here."""
    out = []
    for t in tools:
        if t.get("type"):                      # mcp_toolset and friends: not ours to translate
            continue
        out.append({"type": "function", "function": {
            "name": t["name"],
            "description": t.get("description", ""),
            "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
        }})
    return out


def resident(base, model, timeout=4.0):
    """Is the model already in VRAM? Cheap, and it is the difference between a one second answer
    and a thirteen second one - so it is worth saying which is about to happen."""
    try:
        req = urllib.request.Request(base.rstrip("/") + "/api/ps")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8"))
        return any(m.get("name") == model for m in d.get("models", []))
    except Exception:
        return False


def warm(base, model, system="", tools=None, timeout=40.0):
    """Load the model into VRAM AND put the real prompt prefix in its cache.

    Loading alone is not enough. Measured: with the model resident but the prefix cold, the first
    question still took 15.1s while the ones after it took 1.6s - the cost was evaluating a long
    system prompt the host had never seen. Ollama caches the prefix of a conversation, so warming
    with the SAME system prompt and tool definitions the questions will carry means the first one
    only pays for the words the operator actually typed.

    One token of output, which forces both and costs nothing. Failure is silent on purpose: a host
    that is down should surface when somebody asks a question, with a message about the question,
    not as an error nobody asked for.
    """
    try:
        body = {"model": model, "stream": False, "think": False, "keep_alive": KEEP_ALIVE,
                "messages": ([{"role": "system", "content": system}] if system else []) +
                            [{"role": "user", "content": "ready?"}],
                "options": {"num_predict": 1}}
        if tools:
            body["tools"] = _as_ollama_tools(tools)
        with _post(base, "/api/chat", body, timeout=timeout) as r:
            r.read()
        return True
    except Exception:
        return False


def _unreachable(base, err):
    """Why no model answered, written for the person at the machine.

    A refused connection means nothing is listening, and saying so is the whole message - the
    errno adds nothing. A timeout or a name that will not resolve is different: that is a
    symptom worth repeating, because it points at the network rather than at the model.
    """
    reason = str(getattr(err, "reason", err))
    low = reason.lower()
    boring = ("refused" in low or "10061" in low or "connection reset" in low)
    detail = "" if boring else (" The network said: %s." % reason.strip().rstrip("."))
    return ("No model answered at %s.%s\n\n"
            "IFS AI needs one of two things: a model running somewhere it can reach, or an "
            "Anthropic key. Both are on the Insight screen, under the assistant - set the address "
            "to a machine on this network that is running one, or paste a key to use Anthropic "
            "instead. The instrument is unaffected either way." % (base, detail))


def chat(base, model, system, messages, tools, run_tool, max_steps=24):
    """Stream a turn. Yields the same (event, payload) pairs the Anthropic path does, so the view
    does not know or care which one answered.

    `messages` is Ollama-shaped and is appended to in place. `run_tool(name, args)` executes one
    tool and returns (result_string, is_error).
    """
    wire = [{"role": "system", "content": system}] + messages
    otools = _as_ollama_tools(tools)

    # TIMEOUT is long because generating is slow, but it also governed connecting: a host that
    # was switched off left "Reading the history" on screen for five minutes. Ask it something
    # trivial first, with a short fuse.
    try:
        with urllib.request.urlopen(base.rstrip("/") + "/api/version", timeout=3.0) as r:
            r.read()
    except Exception as e:
        yield ("error", _unreachable(base, e))
        return

    for step in range(max_steps):
        yield ("status", "Reading the history" if step == 0 else "Thinking")
        body = {"model": model, "messages": wire, "tools": otools, "stream": True,
                # think=False is not a preference. Left on, the qwen3 family returns empty content
                # through this endpoint and the answer silently arrives blank.
                "think": False,
                "keep_alive": KEEP_ALIVE}
        try:
            resp = _post(base, "/api/chat", body)
        except urllib.error.URLError as e:
            yield ("error", _unreachable(base, e))
            return
        except Exception as e:
            yield ("error", str(e))
            return

        text = ""
        calls = []
        try:
            for raw in resp:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    d = json.loads(raw.decode("utf-8"))
                except Exception:
                    continue
                if d.get("error"):
                    yield ("error", str(d["error"]))
                    return
                msg = d.get("message") or {}
                piece = msg.get("content") or ""
                if piece:
                    text += piece
                    yield ("delta", piece)
                for c in (msg.get("tool_calls") or []):
                    calls.append(c)
                if d.get("done"):
                    break
        finally:
            try:
                resp.close()
            except Exception:
                pass

        assistant = {"role": "assistant", "content": text}
        if calls:
            assistant["tool_calls"] = calls
        wire.append(assistant)
        messages.append(assistant)

        if not calls:
            yield ("done", {"in": 0, "out": 0})      # Ollama reports counts per call, not per turn
            return

        for c in calls:
            fn = c.get("function") or {}
            name = fn.get("name", "")
            args = fn.get("arguments") or {}
            if isinstance(args, str):                # some builds send the arguments as a string
                try:
                    args = json.loads(args)
                except Exception:
                    args = {}
            # A tool that changes the view is not a query, and listing it under "what it
            # queried" alongside 0 rows is both wrong and confusing.
            data_tool = name in ("read_sql", "station_numbers", "station_findings")
            yield ("status", "Querying the history" if data_tool else "Changing the view")
            result, err = run_tool(name, args)
            if data_tool:
                yield ("query", {"sql": args.get("sql", name),
                                 "rows": 0 if err else result.count("},"),
                                 "error": result if err else None})
            row = {"role": "tool", "content": result}
            # Newer Ollama matches results to calls by name; older builds ignore the field, and
            # sending it is harmless on both.
            if name:
                row["tool_name"] = name
            wire.append(row)
            messages.append(row)

    yield ("error", "Gave up after %d steps without reaching an answer." % max_steps)
