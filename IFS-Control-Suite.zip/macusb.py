"""USB control transfers on macOS through IOKit (IOUSBLib), called with ctypes.

The transport behind dfuse.py in the Mac App Store build. It uses only Apple's own frameworks
(IOKit, CoreFoundation) - no libusb, no third-party code - and only the default control pipe
(endpoint 0), which is all USB DFU needs. Inside the App Sandbox it needs the
com.apple.security.device.usb entitlement (packaging/macos/mas.entitlements has it).

The COM-style interface layout (vtable slots), the IOUSBDevRequestTO layout and the UUIDs below
are taken from the macOS SDK headers (IOKit/usb/IOUSBLib.h, IOKit/IOCFPlugIn.h);
tests/test_dfuse.py compiles a probe against the installed SDK and checks they still match.
"""
import ctypes
import ctypes.util
import time

from dfuse import UsbError

# ---------------------------------------------------------------- ABI facts from the SDK headers
# IOCFPlugInInterface / IUnknown
SLOT_QUERY_INTERFACE = 1
SLOT_RELEASE = 3
# IOUSBDeviceInterface320 (slot = offsetof(field) / sizeof(void*))
SLOT_USB_DEVICE_OPEN = 8
SLOT_USB_DEVICE_CLOSE = 9
SLOT_GET_DEVICE_VENDOR = 13
SLOT_GET_DEVICE_PRODUCT = 14
SLOT_GET_LOCATION_ID = 20
SLOT_GET_CONFIGURATION = 22
SLOT_SET_CONFIGURATION = 23
SLOT_USB_DEVICE_OPEN_SEIZE = 29
SLOT_DEVICE_REQUEST_TO = 30
SLOT_ABORT_PIPE_ZERO = 33

UUID_USB_DEVICE_USER_CLIENT_TYPE = bytes.fromhex("9dc7b7809ec011d4a54f000a27052861")
UUID_CF_PLUGIN_INTERFACE = bytes.fromhex("c244e858109c11d491d40050e4c6426f")
UUID_USB_DEVICE_INTERFACE_320 = bytes.fromhex("01a2d0e942f64a878b8b77057c8ce0ce")

kIOReturnSuccess = 0
kIOReturnExclusiveAccess = 0xE00002C5
kIOReturnNoDevice = 0xE00002C0
kIOReturnNotResponding = 0xE00002ED
kIOReturnAborted = 0xE00002EB
kIOUSBPipeStalled = 0xE000404F
kIOUSBTransactionTimeout = 0xE0004051
_ERR_NAMES = {
    kIOReturnExclusiveAccess: "device in use by another program",
    kIOReturnNoDevice: "device disconnected",
    kIOReturnNotResponding: "device not responding",
    kIOReturnAborted: "request aborted",
    kIOUSBPipeStalled: "request stalled by the device",
    kIOUSBTransactionTimeout: "request timed out",
}

kCFNumberSInt32Type = 3
kCFStringEncodingUTF8 = 0x08000100


class CFUUIDBytes(ctypes.Structure):
    _fields_ = [("b", ctypes.c_uint8 * 16)]


class IOUSBDevRequestTO(ctypes.Structure):
    _fields_ = [("bmRequestType", ctypes.c_uint8), ("bRequest", ctypes.c_uint8),
                ("wValue", ctypes.c_uint16), ("wIndex", ctypes.c_uint16),
                ("wLength", ctypes.c_uint16), ("pData", ctypes.c_void_p),
                ("wLenDone", ctypes.c_uint32), ("noDataTimeout", ctypes.c_uint32),
                ("completionTimeout", ctypes.c_uint32)]


_lib = {}


def _frameworks():
    if _lib:
        return _lib["iokit"], _lib["cf"]
    iokit = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/IOKit.framework/IOKit")
    cf = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
    vp, u32, i32 = ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int32
    iokit.IOServiceMatching.restype = vp
    iokit.IOServiceMatching.argtypes = [ctypes.c_char_p]
    iokit.IOServiceGetMatchingServices.restype = i32
    iokit.IOServiceGetMatchingServices.argtypes = [u32, vp, ctypes.POINTER(u32)]
    iokit.IOIteratorNext.restype = u32
    iokit.IOIteratorNext.argtypes = [u32]
    iokit.IOObjectRelease.restype = i32
    iokit.IOObjectRelease.argtypes = [u32]
    iokit.IORegistryEntryCreateCFProperty.restype = vp
    iokit.IORegistryEntryCreateCFProperty.argtypes = [u32, vp, vp, u32]
    iokit.IOCreatePlugInInterfaceForService.restype = i32
    iokit.IOCreatePlugInInterfaceForService.argtypes = [u32, vp, vp, ctypes.POINTER(vp),
                                                        ctypes.POINTER(i32)]
    cf.CFStringCreateWithCString.restype = vp
    cf.CFStringCreateWithCString.argtypes = [vp, ctypes.c_char_p, u32]
    cf.CFNumberGetValue.restype = ctypes.c_bool
    cf.CFNumberGetValue.argtypes = [vp, ctypes.c_int, vp]
    cf.CFRelease.restype = None
    cf.CFRelease.argtypes = [vp]
    cf.CFUUIDGetConstantUUIDWithBytes.restype = vp
    cf.CFUUIDGetConstantUUIDWithBytes.argtypes = [vp] + [ctypes.c_uint8] * 16
    _lib.update(iokit=iokit, cf=cf)
    return iokit, cf


def _err(code):
    code &= 0xFFFFFFFF
    return "%s (0x%08X)" % (_ERR_NAMES.get(code, "IOKit error"), code)


def _int_prop(service, key):
    iokit, cf = _frameworks()
    k = cf.CFStringCreateWithCString(None, key.encode(), kCFStringEncodingUTF8)
    try:
        ref = iokit.IORegistryEntryCreateCFProperty(service, k, None, 0)
    finally:
        cf.CFRelease(k)
    if not ref:
        return None
    try:
        v = ctypes.c_int32()
        return v.value if cf.CFNumberGetValue(ref, kCFNumberSInt32Type, ctypes.byref(v)) else None
    finally:
        cf.CFRelease(ref)


def _services():
    """io_service_t of every USB device on the system (caller releases)."""
    iokit, _cf = _frameworks()
    out = []
    for cls in (b"IOUSBHostDevice", b"IOUSBDevice"):
        it = ctypes.c_uint32()
        # IOServiceGetMatchingServices consumes the matching dictionary
        if iokit.IOServiceGetMatchingServices(0, iokit.IOServiceMatching(cls), ctypes.byref(it)) != 0:
            continue
        try:
            while True:
                s = iokit.IOIteratorNext(it.value)
                if not s:
                    break
                out.append(s)
        finally:
            iokit.IOObjectRelease(it.value)
        if out:
            break
    return out


def find(vid, pid):
    """[(locationID, ...)] summary of the matching devices present right now."""
    iokit, _cf = _frameworks()
    found = []
    for s in _services():
        try:
            if _int_prop(s, "idVendor") == vid and _int_prop(s, "idProduct") == pid:
                found.append(_int_prop(s, "locationID"))
        finally:
            iokit.IOObjectRelease(s)
    return found


def wait_for(vid, pid, timeout_s=10.0, sleep=time.sleep):
    deadline = time.monotonic() + timeout_s
    while True:
        if find(vid, pid):
            return True
        if time.monotonic() > deadline:
            return False
        sleep(0.25)


class _Com(object):
    """Calls into a COM-style IOKit interface pointer (this -> vtable -> function pointers)."""

    def __init__(self, ptr):
        self.ptr = ctypes.c_void_p(ptr)

    def fn(self, slot, restype, *argtypes):
        vtbl = ctypes.cast(self.ptr, ctypes.POINTER(ctypes.c_void_p))[0]
        addr = ctypes.cast(vtbl, ctypes.POINTER(ctypes.c_void_p))[slot]
        return ctypes.CFUNCTYPE(restype, ctypes.c_void_p, *argtypes)(addr)


class Device(object):
    """One opened USB device; dfuse.py's transport."""

    def __init__(self, vid, pid):
        iokit, cf = _frameworks()
        self.dev = None
        self.opened = False
        service = None
        for s in _services():
            if service is None and _int_prop(s, "idVendor") == vid and _int_prop(s, "idProduct") == pid:
                service = s
            else:
                iokit.IOObjectRelease(s)
        if service is None:
            raise UsbError("USB device %04x:%04x not found" % (vid, pid), kIOReturnNoDevice)
        try:
            plugin = ctypes.c_void_p()
            score = ctypes.c_int32()
            rc = iokit.IOCreatePlugInInterfaceForService(
                service, cf.CFUUIDGetConstantUUIDWithBytes(None, *UUID_USB_DEVICE_USER_CLIENT_TYPE),
                cf.CFUUIDGetConstantUUIDWithBytes(None, *UUID_CF_PLUGIN_INTERFACE),
                ctypes.byref(plugin), ctypes.byref(score))
            if rc != 0 or not plugin.value:
                raise UsbError("cannot open USB device %04x:%04x: %s (in the App Store build this "
                               "needs the USB entitlement)" % (vid, pid, _err(rc)), rc & 0xFFFFFFFF)
        finally:
            iokit.IOObjectRelease(service)
        pcom = _Com(plugin.value)
        try:
            dev = ctypes.c_void_p()
            iid = CFUUIDBytes()
            iid.b[:] = list(UUID_USB_DEVICE_INTERFACE_320)
            hr = pcom.fn(SLOT_QUERY_INTERFACE, ctypes.c_int32, CFUUIDBytes,
                         ctypes.POINTER(ctypes.c_void_p))(pcom.ptr, iid, ctypes.byref(dev))
        finally:
            pcom.fn(SLOT_RELEASE, ctypes.c_uint32)(pcom.ptr)
        if hr != 0 or not dev.value:
            raise UsbError("USB device interface unavailable (0x%08X)" % (hr & 0xFFFFFFFF), hr)
        self.dev = _Com(dev.value)
        rc = self.dev.fn(SLOT_USB_DEVICE_OPEN, ctypes.c_int32)(self.dev.ptr)
        if (rc & 0xFFFFFFFF) == kIOReturnExclusiveAccess:
            rc = self.dev.fn(SLOT_USB_DEVICE_OPEN_SEIZE, ctypes.c_int32)(self.dev.ptr)
        self.opened = rc == 0
        self.open_error = None if self.opened else _err(rc)

    # --------------------------------------------------------------- dfuse.py transport API
    def control(self, bmRequestType, bRequest, wValue, wIndex, data_or_length, timeout_ms):
        if self.dev is None:
            raise UsbError("device closed", kIOReturnNoDevice)
        is_in = bool(bmRequestType & 0x80)
        if is_in:
            n = int(data_or_length)
            buf = (ctypes.c_uint8 * max(n, 1))()
        else:
            data = bytes(data_or_length or b"")
            n = len(data)
            buf = (ctypes.c_uint8 * max(n, 1)).from_buffer_copy(data or b"\0")
        req = IOUSBDevRequestTO(bmRequestType, bRequest, wValue & 0xFFFF, wIndex & 0xFFFF, n,
                                ctypes.cast(buf, ctypes.c_void_p) if n else None, 0,
                                int(timeout_ms), int(timeout_ms))
        rc = self.dev.fn(SLOT_DEVICE_REQUEST_TO, ctypes.c_int32,
                         ctypes.POINTER(IOUSBDevRequestTO))(self.dev.ptr, ctypes.byref(req))
        if rc != 0:
            code = rc & 0xFFFFFFFF
            if code == kIOUSBTransactionTimeout:
                try:
                    self.dev.fn(SLOT_ABORT_PIPE_ZERO, ctypes.c_int32)(self.dev.ptr)
                except Exception:
                    pass
            raise UsbError(_err(rc), code)
        if is_in:
            return bytes(buf[:req.wLenDone])
        return req.wLenDone

    def ensure_configured(self, value):
        cur = ctypes.c_uint8()
        rc = self.dev.fn(SLOT_GET_CONFIGURATION, ctypes.c_int32,
                         ctypes.POINTER(ctypes.c_uint8))(self.dev.ptr, ctypes.byref(cur))
        if rc == 0 and cur.value == value:
            return
        if not self.opened:
            raise UsbError("cannot configure the USB device: it could not be opened (%s)"
                           % self.open_error)
        rc = self.dev.fn(SLOT_SET_CONFIGURATION, ctypes.c_int32, ctypes.c_uint8)(self.dev.ptr, value)
        if rc != 0:
            raise UsbError("SetConfiguration(%d) failed: %s" % (value, _err(rc)), rc & 0xFFFFFFFF)

    def close(self):
        if self.dev is None:
            return
        try:
            if self.opened:
                self.dev.fn(SLOT_USB_DEVICE_CLOSE, ctypes.c_int32)(self.dev.ptr)
        finally:
            self.dev.fn(SLOT_RELEASE, ctypes.c_uint32)(self.dev.ptr)
            self.dev = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def available():
    """True when IOKit can be loaded (any Mac). Says nothing about a device being present."""
    try:
        _frameworks()
        return True
    except OSError:
        return False
