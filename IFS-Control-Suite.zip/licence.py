# -*- coding: utf-8 -*-
"""IFS Suite Pro licensing.

A licence is a small JSON file signed with a key only Augeas holds. The application carries the
matching PUBLIC key, so it can check a licence with no network at all. That matters: the labs this
is sold into run locked-down and sometimes air-gapped machines, which is the same reason the
offline installer exists. Nothing here phones home.

Ed25519 is implemented here in plain Python against RFC 8032 because the embeddable runtime ships
no crypto library, and adding one would mean a binary wheel in a bundle that has to keep working on
a machine with no internet. Verification takes a few milliseconds and happens once at start-up.

THE ONE RULE: a licence that is missing, expired or refused must never stop an instrument running.
It locks the Pro features and nothing else. A lab whose plasma station went dark over a late
renewal would be right never to buy from us again.
"""

import base64
import hashlib
import json
import os
import time

# ----------------------------------------------------------------- Ed25519 (RFC 8032), verify-only
# The signing half lives in scripts/issue-licence.py, with the private key, off every machine that
# runs the application.

_B_BITS = 256
_Q = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493


def _sha512(m):
    return hashlib.sha512(m).digest()


def _inv(x):
    return pow(x, _Q - 2, _Q)


_D = -121665 * _inv(121666) % _Q
_I = pow(2, (_Q - 1) // 4, _Q)


def _xrecover(y):
    xx = (y * y - 1) * _inv(_D * y * y + 1)
    x = pow(xx, (_Q + 3) // 8, _Q)
    if (x * x - xx) % _Q != 0:
        x = (x * _I) % _Q
    if x % 2 != 0:
        x = _Q - x
    return x


_BY = 4 * _inv(5) % _Q
_BX = _xrecover(_BY)
_BASE = (_BX % _Q, _BY % _Q, 1, (_BX * _BY) % _Q)


def _add(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = (y1 - x1) * (y2 - x2) % _Q
    b = (y1 + x1) * (y2 + x2) % _Q
    c = t1 * 2 * _D * t2 % _Q
    d = z1 * 2 * z2 % _Q
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _Q, g * h % _Q, f * g % _Q, e * h % _Q)


def _double(p):
    x1, y1, z1, _t = p
    a = x1 * x1 % _Q
    b = y1 * y1 % _Q
    c = 2 * z1 * z1 % _Q
    h = a + b
    e = h - (x1 + y1) * (x1 + y1) % _Q
    g = a - b
    f = c + g
    return (e * f % _Q, g * h % _Q, f * g % _Q, e * h % _Q)


def _scalarmult(p, e):
    """Double-and-add, iterative: a recursive version would be 256 frames deep on every check."""
    q = (0, 1, 1, 0)
    while e > 0:
        if e & 1:
            q = _add(q, p)
        p = _double(p)
        e >>= 1
    return q


def _on_curve(p):
    x, y, z, t = p
    return (-x * x + y * y - z * z - _D * t * t) % _Q == 0 and (x * y) % _Q == (z * t) % _Q


def _decodepoint(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    if y >= _Q:
        raise ValueError("y out of range")
    x = _xrecover(y)
    if (x & 1) != ((s[31] >> 7) & 1):
        x = _Q - x
    p = (x, y, 1, x * y % _Q)
    if not _on_curve(p):
        raise ValueError("point is not on the curve")
    return p


def _equal(p, q):
    x1, y1, z1, _a = p
    x2, y2, z2, _b = q
    return (x1 * z2 - x2 * z1) % _Q == 0 and (y1 * z2 - y2 * z1) % _Q == 0


def ed25519_verify(public_key, message, signature):
    """True only for a signature this public key really made over this exact message."""
    if len(signature) != 64 or len(public_key) != 32:
        return False
    try:
        r = _decodepoint(signature[:32])
        a = _decodepoint(public_key)
    except Exception:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _L:                       # a malleable S is a forged signature
        return False
    h = int.from_bytes(_sha512(signature[:32] + public_key + message), "little") % _L
    return _equal(_scalarmult(_BASE, s), _add(r, _scalarmult(a, h)))


# ----------------------------------------------------------------- the licence itself

# The public half of the Augeas licensing key. The private half never leaves the vault and is never
# in this repository. Replacing this constant invalidates every licence ever issued, so it changes
# only when the signing key is deliberately rotated.
LICENCE_PUBKEY_HEX = "30a0ee2cec58637b9d8c620a1450a24ba67e2ea2cda65022d9c50c3bf30ba318"

TIERS = ("fleet", "integration", "records")

# What each tier unlocks. Nothing that runs an instrument appears anywhere in this table, and
# nothing ever should.
FEATURES = {
    "fleet":       ("fleet_dashboard", "staged_rollout", "usage_totals", "service_reminders"),
    "integration": ("external_api", "lims_events", "insight_ai"),
    "records":     ("audit_trail", "e_signatures", "roles"),
}


def _canonical(obj):
    """The exact bytes that get signed. Sorted keys and no incidental whitespace, so the issuer and
    the verifier can never disagree about what was signed."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _today():
    return time.strftime("%Y-%m-%d")


def read_licence(path, host_id, pubkey_hex=None, now=None):
    """Read and check a licence file. Returns a dict describing what is unlocked and why.

    Never raises, and never returns something that stops the instrument: the worst answer is
    "nothing Pro is unlocked".
    """
    out = {"ok": False, "tiers": [], "features": [], "state": "none", "reason": "",
           "issued_to": "", "expires": "", "id": "", "seats": 0, "host_id": host_id}

    key_hex = pubkey_hex if pubkey_hex is not None else LICENCE_PUBKEY_HEX
    if not key_hex:
        out["state"] = "unlicensed"
        out["reason"] = "This build carries no licensing key."
        return out
    if not path or not os.path.isfile(path):
        out["state"] = "none"
        out["reason"] = "No licence is installed."
        return out

    # A licence is {"licence": {...}, "sig": "..."}. Anything else - a key pasted into the wrong
    # box, a truncated copy, a file that is not ours - is refused in words an operator can act on,
    # rather than with whatever the JSON parser happened to say.
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            doc = json.load(f)
    except Exception:
        out["state"] = "malformed"
        out["reason"] = "That is not a licence file."
        return out
    if not isinstance(doc, dict) or not isinstance(doc.get("licence"), dict)             or not isinstance(doc.get("sig"), str):
        out["state"] = "malformed"
        out["reason"] = "That is not a licence file."
        return out
    body = doc["licence"]
    try:
        sig = base64.b64decode(doc["sig"], validate=True)
    except Exception:
        out["state"] = "malformed"
        out["reason"] = "That licence file is damaged."
        return out

    if not ed25519_verify(bytes.fromhex(key_hex), _canonical(body), sig):
        out["state"] = "invalid"
        out["reason"] = "This licence was not issued by Augeas Technologies."
        return out

    out["issued_to"] = str(body.get("issued_to", ""))
    out["id"] = str(body.get("id", ""))
    out["expires"] = str(body.get("expires", ""))
    out["seats"] = int(body.get("seats") or 0)

    hosts = [str(h).lower() for h in (body.get("hosts") or [])]
    if hosts and str(host_id).lower() not in hosts:
        out["state"] = "wrong_host"
        out["reason"] = ("This licence is for another station. It names %d station%s and this one "
                         "is %s." % (len(hosts), "" if len(hosts) == 1 else "s", host_id))
        return out

    today = now or _today()
    starts = str(body.get("starts") or "")
    if starts and today < starts:
        out["state"] = "not_yet"
        out["reason"] = "This licence starts on %s." % starts
        return out
    if out["expires"] and today > out["expires"]:
        out["state"] = "expired"
        out["reason"] = ("This licence ended on %s. Pro features are locked. The instrument is "
                         "unaffected and keeps running." % out["expires"])
        return out

    tiers = [t for t in (body.get("tiers") or []) if t in TIERS]
    feats = []
    for t in tiers:
        feats.extend(FEATURES.get(t, ()))

    out.update({"ok": bool(tiers), "tiers": tiers, "features": sorted(set(feats)),
                "state": "active" if tiers else "empty"})
    if not tiers:
        out["reason"] = "This licence grants nothing. Ask Augeas to reissue it."
    return out


def days_left(lic, now=None):
    """Days until expiry, or None when it does not expire. Negative once it has."""
    if not lic.get("expires"):
        return None
    try:
        end = time.mktime(time.strptime(lic["expires"], "%Y-%m-%d"))
        ref = time.mktime(time.strptime(now or _today(), "%Y-%m-%d"))
        return int(round((end - ref) / 86400.0))
    except Exception:
        return None
