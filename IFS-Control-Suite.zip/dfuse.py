"""USB DFU 1.1 / ST DfuSe firmware writer for the Arduino Opta bootloader (2341:0364).

Written for the IFS Control Suite from the public specifications only:
  * USB Device Firmware Upgrade Specification, Revision 1.1 (USB-IF)
  * ST AN3156 "USB DFU protocol used in the STM32 bootloader" (the DfuSe extensions)
It is used by the Mac App Store build, which does not carry dfu-util. The Windows build and the
direct-download Mac build keep using dfu-util; nothing here changes them.

What it does, in order (DfuSe):
  1. reads the configuration descriptor -> the DFU interface for the requested alternate setting,
     its DFU functional descriptor (wTransferSize) and its interface string, which in DfuSe is the
     memory layout, e.g. "@Internal Flash  /0x08000000/01*128Ka,15*128Kg";
  2. works out the flash sectors covering [base, base + len(bin)) and refuses anything that
     would erase or write below MIN_WRITE_ADDR (the Opta bootloader lives there) - a hard guard
     enforced again at the lowest level, on every address that goes to the device;
  3. page-erases exactly those sectors (DNLOAD block 0, command 0x41 + address);
  4. writes the image wTransferSize at a time (Set Address Pointer 0x21, then DNLOAD block 2);
  5. reads the written range back (UPLOAD) and compares it byte for byte;
  6. only if the read-back matches, leaves DFU mode (Set Address Pointer to base, zero-length
     DNLOAD -> manifestation) so the Opta boots the new application. On a mismatch it stays in
     the bootloader, which is untouched and still able to take a retry.
Every DNLOAD is followed by GETSTATUS polling that honours bwPollTimeout and gives up after a
deadline; an error state is reported by name and cleared with CLRSTATUS.

The USB transport is anything with
    control(bmRequestType, bRequest, wValue, wIndex, data_or_length, timeout_ms)
returning the bytes read (IN) or the count written (OUT), raising UsbError on failure, plus
ensure_configured(config_value) and close(). macusb.py provides one over IOKit; the unit tests
(tests/test_dfuse.py) provide a simulated DfuSe device.
"""
import re
import struct
import time

# ---------------------------------------------------------------- constants (DFU 1.1 / AN3156)
DFU_DETACH, DFU_DNLOAD, DFU_UPLOAD, DFU_GETSTATUS, DFU_CLRSTATUS, DFU_GETSTATE, DFU_ABORT = range(7)
REQ_OUT = 0x21     # host-to-device | class | interface
REQ_IN = 0xA1      # device-to-host | class | interface

STATE_NAMES = {
    0: "appIDLE", 1: "appDETACH", 2: "dfuIDLE", 3: "dfuDNLOAD-SYNC", 4: "dfuDNBUSY",
    5: "dfuDNLOAD-IDLE", 6: "dfuMANIFEST-SYNC", 7: "dfuMANIFEST", 8: "dfuMANIFEST-WAIT-RESET",
    9: "dfuUPLOAD-IDLE", 10: "dfuERROR",
}
(ST_APP_IDLE, ST_APP_DETACH, ST_IDLE, ST_DNLOAD_SYNC, ST_DNBUSY, ST_DNLOAD_IDLE,
 ST_MANIFEST_SYNC, ST_MANIFEST, ST_MANIFEST_WAIT_RESET, ST_UPLOAD_IDLE, ST_ERROR) = range(11)

STATUS_NAMES = {
    0x00: "OK", 0x01: "errTARGET", 0x02: "errFILE", 0x03: "errWRITE", 0x04: "errERASE",
    0x05: "errCHECK_ERASED", 0x06: "errPROG", 0x07: "errVERIFY", 0x08: "errADDRESS",
    0x09: "errNOTDONE", 0x0A: "errFIRMWARE", 0x0B: "errVENDOR", 0x0C: "errUSBR",
    0x0D: "errPOR", 0x0E: "errUNKNOWN", 0x0F: "errSTALLEDPKT",
}

CMD_SET_ADDRESS = 0x21
CMD_ERASE = 0x41

# The Opta (mbed_opta core) application starts here; everything below is the Arduino bootloader.
# Nothing in this module will ever erase, write or point the device at an address below this.
MIN_WRITE_ADDR = 0x08040000

# STM32H7 internal flash programs 256-bit flash words; the last block is padded with the erased
# value (0xFF) to this multiple so the bootloader never sees a partial flash word. Verify only
# compares the image's own bytes.
FLASH_WORD = 32

CTRL_TIMEOUT_MS = 5000
POLL_DEADLINE_S = 30.0      # one erase / write must finish in this long
MAX_IMAGE = 2 * 1024 * 1024  # STM32H747: 2 MB of internal flash in total


class UsbError(Exception):
    """A control transfer failed (stall, timeout, device gone). Raised by transports."""
    def __init__(self, msg, code=None):
        Exception.__init__(self, msg)
        self.code = code


class DfuError(Exception):
    """The DFU/DfuSe exchange failed. The message is meant for the operator."""


class GuardError(DfuError):
    """A request would have touched the bootloader region or memory the layout does not allow."""


# ---------------------------------------------------------------- memory layout (DfuSe string)
class Sector(object):
    __slots__ = ("start", "size", "flags")

    def __init__(self, start, size, flags):
        self.start, self.size, self.flags = start, size, flags

    @property
    def end(self):
        return self.start + self.size

    readable = property(lambda s: bool(s.flags & 1))
    erasable = property(lambda s: bool(s.flags & 2))
    writable = property(lambda s: bool(s.flags & 4))

    def __repr__(self):
        return "Sector(0x%08X, %d, %s)" % (self.start, self.size, "".join(
            c for c, b in (("r", 1), ("e", 2), ("w", 4)) if self.flags & b))


class Segment(object):
    def __init__(self, name, start, sectors):
        self.name, self.start, self.sectors = name, start, sectors

    @property
    def end(self):
        return self.sectors[-1].end if self.sectors else self.start


_UNITS = {"": 1, " ": 1, "B": 1, "K": 1024, "M": 1024 * 1024}


def parse_layout(s):
    """Parse a DfuSe memory-layout string into [Segment].

    Format (AN3156): "@<name>/0x<addr>/<n>*<size><unit><type>[,<n>*<size><unit><type>]...
    [/0x<addr>/...]" where unit is ' ', 'B', 'K' or 'M' and type is a letter 'a'..'g' whose low
    3 bits are readable(1) | erasable(2) | writable(4). Raises DfuError if it is not one."""
    if not s or not s.startswith("@"):
        raise DfuError("the DFU interface has no DfuSe memory layout (got %r)" % (s,))
    parts = s[1:].split("/")
    if len(parts) < 3:
        raise DfuError("malformed DfuSe memory layout %r" % (s,))
    name = parts[0].strip()
    segs = []
    i = 1
    while i + 1 < len(parts):
        a = parts[i].strip()
        if not re.fullmatch(r"0[xX][0-9a-fA-F]{1,8}", a):
            raise DfuError("malformed address %r in DfuSe memory layout" % a)
        addr = int(a, 16)
        start = addr
        sectors = []
        for grp in parts[i + 1].split(","):
            grp = grp.strip()
            if not grp:
                continue
            m = re.fullmatch(r"(\d+)\*(\d+)\s*([BKM ]?)\s*([a-g])", grp)
            if not m:
                raise DfuError("malformed sector group %r in DfuSe memory layout" % grp)
            n, size, unit, typ = int(m.group(1)), int(m.group(2)), m.group(3), m.group(4)
            size *= _UNITS[unit]
            flags = (ord(typ) - ord("a") + 1) & 7
            if n <= 0 or size <= 0:
                raise DfuError("empty sector group %r in DfuSe memory layout" % grp)
            for _ in range(n):
                sectors.append(Sector(addr, size, flags))
                addr += size
        if not sectors:
            raise DfuError("segment at 0x%08X has no sectors" % start)
        segs.append(Segment(name, start, sectors))
        i += 2
    if not segs:
        raise DfuError("DfuSe memory layout %r lists no memory" % (s,))
    return segs


def plan_sectors(segments, base, length, min_addr=MIN_WRITE_ADDR):
    """The sectors that must be erased to write `length` bytes at `base`.

    Refuses (GuardError) when the range starts below min_addr, is empty or too large, falls
    outside one contiguous run of erasable + writable + readable sectors, or when any sector it
    needs starts below min_addr (erasing it would take part of the bootloader with it)."""
    if length <= 0:
        raise GuardError("the firmware image is empty")
    if length > MAX_IMAGE:
        raise GuardError("the firmware image is %d bytes - larger than the Opta's flash" % length)
    if base < min_addr:
        raise GuardError("refusing to write at 0x%08X: below 0x%08X is the Opta bootloader"
                         % (base, min_addr))
    end = base + length
    sectors = [s for g in segments for s in g.sectors]
    need = [s for s in sectors if s.start < end and s.end > base]
    if not need:
        raise GuardError("0x%08X..0x%08X is not in the device's memory layout" % (base, end - 1))
    need.sort(key=lambda s: s.start)
    if need[0].start > base or need[-1].end < end:
        raise GuardError("0x%08X..0x%08X runs outside the device's memory layout" % (base, end - 1))
    for a, b in zip(need, need[1:]):
        if a.end != b.start:
            raise GuardError("0x%08X..0x%08X spans a gap in the memory layout" % (base, end - 1))
    for s in need:
        if s.start < min_addr:
            raise GuardError("refusing: sector 0x%08X (%d KB) starts below 0x%08X - erasing it "
                             "would erase the bootloader" % (s.start, s.size // 1024, min_addr))
        if not (s.erasable and s.writable):
            raise GuardError("sector 0x%08X is not erasable+writable (%r)" % (s.start, s))
        if not s.readable:
            raise GuardError("sector 0x%08X cannot be read back to verify (%r)" % (s.start, s))
    return need


# ---------------------------------------------------------------- descriptors
def parse_config(desc):
    """Standard configuration descriptor -> dict with bConfigurationValue and the DFU interfaces:
    [{'number', 'alt', 'iInterface', 'protocol', 'transfer_size', 'bcd', 'attributes'}]."""
    if len(desc) < 9 or desc[1] != 2:
        raise DfuError("the device returned no configuration descriptor")
    out = {"value": desc[5], "dfu": []}
    i, cur = 0, None
    while i + 2 <= len(desc):
        ln, typ = desc[i], desc[i + 1]
        if ln < 2 or i + ln > len(desc):
            break
        d = desc[i:i + ln]
        if typ == 4 and ln >= 9:                      # INTERFACE
            cur = None
            if d[5] == 0xFE and d[6] == 0x01:         # application specific / DFU
                cur = {"number": d[2], "alt": d[3], "protocol": d[7], "iInterface": d[8],
                       "transfer_size": None, "bcd": None, "attributes": None}
                out["dfu"].append(cur)
        elif typ == 0x21 and ln >= 7:                 # DFU FUNCTIONAL
            attrs, _detach, xfer = struct.unpack_from("<BHH", d, 2)
            bcd = struct.unpack_from("<H", d, 7)[0] if ln >= 9 else None
            # one functional descriptor serves every alt setting of the interface
            for itf in out["dfu"]:
                if cur is None or itf["number"] == cur["number"]:
                    if itf["transfer_size"] is None:
                        itf.update(transfer_size=xfer, bcd=bcd, attributes=attrs)
        i += ln
    return out


# ---------------------------------------------------------------- the device
class DfuSe(object):
    def __init__(self, usb, alt=0, log=None, sleep=time.sleep, clock=time.monotonic,
                 min_addr=MIN_WRITE_ADDR):
        self.usb = usb
        self.log = log or (lambda m: None)
        self._sleep, self._clock = sleep, clock
        self.min_addr = min_addr
        head = bytes(usb.control(0x80, 6, 0x0200, 0, 9, CTRL_TIMEOUT_MS))
        if len(head) < 9:
            raise DfuError("short configuration descriptor from the device")
        total = struct.unpack_from("<H", head, 2)[0]
        cfg = parse_config(bytes(usb.control(0x80, 6, 0x0200, 0, total, CTRL_TIMEOUT_MS)))
        itfs = [d for d in cfg["dfu"] if d["alt"] == alt]
        if not itfs:
            raise DfuError("the device has no DFU interface with alternate setting %d" % alt)
        self.itf = itfs[0]
        if self.itf["transfer_size"] is None:
            raise DfuError("the DFU interface has no DFU functional descriptor")
        self.interface = self.itf["number"]
        self.xfer = self.itf["transfer_size"]
        if not 64 <= self.xfer <= 65535:
            raise DfuError("implausible DFU wTransferSize %d" % self.xfer)
        if alt != 0:
            raise DfuError("only alternate setting 0 is supported")
        usb.ensure_configured(cfg["value"])
        self.layout_string = self._string(self.itf["iInterface"])
        self.segments = parse_layout(self.layout_string)

    # ------------------------------------------------ standard requests
    def _string(self, index):
        if not index:
            return ""
        langs = bytes(self.usb.control(0x80, 6, 0x0300, 0, 255, CTRL_TIMEOUT_MS))
        lang = struct.unpack_from("<H", langs, 2)[0] if len(langs) >= 4 else 0x0409
        raw = bytes(self.usb.control(0x80, 6, 0x0300 | index, lang, 255, CTRL_TIMEOUT_MS))
        if len(raw) < 2 or raw[1] != 3:
            raise DfuError("bad string descriptor %d" % index)
        return raw[2:raw[0]].decode("utf-16-le", "replace")

    # ------------------------------------------------ DFU class requests
    def get_status(self):
        r = bytes(self.usb.control(REQ_IN, DFU_GETSTATUS, 0, self.interface, 6, CTRL_TIMEOUT_MS))
        if len(r) < 6:
            raise DfuError("short DFU_GETSTATUS reply (%d bytes)" % len(r))
        return r[0], r[1] | (r[2] << 8) | (r[3] << 16), r[4]

    def clear_status(self):
        self.usb.control(REQ_OUT, DFU_CLRSTATUS, 0, self.interface, b"", CTRL_TIMEOUT_MS)

    def abort(self):
        self.usb.control(REQ_OUT, DFU_ABORT, 0, self.interface, b"", CTRL_TIMEOUT_MS)

    def to_idle(self):
        """Bring the device to dfuIDLE from wherever a previous session left it."""
        for _ in range(4):
            status, _poll, state = self.get_status()
            if state == ST_IDLE and status == 0:
                return
            if state == ST_ERROR or status != 0:
                self.clear_status()
            elif state in (ST_DNLOAD_IDLE, ST_UPLOAD_IDLE, ST_DNLOAD_SYNC):
                self.abort()
            elif state in (ST_APP_IDLE, ST_APP_DETACH):
                raise DfuError("the device is in %s - it is running its application, not the "
                               "bootloader" % STATE_NAMES[state])
            else:
                self._sleep(0.1)
        status, _poll, state = self.get_status()
        if state != ST_IDLE:
            raise DfuError("the device will not go idle (state %s, status %s)"
                           % (STATE_NAMES.get(state, state), STATUS_NAMES.get(status, status)))

    def _wait(self, what):
        """GETSTATUS until the download finished. Honours bwPollTimeout; bounded by a deadline."""
        deadline = self._clock() + POLL_DEADLINE_S
        for _ in range(100000):                        # also bounded if the clock misbehaves
            status, poll_ms, state = self.get_status()
            if status != 0 or state == ST_ERROR:
                try:
                    self.clear_status()
                except UsbError:
                    pass
                raise DfuError("%s failed: device reported %s (state %s)" % (
                    what, STATUS_NAMES.get(status, "0x%02X" % status), STATE_NAMES.get(state, state)))
            if state not in (ST_DNBUSY, ST_DNLOAD_SYNC):
                return state
            if self._clock() > deadline:
                raise DfuError("%s timed out: device still busy after %.0f s" % (what, POLL_DEADLINE_S))
            self._sleep(max(poll_ms, 1) / 1000.0)
        raise DfuError("%s timed out: device never left dfuDNBUSY" % what)

    def _dnload(self, block, data, what):
        try:
            self.usb.control(REQ_OUT, DFU_DNLOAD, block, self.interface, data, CTRL_TIMEOUT_MS)
        except UsbError as e:
            reason = ""
            try:
                status, _p, state = self.get_status()
                reason = " (device: %s, %s)" % (STATUS_NAMES.get(status, status), STATE_NAMES.get(state, state))
                if status != 0 or state == ST_ERROR:
                    self.clear_status()
            except (UsbError, DfuError):
                pass
            raise DfuError("%s was refused: %s%s" % (what, e, reason))
        return self._wait(what)

    def _command(self, cmd, addr):
        """A DfuSe command (block 0). The bootloader guard lives here: every address that reaches
        the device passes through this check, whatever the caller computed."""
        if cmd not in (CMD_SET_ADDRESS, CMD_ERASE):
            raise GuardError("DfuSe command 0x%02X is not allowed" % cmd)
        if not isinstance(addr, int) or addr < self.min_addr or addr > 0xFFFFFFFF:
            raise GuardError("refusing DfuSe command 0x%02X at %r: below 0x%08X is the Opta "
                             "bootloader" % (cmd, addr if not isinstance(addr, int) else "0x%08X" % addr,
                                             self.min_addr))
        name = "set address 0x%08X" % addr if cmd == CMD_SET_ADDRESS else "erase sector 0x%08X" % addr
        state = self._dnload(0, struct.pack("<BI", cmd, addr), name)
        if state != ST_DNLOAD_IDLE:
            raise DfuError("%s: unexpected state %s" % (name, STATE_NAMES.get(state, state)))

    def set_address(self, addr):
        self._command(CMD_SET_ADDRESS, addr)

    def erase(self, addr):
        self._command(CMD_ERASE, addr)

    def write_block(self, addr, data):
        if addr < self.min_addr:
            raise GuardError("refusing to write at 0x%08X (bootloader)" % addr)
        if not 0 < len(data) <= self.xfer:
            raise DfuError("block of %d bytes does not fit wTransferSize %d" % (len(data), self.xfer))
        self.set_address(addr)
        state = self._dnload(2, bytes(data), "write 0x%08X" % addr)
        if state != ST_DNLOAD_IDLE:
            raise DfuError("write 0x%08X: unexpected state %s" % (addr, STATE_NAMES.get(state, state)))

    def read(self, addr, length):
        """Read `length` bytes at `addr` (DfuSe UPLOAD from block 2 on)."""
        self.set_address(addr)
        self.abort()                                   # dfuDNLOAD-IDLE -> dfuIDLE
        out = bytearray()
        block = 2
        while len(out) < length:
            n = min(self.xfer, length - len(out))
            try:
                chunk = bytes(self.usb.control(REQ_IN, DFU_UPLOAD, block, self.interface, n,
                                               CTRL_TIMEOUT_MS))
            except UsbError as e:
                raise DfuError("read-back at 0x%08X failed: %s" % (addr + len(out), e))
            if not chunk:
                raise DfuError("read-back at 0x%08X returned nothing" % (addr + len(out)))
            out += chunk[:n]
            block += 1
            if block > 0xFFFF:
                raise DfuError("read-back too long for one upload")
        self.abort()
        return bytes(out)

    def leave(self, addr):
        """Leave DFU mode and start the application at addr: Set Address Pointer, then a
        zero-length DNLOAD (manifestation). The device resets, so a vanishing device here is the
        expected outcome, not an error."""
        self.set_address(addr)
        try:
            self.usb.control(REQ_OUT, DFU_DNLOAD, 0, self.interface, b"", CTRL_TIMEOUT_MS)
            self.get_status()                          # triggers manifestation on DfuSe
        except (UsbError, DfuError):
            pass

    # ------------------------------------------------ the whole job
    def flash(self, image, base, verify=True, leave=True):
        """Generator: erase, write, verify and (on success) leave. Yields operator messages,
        raises DfuError/GuardError. Nothing is erased until every guard has passed."""
        image = bytes(image)
        sectors = plan_sectors(self.segments, base, len(image), self.min_addr)
        yield ("DFU device: %s, interface %d, transfer size %d, DFU %s"
               % (self.segments[0].name or "memory", self.interface, self.xfer,
                  ("%x.%02x" % (self.itf["bcd"] >> 8, self.itf["bcd"] & 0xFF)) if self.itf["bcd"] else "?"))
        yield ("Image %d bytes -> 0x%08X..0x%08X; erasing %d sector%s (0x%08X..0x%08X). "
               "Bootloader below 0x%08X is not touched."
               % (len(image), base, base + len(image) - 1, len(sectors), "" if len(sectors) == 1 else "s",
                  sectors[0].start, sectors[-1].end - 1, self.min_addr))
        self.to_idle()
        for i, s in enumerate(sectors):
            yield "Erasing sector %d/%d at 0x%08X (%d KB)..." % (i + 1, len(sectors), s.start, s.size // 1024)
            self.erase(s.start)
        padded = image
        if len(padded) % FLASH_WORD:
            padded += b"\xFF" * (FLASH_WORD - len(padded) % FLASH_WORD)
        total, done, shown = len(padded), 0, -1
        yield "Writing %d bytes..." % len(image)
        while done < total:
            n = min(self.xfer, total - done)
            self.write_block(base + done, padded[done:done + n])
            done += n
            pct = done * 100 // total
            if pct // 10 != shown // 10 or done == total:
                shown = pct
                yield "Writing... %d%%" % pct
        if verify:
            yield "Verifying (reading %d bytes back)..." % len(image)
            self.to_idle()
            back = self.read(base, len(image))
            if back != image:
                bad = next(i for i in range(len(image)) if i >= len(back) or back[i] != image[i])
                raise DfuError("VERIFY FAILED at 0x%08X: wrote 0x%02X, read back %s. The Opta is "
                               "left in its bootloader (untouched) - run the update again."
                               % (base + bad, image[bad], "0x%02X" % back[bad] if bad < len(back) else "nothing"))
            yield "Verify OK: all %d bytes read back match." % len(image)
        if leave:
            yield "Leaving DFU mode - starting the new firmware at 0x%08X..." % base
            self.to_idle()
            self.leave(base)
