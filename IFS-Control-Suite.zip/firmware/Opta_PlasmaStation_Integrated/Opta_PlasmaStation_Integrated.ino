/*
  =====================================================================
  Opta Plasma Station - Integrated Controller
  Base: Adithya's A6-RS controller (9/18/2025), extended with the
  4D-display (Waveshare/Ethernet) channel + full run sequence.
  Edited by Adithya Mallela - 2026-07-17 00:09: relay pin map fix
  (RELAY1=actuator, RELAY2=fan), 9600 everywhere, display-connect
  backoff + link gate, actuator crash-guard, display command tokens.
  =====================================================================

  THREE CHANNELS
    - Serial1  : RS485 Modbus RTU  -> StepperOnline A6-RS drive
    - Serial2  : RS232             -> Tip Charger (plasma PSU: TIME, plate-in, ready)
    - Ethernet : -> Waveshare -> RS232 -> 4D display (Form4 HMI)

  ADDED ON TOP OF THE BASE CODE
    - 4D display link over Ethernet (192.168.1.200:4196), robust reconnect.
    - Streams electrode temp (RTD A0 -> deg F) to Form4 as  T<degF>\n .
    - Form4 commands in:  S=start clean  X=abort  O/C=actuator open/close
      N/F=fan on/off  P1/P2/P3 setup via  Z1<val>! Z2<val>! Z3<val>! .
    - Positions persisted to flash (KVStore) so they survive power-off.
    - Plasma OWNED BY TIP CHARGER: Opta requests, waits for plate-inside,
      Tip Charger auto-stops on its timer; Opta runs the servo passes and
      exits when plasma clears.
    - Errors forwarded to the display; the display also shows "comms lost"
      on its own when the T-stream goes stale (handled in the 4DGL side).

  HARDWARE NOTE (unchanged): A6-RS CN1 inputs are 24V; Opta outputs drive
  interposing relays, never wire an MCU pin straight into CN1.
*/

#include <Arduino.h>
#include <math.h>
#include <Ethernet.h>
#include <opta_info.h>
#include <ArduinoRS485.h>
#include <ArduinoModbus.h>
#include "drivers/Watchdog.h"      // hardware watchdog: auto-reset on a firmware hang (reset = plasma OFF = fail-safe)
#include "FlashIAPBlockDevice.h"   // dedicated persistence store on internal flash (positions/serial/config)
#include "TDBStore.h"
#include "drivers/FlashIAP.h"

// ---------------- SERIAL PORT SELECTION ----------------
#define DEBUG_SERIAL Serial
#define SERVO_SERIAL Serial1   // RS485 transceiver -> A6-RS
#define TIP_SERIAL   Serial2   // RS232 -> Tip Charger

// ---------------- 4D DISPLAY (Ethernet via Waveshare) ----------------
// These are runtime-editable from the serial console / Ethernet API and
// persisted to flash (see loadConfig/saveConfig). Values here are defaults.
IPAddress OPTA_IP     (192, 168, 1, 100);
IPAddress WAVESHARE_IP(192, 168, 1, 200);
uint16_t  WAVESHARE_PORT = 4196;
uint16_t  API_PORT       = 8080;      // PC connects here to send API commands
const uint32_t DISPLAY_RECONNECT_MS = 15000;  // normal reconnect cadence once the link is healthy
const uint32_t DISPLAY_RETRY_MAX_MS = 300000; // after a FAILED (unreachable) connect the mbed connect()
                                              // blocks ~28s, so back off 5 min - otherwise it re-blocks
                                              // every cycle and starves the USB status stream (the app
                                              // then can't verify the Opta and "won't connect").
const uint32_t TC_SEND_INTERVAL_MS  = 1000;
// Half-open detection for the send-mostly display link: on a Waveshare slot that went
// half-open (peer gone, no FIN/RST - the "had to restart the module" symptom) the socket
// stays connected()==true but stops ACCEPTING bytes. RX-gap detection is unreliable here
// (telemetry goes to the 4D-UPA, not back to the Opta), so we watch the WRITE side instead:
// if this many streamTempOnly() intervals in a row are rejected (0 bytes accepted), we
// force-drop so serviceDisplayLink() gets a fresh slot in seconds instead of waiting minutes
// for the TCP stack to exhaust its retransmits.
const uint8_t  DISPLAY_WRITE_FAIL_LIMIT = 5;
uint8_t displayWriteFails = 0;        // consecutive intervals where the display socket accepted nothing

OptaBoardInfo *boardInfo();
OptaBoardInfo *optaInfo;
EthernetClient displayClient;         // client -> Waveshare -> 4D display
EthernetServer *apiServer = nullptr;  // server <- PC API commands (created in setup)
EthernetClient apiClient;             // the currently-connected API client
uint32_t lastDisplayReconnect = 0;
uint32_t displayReconnectMs   = DISPLAY_RECONNECT_MS;  // grows to DISPLAY_RETRY_MAX_MS after a failed connect
uint32_t lastTcSend = 0;

// ---------------- SERVO over a SECOND Waveshare (RS485-to-ETH) ----------------
// The A6 servo runs on the Opta's NATIVE RS485 (Serial1, default) OR is tunneled as
// Modbus-RTU-over-TCP through its OWN Waveshare RS485-to-ETH bridge. SEPARATE socket
// (servoClient) + SEPARATE IP from the display's RS232-to-ETH (.200), so the two Waveshare
// streams NEVER cross. Runtime-editable (setservoip / setservoport / servoeth on|off), persisted.
IPAddress SERVO_ETH_IP  (192, 168, 1, 201);   // default; change with 'setservoip'
uint16_t  SERVO_ETH_PORT = 4196;
bool      servoOverEth   = false;             // false = native RS485 (Serial1); true = RTU-over-TCP
EthernetClient servoClient;                   // client -> Waveshare RS485-to-ETH -> A6 servo
uint32_t servoEthNextTry = 0;
const uint32_t SERVO_ETH_TIMEOUT_MS = 300;
// When the servo runs over Ethernet, it CANNOT be probed/configured in setup(): the Modbus path needs
// the Ethernet stack up AND the bridge socket connected, and both happen later (Ethernet.begin() runs
// after the servo block, and serviceServoLink() only runs from loop()). Probing there always failed and
// dropped straight into faultOut("DRIVE_CONFIGURATION_FAILED"), bricking boot the first time anyone set
// 'servoeth on'. Instead defer: flag it here, and configure once the bridge link is actually up.
bool servoBootConfigPending = false;
// HALF-OPEN WATCHDOG for the servo bridge, mirroring what the display link already does. A Waveshare
// slot can go half-open (peer gone, no FIN) and EthernetClient::connected() still reports true, so
// every RTU transaction would quietly time out forever and the drive would look dead while we never
// reconnected. Consecutive transaction failures drop the socket so serviceServoLink() gets a fresh
// slot - the same self-heal that fixed the display's "had to restart the module" symptom.
uint8_t servoTxnFails = 0;
const uint8_t SERVO_TXN_FAIL_LIMIT = 5;

// USB serial console line buffer
String consoleRx;

// ---------------- PIN MAP ----------------
const int PIN_RS485_DE_RE      = 2;
const int PIN_SERVO_SON        = 3;
const int PIN_SERVO_FAULT_RST  = 4;
const int PIN_SERVO_STEP_TRIG  = 5;
// Opta onboard relays are RELAY1..RELAY4 = D0..D3 (pins 0..3) - electromechanical, they click.
const int PIN_ACTUATOR_DOWN    = 0;   // RELAY1 (Opta D0) - actuator auxiliary relay
const int PIN_LED_ACT          = 7;   // LED_D0 - lights when RELAY1 (actuator) is engaged, so the operator SEES the relay fire
const int PIN_PLASMA_ON        = 153; // LED_D3 - plasma-request indicator ONLY. Moved OFF LED_D0 (which sits next to RELAY1
                                      //   and looked like "RELAY1 turned on"). Plasma is fired by "PLASMA_GO" to the Tip Charger, not a relay.
const int PIN_FAN_ON           = 1;   // RELAY2 (Opta D1) - fan/exhaust auxiliary relay
const int PIN_LED_FAN          = 9;   // LED_D1 = LED_RELAY2 - the Opta's status LED that MATCHES RELAY2. Was LED_D2 (=LED_RELAY3) only because the old home-switch squatted on pin 9; that pin is now free (home moved to A3), so the fan LED finally lines up with its own relay instead of lighting the "3" LED.
// Digital switch/feedback inputs MUST land on the Opta's real external input terminals
// I1..I8 = A0..A7 (core pins 15..22). Pins 9-12 are INTERNAL-only (LED_D1 / SPI-MISO /
// I2C-SDA / I2C-SCL) with NO screw terminal, so digitalRead() there can never see the
// physical switch - the front-limit interlock and homing silently fail. A0-A2 are taken
// by RTD/LEM below; A6 is also the DAC pin, so skip it. Use A3/A4/A5/A7.
const int PIN_HOME_SWITCH      = A3;  // I4
const int PIN_FRONT_LIMIT      = A4;  // I5
const int PIN_ACTUATOR_UP_FB   = A5;  // I6
const int PIN_ACTUATOR_DN_FB   = A7;  // I8
const int PIN_RTD_ANALOG       = A0;
const int PIN_LEM_VOLTAGE      = A1;   // LEM voltage transducer output (0-10V into Opta)
const int PIN_LEM_CURRENT      = A2;   // LEM current transducer output (0-10V into Opta)

// ---------------- DRIVE COMM DEFAULTS ----------------
const uint8_t  SERVO_ID   = 1;
const uint32_t SERVO_BAUD = 9600;    // whole station standardized to 9600 8N1 - the A6 servo DRIVE must be set to 9600 too
const uint32_t TIP_BAUD   = 9600;

// ---------------- MACHINE VALUES (persisted; defaults below) ----------------
int32_t POS_HOME         = 0;
int32_t POS_BEFORE_DOOR  = 800;
int32_t POS_PLASMA_START = 2800;   // "row 1" - plasma head at first microplate row
int32_t POS_LAST_ROW     = 8800;   // last row

const float APP_UNITS_PER_REV = 1000.0f;

const uint16_t RPM_HOME_FAST   = 80;
const uint16_t RPM_HOME_SLOW   = 20;
const uint16_t RPM_TRAVEL      = 180;
const uint16_t RPM_RETURN_FAST = 300;
const uint16_t RPM_MIN_PASS    = 40;
const uint16_t RPM_MAX_PASS    = 400;
const int16_t  MAX_STEP_UNITS  = 9999;
const int32_t  POS_MAX_TRAVEL  = 20000;   // soft travel limit (pulses) for taught positions

// RTD scaling. The transmitter outputs 0-5V for 0-400C, but the Opta analog
// input is 0-10V full-scale at 12-bit, so raw 0..4095 maps to 0..10V.
const float RTD_INPUT_VMAX  = 10.0f;      // Opta analog terminal full-scale
const float RTD_VOLTS_MIN   = 0.0f;
const float RTD_VOLTS_MAX    = 5.0f;      // transmitter span
const float RTD_TEMP_MIN_C   = 0.0f;
const float RTD_TEMP_MAX_C   = 400.0f;
const int   TC_MIN_F = 50;
const int   TC_MAX_F = 250;
// ---- RTD SENSOR-FAULT DETECTION (electrode over-temp is FAIL-OPEN without this) ----
// The transmitter span is 0-5 V -> 0-400 C, so 0 V is a LEGAL reading meaning 0 C. A dead, unpowered
// or disconnected transmitter therefore reads "stone cold", readTempC() > PLASMA_MAX_TEMP_C stays
// false forever, and the electrode over-temp interlock silently disappears while plasma runs - the
// only remaining backstop being the time cap. (A live-zero 1-5 V / 4-20 mA transmitter would make an
// open circuit self-evident; 0-5 V cannot.) An electrode at ~0 C is physically impossible in an
// operating station - ambient alone is ~20 C - so a near-zero or pegged-high reading DURING plasma is
// treated as a SENSOR FAULT rather than as a temperature.
const float RTD_OPEN_V = 0.05f;   // at/below this = open circuit / dead or unpowered transmitter
const float RTD_SAT_V  = 4.95f;   // at/above this = short / over-range
// Default OFF on purpose: the bench RTD currently reads 0 V, so defaulting ON would fault every
// single plasma fire - exactly the trap the PA4 safety loop set. Enable with 'tempguard on' (state is
// persisted). This MUST be ON for a machine that ships; boot and 'status' both say so when it is off.
bool  tempGuard = false;

// LEM power sensing. Tap the Tip Charger's existing LEM feedback signals into the
// Opta analog inputs (share grounds):
//   A1 <- HV_Fbk  (LV 25-P voltage transducer):  0-250 V -> 0-2.5 V   => 100  V/input-V
//   A2 <- Li_Fbk  (LA 25-NP current transducer):  0-8 A  -> 0-2.5 V   => 3.2  A/input-V
// Engineering value = inputVolts * scale + offset. Scales/offsets are calibratable
// at runtime (setvscale/setvoffset/setiscale/setioffset) and persisted to flash
// ("plasma_lem"), so a buffer/gain stage or different wiring can be trimmed without
// recompiling. Defaults below are the exact schematic values (Universal Controller 4.1).
float LEM_V_SCALE  = 100.0f;   // volts per input-volt  (HV_Fbk: 250V @ 2.5V)
float LEM_V_OFFSET = 0.0f;     // volts
float LEM_I_SCALE  = 3.2f;     // amps per input-volt   (Li_Fbk: 8A @ 2.5V)
float LEM_I_OFFSET = 0.0f;     // amps

const float    PLASMA_MAX_TEMP_C   = 300.0f;  // hard over-temp abort (uses UNCLAMPED reading)
const float    PLASMA_MIN_TEMP_C   = 45.0f;
const uint32_t TEMP_RISE_TIMEOUT_MS= 5000;
const uint32_t ACTUATOR_TIMEOUT_MS = 6000;
const uint32_t MOTION_TIMEOUT_MS   = 20000;
const uint32_t PLATE_IN_TIMEOUT_MS = 30000;
const uint32_t PLASMA_DONE_TIMEOUT_MS = 120000;

// ---------------- PROCESS COMMANDS ----------------
String   tipRx;
uint32_t plasmaTotalTimeMs = 5000;
bool     abortRequested = false;
bool     plateInside = false;     // set by Tip Charger "PLATEIN!"
bool     plasmaDone  = false;     // set by Tip Charger "PDONE!" (timer elapsed)

// ---------------- SOFTWARE POSITION TRACKING ----------------
bool    currentPosKnown = false;
int32_t currentPosUnits = 0;

// ---------------- PROCESS STATE ----------------
enum ProcessState { ST_IDLE, ST_RUNNING, ST_FAULT };
ProcessState processState = ST_IDLE;
String lastFault = "";

// =====================================================================
// PERSISTENCE - dedicated flash key/value store (positions, serial, config)
// -----------------------------------------------------------------------
// We deliberately do NOT use mbed's global kv_set/kv_get. On the Arduino Opta
// core there is no global KVStore mounted, so every kv_set returned
// INVALID_ARGUMENT (0x80FF0101) and nothing survived a power cycle - that is
// exactly why the serial number, taught positions and network config kept
// resetting to defaults.
//
// Instead we own a small TDBStore on the internal flash. It lives in the last
// 256 KB of flash (two 128 KB sectors - TDBStore's minimum for its wear-leveled
// dual-area layout). On the Opta's STM32H747 that region sits in BANK 2, while
// the sketch executes from BANK 1, so erasing/programming the store never
// stalls instruction fetch (the H7 read-while-write same-bank rule). Keys are
// '/'-free because TDBStore rejects '/' inside a key.
// Every write is read back and verified; a failed store is reformatted once and
// retried, and its health is reported on the console - no silent data loss.
// Edited by Adithya Mallela - 2026-07-17: self-owned, bulletproof persistence.
// =====================================================================
static FlashIAPBlockDevice *kvBd    = nullptr;
static mbed::TDBStore      *kvStore = nullptr;
bool kvHealthy = false;   // true once the store is up (and after each verified write)

// Bring the store up once (lazy); format it if it has never been initialized.
static bool kvBegin() {
  if (kvStore) return kvHealthy;
  mbed::FlashIAP fi;
  if (fi.init() != 0) { DEBUG_SERIAL.println("KV: FlashIAP init failed"); return false; }
  uint32_t fstart = fi.get_flash_start();
  uint32_t fsize  = fi.get_flash_size();
  fi.deinit();
  const uint32_t RESERVE = 256u * 1024u;         // 2 x 128 KB sectors (TDBStore minimum)
  uint32_t addr = fstart + fsize - RESERVE;      // top of flash = BANK 2 on the 2 MB H7
  kvBd = new FlashIAPBlockDevice(addr, RESERVE);
  if (!kvBd || kvBd->init() != 0) { DEBUG_SERIAL.println("KV: block device init failed"); return false; }
  kvStore = new mbed::TDBStore(kvBd);
  int rc = kvStore->init();
  if (rc != MBED_SUCCESS) {                       // never formatted / corrupt -> format once
    DEBUG_SERIAL.print("KV: TDBStore init rc="); DEBUG_SERIAL.print(rc); DEBUG_SERIAL.println(" - formatting");
    kvStore->reset();
    rc = kvStore->init();
  }
  kvHealthy = (rc == MBED_SUCCESS);
  DEBUG_SERIAL.print("KV: store @0x"); DEBUG_SERIAL.print(addr, HEX);
  DEBUG_SERIAL.print(" ("); DEBUG_SERIAL.print(RESERVE / 1024); DEBUG_SERIAL.print("KB) - ");
  DEBUG_SERIAL.println(kvHealthy ? "ready." : "UNAVAILABLE.");
  return kvHealthy;
}

// Write + read-back verify; reformat-and-retry once on failure. Returns true
// only when the value is confirmed persisted on flash.
static bool kvSetVerified(const char *key, const void *buf, size_t len) {
  if (!kvBegin()) return false;
  for (int attempt = 0; attempt < 2; attempt++) {
    int rc = kvStore->set(key, buf, len, 0);
    if (rc == MBED_SUCCESS) {
      uint8_t chk[64]; size_t got = 0;
      if (len > sizeof(chk)) { kvHealthy = true; return true; }   // too big to verify inline - trust the set
      if (kvStore->get(key, chk, len, &got) == MBED_SUCCESS && got == len && memcmp(chk, buf, len) == 0) {
        kvHealthy = true; return true;
      }
      DEBUG_SERIAL.print("WARN: kv read-back mismatch for "); DEBUG_SERIAL.println(key);
    } else {
      DEBUG_SERIAL.print("WARN: kv set("); DEBUG_SERIAL.print(key);
      DEBUG_SERIAL.print(") rc="); DEBUG_SERIAL.println(rc);
    }
    // retry the SAME key only - do NOT reset()/reformat here: TDBStore::reset() erases
    // EVERY key (positions, LEM cal, net cfg), so a single transient hiccup while saving
    // one setting would wipe all the others. Format-on-corruption is handled once in kvBegin().
  }
  DEBUG_SERIAL.print("ERROR: flash write ("); DEBUG_SERIAL.print(key);
  DEBUG_SERIAL.println(") FAILED - persistence unavailable");
  kvHealthy = false;
  return false;
}

// Read a key (exact-length match required). Returns true on a clean hit.
static bool kvGetChecked(const char *key, void *buf, size_t len) {
  if (!kvBegin()) return false;
  size_t got = 0;
  return (kvStore->get(key, buf, len, &got) == MBED_SUCCESS && got == len);
}

// Boot self-test: brings the store up (formatting if needed) so the real
// settings below save cleanly, and reports health on the console.
void kvSelfTest() {
  if (kvBegin()) DEBUG_SERIAL.println("KVStore ready - persistence healthy.");
  else           DEBUG_SERIAL.println("KVStore UNHEALTHY - settings will NOT persist. Check flash.");
}

void savePositions() {
  int32_t buf[5] = { POS_HOME, POS_BEFORE_DOOR, POS_PLASMA_START, POS_LAST_ROW, (int32_t)plasmaTotalTimeMs };
  if (!kvSetVerified("plasma_pos", buf, sizeof(buf))) DEBUG_SERIAL.println("WARN: flash write (positions) FAILED");
}
void loadPositions() {
  int32_t buf[5];
  if (kvGetChecked("plasma_pos", buf, sizeof(buf))) {
    POS_HOME = buf[0]; POS_BEFORE_DOOR = buf[1];
    POS_PLASMA_START = buf[2]; POS_LAST_ROW = buf[3];
    if (buf[4] >= 500 && buf[4] <= 120000) plasmaTotalTimeMs = (uint32_t)buf[4];
    DEBUG_SERIAL.println("Positions + plasma time loaded from flash.");
  } else {
    DEBUG_SERIAL.println("No saved positions - using defaults.");
  }
}

// LEM calibration persistence: vScale vOffset iScale iOffset (4 floats)
void saveLem() {
  float buf[4] = { LEM_V_SCALE, LEM_V_OFFSET, LEM_I_SCALE, LEM_I_OFFSET };
  if (!kvSetVerified("plasma_lem", buf, sizeof(buf))) DEBUG_SERIAL.println("WARN: flash write (lem) FAILED");
}
void loadLem() {
  float buf[4];
  if (kvGetChecked("plasma_lem", buf, sizeof(buf))) {
    LEM_V_SCALE = buf[0]; LEM_V_OFFSET = buf[1]; LEM_I_SCALE = buf[2]; LEM_I_OFFSET = buf[3];
    DEBUG_SERIAL.println("LEM calibration loaded from flash.");
  } else {
    DEBUG_SERIAL.println("No saved LEM calibration - using defaults.");
  }
}

// Network config persistence: OptaIP(4) WaveIP(4) WavePort(2) ApiPort(2)
void saveConfig() {
  uint8_t buf[12];
  for (int i=0;i<4;i++) buf[i]   = OPTA_IP[i];
  for (int i=0;i<4;i++) buf[4+i] = WAVESHARE_IP[i];
  buf[8]  = WAVESHARE_PORT & 0xFF; buf[9]  = (WAVESHARE_PORT >> 8) & 0xFF;
  buf[10] = API_PORT & 0xFF;       buf[11] = (API_PORT >> 8) & 0xFF;
  if (!kvSetVerified("plasma_net", buf, sizeof(buf))) DEBUG_SERIAL.println("WARN: flash write (config) FAILED");
}
void loadConfig() {
  uint8_t buf[12];
  if (kvGetChecked("plasma_net", buf, sizeof(buf))) {
    OPTA_IP      = IPAddress(buf[0], buf[1], buf[2], buf[3]);
    WAVESHARE_IP = IPAddress(buf[4], buf[5], buf[6], buf[7]);
    WAVESHARE_PORT = buf[8]  | (buf[9]  << 8);
    API_PORT       = buf[10] | (buf[11] << 8);
    DEBUG_SERIAL.println("Network config loaded from flash.");
  } else {
    DEBUG_SERIAL.println("No saved network config - using defaults.");
  }
}

// Servo-over-Ethernet config in its OWN flash key (keeps loadConfig backward-compatible).
void saveServoNet() {
  uint8_t buf[8];
  for (int i=0;i<4;i++) buf[i] = SERVO_ETH_IP[i];
  buf[4] = SERVO_ETH_PORT & 0xFF; buf[5] = (SERVO_ETH_PORT >> 8) & 0xFF;
  buf[6] = servoOverEth ? 1 : 0;
  buf[7] = tempGuard ? 1 : 0;   // spare byte of this record reused for the RTD sensor-fault guard (avoids a second flash key); 0 = off, which is also what old records read back as
  if (!kvSetVerified("plasma_servonet", buf, sizeof(buf))) DEBUG_SERIAL.println("WARN: flash write (servonet) FAILED");
}
void loadServoNet() {
  uint8_t buf[8];
  if (kvGetChecked("plasma_servonet", buf, sizeof(buf))) {
    SERVO_ETH_IP   = IPAddress(buf[0], buf[1], buf[2], buf[3]);
    SERVO_ETH_PORT = buf[4] | (buf[5] << 8);
    servoOverEth   = buf[6] != 0;
    tempGuard      = buf[7] != 0;   // records written before this existed have 0 here = guard off = previous behaviour
    // SAFETY: flash may predate the setservoip/setservoport collision guards (or be corrupt). If the
    // stored servo endpoint is the DISPLAY's bridge, refuse to route the servo over Ethernet: sharing
    // one transparent bridge would interleave binary Modbus frames with the display's ASCII stream and
    // corrupt both. Fall back to native RS485 (Serial1), which is always safe, and say so loudly.
    if (servoOverEth && SERVO_ETH_IP == WAVESHARE_IP && SERVO_ETH_PORT == WAVESHARE_PORT) {
      servoOverEth = false;
      DEBUG_SERIAL.println("WARN: stored servo endpoint collides with the display bridge - forcing native RS485. Set a distinct 'setservoip' before 'servoeth on'.");
    }
    DEBUG_SERIAL.println("Servo-net config loaded from flash.");
  }
}

// Station/module serial number: settable from the app (setserial), persisted to flash,
// reported in status as SN=, and used by the app to auto-fill the Data Log run name.
int32_t stationSerial = 0;
void saveSerial() {
  if (!kvSetVerified("plasma_serial", &stationSerial, sizeof(stationSerial))) DEBUG_SERIAL.println("WARN: flash write (serial) FAILED");
}
void loadSerial() {
  int32_t v;
  if (kvGetChecked("plasma_serial", &v, sizeof(v))) stationSerial = v;
}

// =====================================================================
// MODBUS RTU HELPERS  -- Opta NATIVE RS485 via ArduinoModbus.
// The A6-RS is addressed as (group, offset); the Modbus register address is
// (group << 8) | offset. ModbusRTUClient drives the Opta's built-in RS485
// transceiver (automatic DE/RE) - no manual pin toggling.
// =====================================================================
static inline uint16_t regAddr(uint8_t group, uint8_t offset) { return ((uint16_t)group << 8) | offset; }

// ---- Modbus RTU over TCP (servo via the SEPARATE Waveshare RS485-to-ETH bridge) ----
// The Waveshare bridge is TRANSPARENT: it forwards raw RTU frames <-> RS485, so we build the
// full RTU frame (CRC appended) ourselves and tunnel it over servoClient. This shares NOTHING
// with displayClient - different socket, different IP - so the two Waveshare streams never cross.
static uint16_t modbusCRC(const uint8_t *buf, int len) {
  uint16_t crc = 0xFFFF;
  for (int i = 0; i < len; i++) { crc ^= buf[i]; for (int b = 0; b < 8; b++) { if (crc & 1) { crc >>= 1; crc ^= 0xA001; } else crc >>= 1; } }
  return crc;
}
// Count a failed RTU transaction. After a run of them the bridge slot is presumed half-open (see
// servoTxnFails) and the socket is dropped so serviceServoLink() can take a fresh one. Only ever
// reached on the Ethernet path; the native RS485 path has its own ArduinoModbus timeout handling.
static void servoTxnFailed() {
  if (++servoTxnFails >= SERVO_TXN_FAIL_LIMIT) {
    servoTxnFails = 0;
    servoClient.stop();
    servoEthNextTry = 0;   // eligible to reconnect immediately (serviceServoLink still refuses mid-cycle)
    DEBUG_SERIAL.println("Servo RS485-ETH link looks half-open (repeated RTU timeouts) - dropped for a fresh bridge slot.");
  }
}
// Append CRC, send the frame, read EXACTLY expectLen reply bytes (timeout), verify slave echo + CRC.
static bool servoRtuTxn(uint8_t *frame, int payloadLen, uint8_t *resp, int expectLen) {
  if (!servoClient.connected()) return false;
  uint16_t crc = modbusCRC(frame, payloadLen);
  frame[payloadLen]   = crc & 0xFF;          // RTU: CRC low byte first on the wire
  frame[payloadLen+1] = (crc >> 8) & 0xFF;
  while (servoClient.available()) servoClient.read();   // drop any stale bytes so replies can't shift
  servoClient.write(frame, payloadLen + 2);
  servoClient.flush();
  int n = 0; uint32_t t0 = millis();
  while (n < expectLen && (millis() - t0) < SERVO_ETH_TIMEOUT_MS) {
    if (servoClient.available()) { resp[n++] = servoClient.read(); t0 = millis(); }
  }
  if (n != expectLen)                { servoTxnFailed(); return false; }
  uint16_t rcrc = modbusCRC(resp, expectLen - 2);
  if (resp[expectLen-2] != (rcrc & 0xFF) || resp[expectLen-1] != ((rcrc >> 8) & 0xFF)) { servoTxnFailed(); return false; }
  servoTxnFails = 0;                 // a good framed+CRC-checked reply proves the socket is genuinely alive
  return true;
}
static bool tcpReadU16(uint8_t slave, uint16_t addr, uint16_t &value) {
  uint8_t req[8] = { slave, 0x03, (uint8_t)(addr>>8), (uint8_t)(addr&0xFF), 0x00, 0x01 };
  uint8_t resp[7];
  if (!servoRtuTxn(req, 6, resp, 7)) return false;
  if (resp[0] != slave || resp[1] != 0x03 || resp[2] != 2) return false;
  value = ((uint16_t)resp[3] << 8) | resp[4];
  return true;
}
static bool tcpWriteU16(uint8_t slave, uint16_t addr, uint16_t val) {
  uint8_t req[8] = { slave, 0x06, (uint8_t)(addr>>8), (uint8_t)(addr&0xFF), (uint8_t)(val>>8), (uint8_t)(val&0xFF) };
  uint8_t resp[8];
  if (!servoRtuTxn(req, 6, resp, 8)) return false;
  return (resp[0] == slave && resp[1] == 0x06);
}
static bool tcpWriteU32(uint8_t slave, uint16_t addr, uint16_t lowWord, uint16_t highWord) {
  uint8_t req[13] = { slave, 0x10, (uint8_t)(addr>>8), (uint8_t)(addr&0xFF), 0x00, 0x02, 0x04,
                      (uint8_t)(lowWord>>8), (uint8_t)(lowWord&0xFF), (uint8_t)(highWord>>8), (uint8_t)(highWord&0xFF) };
  uint8_t resp[8];
  if (!servoRtuTxn(req, 11, resp, 8)) return false;
  return (resp[0] == slave && resp[1] == 0x10);
}

bool readU16(uint8_t slave, uint8_t group, uint8_t offset, uint16_t &value, uint16_t &err) {
  err = 0; value = 0;
  if (servoOverEth) {                                    // RTU-over-TCP via the RS485-ETH bridge
    if (!tcpReadU16(slave, regAddr(group, offset), value)) { err = 1; return false; }
    return true;
  }
  long v = ModbusRTUClient.holdingRegisterRead(slave, regAddr(group, offset));
  if (v < 0) { err = 1; return false; }
  value = (uint16_t)v;
  return true;
}
bool readI16(uint8_t slave, uint8_t group, uint8_t offset, int16_t &value, uint16_t &err) {
  uint16_t raw = 0; bool ok = readU16(slave, group, offset, raw, err); value = (int16_t)raw; return ok;
}
bool writeU16(uint8_t slave, uint8_t group, uint8_t offset, uint16_t value) {
  if (servoOverEth) return tcpWriteU16(slave, regAddr(group, offset), value);
  return ModbusRTUClient.holdingRegisterWrite(slave, regAddr(group, offset), value);
}
bool writeI16(uint8_t slave, uint8_t group, uint8_t offset, int16_t value) { return writeU16(slave, group, offset, (uint16_t)value); }
bool writeU32(uint8_t slave, uint8_t group, uint8_t offset, uint32_t value) {
  uint16_t lowWord = value & 0xFFFF, highWord = (value >> 16) & 0xFFFF;   // low word first (C0A.06 default)
  if (servoOverEth) return tcpWriteU32(slave, regAddr(group, offset), lowWord, highWord);
  ModbusRTUClient.beginTransmission(slave, HOLDING_REGISTERS, regAddr(group, offset), 2);
  ModbusRTUClient.write(lowWord);
  ModbusRTUClient.write(highWord);
  return ModbusRTUClient.endTransmission();
}
bool writeI32(uint8_t slave, uint8_t group, uint8_t offset, int32_t value) { return writeU32(slave, group, offset, (uint32_t)value); }

// =====================================================================
// DRIVE REGISTER SHORTCUTS  (unchanged from base)
// =====================================================================
bool drvSetStepMode()                      { return writeU16(SERVO_ID, 0x03, 0x00, 2); }
bool drvSetGearNum(uint32_t v)             { return writeU32(SERVO_ID, 0x03, 0x02, v); }
bool drvSetGearDen(uint32_t v)             { return writeU32(SERVO_ID, 0x03, 0x04, v); }
bool drvSetDI7ToStepEnable()               { return writeU16(SERVO_ID, 0x04, 0x18, 34); }
bool drvSetDI7LogicNO()                    { return writeU16(SERVO_ID, 0x04, 0x19, 0); }
bool drvEnsureDI8HomeSwitch()              { return writeU16(SERVO_ID, 0x04, 0x1C, 5); }
bool drvEnsureDI5Son()                     { return writeU16(SERVO_ID, 0x04, 0x10, 1); }
bool drvEnsureDI4FaultReset()              { return writeU16(SERVO_ID, 0x04, 0x0C, 2); }
bool drvEnsureDI1PlusLimit()               { return writeU16(SERVO_ID, 0x04, 0x00, 6); }
bool drvEnsureDI2MinusLimit()              { return writeU16(SERVO_ID, 0x04, 0x04, 7); }
bool drvFaultReset()                       { return writeU16(SERVO_ID, 0x31, 0x00, 1); }
bool drvWriteStepAmount(int16_t step)      { return writeI16(SERVO_ID, 0x03, 0x0C, step); }
bool drvWriteStepSpeed(uint16_t rpm)       { return writeU16(SERVO_ID, 0x03, 0x0D, rpm); }
bool drvSetHomeMethod35()                  { return writeI16(SERVO_ID, 0x10, 0x01, 35); }
bool drvSetHomeOffsetAbs()                 { return writeU16(SERVO_ID, 0x10, 0x0A, 0); }
bool drvSetHomeOffsetDistance(int32_t v)   { return writeI32(SERVO_ID, 0x10, 0x0B, v); }
bool drvUseCurrentPositionAsHome()         { return writeU16(SERVO_ID, 0x10, 0x00, 3); }
bool drvReadSpeedFeedback(int16_t &rpm)    { uint16_t e=0; return readI16(SERVO_ID, 0x40, 0x01, rpm, e); }
bool drvReadServoStatus(uint16_t &s)       { uint16_t e=0; return readU16(SERVO_ID, 0x41, 0x0A, s, e); }
bool drvReadMcuFault(uint16_t &v)          { uint16_t e=0; return readU16(SERVO_ID, 0x41, 0x01, v, e); }
bool drvReadFpgaFault(uint16_t &v)         { uint16_t e=0; return readU16(SERVO_ID, 0x41, 0x03, v, e); }
bool drvReadEncFault(uint16_t &v)          { uint16_t e=0; return readU16(SERVO_ID, 0x41, 0x05, v, e); }

// =====================================================================
// UTILITIES
// =====================================================================
String hex16(uint16_t v) { String s = String(v, HEX); s.toUpperCase(); return "0x" + s; }
void sendTip(const String &s) { TIP_SERIAL.println(s); DEBUG_SERIAL.println("[TIP TX] " + s); }

// ---- Unified event / error reporting -------------------------------------
// Every message goes to all four channels in a consistent, parseable form:
//   USB      : "[INFO] ..."  / "[ERROR] ..."
//   4D disp  : "E<msg>\n"    (display shows it on the warning form)
//   Tip Chgr : "ERR! <msg>"  (errors only)
//   API      : "ERR <msg>" / "INFO <msg>"
// level: 0 = info, 1 = error
void report(uint8_t level, const String &msg) {
  const char *tag = level ? "ERROR" : "INFO";
  DEBUG_SERIAL.println("[" + String(tag) + "] " + msg);
  // CRITICAL FIX 2026-07-19: do NOT stream 'E'+free-text to the 4D display. The display has NO 'E'
  // parser; it processes each incoming byte with its legacy single-char handlers, so the 'A'/'C'/'F'
  // letters inside an error message (ELECTRODE, FAULT, ACTUATOR, PLASMA_NO_TEMP_RISE, ...) were parsed
  // as plasma-FIRE commands and energized the display's PA11 HV relay - a fault message literally
  // FIRING plasma. Errors still go to USB, the Tip Charger (ERR!), and the API. If the display should
  // show faults, add a framed, non-command-byte protocol + a matching display parser (not raw text).
  if (level) sendTip("ERR! " + msg);
  if (apiClient && apiClient.connected()) { apiClient.print(level ? "ERR " : "INFO "); apiClient.println(msg); }
}
void reportError(const String &msg) { report(1, msg); }
void reportInfo (const String &msg) { report(0, msg); }

void setServoOn(bool on) { digitalWrite(PIN_SERVO_SON, on ? HIGH : LOW); }
uint32_t plasmaPhaseT0 = 0, plasmaCapMs = 0;   // plasma-phase clock; shared so waitMotionComplete can enforce over-temp + time-cap DURING a move, not only between passes. Declared here (before setPlasma) so setPlasma can disarm the cap on plasma-off.
bool plasmaOn = false;        // plasma-enable request (mirrors PIN_PLASMA_ON)
bool fanOnState = true;       // fan runs at boot (setup drives PIN_FAN_ON HIGH)
bool actuatorClosed = false;  // actuator down = closed
bool fanManualOverride = false;   // an operator 'fan on/off' sets this so a plasma toggle can't clobber it; cleared at cycle start
// setPlasma drives the exhaust fan inverse to plasma DURING the automated cycle, but never
// overrides an explicit operator fan command (fanManualOverride) - so the Fan button 'sticks'.
void setPlasma(bool on)  { plasmaOn = on; if (!on) plasmaCapMs = 0; /* disarm stale time-cap so a later manual `plasma on`+move can't fire a false PLASMA_LOCAL_TIME_CAP */ digitalWrite(PIN_PLASMA_ON, on ? HIGH : LOW); if (!fanManualOverride) { fanOnState = !on; digitalWrite(PIN_FAN_ON, on ? LOW : HIGH); digitalWrite(PIN_LED_FAN, on ? LOW : HIGH); } }
// CRASH GUARD: the actuator door must not close while the plate is at the doorway/outside -
// it would crash the plate into the door. "Inside" = homed AND at/past the plasma row (plate
// has cleared the door). "Known outside" = homed AND short of the plasma row = a DEFINITE
// crash. If position is UNKNOWN (e.g. on a bench, not homed) we do NOT block - there is no
// plate to crash and the operator may be exercising the relay.
bool plateInsideChamber() { return currentPosKnown && currentPosUnits >= POS_PLASMA_START; }
bool plateKnownOutside()  { return currentPosKnown && currentPosUnits <  POS_PLASMA_START; }
void setActuatorRelay(bool down) {
  if (down && plateKnownOutside()) return;   // never close over a plate we KNOW is outside
  actuatorClosed = down; digitalWrite(PIN_ACTUATOR_DOWN, down ? HIGH : LOW);
  digitalWrite(PIN_LED_ACT, down ? HIGH : LOW);   // mirror RELAY1 on LED_D0 so the operator sees it fire
}
void setFan(bool on) { fanOnState = on; fanManualOverride = true; digitalWrite(PIN_FAN_ON, on ? HIGH : LOW); digitalWrite(PIN_LED_FAN, on ? HIGH : LOW); }   // manual fan command 'sticks'; mirror RELAY2 on LED_D2
void pulseStepEnable(uint32_t ms = 50) { digitalWrite(PIN_SERVO_STEP_TRIG, HIGH); delay(ms); digitalWrite(PIN_SERVO_STEP_TRIG, LOW); }

float mapFloat(float x, float a, float b, float c, float d) { if (fabs(b-a)<1e-9f) return c; return (x-a)*(d-c)/(b-a)+c; }
float readRtdVolts() { int raw = analogRead(PIN_RTD_ANALOG); return (raw / 4095.0f) * RTD_INPUT_VMAX; }
float readTempC()    { return mapFloat(readRtdVolts(), RTD_VOLTS_MIN, RTD_VOLTS_MAX, RTD_TEMP_MIN_C, RTD_TEMP_MAX_C); }
// True when the RTD reading cannot be a real electrode temperature (open circuit / dead transmitter
// at the bottom, short / over-range at the top). Only ever acted on while plasma is on and only when
// tempGuard is enabled - see the constants above for why the 0-5 V span makes this necessary.
bool  rtdImplausible() { float v = readRtdVolts(); return (v <= RTD_OPEN_V || v >= RTD_SAT_V); }
int   readTempF()    { int f = (int)(readTempC() * 9.0 / 5.0 + 32.0 + 0.5);
                       if (f < TC_MIN_F) f = TC_MIN_F; if (f > TC_MAX_F) f = TC_MAX_F; return f; }

// ---- LEM power sensing (voltage on A1, current on A2) ----
float lemInputVolts(int pin) { int raw = analogRead(pin); return (raw / 4095.0f) * 10.0f; }
float readLineVolts() { float v = lemInputVolts(PIN_LEM_VOLTAGE) * LEM_V_SCALE + LEM_V_OFFSET; return v < 0 ? 0 : v; }
float readLineAmps()  { float a = lemInputVolts(PIN_LEM_CURRENT) * LEM_I_SCALE + LEM_I_OFFSET; return a < 0 ? 0 : a; }
float readWatts()     { return readLineVolts() * readLineAmps(); }
bool  plasmaIsOn()    { return plasmaOn; }

String servoStatusText(uint16_t s) { switch (s){case 0:return "NOT_READY";case 1:return "READY";case 2:return "RUNNING";case 3:return "FAULT";default:return "UNKNOWN";} }
String knownFaultText(uint16_t c) {
  switch (c){case 0x7500:return "COMMS";case 0x7600:return "STORAGE";case 0x8400:return "SPEED";case 0x8611:return "FOLLOWING";
             case 0x8220:return "LENGTH";case 0x8700:return "SYNC";case 0x8900:return "PDMON";case 0x0FFF:return "FACTORY";default:return hex16(c);} }

void pumpServices();   // fwd decl: service all comms channels + honor abort during blocking waits

void hardStopOutputs() {
  sendTip("PLASMA_STOP");   // SAFETY: command the Tip Charger to OPEN the arc NOW - never wait for its timer. (Tip Charger must implement PLASMA_STOP.)
  setPlasma(false); setActuatorRelay(false);
  digitalWrite(PIN_SERVO_STEP_TRIG, LOW);
  setServoOn(false);   // SAFETY: remove drive torque on any stop/fault. Re-armed by RST!.
}

void faultOut(const String &msg) {
  lastFault = msg; processState = ST_FAULT; abortRequested = true;
  hardStopOutputs();
  reportError(msg);                // -> USB + 4D display + Tip Charger + API
}

bool waitServoReady(uint32_t timeoutMs = 3000) {
  uint32_t t0 = millis();
  while (millis() - t0 < timeoutMs) { uint16_t s=0; if (drvReadServoStatus(s) && (s==1||s==2)) return true; delay(50); }
  return false;
}
bool waitMotionComplete(uint32_t timeoutMs) {
  delay(50);
  uint32_t t0 = millis(), stableStart = 0;
  while (millis() - t0 < timeoutMs) {
    pumpServices();                       // keep abort (display/API/USB/tip) + temp telemetry alive during motion
    if (abortRequested) return false;
    // Runtime front-limit interlock (the loop() check is unreachable while the cycle blocks).
    if (digitalRead(PIN_FRONT_LIMIT) == LOW) { faultOut("FRONT_LIMIT_TRIPPED"); return false; }
    // Runtime over-temp + time-cap interlock DURING a move (PLASMA_SAFE_CHECK only runs BETWEEN
    // passes, so a thermal runaway mid-stroke would otherwise go unacted for a whole pass).
    // faultOut() -> hardStopOutputs() cuts plasma + the arc. Gated on plasmaIsOn() so travel/home
    // moves (plasma off) are unaffected and the stale deadline is harmless.
    if (plasmaIsOn()) {
      // Sensor sanity FIRST: a dead RTD reads 0 V = "0 C", which would let the over-temp test below
      // pass forever. Without this the interlock is fail-open. (Opt-in; see tempGuard.)
      if (tempGuard && rtdImplausible())                           { faultOut("ELECTRODE_TEMP_SENSOR_FAULT"); return false; }
      if (readTempC() > PLASMA_MAX_TEMP_C)                         { faultOut("ELECTRODE_OVERTEMP");    return false; }
      if (plasmaCapMs && (millis() - plasmaPhaseT0) > plasmaCapMs) { faultOut("PLASMA_LOCAL_TIME_CAP"); return false; }
    }
    uint16_t s = 0; int16_t speed = 0;
    if (!drvReadServoStatus(s)) { delay(20); continue; }
    if (s == 3) {
      uint16_t mcu=0,fpga=0,enc=0; drvReadMcuFault(mcu); drvReadFpgaFault(fpga); drvReadEncFault(enc);
      faultOut("SERVO_FAULT MCU=" + knownFaultText(mcu) + " FPGA=" + knownFaultText(fpga) + " ENC=" + knownFaultText(enc));
      return false;
    }
    if (!drvReadSpeedFeedback(speed)) { stableStart = 0; delay(20); continue; }  // failed read != at rest
    if (abs(speed) <= 3) { if (stableStart==0) stableStart=millis(); if (millis()-stableStart>=250) return true; }
    else stableStart = 0;
    delay(20);
  }
  faultOut("MOTION_TIMEOUT");
  return false;
}

// =====================================================================
// DRIVE SETUP + MOTION  (unchanged from base)
// =====================================================================
bool configureDrive() {
  if (!drvSetStepMode()) return false;
  if (!drvSetGearNum(131072UL)) return false;
  if (!drvSetGearDen(1000UL))   return false;
  if (!drvEnsureDI1PlusLimit()) return false;
  if (!drvEnsureDI2MinusLimit())return false;
  if (!drvEnsureDI4FaultReset())return false;
  if (!drvEnsureDI5Son())       return false;
  if (!drvEnsureDI8HomeSwitch())return false;
  if (!drvSetDI7ToStepEnable()) return false;
  if (!drvSetDI7LogicNO())      return false;
  if (!drvSetHomeMethod35())    return false;
  if (!drvSetHomeOffsetAbs())   return false;
  if (!drvSetHomeOffsetDistance(0)) return false;
  return true;
}
bool stepMoveRelative(int16_t deltaUnits, uint16_t rpm, uint32_t timeoutMs = MOTION_TIMEOUT_MS) {
  if (deltaUnits == 0) return true;
  if (deltaUnits > MAX_STEP_UNITS || deltaUnits < -MAX_STEP_UNITS) { faultOut("STEP_OUT_OF_RANGE"); return false; }
  if (rpm == 0) rpm = 10; if (rpm > 1500) rpm = 1500;
  if (!drvWriteStepAmount(deltaUnits)) { faultOut("WRITE_STEP_AMOUNT_FAILED"); return false; }
  if (!drvWriteStepSpeed(rpm))         { faultOut("WRITE_STEP_SPEED_FAILED");  return false; }
  if (abortRequested) return false;    // SAFETY: don't latch a new stroke if an abort is pending
  pulseStepEnable(80);
  return waitMotionComplete(timeoutMs);
}
bool moveToAbsoluteKnown(int32_t targetUnits, uint16_t rpm, uint32_t timeoutMs = MOTION_TIMEOUT_MS) {
  if (!currentPosKnown) { faultOut("ABSOLUTE_POSITION_UNKNOWN_HOME_FIRST"); return false; }
  int32_t delta = targetUnits - currentPosUnits;
  if (delta > MAX_STEP_UNITS || delta < -MAX_STEP_UNITS) { faultOut("ABS_MOVE_DELTA_TOO_LARGE"); return false; }
  if (!stepMoveRelative((int16_t)delta, rpm, timeoutMs)) return false;
  currentPosUnits = targetUnits;
  return true;
}
uint16_t computePassRpm(int32_t fromUnits, int32_t toUnits, uint32_t timeMs) {
  float dist = fabs((float)toUnits - (float)fromUnits);
  if (timeMs < 50) timeMs = 50;
  float revs = dist / APP_UNITS_PER_REV, minutes = timeMs / 60000.0f;
  float rpm = (minutes > 0.0f) ? (revs / minutes) : RPM_MAX_PASS;
  if (rpm < RPM_MIN_PASS) rpm = RPM_MIN_PASS; if (rpm > RPM_MAX_PASS) rpm = RPM_MAX_PASS;
  return (uint16_t)rpm;
}
// Inverse of computePassRpm: how long (ms) a move of this distance takes at this rpm.
// Used to tell the display how long to animate the swift return.
uint32_t computeMoveMs(int32_t fromUnits, int32_t toUnits, uint16_t rpm) {
  if (rpm == 0) rpm = 1;
  float revs = fabs((float)toUnits - (float)fromUnits) / APP_UNITS_PER_REV;
  float ms = (revs / (float)rpm) * 60000.0f;
  return (ms < 1.0f) ? 1u : (uint32_t)ms;
}
bool declareCurrentPositionAsHome() {
  if (!drvSetHomeMethod35()) return false;
  if (!drvSetHomeOffsetAbs()) return false;
  if (!drvSetHomeOffsetDistance(0)) return false;
  if (!drvUseCurrentPositionAsHome()) return false;
  delay(100); currentPosUnits = 0; currentPosKnown = true; return true;
}
bool doSoftHome() {
  DEBUG_SERIAL.println("Soft-home...");
  if (digitalRead(PIN_HOME_SWITCH) == LOW) { if (!stepMoveRelative(+300, RPM_HOME_FAST, 8000)) return false; }
  uint32_t coarse = 0;
  while (digitalRead(PIN_HOME_SWITCH) != LOW) {
    pumpServices(); if (abortRequested) return false;
    if (++coarse > 200) { faultOut("HOME_SEARCH_FAILED_NO_SWITCH"); return false; }
    if (!stepMoveRelative(-150, RPM_HOME_FAST, 8000)) return false;
  }
  if (!stepMoveRelative(+200, RPM_HOME_FAST, 8000)) return false;
  uint32_t fine = 0;
  while (digitalRead(PIN_HOME_SWITCH) != LOW) {
    pumpServices(); if (abortRequested) return false;
    if (++fine > 50) { faultOut("HOME_FINE_SEARCH_FAILED"); return false; }
    if (!stepMoveRelative(-20, RPM_HOME_SLOW, 8000)) return false;
  }
  if (!declareCurrentPositionAsHome()) { faultOut("DECLARE_HOME_FAILED"); return false; }
  DEBUG_SERIAL.println("Home = 0"); return true;
}
// NOTE: DN/UP feedback are read LOW-asserted to match the other INPUT_PULLUP switches
// (home/front-limit): a switch-to-ground reads HIGH at rest, LOW when reached, so an
// open/broken sensor reads HIGH = "not reached" = timeout = fault (fail-safe). If your
// DN/UP feedback are verified ACTIVE-HIGH push-pull sensors instead, revert these to
// ==HIGH AND set those pins to INPUT_PULLDOWN in setup(). Verify on the bench.
bool actuatorDown(uint32_t timeoutMs = ACTUATOR_TIMEOUT_MS) {
  setActuatorRelay(true);
  uint32_t t0 = millis();
  while (millis()-t0 < timeoutMs) { pumpServices(); if (abortRequested) return false; if (digitalRead(PIN_ACTUATOR_DN_FB)==LOW) return true; delay(20); }
  return false;
}
bool actuatorUp(uint32_t timeoutMs = ACTUATOR_TIMEOUT_MS) {
  setActuatorRelay(false);
  uint32_t t0 = millis();
  while (millis()-t0 < timeoutMs) { pumpServices(); if (abortRequested) return false; if (digitalRead(PIN_ACTUATOR_UP_FB)==LOW) return true; delay(20); }
  return false;
}

// =====================================================================
// 4D DISPLAY LINK (Ethernet via Waveshare)
// =====================================================================
bool connectDisplay() {
  if (Ethernet.linkStatus() == LinkOFF) return false;   // no Ethernet cable/link -> don't even try (that call blocks ~28s)
  displayClient.stop();
  displayClient.setSocketTimeout(3000);
  DEBUG_SERIAL.print("Display connect "); DEBUG_SERIAL.print(WAVESHARE_IP);
  DEBUG_SERIAL.print(":"); DEBUG_SERIAL.println(WAVESHARE_PORT);
  mbed::Watchdog::get_instance().kick();   // this connect() can block ~28s on an unreachable bridge; feed the dog first so it doesn't trip
  if (displayClient.connect(WAVESHARE_IP, WAVESHARE_PORT)) { DEBUG_SERIAL.println("Display connected."); displayWriteFails = 0; return true; }
  return false;
}
// Send the electrode-temp heartbeat to Form4 (non-blocking). Called both from
// the idle loop and from pumpServices() during a cycle so the display's
// staleness watchdog never falsely trips mid-run.
uint8_t  lastReadySent = 0xFF;   // last Y (ready flag) sent to the panel (0xFF = none yet -> force first send)
uint32_t lastYSend     = 0;      // millis() of the last Y sent
void streamTempOnly() {
  if (!displayClient.connected()) return;
  uint32_t now = millis();
  uint8_t  readyNow = (processState == ST_IDLE) ? 1 : 0;
  // CLEAN COMMS - do NOT push the same bytes over and over:
  //  - Y (ready flag for the panel's Start-Clean gate): send ONLY when it CHANGES, plus a 2s
  //    heartbeat (< the panel's ~3s ready-timeout) so the gate stays fresh without 1 Hz spam.
  //  - T (electrode temp): stream at 1 Hz ONLY while plasma is ON (that is when temp matters);
  //    when idle the panel uses its own sensor, so we send nothing.
  bool sendY = (readyNow != lastReadySent) || (now - lastYSend >= 2000);
  bool sendT = plasmaIsOn() && (now - lastTcSend >= TC_SEND_INTERVAL_MS);
  size_t w = 0;
  if (sendT) { lastTcSend = now; w += displayClient.print('T'); w += displayClient.print(readTempF()); w += displayClient.print('\n'); }
  if (sendY) { lastYSend = now; lastReadySent = readyNow; w += displayClient.print('Y'); w += displayClient.print(readyNow); w += displayClient.print('\n'); }
  if (sendT || sendY) {
    // Half-open watchdog: a live socket accepts the bytes; a half-open one rejects them (0).
    if (w == 0) { if (++displayWriteFails >= DISPLAY_WRITE_FAIL_LIMIT) { displayWriteFails = 0; displayClient.stop(); } }
    else displayWriteFails = 0;
  }
}
// Drive the display's plate-progress animation. The servo position only updates at
// each pass END (a pass is one Modbus stroke), so the PANEL runs the smooth motion:
//   'M'<ms>  sweep the slider row1 -> last row over <ms> milliseconds (a plasma pass)
//   'V'<ms>  swift return last row -> row1 over <ms>  ('V', not 'B': 'B' is the panel's abort)
// The display firmware animates its slider/indicator over that duration; a build that
// doesn't parse M/V simply ignores these lines. Edited by Adithya Mallela - 2026-07-17.
void displayAnim(char dir, uint32_t ms) {
  if (displayClient.connected()) { displayClient.print(dir); displayClient.print(ms); displayClient.print('\n'); }
}
void serviceDisplayLink() {
  // No RX-based "stale" self-heal: this link is SEND-mostly (the Opta streams temp/status to the
  // panel; the panel sends only occasional button presses back). In this bench topology the panel's
  // telemetry goes to the 4D-UPA, not back to the Opta, so an RX gap does NOT mean the link is dead.
  // Dropping it on no-RX churned the connection every ~12 s and stalled the command loop (laggy
  // buttons). We now rely on connected() (TCP) to detect a genuinely dropped link.
  if (!displayClient.connected()) {
    if (processState == ST_RUNNING) return;   // never do a blocking reconnect mid-cycle
    if (millis() - lastDisplayReconnect >= displayReconnectMs) {
      lastDisplayReconnect = millis();
      // Smart backoff so a merely-FLAPPING bridge recovers in seconds, not minutes:
      //  - connect OK             -> normal 15s cadence
      //  - fast refuse (<10s)     -> bridge is reachable but dropped us; retry at the normal
      //                              cadence so DISP comes back quickly
      //  - connect BLOCKED (~28s) -> bridge is truly unreachable; back off HARD (5 min) so the
      //                              blocking mbed connect() can't starve the USB status stream
      uint32_t t0 = millis();
      bool ok = connectDisplay();
      uint32_t took = millis() - t0;
      displayReconnectMs = ok ? DISPLAY_RECONNECT_MS
                              : (took > 10000 ? DISPLAY_RETRY_MAX_MS : DISPLAY_RECONNECT_MS);
    }
    return;
  }
  displayReconnectMs = DISPLAY_RECONNECT_MS;   // connected -> back to normal cadence
  streamTempOnly();
}
// Keep the servo's RS485-to-ETH bridge socket up (ONLY when servoOverEth). Its OWN socket +
// backoff, fully independent of the display link, so a servo-bridge outage never disturbs display
// telemetry and vice versa. Same "hard back off on a blocking (~28s) connect" guard as the display.
void serviceServoLink() {
  if (!servoOverEth) return;
  if (servoClient.connected()) return;
  if (processState == ST_RUNNING) return;      // never do a blocking reconnect mid-cycle
  if (millis() < servoEthNextTry) return;
  if (Ethernet.linkStatus() == LinkOFF) { servoEthNextTry = millis() + 5000; return; }
  servoClient.stop();
  servoClient.setSocketTimeout(3000);
  mbed::Watchdog::get_instance().kick();        // connect() can block on an unreachable bridge; feed the dog first
  uint32_t t0 = millis();
  bool ok = servoClient.connect(SERVO_ETH_IP, SERVO_ETH_PORT);
  servoEthNextTry = ok ? 0 : (millis() + ((millis() - t0) > 10000 ? 300000 : 15000));
  if (ok) {
    DEBUG_SERIAL.println("Servo RS485-ETH connected.");
    // DEFERRED BOOT CONFIG: setup() cannot probe/configure over Ethernet (no stack, no socket yet),
    // so it only flagged the work. The bridge socket is now genuinely up, so do it exactly once.
    // Cleared BEFORE the attempt so a fault here can never re-enter this on every reconnect.
    if (servoBootConfigPending) {
      servoBootConfigPending = false;
      uint16_t st = 0, e = 0;
      if (readU16(SERVO_ID, 0x41, 0x0A, st, e)) {
        DEBUG_SERIAL.print("Servo probe OK (eth), status="); DEBUG_SERIAL.println(st);
      } else {
        DEBUG_SERIAL.println("Servo probe (eth): NO REPLY - check the RS485-to-ETH bridge A/B wiring, servo power, ID=1, 9600 8N1");
      }
      // The link is proven at this point, so a configure failure is a genuine drive fault - treat it
      // exactly as the native RS485 path does.
      if (!configureDrive())      faultOut("DRIVE_CONFIGURATION_FAILED");
      else if (!waitServoReady()) faultOut("SERVO_NOT_READY_AFTER_BOOT");
      else                        DEBUG_SERIAL.println("Servo READY (over Ethernet).");
    }
  }
}
// The display sends whole newline-terminated lines. We only act on FRAMED /
// known lines so button commands can never collide with the CSV telemetry or
// the boot banners (which contain letters like the O in "POWER"):
//    "R!"  start   "CABT!" abort   "#O"/"#C" actuator open/close   "#N"/"#F" fan
//    "Z1 800!" / "Z2 2800!" / "Z3 8800!"  = teach door/row1/lastrow positions
// Everything else (telemetry, banners) is ignored.
String dispRx;
char pollDisplay() {
  char action = 0;
  while (displayClient.connected() && displayClient.available() > 0) {
    int b = displayClient.read();
    if (b < 0) break;
    displayWriteFails = 0;             // any RX byte also proves the socket is live -> clear the half-open counter
    char c = (char)b;
    if (c == '\n' || c == '\r') {
      dispRx.trim();
      // --- match the protocol already written on the 4D display side ---
      if      (dispRx == "R!")    action = 'S';          // Start Clean button
      else if (dispRx == "CABT!") action = 'X';          // Abort button
      else if (dispRx == "#O") action = 'O';             // manual actuator open
      else if (dispRx == "#C") action = 'C';             // manual actuator close
      else if (dispRx == "#N") action = 'N';             // manual fan on
      else if (dispRx == "#F") action = 'F';             // manual fan off
      else if (dispRx.startsWith("#") && dispRx.length() >= 2) {
        action = dispRx.charAt(1);                       // any other framed cmd
      } else if (dispRx.startsWith("Z") && dispRx.endsWith("!")) {
        int slot = dispRx.substring(1,2).toInt();
        int32_t val = dispRx.substring(2, dispRx.length()-1).toInt();
        if (val < 0 || val > POS_MAX_TRAVEL) {
          DEBUG_SERIAL.println("[SETUP] slot " + String(slot) + " = " + String(val) + " REJECTED (out of range)");
        } else {
          if      (slot==1) POS_BEFORE_DOOR  = val;
          else if (slot==2) POS_PLASMA_START = val;
          else if (slot==3) POS_LAST_ROW     = val;
          savePositions();
          DEBUG_SERIAL.println("[SETUP] slot " + String(slot) + " = " + String(val) + " (saved)");
        }
      }
      dispRx = "";
      if (action) break;   // one command per call; leave any queued framed lines for the next loop pass (nothing dropped)
    } else {
      dispRx += c;
      if (dispRx.length() > 40) dispRx = "";
    }
  }
  return action;
}

// =====================================================================
// PROCESS CYCLE  (plasma owned by Tip Charger)
// =====================================================================
// Abort-aware pause that keeps the display / API / Tip-Charger links serviced.
bool dwell(uint32_t ms) {
  uint32_t t = millis();
  while (millis() - t < ms) { pumpServices(); if (abortRequested) return false; delay(10); }
  return true;
}

bool runCleaningCycle() {
  abortRequested = false; plateInside = false; plasmaDone = false; fanManualOverride = false;   // the cycle drives the fan (inverse of plasma); clear any manual override
  processState = ST_RUNNING;

  if (digitalRead(PIN_FRONT_LIMIT) == LOW) { faultOut("FRONT_LIMIT_ACTIVE_AT_START"); return false; }

  // Validate taught positions before any motion: must be ordered and in-envelope.
  if (!(POS_HOME >= 0 && POS_HOME <= POS_BEFORE_DOOR && POS_BEFORE_DOOR <= POS_PLASMA_START
        && POS_PLASMA_START <= POS_LAST_ROW && POS_LAST_ROW <= POS_MAX_TRAVEL)) {
    faultOut("BAD_POSITIONS (need 0<=door<=row1<=last<=" + String(POS_MAX_TRAVEL) + ")"); return false;
  }
  // Each cycle move is a SINGLE Modbus stroke; moveToAbsoluteKnown() faults if |delta| > MAX_STEP_UNITS.
  // Reject an un-reachable span HERE (before homing / before the arc), not mid-sweep with plasma live.
  if ((POS_PLASMA_START - POS_HOME)        > MAX_STEP_UNITS ||   // home -> row1
      (POS_LAST_ROW    - POS_PLASMA_START) > MAX_STEP_UNITS ||   // row1 <-> last (the plasma sweep)
      (POS_LAST_ROW    - POS_BEFORE_DOOR)  > MAX_STEP_UNITS) {   // last -> door
    faultOut("SPAN_TOO_LARGE (each segment must be <=" + String(MAX_STEP_UNITS) + " pulses)"); return false;
  }

  if (!doSoftHome()) return false;                              // 1) home
  if (!moveToAbsoluteKnown(POS_PLASMA_START, RPM_RETURN_FAST)) return false;  // carriage -> plasma pos (row 1)
  if (!plateInsideChamber()) { faultOut("ACTUATOR_CLOSE_UNSAFE_PLATE_NOT_INSIDE"); return false; }  // crash guard
  if (!actuatorDown()) { faultOut("ACTUATOR_DOWN_TIMEOUT"); return false; }   // 2) close actuator (plate is inside)

  // 3) wait for Tip Charger "plate inside / all set"
  sendTip("READY_PLATE?");
  uint32_t t0 = millis();
  while (!plateInside) {
    pumpServices(); if (abortRequested) return false;
    if (millis() - t0 > PLATE_IN_TIMEOUT_MS) { faultOut("TIMEOUT_WAITING_PLATE_IN"); return false; }
    delay(20);
  }

  // 3b) settle: actuator closed, hold ~1s before striking plasma
  if (!dwell(1000)) return false;

  // 4) request plasma (Tip Charger fires + owns the timer), fan off.
  //    Arm the plasma-phase clock BEFORE striking so the over-temp/time-cap backstops
  //    (now also enforced DURING each move in waitMotionComplete) have a valid deadline.
  plasmaPhaseT0 = millis();
  plasmaCapMs   = plasmaTotalTimeMs + 15000UL;   // configured time + 15s margin (comms-loss backstop)
  setPlasma(true);
  sendTip("PLASMA_GO");

  // 4b) Confirm the arc actually struck AND the RTD channel is alive: the electrode temp
  //     must climb past PLASMA_MIN_TEMP_C within TEMP_RISE_TIMEOUT_MS. This catches a failed
  //     strike and a dead/open RTD (unpowered transmitter / broken wire -> ~0 V -> ~0 C) BEFORE
  //     we rely on that same channel for the over-temp backstop below.
  {
    uint32_t tRise = millis();
    while (readTempC() < PLASMA_MIN_TEMP_C && !plasmaDone) {
      pumpServices();
      if (abortRequested) { setPlasma(false); return false; }
      if (millis() - tRise > TEMP_RISE_TIMEOUT_MS) { setPlasma(false); faultOut("PLASMA_NO_TEMP_RISE"); return false; }
      delay(20);
    }
  }

  // 5) TWO-PASS SWEEP synchronized to the plasma-on time. The electrode covers the
  //    plate (row 1 -> last row) over HALF the set time, snaps SWIFTLY back to row 1,
  //    then covers it a second time over the other half. So 5 s of plasma = a 2.5 s
  //    forward pass, a quick return, then a second 2.5 s forward pass. The display's
  //    slider is animated over each pass's duration via displayAnim().
  //    Safety backstops still cut it short at any point: abort, over-temp on the
  //    UNCLAMPED electrode temp, the Tip Charger's own "PDONE!", and a local time cap.
  const int      PLASMA_PASSES = 2;
  uint32_t       passMs   = plasmaTotalTimeMs / PLASMA_PASSES;                 // forward-pass duration
  uint16_t       passRpm  = computePassRpm(POS_PLASMA_START, POS_LAST_ROW, passMs);
  uint16_t       backRpm  = RPM_RETURN_FAST;
  uint32_t       returnMs = computeMoveMs(POS_LAST_ROW, POS_PLASMA_START, backRpm);   // swift return duration (for the animation)
  t0 = plasmaPhaseT0;   // the sweep macro shares the plasma-phase clock

  #define PLASMA_SAFE_CHECK() do { \
      pumpServices(); \
      if (abortRequested)                  { setPlasma(false); return false; } \
      if (tempGuard && rtdImplausible())   { setPlasma(false); faultOut("ELECTRODE_TEMP_SENSOR_FAULT"); return false; } \
      if (readTempC() > PLASMA_MAX_TEMP_C) { setPlasma(false); faultOut("ELECTRODE_OVERTEMP");     return false; } \
      if (millis() - t0 > plasmaCapMs)     { setPlasma(false); faultOut("PLASMA_LOCAL_TIME_CAP");  return false; } \
    } while (0)

  // Nominal profile: exactly PLASMA_PASSES forward passes, each timed to passMs.
  for (int pass = 0; pass < PLASMA_PASSES && !plasmaDone; pass++) {
    PLASMA_SAFE_CHECK();
    displayAnim('M', passMs);                                                                   // animate slider row1 -> last
    if (!moveToAbsoluteKnown(POS_LAST_ROW, passRpm, MOTION_TIMEOUT_MS)) { setPlasma(false); return false; }
    if (plasmaDone) break;
    if (pass < PLASMA_PASSES - 1) {
      PLASMA_SAFE_CHECK();
      displayAnim('V', returnMs);                                                               // animate swift return
      if (!moveToAbsoluteKnown(POS_PLASMA_START, backRpm)) { setPlasma(false); return false; }
    }
  }

  // If the Tip Charger's timer is still running after the two passes, keep sweeping so
  // the head is never parked hot - until PDONE! / cap / abort. (The two passes above are
  // the intended profile; this only runs if the panel-set time and Tip Charger disagree.)
  while (!plasmaDone) {
    PLASMA_SAFE_CHECK();
    displayAnim('V', returnMs);
    if (!moveToAbsoluteKnown(POS_PLASMA_START, backRpm)) { setPlasma(false); return false; }
    if (plasmaDone) break;
    PLASMA_SAFE_CHECK();
    displayAnim('M', passMs);
    if (!moveToAbsoluteKnown(POS_LAST_ROW, passRpm, MOTION_TIMEOUT_MS)) { setPlasma(false); return false; }
    if (millis() - t0 > PLASMA_DONE_TIMEOUT_MS) { setPlasma(false); faultOut("PLASMA_DONE_TIMEOUT"); return false; }
  }
  #undef PLASMA_SAFE_CHECK
  setPlasma(false);                              // release plasma request, fan back on
  if (!dwell(1000)) return false;                // pause after plasma before opening up

  // 6) move to the door, open the actuator, then exit home
  if (!moveToAbsoluteKnown(POS_BEFORE_DOOR, RPM_TRAVEL)) return false;
  if (!actuatorUp()) { faultOut("ACTUATOR_UP_TIMEOUT"); return false; }
  if (!doSoftHome()) return false;

  processState = ST_IDLE;
  sendTip("DONE!");
  if (displayClient.connected()) { displayClient.print("D\n"); }   // tell display: cycle done
  return true;
}

// =====================================================================
// TIP CHARGER COMMAND PARSER
// =====================================================================
void handleTipCommand(String cmd) {
  cmd.trim();
  DEBUG_SERIAL.println("[TIP RX] " + cmd);
  if (cmd == "I!") { if (processState==ST_IDLE){ sendTip("ACK! START"); runCleaningCycle(); } else sendTip("BUSY!"); return; }
  if (cmd == "PLATEIN!") { plateInside = true; sendTip("ACK! PLATEIN"); return; }
  if (cmd == "PDONE!")   { plasmaDone  = true; sendTip("ACK! PDONE");   return; }
  if (cmd == "B!") { abortRequested = true; setPlasma(false); sendTip("ACK! B"); if (processState==ST_RUNNING) faultOut("CANCELLED_BY_B"); return; }
  if ((cmd.startsWith("T") && cmd.endsWith("!")) || (cmd.startsWith("TIME=") && cmd.endsWith("!"))) {
    String n = cmd.startsWith("TIME=") ? cmd.substring(5, cmd.length()-1) : cmd.substring(1, cmd.length()-1);
    uint32_t v = n.toInt();
    if (v >= 500 && v <= 120000) { plasmaTotalTimeMs = v; sendTip("ACK! TIME=" + String(v)); } else sendTip("ERR! BAD_TIME");
    return;
  }
  if (cmd == "HOME!") { if (processState==ST_IDLE){ if (doSoftHome()) sendTip("ACK! HOME_DONE"); } else sendTip("BUSY!"); return; }
  if (cmd == "RST!") {
    if (processState == ST_RUNNING) { sendTip("BUSY!"); return; }   // never clear abort mid-cycle
    abortRequested=false; hardStopOutputs(); drvFaultReset(); setServoOn(true); processState=ST_IDLE; sendTip("ACK! RESET"); return;
  }
  if (cmd == "STAT!") {
    uint16_t s=0,mcu=0,fpga=0,enc=0; int16_t spd=0;
    drvReadServoStatus(s); drvReadSpeedFeedback(spd); drvReadMcuFault(mcu); drvReadFpgaFault(fpga); drvReadEncFault(enc);
    sendTip("STAT! SERVO=" + servoStatusText(s) + " SPD=" + String(spd) + " TEMP=" + String(readTempC(),1) + "C" +
            " POS=" + String(currentPosUnits) + " MCU=" + knownFaultText(mcu));
    return;
  }
  sendTip("ERR! UNKNOWN_CMD");
}
unsigned long tipLastRx = 0;      // millis() of the last byte from the Tip Charger, 0 = never
void serviceTipSerial_inline() {
  while (TIP_SERIAL.available()) { char c=(char)TIP_SERIAL.read(); tipLastRx = millis(); tipRx += c; if (c=='!'){ handleTipCommand(tipRx); tipRx=""; } if (tipRx.length()>48) tipRx=""; }
}
// The panel chatters while a cycle runs and is quiet between them, so allow a generous window
// before calling it gone - a silent Tip Charger is not necessarily a disconnected one.
static const unsigned long TIP_ALIVE_MS = 30000;
bool tipCharger_isAlive() { return tipLastRx && (millis() - tipLastRx) < TIP_ALIVE_MS; }

// =====================================================================
// INTERACTIVE COMMAND PROCESSOR  (shared by USB console + Ethernet API)
// Newline-terminated ASCII. Same command set works over both channels, so a
// PC can telnet/socket to <OptaIP>:<API_PORT> or use the USB serial monitor.
// =====================================================================
// Parse "a.b.c.d"; returns false (out=unchanged) if malformed or any octet >255.
bool parseIpChecked(const String &s, IPAddress &out) {
  int p1=s.indexOf('.'), p2=s.indexOf('.',p1+1), p3=s.indexOf('.',p2+1);
  if (p1<0||p2<0||p3<0) return false;
  long o[4] = { s.substring(0,p1).toInt(), s.substring(p1+1,p2).toInt(),
                s.substring(p2+1,p3).toInt(), s.substring(p3+1).toInt() };
  for (int i=0;i<4;i++) if (o[i] < 0 || o[i] > 255) return false;
  out = IPAddress(o[0],o[1],o[2],o[3]);
  return true;
}

void printStatus(Print &out) {
  uint16_t s=0; drvReadServoStatus(s);
  out.println("OK STATE=" + String(processState==ST_IDLE?"IDLE":(processState==ST_RUNNING?"RUNNING":"FAULT")) +
              " SERVO=" + servoStatusText(s) +
              " TEMP_F=" + String(readTempF()) +
              " PLASMA_TIME_MS=" + String(plasmaTotalTimeMs) +
              " POS=" + String(currentPosUnits) +
              " PLASMA=" + String(plasmaIsOn()?1:0) +
              " ACT=" + String(actuatorClosed?1:0) +
              " FAN=" + String(fanOnState?1:0) +
              " SN=" + String(stationSerial) +
              " VOLTS=" + String(readLineVolts(),1) +
              " AMPS=" + String(readLineAmps(),2) +
              " WATTS=" + String(readWatts(),0) +
              " DISP=" + String(displayClient.connected()?"UP":"DOWN") +
              " TIP=" + String(tipCharger_isAlive()?"UP":"DOWN") +
              " LASTFAULT=" + (lastFault.length()?lastFault:"none"));
}

void processCommand(String cmd, Print &out) {
  cmd.trim();
  if (cmd.length()==0) return;
  String lc = cmd; lc.toLowerCase();
  int sp = cmd.indexOf(' ');
  String arg = (sp>0) ? cmd.substring(sp+1) : "";
  arg.trim();

  if (lc == "help") {
    out.println("OK ===== Plasma Station commands (USB console + Ethernet API, 9600 8N1) =====");
    out.println("STATUS / INFO");
    out.println("  stat          - full status line: state, servo, temp, POS, plasma, act, fan, SN, V/A/W, disp, lastfault");
    out.println("  show          - saved config: IPs, ports, plasma time, taught positions");
    out.println("  serial        - show the station serial number (SN)");
    out.println("  probe         - servo Modbus diagnostic: read registers + one test write, scan bauds");
    out.println("  selftest      - one-shot check: RTD, display link, Tip Charger, inputs, relay pins, servo baud scan");
    out.println("PERSISTENCE (stored in on-board flash, survives power-off)");
    out.println("  save          - write config + taught positions + LEM calibration to flash");
    out.println("  setserial <n> - set + save the station serial number (SN=, auto-names Data Log runs)");
    out.println("  settime <ms>  - plasma-on time per cycle (500-120000 ms); split evenly across the 2 passes");
    out.println("  posdoor <n>   - teach the door/entry position (pulses, 0-" + String(POS_MAX_TRAVEL) + ")");
    out.println("  pos1 <n>      - teach row 1 / plasma-start position (pulses)");
    out.println("  poslast <n>   - teach the last-row position (pulses)");
    out.println("NETWORK (reboot to apply IP/port changes)");
    out.println("  setwsip <a.b.c.d>  - Waveshare bridge IP (link to the 4D display)");
    out.println("  setwsport <n>      - Waveshare bridge TCP port");
    out.println("  setoptaip <a.b.c.d> - this Opta's IP");
    out.println("  setapiport <n>     - Ethernet API port");
    out.println("MANUAL CONTROL (bench use; blocked while a cycle is RUNNING)");
    out.println("  plasma on|off - plasma indicator + request (plasma is actually fired by the Tip Charger)");
    out.println("  fan on|off    - fan relay (RELAY2); a manual fan command 'sticks' until the next cycle");
    out.println("  act open|close- actuator relay (RELAY1); CLOSE is crash-guarded when the plate is outside");
    out.println("  clicktest     - audibly cycle RELAY1 then RELAY2 four times each to confirm relays + wiring");
    out.println("CYCLE / SERVO / SYSTEM");
    out.println("  start         - run a full cleaning cycle: home, position, close, plasma 2-pass sweep, retract, home");
    out.println("  home          - soft-home the carriage to the home switch");
    out.println("  abort         - stop plasma + motion now; from FAULT it re-arms the drive back to IDLE");
    out.println("  reboot        - restart the Opta (fail-safe: boot drives plasma + actuator OFF)");
    return;
  }
  if (lc == "show") {
    out.println("OK CONFIG");
    out.println(" optaIP=" + String(OPTA_IP[0])+"."+OPTA_IP[1]+"."+OPTA_IP[2]+"."+OPTA_IP[3]);
    out.println(" waveshareIP=" + String(WAVESHARE_IP[0])+"."+WAVESHARE_IP[1]+"."+WAVESHARE_IP[2]+"."+WAVESHARE_IP[3]+":"+String(WAVESHARE_PORT));
    // Servo bridge reported in the SAME shape as waveshareIP so the app can read both back and show
    // the operator what actually landed in flash, instead of trusting the page's HTML defaults.
    out.println(" servoBridge=" + String(SERVO_ETH_IP[0])+"."+SERVO_ETH_IP[1]+"."+SERVO_ETH_IP[2]+"."+SERVO_ETH_IP[3]+":"+String(SERVO_ETH_PORT)
                + " transport=" + String(servoOverEth ? "eth" : "rs485"));
    out.println(" tempGuard=" + String(tempGuard ? "on" : "off"));
    out.println(" apiPort=" + String(API_PORT));
    out.println(" plasmaTimeMs=" + String(plasmaTotalTimeMs));
    out.println(" posDoor=" + String(POS_BEFORE_DOOR) + " pos1=" + String(POS_PLASMA_START) + " posLast=" + String(POS_LAST_ROW));
    return;
  }
  if (lc == "stat")  { printStatus(out); return; }
  if (lc == "probe") {
    if (processState == ST_RUNNING) { out.println("ERR busy - not during a cycle"); return; }  // tears down the live servo link
    // Detailed servo Modbus diagnostic - reads several regs and tries one write.
    out.println("OK servo probe (ID=" + String(SERVO_ID) + " @ " + String(SERVO_BAUD) + " 8N1):");
    struct { uint8_t g, o; const char *n; } regs[] = {
      {0x41,0x0A,"status U41.0A"}, {0x40,0x01,"speed U40.01"},
      {0x41,0x01,"mcuFlt U41.01"}, {0x03,0x00,"ctrlMode C03.00"} };
    for (auto &r : regs) {
      long v = ModbusRTUClient.holdingRegisterRead(SERVO_ID, ((uint16_t)r.g<<8)|r.o);
      out.print("  "); out.print(r.n); out.print(" -> ");
      if (v < 0) { out.print("NO REPLY ("); out.print(ModbusRTUClient.lastError()); out.println(")"); }
      else       { out.println(v); }
    }
    bool w = ModbusRTUClient.holdingRegisterWrite(SERVO_ID, 0x0411, 1);  // servo-on
    out.println(w ? "  write C04.11=1 (SON) -> ACK" : "  write C04.11=1 (SON) -> FAIL");
    out.println("  (all NO REPLY/FAIL => wiring/power/baud/ID; some OK => register-level issue)");
    return;
  }
  if (lc == "selftest") {
    if (processState == ST_RUNNING) { out.println("ERR busy - not during a cycle"); return; }  // re-scans servo bauds; would disrupt a live sweep
    out.println("===== SELF TEST =====");
    out.print("RTD: raw="); out.print(analogRead(PIN_RTD_ANALOG));
    out.print(" V="); out.print(readRtdVolts(),2);
    out.print(" C="); out.print(readTempC(),1);
    out.print(" F="); out.println(readTempF());
    out.print("Display link: "); out.println(displayClient.connected()?"CONNECTED":"down");
    out.println("Tip Charger: sent 'PING!' on Serial2 (any reply shows as [TIP RX])");
    TIP_SERIAL.println("PING!");
    out.print("Inputs: home="); out.print(digitalRead(PIN_HOME_SWITCH));
    out.print(" frontLimit="); out.print(digitalRead(PIN_FRONT_LIMIT));
    out.print(" actUpFB="); out.print(digitalRead(PIN_ACTUATOR_UP_FB));
    out.print(" actDnFB="); out.println(digitalRead(PIN_ACTUATOR_DN_FB));
    out.print("Relay pins: actuator="); out.print(digitalRead(PIN_ACTUATOR_DOWN));
    out.print(" fan="); out.print(digitalRead(PIN_FAN_ON));
    out.print(" plasmaReq="); out.println(digitalRead(PIN_PLASMA_ON));
    out.println("Servo baud scan (ID 1):");
    uint32_t bauds[] = {9600,19200,38400,57600,115200};
    bool found = false;
    for (uint8_t i=0;i<5;i++) {
      uint32_t b = bauds[i];
      ModbusRTUClient.end(); RS485.end();
      float bit=1.0f/(float)b; int d=(int)(bit*9.6f*3.5f*1e6f);
      RS485.begin(b); RS485.setDelays(d,d);
      ModbusRTUClient.begin(b, SERIAL_8N1); ModbusRTUClient.setTimeout(300);
      delay(60);
      long v = ModbusRTUClient.holdingRegisterRead(SERVO_ID, 0x410A);
      out.print("  "); out.print(b); out.print(" -> ");
      out.println(v>=0 ? ("REPLY status="+String(v)) : String("no reply"));
      if (v>=0) found = true;
    }
    ModbusRTUClient.end(); RS485.end();
    RS485.begin(SERVO_BAUD); ModbusRTUClient.begin(SERVO_BAUD, SERIAL_8N1); ModbusRTUClient.setTimeout(500);
    out.println(found ? "Servo: FOUND (use the baud above)" : "Servo: NO reply at any baud -> drive power or A/B wiring");
    out.println("===== END =====");
    return;
  }
  if (lc == "save")  { saveConfig(); savePositions(); saveLem(); out.println("OK saved"); return; }
  // (the guarded 'reboot' handler is below - it refuses mid-cycle; no unguarded duplicate here)

  // ---- LEM power sensing: live read + calibration ----
  if (lc == "power" || lc == "lem") {
    out.println("OK VOLTS=" + String(readLineVolts(),1) + " AMPS=" + String(readLineAmps(),2) +
                " WATTS=" + String(readWatts(),0) + " PLASMA=" + String(plasmaIsOn()?1:0));
    return;
  }
  if (lc == "lemraw") {   // calibration aid: raw counts + input volts on both channels
    out.println("V: raw=" + String(analogRead(PIN_LEM_VOLTAGE)) + " in=" + String(lemInputVolts(PIN_LEM_VOLTAGE),3) + "V" +
                "  I: raw=" + String(analogRead(PIN_LEM_CURRENT)) + " in=" + String(lemInputVolts(PIN_LEM_CURRENT),3) + "V");
    out.println("cal: vScale=" + String(LEM_V_SCALE,4) + " vOffset=" + String(LEM_V_OFFSET,4) +
                " iScale=" + String(LEM_I_SCALE,4) + " iOffset=" + String(LEM_I_OFFSET,4));
    return;
  }
  if (lc.startsWith("setvscale "))  { LEM_V_SCALE  = arg.toFloat(); saveLem(); out.println("OK vScale="  + String(LEM_V_SCALE,4));  return; }
  if (lc.startsWith("setvoffset ")) { LEM_V_OFFSET = arg.toFloat(); saveLem(); out.println("OK vOffset=" + String(LEM_V_OFFSET,4)); return; }
  if (lc.startsWith("setiscale "))  { LEM_I_SCALE  = arg.toFloat(); saveLem(); out.println("OK iScale="  + String(LEM_I_SCALE,4));  return; }
  if (lc.startsWith("setioffset ")) { LEM_I_OFFSET = arg.toFloat(); saveLem(); out.println("OK iOffset=" + String(LEM_I_OFFSET,4)); return; }

  if (lc.startsWith("setwsip "))   { IPAddress ip; if(parseIpChecked(arg,ip)){ if(ip==SERVO_ETH_IP && WAVESHARE_PORT==SERVO_ETH_PORT){ out.println("ERR that endpoint is the SERVO bridge (RS485-to-ETH). The display must use its OWN RS232-to-ETH bridge: sharing one endpoint would interleave the display's ASCII stream with binary Modbus frames and corrupt both."); return; } WAVESHARE_IP=ip; saveConfig(); displayClient.stop(); out.println("OK waveshareIP="+arg+" (reconnecting)"); } else out.println("ERR bad IP"); return; }
  if (lc.startsWith("setwsport "))  { long v=arg.toInt(); if(v>0&&v<=65535){ if((uint16_t)v==SERVO_ETH_PORT && WAVESHARE_IP==SERVO_ETH_IP){ out.println("ERR that would put the display on the SAME endpoint as the servo bridge - the two Waveshare streams must stay separate."); return; } WAVESHARE_PORT=(uint16_t)v; saveConfig(); displayClient.stop(); out.println("OK wavesharePort="+arg);} else out.println("ERR bad port"); return; }
  // ---- servo over the SECOND Waveshare (RS485-to-ETH), separate socket/IP from the display ----
  if (lc.startsWith("setservoip "))   { IPAddress ip; if(parseIpChecked(arg,ip)){ if(ip==WAVESHARE_IP && SERVO_ETH_PORT==WAVESHARE_PORT){ out.println("ERR that endpoint is the DISPLAY bridge (RS232-to-ETH). The servo must use its OWN RS485-to-ETH bridge: sharing one endpoint would interleave binary Modbus frames with the display's ASCII stream and corrupt both."); return; } SERVO_ETH_IP=ip; saveServoNet(); servoClient.stop(); servoEthNextTry=0; out.println("OK servoEthIP="+arg+(servoOverEth?" (reconnecting)":" (saved; 'servoeth on' to use)")); } else out.println("ERR bad IP"); return; }
  if (lc.startsWith("setservoport ")) { long v=arg.toInt(); if(v>0&&v<=65535){ if((uint16_t)v==WAVESHARE_PORT && SERVO_ETH_IP==WAVESHARE_IP){ out.println("ERR that would put the servo on the SAME endpoint as the display bridge - the two Waveshare streams must stay separate."); return; } SERVO_ETH_PORT=(uint16_t)v; saveServoNet(); servoClient.stop(); servoEthNextTry=0; out.println("OK servoEthPort="+arg);} else out.println("ERR bad port"); return; }
  if (lc == "servoeth on")  { if(SERVO_ETH_IP==WAVESHARE_IP && SERVO_ETH_PORT==WAVESHARE_PORT){ out.println("ERR servo endpoint is the DISPLAY bridge - set a distinct 'setservoip' first, or the Modbus and display streams would share one socket."); return; } servoOverEth=true;  saveServoNet(); servoEthNextTry=0; ModbusRTUClient.end(); RS485.end(); out.println("OK servo transport = RS485-over-Ethernet (connecting to the bridge)"); return; }
  if (lc == "servoeth off") { servoOverEth=false; saveServoNet(); servoClient.stop(); RS485.begin(SERVO_BAUD); { float bit=1.0f/(float)SERVO_BAUD; int d=(int)(bit*9.6f*3.5f*1e6f); RS485.setDelays(d,d); }  /* FIX: setup() sets these ~3.5-char-time pre/post delays; switching back to native RS485 at runtime skipped them, leaving RTU framing tighter than the drive expects */ ModbusRTUClient.begin(SERVO_BAUD, SERIAL_8N1); ModbusRTUClient.setTimeout(500); out.println("OK servo transport = native RS485 (Serial1)"); return; }
  if (lc == "tempguard on")  { tempGuard=true;  saveServoNet(); out.println("OK electrode temp SENSOR-FAULT guard ON (implausible RTD reading during plasma now faults instead of reading as 0 C)"); return; }
  if (lc == "tempguard off") { tempGuard=false; saveServoNet(); out.println("OK temp sensor-fault guard OFF - WARNING: a dead RTD reads 0 V = 0 C, so electrode OVER-TEMP protection is fail-open. Bench use only."); return; }
  if (lc == "tempguard") { out.print("Temp sensor-fault guard: "); out.print(tempGuard?"ON":"OFF (fail-open - enable before shipping)"); out.print("  RTD="); out.print(readRtdVolts(),2); out.print("V "); out.print(readTempC(),1); out.print("C"); if(rtdImplausible()) out.print("  [IMPLAUSIBLE - sensor looks dead/shorted]"); out.println(); return; }
  if (lc == "servoeth" || lc == "servostat") { out.print("Servo transport: "); out.print(servoOverEth?"RS485-over-ETH ":"native RS485 "); if(servoOverEth){ out.print(SERVO_ETH_IP); out.print(":"); out.print(SERVO_ETH_PORT); out.print(servoClient.connected()?" CONNECTED":" (down)"); } out.println(); return; }
  if (lc.startsWith("setoptaip "))  { IPAddress ip; if(parseIpChecked(arg,ip)){ OPTA_IP=ip; saveConfig(); out.println("OK optaIP="+arg+" (reboot to apply)"); } else out.println("ERR bad IP"); return; }
  if (lc.startsWith("setapiport ")) { long v=arg.toInt(); if(v>0&&v<=65535){ API_PORT=(uint16_t)v; saveConfig(); out.println("OK apiPort="+arg+" (reboot to apply)"); } else out.println("ERR bad port"); return; }

  if (lc.startsWith("settime "))   { uint32_t v=arg.toInt(); if(v>=500&&v<=120000){ plasmaTotalTimeMs=v; savePositions(); sendTip("SETTIME " + String(v) + "!"); out.println("OK time="+String(v)); } else out.println("ERR bad time"); return; }  // also push the new plasma time to the Tip Charger (must handle SETTIME <ms>!)
  if (lc.startsWith("posdoor "))   { long v=arg.toInt(); if(v>=0&&v<=POS_MAX_TRAVEL){ POS_BEFORE_DOOR=v;  savePositions(); out.println("OK posDoor="+arg);} else out.println("ERR out of range"); return; }
  if (lc.startsWith("pos1 "))      { long v=arg.toInt(); if(v>=0&&v<=POS_MAX_TRAVEL){ POS_PLASMA_START=v; savePositions(); out.println("OK pos1="+arg);}    else out.println("ERR out of range"); return; }
  if (lc.startsWith("poslast "))   { long v=arg.toInt(); if(v>=0&&v<=POS_MAX_TRAVEL){ POS_LAST_ROW=v;     savePositions(); out.println("OK posLast="+arg);} else out.println("ERR out of range"); return; }
  if (lc.startsWith("setserial "))  { stationSerial = arg.toInt(); saveSerial(); out.println("OK serial=" + String(stationSerial)); return; }
  if (lc == "serial")               { out.println("OK serial=" + String(stationSerial)); return; }

  // Remote restart. A reset drives PLASMA/actuator OFF in setup() (fail-safe), so
  // this is safe from IDLE/FAULT; refused mid-cycle. Also the clean way to confirm
  // that saved settings (serial, positions, config) really survive a power cycle.
  if (lc == "reboot") {
    if (processState == ST_RUNNING) { out.println("ERR busy - cannot reboot during a cycle"); return; }
    out.println("OK rebooting..."); delay(200); NVIC_SystemReset(); return;
  }

  // Relay click test. The Opta's RELAY1 (actuator) and RELAY2 (fan) are
  // ELECTROMECHANICAL - they click audibly on each toggle. This cycles both so
  // you can confirm the relays and wiring are live. NOTE: RELAY1 actuates the
  // actuator, so only run it when that is safe. Original states are restored.
  if (lc == "clicktest") {
    if (processState == ST_RUNNING) { out.println("ERR busy - not during a cycle"); return; }
    bool fan0 = fanOnState, act0 = actuatorClosed;
    out.println("Relay click test - electromechanical relays should CLICK on each toggle:");
    // Actuator toggles go through setActuatorRelay() so the crash guard (won't CLOSE onto a plate
    // known to be outside the chamber) still applies - clicktest is runnable from IDLE/FAULT where
    // the carriage may be homed at a known-outside position.
    for (int i=0;i<4;i++){ setActuatorRelay(true);
                           out.println(plateKnownOutside() ? "  RELAY1 (actuator) held OPEN - plate outside (crash guard)" : "  RELAY1 (actuator) ON  *click*"); delay(450);
                           setActuatorRelay(false); out.println("  RELAY1 (actuator) OFF *click*"); delay(450); }
    for (int i=0;i<4;i++){ digitalWrite(PIN_FAN_ON,HIGH); out.println("  RELAY2 (fan) ON  *click*"); delay(450);
                           digitalWrite(PIN_FAN_ON,LOW);  out.println("  RELAY2 (fan) OFF *click*"); delay(450); }
    setActuatorRelay(act0);                          // restore via the guard so actuatorClosed stays consistent
    digitalWrite(PIN_FAN_ON, fan0?HIGH:LOW);
    out.println("Relay click test done. If you heard NO clicks, the coil supply/relay is the issue, not the firmware.");
    return;
  }

  // SAFETY: manual plasma/fan/actuator control is BLOCKED while a cycle is RUNNING. Otherwise a PC on
  // the Ethernet API (or the USB console) could open the chamber mid-arc, kill the exhaust fan (and
  // latch fanManualOverride so the cycle can't re-enable it), or desync the plasma flag. Mirrors the
  // display-button gate in loop(). ST_RUNNING (not !=ST_IDLE) so bench control still works from FAULT.
  if ((lc == "plasma on" || lc == "plasma off" || lc == "fan on" || lc == "fan off" || lc.startsWith("act ")) && processState == ST_RUNNING) {
    out.println("ERR busy - manual control blocked during a cycle"); return;
  }
  // Manual plasma must actually COMMAND the Tip Charger (which owns the arc), not just light the
  // indicator LED. Mirror the cycle: PLASMA_GO to fire, PLASMA_STOP to open the arc. (Before, this
  // only drove PIN_PLASMA_ON, so the LED came on but no plasma command was ever sent.)
  if (lc == "plasma on")  { setPlasma(true);  sendTip("PLASMA_GO");   out.println("OK plasma ON (manual) - PLASMA_GO sent to Tip Charger");  return; }
  if (lc == "plasma off") { setPlasma(false); sendTip("PLASMA_STOP"); out.println("OK plasma OFF (manual) - PLASMA_STOP sent to Tip Charger"); return; }
  if (lc == "fan on")     { setFan(true);  out.println("OK fan ON");  return; }
  if (lc == "fan off")    { setFan(false); out.println("OK fan OFF"); return; }
  if (lc == "act open")   { setActuatorRelay(false); out.println("OK actuator OPEN");  return; }
  if (lc == "act close")  {
    if (plateKnownOutside()) { out.println("ERR actuator CLOSE blocked - carriage is OUTSIDE the chamber (crash guard). Move the plate in first."); return; }
    setActuatorRelay(true);  out.println(currentPosKnown ? "OK actuator CLOSE" : "OK actuator CLOSE (position unknown - not homed)"); return; }

  if (lc == "abort") { abortRequested=true; setPlasma(false); sendTip("PLASMA_STOP");   // ALWAYS abort the Tip Charger (open the arc), regardless of state - not only mid-cycle
    if (processState==ST_RUNNING) faultOut("ABORT_FROM_API");
    else if (processState==ST_FAULT) { abortRequested=false; drvFaultReset(); setServoOn(true); processState=ST_IDLE; }   // re-arm the drive, like the display 'X' path
    else processState=ST_IDLE;
    out.println("OK abort"); return; }
  if (lc == "home")  { if(processState==ST_IDLE){ out.println("OK homing"); doSoftHome(); out.println("OK home done"); } else out.println("ERR busy"); return; }
  if (lc == "start") { if(processState==ST_IDLE){ out.println("OK cycle starting"); runCleaningCycle(); } else out.println("ERR busy"); return; }

  out.println("ERR unknown cmd (try 'help')");
}

// USB serial console
void serviceConsole() {
  while (DEBUG_SERIAL.available()) {
    char c = (char)DEBUG_SERIAL.read();
    if (c=='\n' || c=='\r') { if (consoleRx.length()) { processCommand(consoleRx, DEBUG_SERIAL); consoleRx=""; } }
    else { consoleRx += c; if (consoleRx.length()>80) consoleRx=""; }
  }
}

// Ethernet API server (one client at a time)
String apiRx;
unsigned long lastApiActivity = 0;
void serviceApi() {
  if (apiServer == nullptr) return;
  // Reclaim a half-open / idle client so one dead peer can't lock the API slot.
  if (apiClient && apiClient.connected() && (millis() - lastApiActivity > 60000UL)) apiClient.stop();
  if (!apiClient || !apiClient.connected()) {
    EthernetClient c = apiServer->available();
    if (c) { apiClient = c; apiRx=""; lastApiActivity = millis(); apiClient.println("OK Opta Plasma Station API - type 'help'"); }
  }
  while (apiClient && apiClient.connected() && apiClient.available()) {
    char c = (char)apiClient.read(); lastApiActivity = millis();
    if (c=='\n' || c=='\r') { if (apiRx.length()) { processCommand(apiRx, apiClient); apiRx=""; } }
    else { apiRx += c; if (apiRx.length()>80) apiRx=""; }
  }
}

// Service ALL comms channels + keep the display temp heartbeat alive. Called
// from every blocking wait inside the cycle so abort (display/API/USB/tip) is
// honored within tens of ms - the fix for the "abort dead during a cycle" bug.
void pumpServices() {
  mbed::Watchdog::get_instance().kick();                       // every in-cycle blocking wait routes through here -> watchdog stays fed during long ops
  serviceTipSerial_inline();                                   // Tip Charger: B! -> abort (guarded)
  char act = pollDisplay();                                    // 4D display (non-blocking read)
  if (act == 'X' && processState == ST_RUNNING) faultOut("ABORT_FROM_DISPLAY");
  serviceApi();                                                // Ethernet API: 'abort' -> faultOut if running
  serviceConsole();                                            // USB console: 'abort' -> faultOut if running
  streamTempOnly();                                            // keep Form4 temp fresh so it doesn't false 'comms lost'
}

// =====================================================================
// BOOT / LOOP
// =====================================================================
void setup() {
  pinMode(PIN_RS485_DE_RE, OUTPUT); digitalWrite(PIN_RS485_DE_RE, LOW);
  pinMode(PIN_SERVO_SON, OUTPUT); pinMode(PIN_SERVO_FAULT_RST, OUTPUT); pinMode(PIN_SERVO_STEP_TRIG, OUTPUT);
  pinMode(PIN_ACTUATOR_DOWN, OUTPUT); pinMode(PIN_PLASMA_ON, OUTPUT); pinMode(PIN_FAN_ON, OUTPUT);
  pinMode(PIN_LED_ACT, OUTPUT); pinMode(PIN_LED_FAN, OUTPUT);   // relay-feedback LEDs
  pinMode(PIN_HOME_SWITCH, INPUT_PULLUP); pinMode(PIN_FRONT_LIMIT, INPUT_PULLUP);
  pinMode(PIN_ACTUATOR_UP_FB, INPUT_PULLUP); pinMode(PIN_ACTUATOR_DN_FB, INPUT_PULLUP);
  digitalWrite(PIN_SERVO_SON, LOW); digitalWrite(PIN_SERVO_FAULT_RST, LOW); digitalWrite(PIN_SERVO_STEP_TRIG, LOW);
  digitalWrite(PIN_ACTUATOR_DOWN, LOW); digitalWrite(PIN_PLASMA_ON, LOW); digitalWrite(PIN_FAN_ON, HIGH);
  digitalWrite(PIN_LED_ACT, LOW); digitalWrite(PIN_LED_FAN, HIGH);   // actuator off, fan on at boot (match the relays)

  analogReadResolution(12);

  DEBUG_SERIAL.begin(9600);   // Opta USB console - whole station is 9600 8N1
  { unsigned long w = millis(); while (!DEBUG_SERIAL && (millis() - w < 4000)) delay(10); }  // catch boot log
  TIP_SERIAL.begin(TIP_BAUD);
  delay(500);
  DEBUG_SERIAL.println("\nBOOT: Opta plasma station (integrated)");
  DEBUG_SERIAL.println("Type 'help' for the interactive console.");

  kvSelfTest();       // prove/repair flash persistence BEFORE loading settings, so saves land cleanly
  loadConfig();       // network settings (may override OPTA_IP/WAVESHARE_IP)
  loadServoNet();     // servo-over-Ethernet settings (SERVO_ETH_IP/PORT + servoOverEth), own flash key
  loadPositions();
  loadLem();          // LEM voltage/current calibration
  loadSerial();       // station serial number
  if (!tempGuard) DEBUG_SERIAL.println("WARN: electrode temp SENSOR-FAULT guard is OFF - a dead/unpowered RTD reads 0 V = 0 C, so the OVER-TEMP interlock is fail-open (only the time cap remains). Run 'tempguard on' before this unit ships.");

  // ---- Servo transport ----
  // NATIVE RS485 (ArduinoModbus): initialise + probe + configure right here, so servo diagnostics
  // print even if the display link stalls.
  // Over ETHERNET none of that is possible yet: Ethernet.begin() runs BELOW this block and the bridge
  // socket is only opened by serviceServoLink() from loop(). Probing here always failed and fell into
  // faultOut("DRIVE_CONFIGURATION_FAILED"), so the first reboot after 'servoeth on' bricked the
  // station. Defer the probe/configure to the loop instead, once the link genuinely exists.
  if (!servoOverEth) {
    {
      float bit = 1.0f / (float)SERVO_BAUD;
      int   d   = (int)(bit * 9.6f * 3.5f * 1e6f);   // ~3.5 char times, microseconds
      RS485.begin(SERVO_BAUD);
      RS485.setDelays(d, d);
    }
    if (!ModbusRTUClient.begin(SERVO_BAUD, SERIAL_8N1)) {
      DEBUG_SERIAL.println("ERROR: ModbusRTUClient.begin() failed");
    }
    ModbusRTUClient.setTimeout(500);

    setServoOn(true);
    delay(200);

    // Probe the servo before configuring, so we can tell RS485-dead from config-fail.
    uint16_t st = 0, e = 0;
    if (readU16(SERVO_ID, 0x41, 0x0A, st, e)) {
      DEBUG_SERIAL.print("Servo probe OK, status="); DEBUG_SERIAL.println(st);
    } else {
      DEBUG_SERIAL.println("Servo probe: NO REPLY - check RS485 A/B, servo power, ID=1, 9600 8N1 (set the A6 drive to 9600)");
    }

    if (!configureDrive())      faultOut("DRIVE_CONFIGURATION_FAILED");
    else if (!waitServoReady()) faultOut("SERVO_NOT_READY_AFTER_BOOT");
    else                        DEBUG_SERIAL.println("Servo READY.");
  } else {
    setServoOn(true);                 // SON is a local GPIO (digitalWrite) - safe before any link is up
    servoBootConfigPending = true;    // configure as soon as serviceServoLink() has the bridge socket
    DEBUG_SERIAL.print("Servo transport = RS485-over-Ethernet ");
    DEBUG_SERIAL.print(SERVO_ETH_IP); DEBUG_SERIAL.print(":"); DEBUG_SERIAL.println(SERVO_ETH_PORT);
    DEBUG_SERIAL.println("Servo probe/configure DEFERRED until the bridge link is up (see loop).");
  }

  // ---- 4D display over Ethernet + API server (after servo, so a stalled
  //      Waveshare connect can't hide the servo status) ----
  optaInfo = boardInfo();
  if (optaInfo && optaInfo->magic == 0xB5) {
    Ethernet.begin(optaInfo->mac_address, OPTA_IP);
    delay(1200);
    DEBUG_SERIAL.print("Opta IP: "); DEBUG_SERIAL.println(Ethernet.localIP());
    apiServer = new EthernetServer(API_PORT);
    apiServer->begin();
    DEBUG_SERIAL.print("API server on port "); DEBUG_SERIAL.println(API_PORT);
    // NOTE: do NOT connect the display here - a blocking connect to an unreachable bridge
    // would freeze boot ~28s. serviceDisplayLink() brings it up from the loop (after the
    // first cadence window), so the USB status stream is live immediately for the app.
  } else {
    DEBUG_SERIAL.println("WARN: board info unreadable - display link disabled.");
  }

  // Hardware watchdog, armed last so the (bounded) boot init above can't trip it.
  // If the firmware ever hangs, the Opta resets itself; setup() drives PLASMA and
  // the actuator OFF on every boot, so a watchdog reset is the fail-safe state.
  // Fed from loop() (idle) and pumpServices() (every in-cycle blocking wait), so
  // homing, a full plasma cycle, and a ~28s display reconnect never trip it.
  // Edited by Adithya Mallela - 2026-07-17: watchdog for hang recovery.
  {
    mbed::Watchdog &wd = mbed::Watchdog::get_instance();
    uint32_t to = wd.get_max_timeout();
    if (to == 0 || to > 32000) to = 32000;   // STM32H7 IWDG max ~32.7s; leaves margin over the 28s connect
    if (wd.start(to)) { DEBUG_SERIAL.print("Watchdog armed ("); DEBUG_SERIAL.print(to); DEBUG_SERIAL.println(" ms)."); }
    else DEBUG_SERIAL.println("WARN: watchdog failed to start");
  }

  sendTip("READY!");
  DEBUG_SERIAL.println("System ready (or in FAULT - see above).");
}

void loop() {
  mbed::Watchdog::get_instance().kick();   // idle heartbeat - fed every loop; a real hang stops this and resets the Opta
  serviceTipSerial_inline();
  serviceDisplayLink();
  serviceServoLink();   // keep the servo's RS485-to-ETH bridge socket up (only when servoOverEth; own socket)
  serviceConsole();      // USB serial interactive console
  serviceApi();          // Ethernet API commands from a PC
  char act = pollDisplay();

  // Form4 buttons / manual controls (only when idle, except abort)
  if (act == 'X') {
    setPlasma(false);
    sendTip("PLASMA_STOP");   // HIGH FIX 2026-07-19: ALWAYS command the Tip Charger to open the arc,
                              // regardless of state (mirror the API 'abort' at line ~1110). setPlasma(false)
                              // only toggles local pins; at IDLE/FAULT a manually-struck arc ('plasma on')
                              // used to keep burning up to ~2 min on the Tip Charger's own timer after ABORT.
    if (processState==ST_RUNNING) faultOut("ABORT_FROM_DISPLAY");
    else if (processState==ST_FAULT) { abortRequested=false; drvFaultReset(); setServoOn(true); processState=ST_IDLE; reportInfo("fault acknowledged"); }
  }
  // Start Clean only from IDLE...
  if (act == 'S') {
    if (processState == ST_IDLE) { sendTip("ACK! START(disp)"); runCleaningCycle(); }
    else sendTip("ERR! START-BLOCKED not idle");
  }
  // ...but manual fan/actuator work in IDLE *and* FAULT (blocked only during a running cycle), so
  // the display's Fan/Actuator buttons are NOT dead while a servo fault holds the unit in ST_FAULT.
  if (processState != ST_RUNNING) {
    if (act == 'O') setActuatorRelay(false);   // actuator open (manual)
    if (act == 'C') { if (!plateKnownOutside()) setActuatorRelay(true);   // crash guard: block only if plate KNOWN outside
                      else sendTip("ERR! CLOSE-BLOCKED plate outside"); }
    if (act == 'N') setFan(true);              // fan on (manual)
    if (act == 'F') setFan(false);             // fan off (manual)
  } else if (act=='O' || act=='C' || act=='N' || act=='F') {
    sendTip("ERR! MANUAL-BLOCKED cycle running");
  }

  // running-state safety checks
  if (processState == ST_RUNNING) {
    if (digitalRead(PIN_FRONT_LIMIT) == LOW) faultOut("FRONT_LIMIT_DURING_RUN");
    uint16_t s = 0;
    if (drvReadServoStatus(s) && s == 3) {
      uint16_t mcu=0,fpga=0,enc=0; drvReadMcuFault(mcu); drvReadFpgaFault(fpga); drvReadEncFault(enc);
      faultOut("SERVO_FAULT MCU=" + knownFaultText(mcu));
    }
  }

  static uint32_t lastPrint = 0;
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    uint16_t s = 0; drvReadServoStatus(s);
    DEBUG_SERIAL.print("STATE="); DEBUG_SERIAL.print(processState==ST_IDLE?"IDLE":(processState==ST_RUNNING?"RUNNING":"FAULT"));
    DEBUG_SERIAL.print(" SERVO="); DEBUG_SERIAL.print(servoStatusText(s));
    DEBUG_SERIAL.print(" TEMP_F="); DEBUG_SERIAL.print(readTempF());
    DEBUG_SERIAL.print(" POS="); DEBUG_SERIAL.print(currentPosUnits);
    DEBUG_SERIAL.print(" PLASMA="); DEBUG_SERIAL.print(plasmaIsOn()?1:0);
    DEBUG_SERIAL.print(" ACT="); DEBUG_SERIAL.print(actuatorClosed?1:0);
    DEBUG_SERIAL.print(" FAN="); DEBUG_SERIAL.print(fanOnState?1:0);
    DEBUG_SERIAL.print(" SN="); DEBUG_SERIAL.print(stationSerial);
    DEBUG_SERIAL.print(" VOLTS="); DEBUG_SERIAL.print(readLineVolts(),1);
    DEBUG_SERIAL.print(" AMPS="); DEBUG_SERIAL.print(readLineAmps(),2);
    DEBUG_SERIAL.print(" WATTS="); DEBUG_SERIAL.print(readWatts(),0);
    DEBUG_SERIAL.print(" DISP="); DEBUG_SERIAL.println(displayClient.connected()?"UP":"down");
  }
}
