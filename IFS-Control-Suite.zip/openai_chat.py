"""IFS AI answered by OpenAI - or anything that speaks OpenAI's Chat Completions API (Azure
OpenAI, LM Studio, vLLM, a lab's own gateway). The customer brings their own key and chooses the
model from what their account actually offers; nothing of Augeas's is used.

Same shape as ollama.chat: a generator of (event, payload) pairs - status, query, delta, done,
error - so the view does not know or care which provider answered.
"""
import json
import urllib.error
import urllib.request

DEFAULT_URL = "https://api.openai.com/v1"
TIMEOUT = 120.0          # a long answer streams for a while; this is the gap allowed between bytes


def _req(base, path, key, body=None, timeout=TIMEOUT):
    url = base.rstrip("/") + path
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method="POST" if data is not None else "GET",
                                 headers={"Content-Type": "application/json",
                                          "Authorization": "Bearer " + (key or "")})
    return urllib.request.urlopen(req, timeout=timeout)


def friendly(e, base=""):
    """An HTTP or network failure as a sentence with the next step in it."""
    if isinstance(e, urllib.error.HTTPError):
        msg = ""
        try:
            d = json.loads(e.read().decode("utf-8", "replace"))
            msg = (d.get("error") or {}).get("message", "") if isinstance(d.get("error"), dict) else str(d.get("error") or "")
        except Exception:
            pass
        code = e.code
        if code == 401:
            return "The key was not accepted. Check it was copied whole, and that it has not been revoked."
        if code == 403:
            return "This key is not allowed to use that model or endpoint. " + msg
        if code == 404:
            return "That model was not found on this account. Choose another from the list. " + msg
        if code == 429:
            return ("The provider refused for now: either a rate limit or the account has no credit left. "
                    + msg)
        if code >= 500:
            return "The provider is having trouble (%d). Try again in a minute." % code
        return "The provider refused the request (%d). %s" % (code, msg)
    if isinstance(e, urllib.error.URLError):
        return "Could not reach %s (%s). Check the address and this PC's internet connection." % (base or "the provider", e.reason)
    return str(e)


def models(base, key):
    """The models this key can use, for the picker. Returns (ids, error)."""
    try:
        with _req(base, "/models", key, timeout=12) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        ids = sorted({m.get("id") for m in (d.get("data") or []) if m.get("id")})
        return ids, None
    except Exception as e:
        return [], friendly(e, base)


def test(base, key, model):
    """One tiny question, so the wizard can say it works. Returns (reply, error)."""
    try:
        with _req(base, "/chat/completions", key,
                  {"model": model, "messages": [{"role": "user", "content": "Reply with the single word OK."}]},
                  timeout=60) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        txt = ((d.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        return txt.strip() or "(empty reply)", None
    except Exception as e:
        return None, friendly(e, base)


def _as_tools(tools):
    out = []
    for t in tools:
        if t.get("type"):                    # mcp_toolset: an Anthropic server-side feature
            continue
        out.append({"type": "function", "function": {
            "name": t["name"], "description": t.get("description", ""),
            "parameters": t.get("input_schema", {"type": "object", "properties": {}})}})
    return out


def chat(base, key, model, system, messages, tools, run_tool, max_steps=24):
    """Stream a turn with tool use. `messages` is plain user/assistant text; tool rounds live only
    in this call (the caller keeps plain history). run_tool(name, args) -> (text, is_error)."""
    wire = [{"role": "system", "content": system}] + [dict(m) for m in messages]
    otools = _as_tools(tools)
    for step in range(max_steps):
        yield ("status", "Reading the history" if step == 0 else "Thinking")
        body = {"model": model, "messages": wire, "stream": True}
        if otools:
            body["tools"] = otools
        try:
            resp = _req(base, "/chat/completions", key, body)
        except Exception as e:
            yield ("error", friendly(e, base))
            return
        text, calls = "", {}
        try:
            for raw in resp:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    d = json.loads(data)
                except Exception:
                    continue
                if d.get("error"):
                    err = d["error"]
                    yield ("error", err.get("message", str(err)) if isinstance(err, dict) else str(err))
                    return
                for ch in d.get("choices") or []:
                    delta = ch.get("delta") or {}
                    piece = delta.get("content") or ""
                    if piece:
                        text += piece
                        yield ("delta", piece)
                    for tc in delta.get("tool_calls") or []:
                        c = calls.setdefault(tc.get("index", 0), {"id": "", "name": "", "args": ""})
                        if tc.get("id"):
                            c["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name"):
                            c["name"] += fn["name"]
                        if fn.get("arguments"):
                            c["args"] += fn["arguments"]
        except Exception as e:
            yield ("error", "The answer was cut off: %s" % e)
            return
        finally:
            try:
                resp.close()
            except Exception:
                pass

        assistant = {"role": "assistant", "content": text or None}
        if calls:
            assistant["tool_calls"] = [
                {"id": c["id"] or "call_%d" % i, "type": "function",
                 "function": {"name": c["name"], "arguments": c["args"] or "{}"}}
                for i, c in sorted(calls.items())]
        wire.append(assistant)
        if not calls:
            yield ("done", {"in": 0, "out": 0})
            return
        for tc in assistant["tool_calls"]:
            name = tc["function"]["name"]
            try:
                args = json.loads(tc["function"]["arguments"] or "{}")
                if not isinstance(args, dict):
                    args = {}
            except Exception:
                args = {}
            data_tool = name in ("read_sql", "station_numbers", "station_findings")
            yield ("status", "Querying the history" if data_tool else "Changing the view")
            result, err = run_tool(name, args)
            if data_tool:
                yield ("query", {"sql": args.get("sql", name), "rows": 0 if err else result.count("},"),
                                 "error": result if err else None})
            wire.append({"role": "tool", "tool_call_id": tc["id"], "content": result})
    yield ("error", "Gave up after %d steps without reaching an answer." % max_steps)
