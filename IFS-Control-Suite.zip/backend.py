﻿"""
Plasma Knife Control Center - local backend
Augeas Technologies, in collaboration with IonField Systems.

Edited by Adithya Mallela - 2026-07-17 00:09.
  Station-wide 9600 baud, auto-connect/reconnect, display firmware push,
  display telemetry CSV decode (Power,Temp,Vacuum) for the Data Log.

Runs a small local web server that the branded UI (served in the browser)
talks to. Bridges the browser to the Opta over EITHER USB-serial OR Ethernet
(the Opta's TCP API on :8080), streams the serial monitor live via SSE, and
drives OTA firmware flashing through arduino-cli / dfu-util.

No end-user setup: packaged as Plasma Knife.exe with PyInstaller.
"""
import atexit
import os, sys, time, json, glob, queue, socket, struct, threading, subprocess, webbrowser

import hashlib
import hmac
import uuid
from collections import deque

from flask import Flask, request, Response, jsonify, send_from_directory, abort
import serial, serial.tools.list_ports

# ------------------------------------------------------------------ paths
def resource_base():
    if getattr(sys, "frozen", False):        # PyInstaller onefile
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))

BASE     = resource_base()
STATIC   = os.path.join(BASE, "static")
FIRMWARE = os.path.join(BASE, "firmware")

# IFS Suite Pro licence checking. Imported from beside this file rather than from whatever the
# working directory happens to be, so a dev run, the frozen exe and the embeddable bundle all
# resolve the same module.
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
if BASE not in sys.path:
    sys.path.insert(0, BASE)
import licence
import insight
import ollama
import openai_chat
APP_PORT = 8765
# Keep child console tools (adb, dfu-util, arduino-cli) from flashing a console
# window in the windowed (native-shell) build.
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# ------------------------------------------------------------------ platform
# One codebase, two desktops. Everything Windows-specific stays exactly as it was; the macOS
# branches below are only ever taken on a Mac. See docs/MACOS.md for the full audit.
IS_WIN = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"
# A Mac App Store build runs inside the App Sandbox, and macOS tells every sandboxed process so
# through this variable. No self-update, no helpers from outside the bundle, no folders the
# operator has not chosen in a Finder panel.
IS_MAS = IS_MAC and bool(os.environ.get("APP_SANDBOX_CONTAINER_ID"))


def _user_data_root():
    """Where this user's settings, history and licence live. Windows: %LOCALAPPDATA%, as it always
    has been. macOS: ~/Library/Application Support (inside the sandbox container on a store build,
    which macOS arranges by pointing HOME into the container)."""
    if IS_MAC:
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support")
    return os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or os.path.expanduser("~")


def _reveal(path):
    """Show a folder to the operator: Explorer on Windows, Finder on a Mac. Best effort."""
    try:
        if IS_MAC:
            try:
                # NSWorkspace works inside the App Sandbox, where spawning /usr/bin/open may not.
                from AppKit import NSWorkspace
                from Foundation import NSURL
                if NSWorkspace.sharedWorkspace().openURL_(NSURL.fileURLWithPath_(path)):
                    return
            except Exception:
                pass
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["explorer", os.path.normpath(path)])
    except Exception:
        pass


# A packaged Mac app has no system CA bundle that Python's OpenSSL can find, so every https
# call outside _ota_open (fleet, licence activation, AI providers) would fail verification.
# Point OpenSSL at certifi's public roots. Verification stays ON; this only gives it roots.
if IS_MAC and not os.environ.get("SSL_CERT_FILE"):
    try:
        import certifi
        os.environ["SSL_CERT_FILE"] = certifi.where()
    except Exception:
        pass

# Python's mimetypes reads /etc/apache2/mime.types the first time a file is served. The App
# Sandbox refuses that read, and the very first page request then fails with a 500. Python's
# built-in table covers everything the UI serves (.html .js .css .png .svg .json), so use only it.
if IS_MAC:
    import mimetypes
    mimetypes.knownfiles = []     # init() always adds these system files, even when given files=[]
    try:
        mimetypes.init()
    except Exception:
        pass

# The serial-port names operators are told to look for in error messages.
if IS_MAC:
    OPTA_PORT_HINT = "usually /dev/cu.usbmodem..."
    DISP_PORT_HINT = "usually /dev/cu.SLAB_USBtoUART or /dev/cu.usbserial-..."
else:
    OPTA_PORT_HINT = "usually COM16"
    DISP_PORT_HINT = "usually COM17"

def _boot_log(msg):
    # Records how far startup got, so a relaunch that "starts but never serves" is diagnosable.
    try:
        d = _user_data_root()
        p = os.path.join(d, "IonField", "IFS"); os.makedirs(p, exist_ok=True)
        with open(os.path.join(p, "boot_diag.log"), "a") as f:
            f.write("%s  pid=%s  %s\n" % (time.strftime("%H:%M:%S"), os.getpid(), msg))
    except Exception: pass
_boot_log("imports done; argv=%r cwd=%r frozen=%s" % (sys.argv, os.getcwd(), getattr(sys, "frozen", False)))

# ---- app self-update (OTA) from a PUBLIC GitHub channel --------------------
APP_VERSION  = "1.0.148"
OTA_MANIFEST = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/main/latest.json"

app = Flask(__name__, static_folder=None)

_BOOT_T0 = time.time()

# When the UI last asked this server for anything, and how many pages are holding a live stream.
# The browser fallback uses both to tell a page that has been CLOSED from one that is merely in a
# background tab, where the browser throttles or freezes timers and polling stops on its own.
_last_request_at = time.time()
_sse_clients = 0
_sse_lock = threading.Lock()


def _sse_open():
    global _sse_clients
    with _sse_lock:
        _sse_clients += 1


def _sse_close():
    global _sse_clients
    with _sse_lock:
        _sse_clients = max(0, _sse_clients - 1)


@app.before_request
def _mark_request():
    global _last_request_at
    _last_request_at = time.time()

# ------------------------------------------------------------------ security
# The app binds to 127.0.0.1, but loopback is NOT a trust boundary on its own:
# any web page (or a DNS-rebinding attack) can POST to it. Since /api/send drives
# plasma/relay hardware and /api/flash reflashes firmware, gate every request:
#   1) Host header must be loopback  -> defeats DNS-rebinding.
#   2) Mutating requests must be same-origin (Origin/Referer) -> defeats CSRF.
_ALLOWED_HOSTS = {"127.0.0.1:%d" % APP_PORT, "localhost:%d" % APP_PORT,
                  "127.0.0.1", "localhost"}
def _host_of(url):
    try:
        from urllib.parse import urlparse
        return (urlparse(url).hostname or "")
    except Exception:
        return ""
@app.before_request
def _guard():
    if (request.host or "") not in _ALLOWED_HOSTS:
        abort(403)                                   # DNS-rebinding / wrong Host
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        origin = request.headers.get("Origin") or request.headers.get("Referer")
        if origin and _host_of(origin) not in ("127.0.0.1", "localhost"):
            abort(403)                               # cross-site CSRF
    # A GET can still have side effects here - asking the assistant is one, because EventSource
    # can only GET. Browsers label every request with where it came from; a page on another site
    # (or another port on this machine) gets nothing. The application's own page is same-origin;
    # Python clients send no such header.
    if request.path.startswith("/api/") and \
            request.headers.get("Sec-Fetch-Site") in ("cross-site", "same-site"):
        abort(403)

# ------------------------------------------------------------------ link
def _rx_fmt(bs):
    """Bytes -> readable one-line ASCII for the monitor: printable kept as-is, newline/CR shown as
    \\n/\\r, everything else hex-escaped. Keeps binary framing legible without wrapping the log."""
    return "".join((chr(b) if 32 <= b < 127 else ("\\n" if b == 10 else ("\\r" if b == 13 else "\\x%02X" % b))) for b in bs)


class Link:
    """One connection to the Opta - serial or tcp - with a reader thread that
       fans out newline-delimited lines to SSE subscribers + a ring buffer."""
    def __init__(self, raw=False):
        self.mode = None            # 'serial' | 'tcp' | None
        self.ser = None
        self.sock = None
        self.connected = False
        self.info = ""
        self.gen = 0                # generation: each reader captures its own; disconnect bumps it
        self.reader = None
        self.buffer = deque(maxlen=3000)
        self.subs = []
        self.last_status = {}
        self.status_at = 0.0        # when last_status was last refreshed by the device
        self.last_rx = 0.0          # wall time of the last REAL device byte (0 = none yet)
        self.lock = threading.RLock()
        self.raw = raw              # raw=True: emit received bytes as hex (binary Genie), no line-split
        self.last_csv = {}          # latest decoded "Power,Temp,Vacuum" from the StandAlone display
        self._csvbuf = b""
        self.quiet = False          # an internal exchange is in progress: keep it out of the console
        self.rx_bytes = 0           # bytes received / sent on this link, for the live traffic rate
        self.tx_bytes = 0
        self.pushed = {"params": None, "popup": None, "teach": None, "run": None, "unit": None, "t": 0.0}   # state the tablet pushed (2.06+)
        self._rawbuf = b""          # reassembles raw-monitor lines so a CSV split across two reads ("0" + ",50,0\n") shows as ONE "RX 0,50,0", not a phantom "missed zero"

    def connect_serial(self, port, baud=9600):   # whole IonField station is 9600 8N1
        with self.lock:
            self._disconnect_locked()
            self.ser = serial.Serial(port, baud, timeout=0.15)
            self.mode = "serial"; self.info = "%s @ %d" % (port, baud)
            self._start_locked()

    def connect_tcp(self, host, port=8080):
        with self.lock:
            self._disconnect_locked()
            self.sock = socket.create_connection((host, int(port)), timeout=5)
            self.sock.settimeout(0.15)
            # keepalive so a dead/half-open peer (pulled cable, powered-off bridge)
            # gets RST'd by the OS instead of sitting "connected" for hours.
            try:
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                if hasattr(self.sock, "ioctl") and hasattr(socket, "SIO_KEEPALIVE_VALS"):
                    self.sock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 8000, 2000))  # on, 8s idle, 2s interval
            except (AttributeError, OSError): pass
            self.mode = "tcp"; self.info = "%s:%s" % (host, port)
            self.host = host; self.port = int(port)   # remembered so a link can reconnect-cycle itself (clears a stale Waveshare client slot)
            self._start_locked()

    def rx_age(self):
        return (time.time() - self.last_rx) if self.last_rx else None

    def _start_locked(self):
        self.gen += 1; mygen = self.gen; self.connected = True; self.last_rx = 0.0
        self.reader = threading.Thread(target=self._loop, args=(mygen,), daemon=True)
        self.reader.start()
        self._emit("[app] connected to %s (%s)" % (self.info, self.mode))

    def _loop(self, mygen):
        buf = b""
        errs = 0                       # consecutive read errors (a serial hiccup must NOT drop the link)
        while True:
            # capture handles under lock; if our generation is stale, exit (a
            # newer connection owns the port now) - no shared stop flag to race.
            with self.lock:
                if self.gen != mygen: break
                ser, sock, mode = self.ser, self.sock, self.mode
            try:
                if mode == "serial":
                    data = ser.read(256) if ser else b""
                elif mode == "tcp":
                    # A TCP recv() of 0 bytes is an orderly peer close (FIN/EOF) - NOT a
                    # timeout. Treat it as a disconnect so the link can't stay "connected"
                    # forever after the Opta/bridge/adb-tunnel drops the socket.
                    try:
                        data = sock.recv(256) if sock else b""
                        if sock is not None and data == b"":
                            raise ConnectionError("peer closed the connection")
                    except socket.timeout:
                        data = b""
                else:
                    data = b""
                if data: self.rx_bytes += len(data)
                errs = 0                            # a completed read (even 0 bytes) proves the port is alive
                if data:
                    self.last_rx = time.time()      # a real device byte arrived
                    if self.raw:
                        # Show readable ASCII (the StandAlone display speaks ASCII, e.g. "0,50,0", "SN=42",
                        # "W040"). REASSEMBLE by newline first: the display's CSV frame often arrives split
                        # across two USB reads ("0" then ",50,0\n"), and emitting each read as its own "RX"
                        # line makes it look like a digit was dropped. Buffer until '\n' so each frame shows
                        # as ONE line; flush any newline-less binary once it passes a small cap.
                        self._rawbuf += data
                        while b"\n" in self._rawbuf:
                            rline, self._rawbuf = self._rawbuf.split(b"\n", 1)
                            self._emit("RX " + _rx_fmt(rline))
                        if len(self._rawbuf) > 240:
                            self._emit("RX " + _rx_fmt(self._rawbuf)); self._rawbuf = b""
                        self._parse_csv(data)   # also decode the display's ASCII "Power,Temp,Vacuum" telemetry
                    else:
                        buf += data
                        while b"\n" in buf:
                            line, buf = buf.split(b"\n", 1)
                            self._emit(line.decode("utf-8", "replace").rstrip("\r"))
                else:
                    time.sleep(0.02)
            except Exception as e:
                # A single serial read hiccup (CP210x/USB latency, a brief driver stall while we're
                # also writing W frames) must NOT tear the link down: dropping it triggers the
                # auto-reconnect, whose 4D-UPA DTR pulse RESETS the panel (the "screen reset" the
                # operator sees) and loses the in-flight setting. Tolerate a short burst of
                # consecutive serial errors and retry; only give up if the port is genuinely gone
                # (unplugged -> every read raises -> we still bail in ~0.4 s). TCP errors (real peer
                # close / RST) still drop immediately - a socket doesn't get transient read faults.
                errs += 1
                if mode == "serial" and errs < 8:
                    time.sleep(0.05)
                    continue
                with self.lock:
                    if self.gen == mygen:           # only our own live connection reports closure
                        self._emit("[app] link closed: %s" % e)
                        self.connected = False; self.mode = None; self.last_status = {}
                        for x in ("ser", "sock"):    # release the handle (frees COM / bridge slot)
                            obj = getattr(self, x)
                            try:
                                if obj: obj.close()
                            except Exception: pass
                            setattr(self, x, None)
                break

    def _emit(self, line):
        item = {"t": time.time(), "line": line}
        # The tablet pushes its state when it changes ("[PARAMS] k=v ...", "[POPUP] title"); that
        # is for IFS, not for the operator's console. Internal exchanges are hidden the same way -
        # but a real alert always shows.
        if "[PARAMS]" in line or "[POPUP]" in line or "[TEACH]" in line or "[RUN]" in line or "[UNIT]" in line:
            self._take_push(line)
            item["q"] = True
        elif "TEACH KEEP" in line or "OK TEACH HOLDING" in line or "OK TEACH IDLE" in line:
            item["q"] = True            # a held continuous move says "still held" 4 times a second
        elif self.quiet and "[ALERT]" not in line:
            item["q"] = True
        self.buffer.append(item)
        self._parse_status(line)
        for q in list(self.subs):
            try: q.put_nowait(item)
            except Exception: pass

    def _take_push(self, line):
        try:
            clean = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", line).strip()
            if "[PARAMS]" in clean:
                vals = {}
                for tok in clean.split("[PARAMS]", 1)[1].split():
                    if "=" in tok:
                        k, v = tok.split("=", 1); vals[k.strip()] = v.strip()
                if vals:
                    self.pushed["params"] = vals; self.pushed["t"] = time.time()
            elif "[RUN]" in clean or "[UNIT]" in clean:
                from urllib.parse import unquote_plus
                tag = "[RUN]" if "[RUN]" in clean else "[UNIT]"
                t = {}
                for tok in clean.split(tag, 1)[1].split():
                    if "=" in tok:
                        k, v = tok.split("=", 1); t[k.strip()] = unquote_plus(v.strip())
                self.pushed["run" if tag == "[RUN]" else "unit"] = t; self.pushed["t"] = time.time()
            elif "[TEACH]" in clean:
                from urllib.parse import unquote_plus
                t = {}
                for tok in clean.split("[TEACH]", 1)[1].split():
                    if "=" in tok:
                        k, v = tok.split("=", 1)
                        t[k.strip()] = unquote_plus(v.strip()) if k.strip() in ("name", "next", "mode") else v.strip()
                self.pushed["teach"] = t; self.pushed["t"] = time.time()
            elif "[POPUP]" in clean:
                self.pushed["popup"] = clean.split("[POPUP]", 1)[1].strip() or "popup"
                self.pushed["t"] = time.time()
        except Exception:
            pass

    def _parse_status(self, line):
        # STATE=IDLE SERVO=READY TEMP_F=72 DISP=UP  -> dict for the dashboard.
        # Never parse our OWN echoes/app lines ("> cmd", "TX/RX hex", "[app] ...") as device
        # telemetry, or a typed command like "> set SERVO=off" would clobber last_status.
        if line[:2] == "> " or line.startswith("TX ") or line.startswith("RX ") or line.startswith("[app]"):
            return
        if line.startswith("STATE=") or " SERVO=" in line:
            d = {}
            for tok in line.split():
                if "=" in tok:
                    k, v = tok.split("=", 1); d[k] = v
            if d: self.last_status = d; self.status_at = time.time()

    def _parse_csv(self, data):
        # The Plasma StandAlone display streams "Power,Temp,Vacuum\n" ASCII (e.g. "0,50,0").
        # Decode it (alongside the hex monitor) so the Data Log can chart real power/temp/vac.
        try:
            self._csvbuf += data
            while b"\n" in self._csvbuf:
                raw, self._csvbuf = self._csvbuf.split(b"\n", 1)
                s = raw.decode("ascii", "ignore").strip()
                if s.startswith("SN="):                       # display serial number line
                    try: self.last_csv["serial"] = int(s[3:].strip())
                    except Exception: pass
                    continue
                if s.startswith("CFG,"):                       # settings snapshot the display emits at boot
                    cf = s[4:].split(",")                      # CFG,pumpOn,pumpOff,plasmaTime,coolTime,brightness
                    # strict isdigit() (not lstrip('-').isdigit()): CFG values are always non-negative, and
                    # this rejects '-5' (unclamped negative) and '--5' (passed the old guard but int() raised,
                    # and the bare except flushed the whole buffer, dropping a valid CSV line behind it).
                    if len(cf) == 5 and all(p.strip().isdigit() for p in cf):
                        self.last_csv["settings"] = {
                            "pumpOn": int(cf[0]), "pumpOff": int(cf[1]), "plasmaTime": int(cf[2]),
                            "coolTime": int(cf[3]), "brightness": int(cf[4]), "t": time.time(),
                        }
                    continue
                parts = s.split(",")
                if len(parts) == 3 and all(p.strip().lstrip("-").isdigit() for p in parts):
                    self.last_csv["power"] = int(parts[0]); self.last_csv["temp"] = int(parts[1])
                    self.last_csv["vac"] = int(parts[2]); self.last_csv["t"] = time.time()
            if len(self._csvbuf) > 512: self._csvbuf = b""   # never grow unbounded on garbage
        except Exception:
            self._csvbuf = b""

    def send(self, text, quiet=False):
        with self.lock:
            if not self.connected: raise RuntimeError("not connected")
            data = (text.rstrip("\n") + "\n").encode()
            ser, sock, mode = self.ser, self.sock, self.mode
        if mode == "serial" and ser: ser.write(data)
        elif mode == "tcp" and sock: sock.sendall(data)
        else: raise RuntimeError("not connected")
        self.tx_bytes += len(data)
        if not quiet:
            self._emit("> " + text)

    def send_raw(self, data):
        with self.lock:
            if not self.connected: raise RuntimeError("not connected")
            ser, sock, mode = self.ser, self.sock, self.mode
        if mode == "serial" and ser: ser.write(data)
        elif mode == "tcp" and sock: sock.sendall(data)
        else: raise RuntimeError("not connected")
        self._emit("TX " + "".join((chr(b) if 32 <= b < 127 else ("\\n" if b == 10 else ("\\r" if b == 13 else "\\x%02X" % b))) for b in data))   # readable ASCII (e.g. "W040", "A!", "N42")

    def subscribe(self):
        q = queue.Queue(maxsize=2000); self.subs.append(q); return q
    def unsubscribe(self, q):
        try: self.subs.remove(q)
        except Exception: pass

    def disconnect(self):
        with self.lock:
            self._disconnect_locked()

    def _disconnect_locked(self):
        self.pushed = {"params": None, "popup": None, "teach": None, "run": None, "unit": None, "t": 0.0}
        self.gen += 1                       # invalidate any running reader
        mygen = self.gen                    # remember OUR generation so we can tell if someone reconnects during the join
        prev = self.reader; self.reader = None
        for x in ("ser", "sock"):
            obj = getattr(self, x)
            try:
                if obj: obj.close()
            except Exception: pass
            setattr(self, x, None)
        self.connected = False; self.mode = None
        self.last_status = {}; self.last_rx = 0.0; self.last_csv = {}; self._csvbuf = b""; self._rawbuf = b""   # don't leave frozen values on the dashboard
        # join outside the lock so the reader (which grabs the lock) can exit
        if prev and prev.is_alive() and prev is not threading.current_thread():
            self.lock.release()
            try: prev.join(timeout=1.0)
            finally: self.lock.acquire()
            # While we had the lock released, another thread (autoconnect, or a manual /connect) could
            # have opened a FRESH connection - which bumps gen again and sets connected/mode/ser. If so,
            # the post-join clear below would wipe THEIR live link's state, leaving a running reader on
            # an open port with connected=False reported to the UI. Only finalize the clear if our
            # generation is still the current one (i.e. nobody reconnected in the window).
            if self.gen != mygen:
                return
        self.connected = False; self.mode = None

link = Link()

# A missing field used to surface as a bare KeyError repr: the operator saw {"error": "'form'"}
# and learned nothing at all. Say which thing is missing, in the words the UI uses for it, and what
# to do about it. Only the fields that are still raw are listed - the connect routes already guard
# `port` and `host` themselves, with better messages that name the expected COM port.
_FIELD_NAMES = {
    "form":     ("form number",  "Say which screen to switch to."),
    "objType":  ("object type",  "Say which kind of widget to write to."),
    "objIndex": ("object index", "Say which widget to write to."),
}
def _need(d, *fields):
    missing = [f for f in fields if d.get(f) in (None, "")]
    if not missing:
        return
    names = [_FIELD_NAMES.get(f, (f, "Fill it in and try again."))[0] for f in missing]
    what  = names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]
    how   = _FIELD_NAMES.get(missing[0], (None, "Fill it in and try again."))[1]
    raise ValueError("No %s %s given. %s" % (what, "was" if len(names) == 1 else "were", how))

# ------------------------------------------------------------------ Tip Charger (4D ViSi-Genie display)
# The Tip Charger's touch screen is a pure ViSi-Genie SLAVE (no onboard host).
# We become its host and change screens with the standard Genie WRITE_OBJ frame
# targeting the FORM object - no firmware changes on the Tip Charger.
# Reach it over Ethernet (its RS232->ETH bridge on the hub) or a USB-serial cable.
# The whole IonField station is standardized to 9600 8N1 - the Opta USB console AND the 4D
# display (USB-serial or the RS232 side of its Ethernet bridge). Single source of truth so no
# serial path can ever open a device at another baud.
DEVICE_BAUD = 9600
# A connected display/Opta streams continuously (~every 0.25-2 s). If a link stays CONNECTED but
# sends nothing for this long, the panel or the Waveshare converter has wedged - the auto-reconnect
# recovers it (reconnect-cycle / re-open) instead of leaving it sitting dead. Generous vs the normal
# stream so a brief hiccup never triggers it.
TC_STALE_RECOVER_S = 15.0
tclink = Link(raw=True)

# ------------------------------------------------------------------ Serial barcode scanner (VCP)
# A generic USB barcode scanner in SERIAL (virtual-COM) mode streams the scanned code as ASCII
# terminated by CR/LF. Most scanners ship in HID/keyboard mode, which the browser handles with zero
# setup; this path covers the ones configured (or wired) for a serial port instead. The bound port is
# EXCLUDED from device auto-connect (see _autoconnect_tick) so a CP210x/FTDI scanner is never mistaken
# for the 4D display or the Opta and driven as one.
SCANNER_PORT = None
class ScannerLink:
    def __init__(self):
        self.ser = None; self.port = None; self.baud = 9600
        self.last = ""; self.last_ts = 0.0
        self._stop = False; self._t = None; self._lock = threading.Lock()
    def connect(self, port, baud=9600):
        self.disconnect()
        self.ser = serial.Serial(port, int(baud), timeout=0.2)
        self.port = port; self.baud = int(baud); self._stop = False
        self._t = threading.Thread(target=self._loop, daemon=True); self._t.start()
        return True
    def _loop(self):
        buf = b""
        while not self._stop and self.ser:
            try: data = self.ser.read(64)
            except Exception: break
            if not data: continue
            buf += data.replace(b"\r", b"\n")
            while b"\n" in buf:
                line, _, buf = buf.partition(b"\n")
                code = line.strip().decode("ascii", "ignore").strip()
                if code:
                    with self._lock: self.last = code; self.last_ts = time.time()
    def disconnect(self):
        self._stop = True
        try:
            if self.ser: self.ser.close()
        except Exception: pass
        self.ser = None; self.port = None
    def state(self):
        with self._lock:
            return {"connected": bool(self.ser), "port": self.port, "baud": self.baud,
                    "last": self.last, "ts": self.last_ts}
scanner = ScannerLink()

GENIE_WRITE_OBJ = 0x01
GENIE_OBJ_FORM  = 0x0A     # activating this object switches the displayed form/screen

def genie_write_obj(obj_type, obj_index, value):
    """Build a ViSi-Genie WRITE_OBJ frame: 0x01, type, index, val_hi, val_lo, XOR-checksum.

    Out-of-range arguments are REFUSED, not masked. This used to do `& 0xFF` / `& 0xFFFF`, which
    silently turned a request into a different one: asking for object type 300 wrote to type 44,
    index 300 wrote to index 44, and a value of -5 arrived as 65531. On the panel that owns the
    plasma relay, quietly writing a widget nobody asked for is not something to paper over - the
    caller gets an error instead, and /api/tc/write already turns that into a 400.
    """
    for name, val, hi in (("object type", obj_type, 0xFF),
                          ("object index", obj_index, 0xFF),
                          ("value", value, 0xFFFF)):
        try:
            n = int(val)
        except (TypeError, ValueError):
            raise ValueError("%s must be a whole number, got %r" % (name, val))
        if n != val and not isinstance(val, int) and float(val) != n:
            raise ValueError("%s must be a whole number, got %r" % (name, val))
        if not (0 <= n <= hi):
            raise ValueError("%s must be 0-%d, got %d" % (name, hi, n))
    v = int(value)
    body = bytes([GENIE_WRITE_OBJ, int(obj_type), int(obj_index), (v >> 8) & 0xFF, v & 0xFF])
    cks = 0
    for b in body: cks ^= b
    return body + bytes([cks])

# ---------------------------------------------------------------- request helpers
def _body():
    """The JSON body as a dict, whatever actually arrived.

    `get_json(silent=True) or {}` reads as safe and is not: a JSON *list* is truthy, so a body of
    `[1,2,3]` passes straight through and the first `.get()` raises AttributeError - an unhandled
    500 out of every endpoint that takes a body. Anything that is not an object is no body at all.
    """
    d = request.get_json(force=True, silent=True)
    return d if isinstance(d, dict) else {}


def _s(v, default=""):
    """A field as a trimmed string. Clients send numbers, nulls and lists where a string is meant;
    `(d.get(k) or "").strip()` raises on every one of those."""
    if v is None or isinstance(v, (dict, list)):
        return default
    try:
        return str(v).strip()
    except Exception:
        return default


def _i(v, default=0):
    """A field as an int, for query strings. Same reason as _s: clients send junk, and int("")
    raises on the one path that most needs not to."""
    try:
        return int(float(str(v).strip()))
    except Exception:
        return default


@app.route("/api/tc/state")
def api_tc_state():
    # Expose a data-freshness gate like /api/state does. Without it, a display that stops streaming
    # while its cable stays enumerated (panel hung, wedged on a form, or powered off behind a live
    # USB adapter) reads 'connected' forever with frozen last_csv - and since the panel OWNS the
    # plasma relay + safety-loop stream, a green 'connected' on a dead panel is dangerously misleading.
    age = tclink.rx_age()
    live = bool(tclink.connected and age is not None and age < 6.0)
    probing = _probing("tc")
    # While the port is only open to be tested, this reports NOT connected. It is the truth, and it
    # is what stops a bare adapter reading as an intermittent Tip Charger.
    return jsonify(connected=bool(tclink.connected and not probing), live=(live and not probing),
                   probing=probing, age=age,
                   mode=tclink.mode, info=tclink.info, csv=tclink.last_csv)

def _genie_read_obj(obj_type=0, obj_index=0):
    """Non-destructive Genie READ_OBJ frame: 0x00,type,index,XOR-checksum. Used to
    prove the display is really there (it answers REPORT_OBJ / ACK / NAK)."""
    t, i = int(obj_type) & 0xFF, int(obj_index) & 0xFF
    return bytes([0x00, t, i, 0x00 ^ t ^ i])

def _tc_wait_or_reset(first_wait=6.0, tries=2):
    """Wait for the display's first byte; if it stays SILENT, try to RECOVER the link and wait again
    - up to `tries` times - then give up. This is the "if the Tip Charger is down, reset it and keep
    trying to connect" recovery, and it recovers a wedged/frozen panel or a stuck converter instead
    of just failing:

      * USB serial link (4D-UPA) -> pulse a hard DTR RESET of the panel (same as /api/tc/reset).
      * Ethernet (Waveshare RS232-to-ETH converter) -> the converter has NO reset line, so instead
        we RECONNECT-CYCLE the socket: close it and reopen it. That frees and re-grabs the
        converter's single client slot, which clears the most common Ethernet failure - a stale/
        half-open connection holding the slot. (The permanent fix for that is the converter's
        'Multi-host = Yes' setting; this recovers it live without touching the converter.)

    Returns True the instant any byte arrives, else False. Safe when the panel is fine - it returns
    on the first byte and never resets."""
    def _wait(t):
        end = time.time() + t
        while time.time() < end and not tclink.last_rx:
            time.sleep(0.05)
        return bool(tclink.last_rx)
    if _wait(first_wait):
        return True
    for _ in range(max(0, tries)):
        with tclink.lock:
            mode = tclink.mode
            ser  = tclink.ser  if mode == "serial" else None
            host = getattr(tclink, "host", None); port = getattr(tclink, "port", None)
        if mode == "serial" and ser is not None:
            try:
                ser.dtr = False; time.sleep(0.25); ser.dtr = True   # hard-reset the panel
            except Exception:
                return False
        elif mode == "tcp" and host:
            try:
                tclink.disconnect(); time.sleep(0.8)                # drop the stale slot
                tclink.connect_tcp(host, port)                      # re-grab it (cycles the converter connection)
            except Exception:
                return False
        else:
            return False   # nothing we can recover
        if _wait(first_wait):
            return True
    return False

@app.route("/api/tc/connect", methods=["POST"])
def api_tc_connect():
    if flashing.is_set():
        return jsonify(ok=False, error="A firmware flash is in progress - opening a port now would interrupt it. Wait for the flash to finish."), 409
    d = _body()
    try:
        if d.get("mode") == "serial":
            if not d.get("port"): return jsonify(ok=False, error="Pick the display serial port (the CP210x / 4D-UPA, %s)." % DISP_PORT_HINT), 400
            # Clear error instead of a raw PermissionError for the common mis-click: selecting the
            # Opta's own port for the display.
            if link.connected and link.mode == "serial" and link.ser is not None and getattr(link.ser, "port", None) == d["port"]:
                return jsonify(ok=False, error="%s is the OPTA's port - it's already connected as the master. The 4D display is on a DIFFERENT port, %s (the CP210x / 4D-UPA)." % (d["port"], DISP_PORT_HINT)), 400
            try:
                tclink.connect_serial(d["port"], DEVICE_BAUD)   # the 4D display is ALWAYS 9600 8N1
            except PermissionError:
                return jsonify(ok=False, error="Could not open %s - it's in use by another connection in this app or another program (Workshop 4 / Arduino IDE / a serial terminal). Close that, or select the display's port (%s)." % (d["port"], DISP_PORT_HINT)), 400
            where = "serial port"
            _target = {"mode": "serial", "port": d["port"], "baud": DEVICE_BAUD}
        else:
            host = _s(d.get("host"), "")
            if not host: return jsonify(ok=False, error="Enter the Tip Charger bridge IP (e.g. 192.168.1.201)."), 400
            tclink.connect_tcp(host, d.get("port", 4196)); where = "bridge IP and its serial baud"
            _target = {"mode": "tcp", "host": host, "port": int(d.get("port", 4196))}
        # LISTEN-only verify: the Plasma StandAlone display streams its CSV continuously, so ANY
        # received byte proves it's alive. We do NOT poke it - the panel is listened to, not written
        # to. Wait out its reboot-on-open for the first byte; and if it's silent (wedged) on a USB
        # serial link, hard-reset it over DTR and keep trying before declaring it down.
        was_serial = (tclink.mode == "serial")
        if not _tc_wait_or_reset():
            tclink.disconnect()
            extra = (" A hardware reset was tried automatically." if was_serial
                     else " (The Ethernet bridge has no reset line - power-cycle the panel.)")
            return jsonify(ok=False, error="Link opened but the display sent nothing - check the %s, the display power, and the single-client bridge slot.%s" % (where, extra)), 400
        remember_connection("tc", _target)   # arm auto-reconnect + remember what worked
        return jsonify(ok=True, info=tclink.info, mode=tclink.mode)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/disconnect", methods=["POST"])
def api_tc_disconnect():
    set_autoconnect("tc", False)   # a manual Disconnect stays disconnected (no auto-reconnect)
    tclink.disconnect(); return jsonify(ok=True)

def _tc_is_standalone():
    # The Plasma StandAlone display STREAMS its "Power,Temp,Vacuum" CSV; a pure-Genie V18 panel
    # never does. So a populated last_csv means we're talking to the StandAlone (a custom ASCII
    # parser we wrote) and must send ONLY its native ASCII commands - NOT binary Genie frames,
    # which are just noise its one-byte-per-loop parser has to wade through.
    return bool(tclink.last_csv)

# Forms actually compiled into the Plasma StandAlone display project. Indices 5, 6, 14, 21 do NOT
# exist; activating a non-existent form indexes past the Genie form table and HARD-FAULTS the panel
# (blank/reset). Guard here too so the app can never send a crashing 'S<n>' even to a panel running
# firmware without the in-panel whitelist.
# What the display's applyWSetting will actually honour (MagicCode0.inc). The protocol editor
# reads these too, so it cannot offer a value the hardware would quietly re-clamp.
TC_PLASMA_S = (5, 30)     # selector 2, plasma time in seconds
TC_COOL_S   = (5, 30)     # selector 3, cooling time in seconds

TC_VALID_FORMS = {0,1,2,3,4,7,8,9,10,11,12,13,15,16,17,18,19,20,22,23,24,25}

# FIX 2026-07-20: this decorator was attached to _tc_is_standalone() above, so api_tc_form() was
# NEVER REGISTERED. Every POST /api/tc/form ran the predicate instead and returned a bare bool,
# which Flask rejects - HTTP 500 on every call. The Screen buttons were therefore dead in every
# shipped build, and so was the one software path for pulling a panel off a form it is stuck on.
@app.route("/api/tc/form", methods=["POST"])
def api_tc_form():
    d = _body()
    try:
        _need(d, "form")
        n = int(d["form"])
        if n not in TC_VALID_FORMS:
            return jsonify(ok=False, error="Form %d does not exist on the panel (valid: 0-4, 7-13, 15-20, 22-25). Sending it would crash the display." % n), 400
        # Send ONLY what the connected display understands - don't spray both protocols at it.
        # StandAlone (streams CSV) -> ASCII 'S<n>'; pure-Genie V18 panel -> Genie form-switch.
        if _tc_is_standalone():
            tclink.send_raw(("S%d\n" % n).encode())
        else:
            tclink.send_raw(genie_write_obj(GENIE_OBJ_FORM, n, 0))
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/plasma", methods=["POST"])
def api_tc_plasma():
    # Manual plasma request to the Plasma StandAlone display: 'A!' fires plasma (the display's
    # MagicEvent18 drives its PA11 plasma relay), 'B!' stops it. On-demand write only - the operator
    # presses the button. The display's own safety-loop gate still applies before it energizes HV.
    d = _body()
    # SAFETY FIX 2026-07-20: refuse to fire plasma while a firmware flash is running. /api/flash puts
    # the Opta MASTER into its DFU bootloader (link.disconnect()), where it runs NO interlocks / servo
    # / actuator supervision - yet tclink (the display) stays connected, so an 'A!' here would energize
    # the panel's PA11 HV relay with the master dark. The connect endpoints already 409 during a flash;
    # this HV command is the one that most needs the same guard. (Stopping plasma is always allowed.)
    if d.get("on") and flashing.is_set():
        return jsonify(ok=False, error="A firmware flash is in progress - plasma is locked out."), 409
    try:
        tclink.send_raw(b"A!" if d.get("on") else b"B!")
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/pump", methods=["POST"])
def api_tc_pump():
    # Cooling-pump control on the Plasma StandAlone display: 'b' (ASCII 98) = pump ON, 'a' (97) = pump OFF.
    # The display GATES these on Serial Control mode (SerialState==1) - if Serial Control is OFF on the
    # panel the command is simply ignored (plasma A!/B! is NOT gated and always works).
    d = _body()
    try:
        tclink.send_raw(b"b" if d.get("on") else b"a")
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/estop", methods=["POST"])
def api_tc_estop():
    # EMERGENCY STOP for tuning: cut plasma and the pump immediately, and abort the Opta master too.
    #   'B!' -> display MagicEvent18(0): drops the PA11 plasma HV relay (always honored).
    #   'a'  -> display cooling-pump OFF (ASCII 97; only acts when the panel is in Serial Control mode,
    #           otherwise harmlessly ignored - plasma still stops).
    # The display's own plasma max-on timer is the hardware backstop; this is the operator's manual cut.
    errs = []
    try: tclink.send_raw(b"B!")
    except Exception as e: errs.append("plasma:%s" % e)
    try: tclink.send_raw(b"a")
    except Exception as e: errs.append("pump:%s" % e)
    try:
        if link.connected: link.send("abort")   # Opta master abort (carriage/actuator/plasma-req)
    except Exception as e: errs.append("opta:%s" % e)
    return jsonify(ok=(not errs), errors=errs)

@app.route("/api/tc/write", methods=["POST"])
def api_tc_write():
    # generic Genie write: set any widget value (e.g. a slider, a gauge, a digit)
    d = _body()
    try:
        _need(d, "objType", "objIndex")
        tclink.send_raw(genie_write_obj(int(d["objType"]), int(d["objIndex"]), int(d.get("value", 0))))
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/settings", methods=["POST"])
def api_tc_settings():
    # Push operating parameters to the Plasma StandAlone display as framed ASCII
    # "W<selector><value>\n" lines (needs the display 'settings' firmware to act on them;
    # unknown frames are ignored, so this is safe to send to any build).
    #   sel 0=pump ON %, 1=pump OFF %, 2=plasma time s, 3=cooling time s, 4=brightness %, 5=vacuum
    d = _body()
    fields = [("pumpOn", 0), ("pumpOff", 1), ("plasmaTime", 2), ("coolTime", 3), ("brightness", 4), ("vacuum", 5)]
    # Server-authoritative clamp per selector (a JS-only clamp is bypassable by a direct POST).
    # These now mirror applyWSetting() in the display firmware (MagicCode0.inc) EXACTLY. They used to
    # be wider (plasma/cool 1..120, brightness 0..100), which let the app accept and display a value
    # the panel then silently re-clamped - e.g. "cooling 45 s" in the UI while the hardware ran 30 s,
    # with no feedback until the next boot CFG snapshot. Same floor, same ceiling, no divergence.
    #   0 pump-ON 25..100 | 1 pump-OFF 50..100 | 2 plasma 5..30 | 3 cooling 5..30 | 4 brightness 10..100
    # NOTE: selector 5 (vacuum) is NOT implemented in applyWSetting - the display ignores W5 frames.
    # It is left mapped so the frame is still well-formed, but it is a no-op on the hardware today.
    LIMITS = {0: (25, 100), 1: (50, 100), 2: (5, 30), 3: (5, 30), 4: (10, 100), 5: (0, 100)}
    try:
        # Build the clamped W frames once, then send each TWICE (paced). The StandAlone parser reads
        # one byte per loop from an unbuffered UART, so a lone frame can lose a byte and be silently
        # ignored - that is exactly "I set cooling to 15 but it stays 11". W writes are idempotent, so
        # a second paced copy makes a single dropped byte harmless without ever flooding the panel.
        frames = []
        for key, sel in fields:
            if d.get(key) is not None:
                lo, hi = LIMITS[sel]
                val = min(hi, max(lo, int(d[key])))
                frames.append(("W%d%d\n" % (sel, val)).encode())
        sent = 0
        for _pass in range(2):
            for fr in frames:
                tclink.send_raw(fr)
                sent += 1
                time.sleep(0.12)   # PACE: one byte per display loop; space frames so each fully parses before the next.
        return jsonify(ok=True, sent=sent, unique=len(frames))
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/reset", methods=["POST"])
def api_tc_reset():
    """Hardware-reset the 4D panel by pulsing the 4D-UPA's DTR line.

    The panel has NO software reboot - 4DGL offers no reset call - so if its screen ever wedges
    (for example stuck on a warning form whose background image will not draw, leaving an
    invisible Acknowledge button) the only way back is a hardware reset or a power cycle.
    The 4D-UPA asserts the panel's reset line from DTR, which is why opening the port has always
    rebooted it. This exposes that deliberately instead of it only happening by accident.
    """
    try:
        with tclink.lock:
            ser = tclink.ser if tclink.mode == "serial" else None
        if ser is None:
            return jsonify(ok=False, error="Panel is not on a USB serial link (Ethernet bridge has no reset line)."), 400
        ser.dtr = False
        time.sleep(0.25)
        ser.dtr = True
        return jsonify(ok=True, message="Panel reset. It reboots and re-sends its settings in a few seconds.")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/serial", methods=["POST"])
def api_tc_serial():
    # Write the module serial number INTO the display as "N<n>\n" (needs the display serial firmware).
    # The panel stores this in a 16-bit SIGNED 4DGL var, so a value above 32767 wraps to a garbage
    # NEGATIVE (e.g. a real 6-digit serial becomes -31024) and is burned into the panel's config.
    # Refuse out-of-range here rather than silently persisting a wrong serial and reporting ok.
    d = _body()
    try:
        n = int(d.get("serial", 0))
        if n < 0 or n > 32767:
            return jsonify(ok=False, error="Serial must be 0-32767 (the panel stores it in a 16-bit field; larger values wrap to a wrong/negative number)."), 400
        tclink.send_raw(("N%d\n" % n).encode())
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/tc/stream")
def api_tc_stream():
    def gen():
        q = tclink.subscribe()
        try:
            for item in list(tclink.buffer)[-200:]:   # inside try so a disconnect mid-replay still unsubscribes
                yield "data: %s\n\n" % json.dumps(item)
            while True:
                try:
                    item = q.get(timeout=15)
                    yield "data: %s\n\n" % json.dumps(item)
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            tclink.unsubscribe(q)
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ------------------------------------------------------------------ Puretip One (Android tablet station)
# The Puretip One station is a tablet running the IonField app with the PC Command
# Bridge (a CommandListener on TCP 127.0.0.1:5000, reached over USB via adb forward).
# We start adb, forward the port, then connect and send ASCII commands (OK.../ERR...).
ADB_DIR = os.path.join(BASE, "tools", "adb")
# This install's own ADB identity, generated on first use and kept in the user's data directory.
#
# It used to be one fixed key shipped inside the exe, so that a tablet which trusted it once never
# prompted again. The comment here used to say that it never prompted again "to anyone", which was
# exactly right and exactly the problem: one private key, published in every build, and physical
# USB access to a provisioned tablet is then an adb shell for whoever pulled it out of the
# download. A prompt costs one tap by an engineer already holding the cable; a shared credential
# costs the fleet.
#
# Per install means a tablet provisioned against the old key prompts once more the first time this
# PC connects. Tap "Always allow" and it is done. There is no migration that avoids that, because
# the old key has to be treated as public.
_adb_key_lock = threading.Lock()


def _ensure_adb_key():
    """This install's adb key, made on first use. Returns the path, or "" if adb could not.

    The path is resolved here rather than at import: CONN_DIR is defined further down the file,
    and this runs long after all of it is loaded.
    """
    path = os.path.join(CONN_DIR, "adbkey")
    with _adb_key_lock:
        if os.path.exists(path):
            return path
        try:
            os.makedirs(CONN_DIR, exist_ok=True)
            r = subprocess.run([find_adb(), "keygen", path], timeout=20,
                               capture_output=True, creationflags=NO_WINDOW)
            if r.returncode == 0 and os.path.exists(path):
                return path
        except Exception:
            pass
        return ""
PT_PORT = 5000            # PurePlate PC Command Bridge (ASCII console)
BIOYOND_ROB_PORT = 56788  # Bioyond Rob INTF (BY-RD-02-003) - the lab scheduler connects here
BIOYOND_HTTP_PORT = 8080  # Bioyond Studio/LIMS HTTP API
ptlink = Link()
# tracks whether the Bioyond host ports are forwarded through to the tablet
bioyond_bridge = {"rob": False, "http": False}

# ------------------------------------------------------------------ auto-connect / auto-reconnect
# Keeps the serial units connected without the operator babysitting the buttons. Every few
# seconds, for any unit that is DOWN and still auto-enabled, it will:
#   1) auto-DETECT a plugged-in device by USB identity  - Arduino Opta / Arduino -> Plasma
#      Station; Silicon Labs CP210x UART -> Tip Charger display - and connect it, OR
#   2) REPLAY the last connection that worked (serial OR Ethernet), so a dropped link and a
#      relaunch both come back on their own.
# Every candidate is VERIFIED (the Opta must actually stream; the display must answer a Genie
# read) before it counts as connected - a wrong/dead port is dropped and briefly backed off,
# never shown as a false green. A manual Disconnect turns a unit's auto OFF until the operator
# connects it again, so "Disconnect" still means what it says.
_APPDATA  = _user_data_root()
CONN_DIR  = os.path.join(_APPDATA, "IonField", "IFS")

# ------------------------------------------------------------------ Augeas Insight
# The station's own history, on this machine. See insight.py for why it is local first and why
# nothing in it can reach the hardware. Opened lazily so a profile we cannot write to costs us a
# log line rather than a boot.
# IFS_DEMO points the history at a seeded file, so showing the suite never writes invented
# cycles into a bench's own record. scripts/seed-demo.py fills it.
INSIGHT_DB = os.path.join(CONN_DIR,
                          "insight-demo.db" if os.environ.get("IFS_DEMO") else "insight.db")
_insight = None
_insight_lock = threading.Lock()


def _store():
    global _insight
    with _insight_lock:
        if _insight is None:
            _insight = insight.Store(INSIGHT_DB)
            if _insight.last_error:
                _boot_log("insight: history unavailable (%s)" % _insight.last_error)
        return _insight


def _ev(kind, severity="info", source="", secs=None, label="", detail=None):
    """Record that something happened. Never raises: a lost event is not worth an exception on a
    path that is usually in the middle of running the machine."""
    try:
        _store().add_event(kind, severity, source, secs, label, detail)
    except Exception:
        pass

CONN_FILE = os.path.join(CONN_DIR, "connections.json")
_conn_lock = threading.RLock()
conn_cfg = {"plasma": {"auto": True, "last": None},   # role -> {auto, last:{mode,port,baud|host,port}}
            "tc":     {"auto": True, "last": None}}
_ac_backoff = {}                                       # (role, target-key) -> retry-not-before time

def _conn_load():
    try:
        with open(CONN_FILE, "r", encoding="utf-8") as f: data = json.load(f)
        with _conn_lock:
            for role in conn_cfg:
                r = data.get(role)
                if isinstance(r, dict):
                    if "auto" in r: conn_cfg[role]["auto"] = bool(r["auto"])
                    if "last" in r: conn_cfg[role]["last"] = r["last"]
        # The whole station is 9600 - heal any stale serial baud persisted from an older build
        # (e.g. an Opta or display remembered at 115200) so auto-reconnect can never replay a wrong baud.
        with _conn_lock:
            for _role in ("plasma", "tc"):
                lastc = conn_cfg.get(_role, {}).get("last")
                if isinstance(lastc, dict) and lastc.get("mode") == "serial" and lastc.get("baud") != DEVICE_BAUD:
                    lastc["baud"] = DEVICE_BAUD
    except Exception: pass

def _conn_save():
    try:
        with _conn_lock: snap = json.loads(json.dumps(conn_cfg))
        _json_write_atomic(CONN_FILE, snap)
    except Exception: pass

def remember_connection(role, cfg):
    """Called on any successful connect (manual or auto): re-arm auto and store what worked."""
    with _conn_lock:
        conn_cfg.setdefault(role, {"auto": True, "last": None})
        conn_cfg[role]["auto"] = True; conn_cfg[role]["last"] = cfg
    _conn_save()

def set_autoconnect(role, on):
    with _conn_lock:
        conn_cfg.setdefault(role, {"auto": True, "last": None})["auto"] = bool(on)
    _conn_save()

def _usb_serial(p):
    """Stable USB adapter serial for a port, or None.

    A COM number is assigned by Windows and can change between re-plugs, so it is a poor identity
    when two Tip Chargers (two CP210x adapters) are attached. The adapter's own serial - e.g.
    'USB VID:PID=10C4:EA60 SER=02505BB9' - does not change, so we prefer it when re-attaching.
    """
    s = getattr(p, "serial_number", None)
    if s: return str(s)
    hw = (getattr(p, "hwid", "") or "")
    key = "SER="
    i = hw.find(key)
    if i < 0: return None
    tail = hw[i + len(key):]
    out = []
    for ch in tail:
        if ch.isalnum(): out.append(ch)
        else: break
    return "".join(out) or None

def classify_port(p):
    """Map a serial port to a unit by USB identity. Opta/Arduino -> plasma; a USB-RS232 converter
    (CP210x / FTDI / Prolific / CH340) -> tc (the Tip Charger / StandAlone display). The Opta is
    matched FIRST so a generic-serial rule can never steal it, and the connect VERIFY still requires
    the tc device to actually stream its CSV, so a non-streaming adapter is dropped rather than driven."""
    desc = (p.description or "").lower()
    hwid = (getattr(p, "hwid", "") or "").upper()
    if "bluetooth" in desc:                                             return None   # BT serial links are not devices
    if "opta" in desc or "2341:" in hwid or "VID:PID=2341" in hwid or "arduino" in desc: return "plasma"
    # USB-to-RS232 bridge chips (including legacy) AND native/legacy hardware RS232 COM ports ->
    # Tip Charger / display. Broad on purpose so any converter works; the connect VERIFY still requires
    # the device to actually stream its CSV, so a non-streaming port is dropped, not driven.
    TC_VIDS = ("VID:PID=10C4",  # Silicon Labs CP210x / CP2102N
               "VID:PID=0403",  # FTDI FT232 / FT230
               "VID:PID=067B",  # Prolific PL2303 (+ legacy)
               "VID:PID=1A86",  # WCH CH340 / CH341 / CH9102
               "VID:PID=04D8",  # Microchip MCP2200 / MCP2221
               "VID:PID=04E2",  # Exar / MaxLinear XR21
               "VID:PID=0483",  # STM32 virtual COM
               "VID:PID=2341")  # (already plasma above; harmless)
    if any(v in hwid for v in TC_VIDS) or "10C4:" in hwid:              return "tc"
    if any(k in desc for k in ("silicon labs", "cp210", "ftdi", "ft232", "prolific", "pl2303",
                               "ch340", "ch341", "ch9102", "exar", "xr21", "mcp220", "microchip",
                               "usb-serial", "usb serial", "usb-to-serial", "serial converter",
                               "rs232", "rs-232", "rs485", "rs-485", "usb serial device",
                               "communications port", "serial port", "com port", "uart")): return "tc"
    return None

def _ac_key(t): return "%s:%s:%s" % (t.get("mode",""), t.get("port") or t.get("host") or "",
                                     t.get("baud") or t.get("port") or "")

def _verify_plasma():
    end = time.time() + 3.0
    while time.time() < end and not link.last_rx: time.sleep(0.05)
    return bool(link.last_rx)

def _verify_tc():
    # LISTEN-only verify (no poke): the display streams its CSV, so ANY received byte proves it is
    # alive. The panel streams several times a second, so a live one answers almost at once - this
    # waits 2.5 s rather than 6, and only then spends a DTR reset on recovering a wedged panel.
    # Holding a port open longer than needed is what the operator sees as a phantom connection.
    return _tc_wait_or_reset(first_wait=2.5, tries=1)

def _ac_try(role, lk, target, verify):
    key = (role, _ac_key(target))
    if _ac_backoff.get(key, 0) > time.time(): return False
    try:
        with _ac_probe_lock: _ac_probe[role] = time.time()
        if target.get("mode") == "tcp":
            lk.connect_tcp(target["host"], int(target.get("port", 8080)))
        else:
            lk.connect_serial(target["port"], DEVICE_BAUD)   # whole station is 9600
    except Exception:
        with _ac_probe_lock: _ac_probe.pop(role, None)
        _ac_backoff[key] = time.time() + 20; return False
    try:
        good = verify()
    finally:
        with _ac_probe_lock: _ac_probe.pop(role, None)
    if not good:
        lk.disconnect()
        # A device we have talked to before is worth asking again soon - it may just have been
        # switched off. One we have never reached gets the long wait, so a bare adapter is not
        # hammered every few seconds.
        with _conn_lock: known = (conn_cfg.get(role, {}).get("last") == target)
        _ac_backoff[key] = time.time() + (8 if known else 20)
        return False
    _ac_backoff.pop(key, None)
    with _conn_lock: prev = conn_cfg.get(role, {}).get("last")
    if prev != target: remember_connection(role, target)
    return True

flashing = threading.Event()   # set while any firmware flash is running; pauses autoconnect so it can't steal the port
_flash_lock = threading.Lock()  # single-flight: only ONE flash (Opta DFU or either display path) at a time - concurrent flashes share staged files + the port

# (Removed the automatic Form-4 navigation: the app must only WRITE to the display on operator
#  demand, never on a timer/connection event. The display's OWN firmware jumps to Form 4 when the
#  Opta first connects; and the operator can switch screens from the Screen buttons. Keeping the
#  app listen-only except for explicit actions is what stops the panel getting flooded/stuck.)

# role -> [ports] when MORE THAN ONE device of that kind is plugged in. Surfaced through
# /api/autoconnect so the UI can say which Tip Charger to pick instead of silently guessing.
_ambiguous = {}

# Roles whose port is open only because the background reconnect is testing it right now.
#
# This is what made the Tip Charger flicker between "connected - no data" and "no link" with
# nothing attached: _ac_try OPENS the port, which sets connected=True, and only then verifies -
# and verification listens for up to twelve seconds. The UI polls every 1.5 s, so it spent that
# whole window reporting a connection that was never established, then dropped it, waited out the
# backoff and did it again. A port held open to ask "is anything there?" is not a connection, and
# is no longer reported as one.
_ac_probe = {}
_ac_probe_lock = threading.Lock()

def _probing(role):
    with _ac_probe_lock:
        return bool(_ac_probe.get(role))

def _autoconnect_tick():
    if flashing.is_set(): return   # never grab a port mid-flash (Opta DFU or 4D ScriptC)
    # Collect EVERY candidate per role, not just the first. Silicon Labs CP210x -> "tc" (the 4D
    # display / Tip Charger link), Opta/Arduino -> "plasma"; see classify_port.
    cands = {}
    try:
        for p in serial.tools.list_ports.comports():
            if SCANNER_PORT and p.device == SCANNER_PORT: continue   # bound to the barcode scanner - never drive it as a device
            r = classify_port(p)
            if r: cands.setdefault(r, []).append((p.device, _usb_serial(p)))
    except Exception:
        return
    for role, lk in (("plasma", link), ("tc", tclink)):
        with _conn_lock: cfg = dict(conn_cfg.get(role, {}))
        found = sorted(cands.get(role, []))
        ports = [d for d, _s in found]
        last  = cfg.get("last")
        lastport = last.get("port") if (last and last.get("mode") == "serial") else None
        lastusb  = last.get("usb")  if (last and last.get("mode") == "serial") else None
        # Report ambiguity even while connected / auto-off, so the operator can always see it.
        _ambiguous[role] = ports if len(ports) > 1 else []
        # Stale-link recovery ("keep it alive, don't sit dead"): the display and the Opta both stream
        # continuously, so a CONNECTED link that has been silent too long means the panel or the
        # Waveshare converter wedged. Drop it now so the reconnect below re-opens it fresh this same
        # tick (serial re-opens/DTR-resets; TCP re-grabs the converter slot). Only when auto is on.
        if lk.connected and cfg.get("auto", True):
            age = lk.rx_age()
            if age is not None and age > TC_STALE_RECOVER_S:
                try: lk.disconnect()
                except Exception: pass
        if not cfg.get("auto", True) or lk.connected: continue
        verify = _verify_plasma if role == "plasma" else _verify_tc
        pick = pickusb = None
        if len(found) == 1:
            pick, pickusb = found[0]                         # exactly one -> plug-and-go
        elif len(found) > 1:
            # SEVERAL devices of this kind (e.g. two different Tip Chargers on CP210x adapters).
            # Never guess - grabbing the wrong panel would drive the wrong machine. Re-attach only
            # to the one we already used successfully, matched by the adapter's USB SERIAL first
            # (stable across re-plugs and COM renumbering) and falling back to the COM name.
            # Otherwise stay off and let the operator choose from the port list.
            for d, s in found:
                if lastusb and s and s == lastusb: pick, pickusb = d, s; break
            if not pick:
                for d, s in found:
                    if lastport and d == lastport: pick, pickusb = d, s; break
        if pick:
            tgt = {"mode": "serial", "port": pick, "baud": DEVICE_BAUD}
            if pickusb: tgt["usb"] = pickusb   # remembered so a COM renumber cannot lose the device
            if _ac_try(role, lk, tgt, verify): continue
        # otherwise replay the last-good config (covers Ethernet, or a port with no USB match)
        if last and not (pick and last.get("mode") == "serial"):
            _ac_try(role, lk, last, verify)

_autoconnect_last_error = None   # surfaced via /api/autoconnect so a persistently broken tick is visible, not silent

def _autoconnect_loop():
    global _autoconnect_last_error
    _conn_load()
    _bio_load()      # customer's Bioyond endpoints (own file, so a bad edit can't break connections.json)
    while True:
        try:
            _autoconnect_tick()
            _autoconnect_last_error = None
        except Exception as e:
            # A persistent tick fault (e.g. a corrupted connections.json making every tick raise) used
            # to kill auto-reconnect permanently and INVISIBLY - the UI just showed "offline" forever.
            # Record it and log it so it is diagnosable instead of a silent dead loop.
            _autoconnect_last_error = "%s: %s" % (type(e).__name__, e)
            try: sys.stderr.write("[IFS] autoconnect tick error: %s\n" % _autoconnect_last_error)
            except Exception: pass
        time.sleep(3.0)

@app.route("/api/autoconnect")
def api_autoconnect():
    # Always report BOTH roles (even before either has a stored config) and include any ambiguity,
    # so the UI can tell the operator "two Tip Chargers are plugged in, pick one" rather than the
    # app silently attaching to whichever enumerated first.
    with _conn_lock:
        out = {}
        for k in set(list(conn_cfg.keys()) + ["plasma", "tc"]):
            v = conn_cfg.get(k, {})
            out[k] = {"auto": v.get("auto", True), "last": v.get("last"),
                      "ambiguous": list(_ambiguous.get(k, []))}
    out["_autoconnectError"] = _autoconnect_last_error   # non-None => the auto-reconnect loop is failing (diagnosable, not silent)
    return jsonify(out)

# ------------------------------------------------------------------ Bioyond integration (customer LAN)
# Endpoints for the CUSTOMER's Bioyond equipment. Every site is wired differently and Bioyond's own
# spec says so - the robot IP "does not have to be the value in this table ... it depends on the
# actual user configuration" - so these are operator-configurable rather than hardcoded.
# The Rob INTF PORT is the exception: BY-RD-02-003 v1.1 section 2.2 states it is NOT configurable and
# must stay 56788, so we keep it constant and refuse to store an override. Exposing it as a free
# field would let a well-meaning edit create a link that can never work and look like our bug.
BIO_FILE = os.path.join(CONN_DIR, "bioyond.json")
BIO_ROB_PORT_FIXED = 56788
# Rob INTF getSysState -> ret.value, per the spec's parameter table (0-5; anything else is illegal).
BIO_STATE = {0: "init", 1: "idle", 2: "running", 3: "error", 4: "paused", 5: "enabled"}
BIO_FRAME_TYPE = {1: "request", 2: "response", 3: "result", 4: "exception"}
# The documents do not agree on where the robot lives, and an engineer standing at a machine that
# will not connect needs to know that rather than be handed one address as if it were the only one.
#
#   Rob INTF v1.1, Table 2-1        192.168.1.220, called the default there
#   LabGenius S4 Product Manual     192.168.3.200 over Ethernet, with the host on 192.168.3.x
#     and Software User Manual      192.168.2.1 over the robot's own Wi-Fi
#
# All three are offered, each labelled with the document it came from. The app does not choose for
# anyone: the site decides, and these are what the manuals say to try.
BY_DOC_ADDRS = [
    {"ip": "192.168.1.220", "note": "Rob INTF v1.1, Table 2-1"},
    {"ip": "192.168.3.200", "note": "LabGenius S4 manual, wired - put this PC on 192.168.3.x"},
    {"ip": "192.168.2.1",   "note": "LabGenius S4 manual, over the robot's own Wi-Fi"},
]

# Codes the LabGenius S4 Service Manual names. getRobotErr carries the robot's own message, but a
# terse or missing one on the code that matters most is worth naming. Only documented codes are
# here - nothing is guessed.
BY_ALARMS = {
    3933:  "Emergency stop triggered",
    3934:  "Emergency stop released",
    29573: "Joint servo error - check the battery module",
}

bio_cfg = {
    "robot":    {"ip": "192.168.1.220", "port": BIO_ROB_PORT_FIXED},  # Rob INTF: JSON/TCP, ONE client only
    "carousel": {"ip": "192.168.1.115", "port": 500},                 # Carousel PLC: binary framed, Big-Endian
    "studio":   {"ip": "",              "port": 44388},               # Bioyond Studio / LIMS: JSON over HTTP
}
_bio_lock = threading.RLock()

def _ip_ok(s):
    parts = (s or "").split(".")
    if len(parts) != 4: return False
    for p in parts:
        if not p.isdigit() or len(p) > 3 or not (0 <= int(p) <= 255): return False
    return True

def _bio_load():
    try:
        with open(BIO_FILE, "r", encoding="utf-8") as f: data = json.load(f)
        with _bio_lock:
            for k in bio_cfg:
                v = data.get(k)
                if not isinstance(v, dict): continue
                if isinstance(v.get("ip"), str): bio_cfg[k]["ip"] = v["ip"].strip()
                try:
                    p = int(v.get("port", bio_cfg[k]["port"]))
                    if 1 <= p <= 65535: bio_cfg[k]["port"] = p
                except Exception: pass
            bio_cfg["robot"]["port"] = BIO_ROB_PORT_FIXED   # spec-fixed; never honour a stored override
    except Exception: pass

def _bio_save():
    try:
        with _bio_lock: snap = json.loads(json.dumps(bio_cfg))
        _json_write_atomic(BIO_FILE, snap, indent=2)
    except Exception: pass

@app.route("/api/bioyond/config", methods=["GET", "POST"])
def api_bioyond_config():
    if request.method == "GET":
        with _bio_lock:
            return jsonify(ok=True, cfg=json.loads(json.dumps(bio_cfg)), robPortFixed=BIO_ROB_PORT_FIXED)
    d = _body()
    with _bio_lock:
        # Validate EVERYTHING into a staging copy first, then commit atomically. The old loop mutated
        # bio_cfg key-by-key and returned 400 on the first bad field - so an earlier key was already
        # changed in memory (and probed by /test) while the operator saw only an error and assumed
        # nothing applied. Now a single bad field rejects the whole request and changes nothing.
        staged = json.loads(json.dumps(bio_cfg))
        for k in bio_cfg:
            v = d.get(k)
            if not isinstance(v, dict): continue
            ip = str(v.get("ip", staged[k]["ip"])).strip()
            if ip and not _ip_ok(ip):
                return jsonify(ok=False, error="%s: '%s' is not a valid IPv4 address." % (k, ip)), 400
            staged[k]["ip"] = ip
            if k != "robot":                       # robot port is spec-fixed - silently ignore any attempt
                try:
                    p = int(v.get("port", staged[k]["port"]))
                    if not (1 <= p <= 65535): raise ValueError()
                    staged[k]["port"] = p
                except Exception:
                    return jsonify(ok=False, error="%s: port must be a number 1-65535." % k), 400
        staged["robot"]["port"] = BIO_ROB_PORT_FIXED
        for k in bio_cfg: bio_cfg[k] = staged[k]   # commit all-or-nothing
        snap = json.loads(json.dumps(bio_cfg))
    _bio_save()
    return jsonify(ok=True, cfg=snap)

def _bio_frame(func, ftype=0x0001, data=b"", frame_id=1):
    """Carousel frame: preamble 0x3553, frame id, 4-byte function code, frame type, length, data.
    Big-Endian throughout, per Carousel Communication Protocol V1.0."""
    return struct.pack(">HHIHH", 0x3553, frame_id & 0xFFFF, func, ftype, len(data)) + data

def _recv_until(s, want, deadline, stop_on_newline=False):
    buf = b""
    while time.time() < deadline and len(buf) < want:
        if stop_on_newline and b"\n" in buf: break
        try: chunk = s.recv(4096)
        except socket.timeout: break
        except Exception: break
        if not chunk: break
        buf += chunk
    return buf

BIO_BAD_PREAMBLE = "bad_preamble"

def _bio_read_carousel_frame(rxbuf, s, deadline):
    """Read exactly ONE Carousel frame (12-byte header + DataLength bytes) from the socket, using
    rxbuf as a carry-over buffer since one TCP segment can contain several frames. Returns
    (func, ftype, data, remaining_rxbuf). func is None on timeout/short read and BIO_BAD_PREAMBLE if
    the frame did not start with 0x3553. Per Carousel Communication Protocol V1.0:
    0x3553 | FrameID(2) | Func(4) | FrameType(2) | Len(2) | data."""
    while len(rxbuf) < 12 and time.time() < deadline:
        try: chunk = s.recv(4096)
        except Exception: break
        if not chunk: break
        rxbuf += chunk
    if len(rxbuf) < 12:
        return None, None, None, rxbuf
    pre, fid, func, ftype, dlen = struct.unpack(">HHIHH", rxbuf[:12])
    if pre != 0x3553:
        return BIO_BAD_PREAMBLE, pre, rxbuf[:12], b""
    while len(rxbuf) < 12 + dlen and time.time() < deadline:
        try: chunk = s.recv(4096)
        except Exception: break
        if not chunk: break
        rxbuf += chunk
    data = rxbuf[12:12 + dlen]
    return func, ftype, data, rxbuf[12 + dlen:]

def _bio_test_robot(ip, port):
    # getSysState is listed "not need a result reply", so it is a clean request/response probe that
    # cannot move the robot or disturb a running program.
    req = (json.dumps({"BRCAPI": "1.0", "cmd": "getSysState", "id": 1}) + "\n").encode("utf-8")
    s = socket.create_connection((ip, port), timeout=3.0)
    try:
        s.settimeout(3.0); s.sendall(req)
        buf = _recv_until(s, 4096, time.time() + 3.0, stop_on_newline=True)
    finally:
        try: s.close()
        except Exception: pass
    if not buf:
        return False, ("Port is open but the robot did not answer getSysState. Rob INTF allows only ONE "
                       "client at a time - another host (a scheduler) may already hold the socket.")
    line = buf.split(b"\n", 1)[0].decode("utf-8", "replace").strip()
    try: obj = json.loads(line)
    except Exception: return False, "Replied, but not valid JSON: %s" % line[:140]
    if isinstance(obj.get("error"), dict):
        e = obj["error"]
        return False, "Robot returned error %s: %s" % (e.get("code"), e.get("message"))
    val = (obj.get("ret") or {}).get("value")
    return True, "Robot reachable. System state %s (%s)." % (val, BIO_STATE.get(val, "unknown"))

def _bio_test_carousel(ip, port):
    # Read System Status (0x00020004) is a pure read - it moves nothing. Per the spec the controller
    # answers with TWO frames: a Response ACK (FrameType 0x0002, no data) then a Result frame
    # (FrameType 0x0003) carrying 8 status bytes. Read the whole exchange so the test genuinely
    # confirms the carousel executes the command, not just that something replied.
    s = socket.create_connection((ip, port), timeout=3.0)
    deadline = time.time() + 3.0
    frames, rx = [], b""
    try:
        s.settimeout(3.0); s.sendall(_bio_frame(0x00020004))
        for _ in range(3):   # Response + Result (+ headroom); stop early once we have a Result/exception
            func, ftype, data, rx = _bio_read_carousel_frame(rx, s, deadline)
            if func is None: break
            frames.append((func, ftype, data))
            if func == BIO_BAD_PREAMBLE or ftype in (0x0003, 0x0004): break
    finally:
        try: s.close()
        except Exception: pass
    if not frames:
        return False, "Port is open but no Carousel frame came back within 3 s."
    if frames[0][0] == BIO_BAD_PREAMBLE:
        return False, "Reply did not start with the 0x3553 preamble (got 0x%04X) - is this really the carousel on this port?" % frames[0][1]
    # A system EXCEPTION frame anywhere in the exchange is a failure.
    for func, ftype, data in frames:
        if ftype == 0x0004:
            return False, "Carousel answered with a system EXCEPTION frame (function 0x%08X)." % func
    # Prefer the Result frame's payload (the actual status bytes); fall back to the ACK.
    result = next((f for f in frames if f[1] == 0x0003), None)
    if result is not None:
        func, ftype, data = result
        return True, "Carousel reachable and executing Read System Status: result frame, function 0x%08X, %d status byte(s) [%s]." % (
            func, len(data), data.hex(" ") if data else "none")
    func, ftype, data = frames[0]
    return True, "Carousel reachable (%s frame, function 0x%08X) - ACK received; no result frame within 3 s." % (
        BIO_FRAME_TYPE.get(ftype, "0x%04X" % ftype), func)

def _bio_test_studio(ip, port, apikey=""):
    """Ask Bioyond Studio a real question instead of only opening its port.

    Per Studio/LIMS v2.0: every call is an HTTP POST of JSON in UTF-8, with the envelope
    {apiKey, requestTime, data}, and the answer carries {code, message, timestamp, data} where
    code 1 is success and 0 is failure. Device List Query is used because it is a pure read -
    it starts nothing and moves nothing.

    An open port proved almost nothing: anything at all can be listening. A refusal from this
    URL, even an authorisation refusal, is real evidence that Bioyond Studio is on the other
    end, and that is worth far more to whoever is setting a station up."""
    import urllib.request, urllib.error
    url  = "http://%s:%d/api/lims/device/device-list" % (ip, int(port))
    body = json.dumps({"apiKey": _s(apikey),
                       "requestTime": time.strftime("%Y-%m-%d %H:%M:%S"),
                       "data": {}}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/json; charset=utf-8",
                                          "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=4.0) as r:
            raw, status = r.read(65536), r.status
    except urllib.error.HTTPError as e:
        raw, status = (e.read(65536) or b""), e.code
    except urllib.error.URLError as e:
        raise OSError(getattr(e, "reason", e))
    try:
        m = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return False, ("Something is listening on %s:%d, but it answered HTTP %d with no JSON - "
                       "this does not look like Bioyond Studio." % (ip, int(port), status))
    if not isinstance(m, dict) or "code" not in m:
        return False, ("%s:%d answered JSON without a code field, so it is not the Studio/LIMS "
                       "interface." % (ip, int(port)))
    code = m.get("code")
    msg  = _s(m.get("message"))
    if code == 1:
        n = len(m.get("data") or []) if isinstance(m.get("data"), list) else None
        return True, ("Bioyond Studio answered Device List Query"
                      + (" - %d device%s." % (n, "" if n == 1 else "s") if n is not None else "."))
    if not _s(apikey):
        return True, ("Bioyond Studio is there and refused the call because no apiKey was given"
                      + (" (%s)." % msg if msg else ".")
                      + " Enter the site's key to read the device list.")
    return False, ("Bioyond Studio refused the call: %s" % (msg or "code %r" % code))

@app.route("/api/bioyond/addresses")
def api_bioyond_addresses():
    """The addresses Bioyond's own documents give for the robot, each with its source."""
    return jsonify(ok=True, addresses=BY_DOC_ADDRS, port=BIO_ROB_PORT_FIXED)


@app.route("/api/bioyond/test", methods=["POST"])
def api_bioyond_test():
    d = _body()
    what = _s(d.get("target"), "")
    if what not in ("robot", "carousel", "studio"):
        return jsonify(ok=False, error="target must be robot, carousel or studio"), 400
    # Prefer the values being edited in the page so Test works BEFORE saving; fall back to stored.
    with _bio_lock: cur = dict(bio_cfg[what])
    ip = _s(d.get("ip"), cur["ip"])
    port = BIO_ROB_PORT_FIXED if what == "robot" else int(d.get("port") or cur["port"])
    if not _ip_ok(ip):
        return jsonify(ok=False, error="Enter a valid IPv4 address first."), 400
    t0 = time.time()
    try:
        if what == "studio":
            good, msg = _bio_test_studio(ip, port, _s(d.get("apikey")))
        else:
            good, msg = ({"robot": _bio_test_robot,
                          "carousel": _bio_test_carousel}[what])(ip, port)
    except socket.timeout:
        return jsonify(ok=False, error="Timed out connecting to %s:%d - nothing answered." % (ip, port))
    except OSError as e:
        return jsonify(ok=False, error="Could not reach %s:%d (%s)." % (ip, port, getattr(e, "strerror", None) or e))
    except Exception as e:
        return jsonify(ok=False, error="%s:%d - %s" % (ip, port, e))
    return jsonify(ok=bool(good), error=None if good else msg, message=msg,
                   ms=int((time.time() - t0) * 1000), ip=ip, port=port)

def _local_subnet():
    """Best-effort /24 prefix of the interface that would reach the lab LAN (no traffic is sent)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.168.1.1", 9))       # UDP connect: picks a route, sends nothing
            ip = s.getsockname()[0]
        finally: s.close()
        return ip.rsplit(".", 1)[0]
    except Exception:
        return "192.168.1"

_scan_lock = threading.Lock()   # single-flight: one subnet sweep at a time (each spawns hundreds of probe threads)

@app.route("/api/net/scan", methods=["POST"])
def api_net_scan():
    """Sweep a /24 for the ports we care about, so a converter or robot whose address was changed
    (or forgotten) can be found from the app instead of hunting with VirCOM."""
    # Single-flight. Each scan spawns hundreds of probe threads and blocks its request thread on the
    # joins; two concurrent scans (a double-click) fight over the shared active-thread throttle and
    # saturate the Flask pool, hanging the whole app for a minute. Reject a second overlapping scan.
    if not _scan_lock.acquire(blocking=False):
        return jsonify(ok=False, error="A network scan is already running - wait for it to finish."), 409
    try:
        d = _body()
        # A robot set up per the LabGenius manual sits on 192.168.3.x while this PC may be on
        # 192.168.1.x, and sweeping only the local /24 could never find it. The documented subnets
        # can be swept as well, so "it is not on my network" stops being the end of the search.
        bases = d.get("subnets")
        if not isinstance(bases, list) or not bases:
            bases = [str(d.get("subnet") or _local_subnet())]
        bases = [str(b).strip().rstrip(".") for b in bases][:3]
        for b in bases:
            if not _ip_ok(b + ".1"):
                return jsonify(ok=False, error="Subnet should look like 192.168.1"), 400
        base = bases[0]
        try:
            ports = [int(p) for p in (d.get("ports") or [4196, BIO_ROB_PORT_FIXED, 500])]
            ports = [p for p in ports if 1 <= p <= 65535][:6]
        except Exception:
            return jsonify(ok=False, error="bad ports"), 400
        found, lock = [], threading.Lock()
        sem = threading.Semaphore(128)   # bound concurrent probe sockets deterministically (not via the global thread count)
        def probe(host, port):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM); s.settimeout(0.35)
                if s.connect_ex((host, port)) == 0:
                    with lock: found.append({"ip": host, "port": port})
                s.close()
            except Exception: pass
            finally: sem.release()
        threads = []
        for b in bases:                      # every subnet asked for, not just the first
            for i in range(1, 255):
                for p in ports:
                    sem.acquire()
                    t = threading.Thread(target=probe, args=("%s.%d" % (b, i), p), daemon=True)
                    threads.append(t); t.start()
        for t in threads: t.join(timeout=2.0)
        found.sort(key=lambda r: ([int(x) for x in r["ip"].split(".")], r["port"]))
        label = {4196: "Waveshare bridge", BIO_ROB_PORT_FIXED: "Bioyond robot (Rob INTF)", 500: "Bioyond carousel"}
        for r in found: r["guess"] = label.get(r["port"], "")
        return jsonify(ok=True, subnet=base, subnets=bases, ports=ports, found=found)
    finally:
        _scan_lock.release()

def _mac_tool(name, bundled=None):
    """A command-line helper on a Mac: the copy inside the app bundle first, then Homebrew.

    Finder starts an app with PATH=/usr/bin:/bin:/usr/sbin:/sbin, so Homebrew's folders are named
    outright. A store build looks ONLY inside its own bundle: the sandbox cannot run a program
    from /opt/homebrew, and a helper the store did not review is not ours to launch."""
    cands = [bundled] if bundled else []
    if not IS_MAS:
        cands += [os.path.join(d, name) for d in ("/opt/homebrew/bin", "/usr/local/bin")]
    for c in cands:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    if not IS_MAS:
        import shutil
        w = shutil.which(name)
        if w:
            return w
    return ""


# Where a Mac build keeps its own adb (Google's platform-tools binary, fetched by
# scripts/build-mac.sh). Kept apart from tools/adb, which holds the Windows adb.exe.
ADB_DIR_MAC = os.path.join(BASE, "tools", "adb-mac")
ADB_MISSING_MAC = ("adb was not found. The Mac build carries its own; for a run from source "
                   "install it with:  brew install android-platform-tools")


_adb_server_was_running = None     # Mac: was another adb server (Android Studio...) already up?


def _note_adb_server():
    """Remember, before this app first touches adb, whether an adb server was already running.
    One adb server serves every adb on the machine, so quitting must only stop it if WE started it."""
    global _adb_server_was_running
    if _adb_server_was_running is None:
        try:
            with socket.create_connection(("127.0.0.1", 5037), timeout=0.3):
                _adb_server_was_running = True
        except OSError:
            _adb_server_was_running = False


def find_adb():
    if IS_MAC:
        _note_adb_server()
        return _mac_tool("adb", os.path.join(ADB_DIR_MAC, "adb")) or "adb"
    p = os.path.join(ADB_DIR, "adb.exe")
    return p if os.path.exists(p) else "adb"

def _adb_env():
    """Make adb offer this install's own key (loaded by the adb server on start)."""
    env = dict(os.environ)
    key = _ensure_adb_key()
    if key:
        env["ADB_VENDOR_KEYS"] = key
    return env

def _adb_run(args, timeout=20, text=False):
    return subprocess.run(args, timeout=timeout, capture_output=True, text=text,
                          creationflags=NO_WINDOW, env=_adb_env())

def _adb_forward(adb, port, serial=None):
    """Forward localhost:<port> -> tablet:<port>. Returns True on success. With more than one
    tablet plugged in adb refuses a forward that does not say which one, so name it."""
    r = subprocess.run([adb] + (["-s", serial] if serial else []) +
                       ["forward", "tcp:%d" % port, "tcp:%d" % port],
                       timeout=20, capture_output=True, text=True, creationflags=NO_WINDOW, env=_adb_env())
    return r.returncode == 0

# The USB link speed, as Windows enumerated the tablet. The port the device sits on is named in
# its location path: HSnn is a USB 2.0 High-Speed port (480 Mb/s), SSnn a SuperSpeed one (USB 3,
# 5 Gb/s or more). Asked once per tablet - it costs a PowerShell call - and cached.
_pt_usb_cache = {}

def _pt_usb_link(serial):
    if not serial or os.name != "nt":
        return None
    if serial in _pt_usb_cache:
        return _pt_usb_cache[serial]
    info = None
    try:
        safe = re.sub(r"[^A-Za-z0-9]", "", serial)
        ps = ("$d = Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB*%s' } | "
              "Select-Object -First 1; if ($d) { (Get-PnpDeviceProperty -InstanceId $d.InstanceId "
              "-KeyName DEVPKEY_Device_LocationPaths).Data -join ';' }" % safe)
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                           timeout=12, creationflags=NO_WINDOW)
        path = (r.stdout or "").upper()
        if "#ACPI(SS" in path:
            info = {"label": "USB 3 SuperSpeed", "mbps": 5000}
        elif "#ACPI(HS" in path:
            info = {"label": "USB 2.0 High-Speed", "mbps": 480}
        elif path.strip():
            info = {"label": "USB", "mbps": None}
    except Exception:
        info = None
    _pt_usb_cache[serial] = info
    return info

_pt_rate = {"t": 0.0, "rx": 0, "tx": 0, "bps": 0.0}

def _pt_traffic():
    """Bytes per second over the tablet link, measured between state polls."""
    now = time.time()
    tot = ptlink.rx_bytes + ptlink.tx_bytes
    dt = now - _pt_rate["t"]
    if _pt_rate["t"] and dt >= 0.5:
        _pt_rate["bps"] = max(0.0, (tot - _pt_rate["rx"]) / dt)
    if not _pt_rate["t"] or dt >= 0.5:
        _pt_rate["t"], _pt_rate["rx"] = now, tot
    return _pt_rate["bps"]


@app.route("/api/pt/state")
def api_pt_state():
    return jsonify(connected=ptlink.connected, mode=ptlink.mode, info=ptlink.info,
                   bioyond=bioyond_bridge, robPort=BIOYOND_ROB_PORT, httpPort=BIOYOND_HTTP_PORT,
                   autoConnect=pt_auto["enabled"], autoStatus=pt_auto["status"],
                   serial=pt_auto.get("serial") or "", name=_pt_name(pt_auto.get("serial")),
                   usb=_pt_usb_link(pt_auto.get("serial")) if ptlink.connected else None,
                   traffic=round(_pt_traffic(), 1) if ptlink.connected else None)

def _adb_state(dev_stdout):
    """Parse `adb devices` into {serial: state}. Ignores daemon banners (only rows with a tab)."""
    out = {}
    for l in dev_stdout.splitlines():
        if "\t" in l:
            serial, rest = l.split("\t", 1)
            out[serial.strip()] = rest.split()[0].strip() if rest.split() else "?"
    return out

def _probe_bioyond():
    """Actually reach the tablet's Bioyond servers (via the adb forwards). A forward
    succeeding only means the tunnel exists; this proves a server is really listening."""
    res = {"rob": False, "http": False, "state": None}
    try:
        s = socket.create_connection(("127.0.0.1", BIOYOND_ROB_PORT), timeout=2)
        try:
            s.sendall(b'{"BRCAPI":"1.0","cmd":"getSysState","id":1}\n')
            s.settimeout(3)
            data = s.recv(2048).decode("utf-8", "replace").strip()
            res["rob"] = bool(data)          # a real reply (not an EOF from a dead tunnel)
            res["state"] = data or None
        finally: s.close()
    except Exception: pass
    try:
        s = socket.create_connection(("127.0.0.1", BIOYOND_HTTP_PORT), timeout=2)
        try:
            s.sendall(b"GET / HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n")
            s.settimeout(3)
            res["http"] = bool(s.recv(64))   # a real HTTP response, not just accept-then-EOF
        finally: s.close()
    except Exception: pass
    return res

# ------------------------------------------------------------------ tablet (adb) auto-connect
# The tablet link connects by itself: a background watcher looks for the tablet every few
# seconds, forwards the ports, opens the Puretip app if it is not running, and reconnects after
# a cable pull, tablet reboot or app restart. A manual Disconnect stays disconnected until the
# operator presses Connect again. Status is exposed to the UI through /api/pt/state (autoStatus).
# The tablet app was renamed to com.augeastechnologies.puretipone (2.03); older tablets may still
# run com.almonddesigns.ionfield. Prefer the new one, fall back to the old one.
PT_PKGS = ("com.augeastechnologies.puretipone", "com.almonddesigns.ionfield")
PT_MAIN_CLASS = "com.almonddesigns.ionfield.MainActivity"   # class name is the same in both

def _pt_installed_pkgs(adb, serial):
    try:
        out = _adb_run([adb, "-s", serial, "shell", "pm", "list", "packages"], timeout=15, text=True).stdout
        have = {l.split(":", 1)[1].strip() for l in out.splitlines() if l.startswith("package:")}
        return [p for p in PT_PKGS if p in have]
    except Exception:
        return list(PT_PKGS[:1])
pt_auto = {"enabled": True, "status": "Looking for the tablet...", "granted": set()}
_pt_lock = threading.Lock()
_pt_server_started = [False]

def _pt_start_server(adb, restart=False):
    # (Re)start the adb server once so it loads the bundled IFS key (ADB_VENDOR_KEYS is read at
    # server start). A tablet that trusts this key authorizes silently - no prompt.
    if restart or not _pt_server_started[0]:
        _adb_run([adb, "kill-server"], timeout=10)
        _adb_run([adb, "start-server"], timeout=20)
        _pt_server_started[0] = True

def _pt_connect(restart_server=False, launch_app=True):
    """One connect attempt. Returns (ok, payload) where payload is the JSON for the API."""
    with _pt_lock:
        if ptlink.connected:
            return True, dict(ok=True, info=ptlink.info, bioyond=bioyond_bridge,
                              robPort=BIOYOND_ROB_PORT, httpPort=BIOYOND_HTTP_PORT)
        adb = find_adb()
        if IS_MAC and adb == "adb":
            pt_auto["status"] = "adb not found on this Mac"
            return False, dict(ok=False, error=ADB_MISSING_MAC)
        _pt_start_server(adb, restart_server)
        dev = _adb_run([adb, "devices"], timeout=20, text=True)
        states = _adb_state(dev.stdout)
        if not states:
            pt_auto["status"] = "Waiting for the tablet (USB-C data cable, USB debugging on)"
            return False, dict(ok=False, error="No tablet detected. Use a USB-C DATA cable and enable USB debugging.")
        st = list(states.values())
        if "device" not in st:
            if "unauthorized" in st:
                pt_auto["status"] = "On the tablet: tap Allow USB debugging and tick Always allow"
                return False, dict(ok=False, error="Tablet not authorized. On the tablet tap 'Allow USB debugging' and CHECK 'Always allow from this computer' - after that first time IFS connects automatically, no prompt.")
            if "offline" in st:
                pt_auto["status"] = "Tablet offline: reseat the cable or wake the tablet"
                return False, dict(ok=False, error="Tablet is OFFLINE - reseat the USB-C DATA cable / wake the tablet, then retry.")
            if any("permission" in x for x in st):
                pt_auto["status"] = "No USB permission: check the Windows ADB driver"
                return False, dict(ok=False, error="No USB permission (driver issue) - check the Windows USB/ADB driver, then retry.")
            pt_auto["status"] = "Tablet not ready (%s)" % ", ".join(sorted(set(st)))
            return False, dict(ok=False, error="Tablet not ready (adb state: %s)." % ", ".join(sorted(set(st))))
        ready = [k for k, v in states.items() if v == "device"]
        pref = _pt_pref()
        if pref:
            if pref not in ready:
                # Never fall back to another tablet: that is a different machine, and commands
                # meant for this one would move it.
                pt_auto["status"] = "Waiting for %s (not plugged in)" % (_pt_name(pref) or pref)
                return False, dict(ok=False, error="The chosen station, %s, is not connected. Plug it "
                                   "in, or choose another station." % (_pt_name(pref) or pref))
            serial = pref
        elif len(ready) > 1:
            pt_auto["status"] = "%d tablets found: choose a station" % len(ready)
            return False, dict(ok=False, error="%d tablets are connected. Choose which station to "
                               "control in Connection." % len(ready))
        else:
            serial = ready[0]
        pt_auto["serial"] = serial
        # First time we see this tablet: let the app keep USB debugging switched on by itself.
        pkgs = _pt_installed_pkgs(adb, serial)
        if serial not in pt_auto["granted"]:
            for pk in pkgs:
                try: _adb_run([adb, "-s", serial, "shell", "pm", "grant", pk, "android.permission.WRITE_SECURE_SETTINGS"], timeout=15)
                except Exception: pass
            pt_auto["granted"].add(serial)
        if not _adb_forward(adb, PT_PORT, serial):
            pt_auto["status"] = "Port 5000 busy: close other adb tools"
            return False, dict(ok=False, error="adb port-forward failed (port 5000 busy?). Close other adb tools and retry.")
        ptlink.connect_tcp("127.0.0.1", PT_PORT)
        # The console server must actually answer - adb accepts localhost:5000 even when the
        # on-tablet app isn't running (then FINs). Require a real reply.
        end = time.time() + 2.5
        while time.time() < end and not ptlink.last_rx:
            time.sleep(0.05)
        if not ptlink.last_rx:
            ptlink.disconnect()
            try: _adb_run([adb, "forward", "--remove", "tcp:%d" % PT_PORT], timeout=10)
            except Exception: pass
            if launch_app:
                if pkgs:
                    try: _adb_run([adb, "-s", serial, "shell", "am", "start", "-n", pkgs[0] + "/" + PT_MAIN_CLASS], timeout=15)
                    except Exception: pass
                pt_auto["status"] = "Opening the Puretip app on the tablet..."
            return False, dict(ok=False, error="Tablet reached but the Puretip command app did not answer - IFS is opening it now; it connects automatically in a few seconds.")
        _adb_forward(adb, BIOYOND_ROB_PORT, serial); _adb_forward(adb, BIOYOND_HTTP_PORT, serial)
        bres = _probe_bioyond()
        bioyond_bridge["rob"], bioyond_bridge["http"] = bres["rob"], bres["http"]
        pt_auto["status"] = "Connected"
        return True, dict(ok=True, info=ptlink.info, bioyond=bioyond_bridge,
                          robPort=BIOYOND_ROB_PORT, httpPort=BIOYOND_HTTP_PORT)

def _pt_pref():
    return _s(_json_read(STATION_FILE).get("pt_serial"), "")


def _pt_name(serial):
    if not serial:
        return ""
    names = _json_read(STATION_FILE).get("pt_names") or {}
    return _s(names.get(serial), "") if isinstance(names, dict) else ""


@app.route("/api/pt/devices")
def api_pt_devices():
    """Every tablet adb can see, with its nickname, so the operator picks the station by name."""
    try:
        adb = find_adb()
        if IS_MAC and adb == "adb":
            return jsonify(ok=False, error=ADB_MISSING_MAC, devices=[]), 200
        r = _adb_run([adb, "devices", "-l"], timeout=15, text=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e), devices=[]), 200
    pref = _pt_pref()
    out = []
    for line in (r.stdout or "").splitlines():
        parts = line.split()
        if len(parts) < 2 or line.startswith("List of"):
            continue
        serial, state = parts[0], parts[1]
        model = next((x.split(":", 1)[1] for x in parts[2:] if x.startswith("model:")), "")
        out.append({"serial": serial, "state": state, "model": model.replace("_", " "),
                    "name": _pt_name(serial), "chosen": serial == pref,
                    "active": ptlink.connected and pt_auto.get("serial") == serial})
    return jsonify(ok=True, devices=out, chosen=pref)


@app.route("/api/pt/select", methods=["POST"])
def api_pt_select():
    """Make this the station IFS controls. Blank means "whichever single tablet is plugged in"."""
    serial = _s(_body().get("serial"), "").strip()[:64]
    if serial and not re.match(r"^[A-Za-z0-9._:-]+$", serial):
        return jsonify(ok=False, error="That is not a device serial."), 400
    _json_merge_write(STATION_FILE, {"pt_serial": serial})
    with _pt_lock:
        if ptlink.connected and pt_auto.get("serial") != serial:
            ptlink.disconnect()
            try: _adb_run([find_adb(), "forward", "--remove-all"], timeout=10)
            except Exception: pass
        pt_auto["enabled"] = True                    # the watcher connects to the new choice
        pt_auto["status"] = "Connected" if ptlink.connected else "Switching station..."
    _ev("pt_station", "info", "app", label=_pt_name(serial) or serial or "auto")
    return jsonify(ok=True, chosen=serial)


@app.route("/api/pt/nickname", methods=["POST"])
def api_pt_nickname():
    d = _body()
    serial = _s(d.get("serial"), "").strip()[:64]
    name = re.sub(r"\s+", " ", _s(d.get("name"), "")).strip()[:40]
    if not serial:
        return jsonify(ok=False, error="Choose a station first."), 400
    names = _json_read(STATION_FILE).get("pt_names") or {}
    if not isinstance(names, dict):
        names = {}
    if name:
        names[serial] = name
    else:
        names.pop(serial, None)
    _json_merge_write(STATION_FILE, {"pt_names": names})
    return jsonify(ok=True, name=name)


def _pt_auto_loop():
    """Background watcher: keep the tablet connected whenever it is plugged in."""
    time.sleep(4.0)
    while True:
        try:
            if pt_auto["enabled"] and not ptlink.connected and not flashing.is_set():
                _pt_connect()
        except Exception as e:
            pt_auto["status"] = "Auto-connect error: %s" % e
        time.sleep(3.0)

@app.route("/api/pt/connect", methods=["POST"])
def api_pt_connect():
    try:
        pt_auto["enabled"] = True              # pressing Connect re-arms auto-connect
        ok, payload = _pt_connect(restart_server=True)
        return (jsonify(payload), 200) if ok else (jsonify(payload), 400)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/pt/disconnect", methods=["POST"])
def api_pt_disconnect():
    pt_auto["enabled"] = False                 # a manual Disconnect stays disconnected
    pt_auto["status"] = "Disconnected (press Connect to resume auto-connect)"
    ptlink.disconnect()
    adb = find_adb()
    for p in (PT_PORT, BIOYOND_ROB_PORT, BIOYOND_HTTP_PORT):
        try: _adb_run([adb, "forward", "--remove", "tcp:%d" % p], timeout=10)
        except Exception: pass
    bioyond_bridge["rob"] = bioyond_bridge["http"] = False
    return jsonify(ok=True)

@app.route("/api/pt/bioyond/check")
def api_pt_bioyond_check():
    """Prove the forwarded Bioyond servers are really live (a listening server replied),
    not just that the adb tunnel accepted a socket."""
    out = _probe_bioyond()
    bioyond_bridge["rob"], bioyond_bridge["http"] = out["rob"], out["http"]
    return jsonify(ok=True, **out)

@app.route("/api/pt/send", methods=["POST"])
def api_pt_send():
    d = _body()
    try: ptlink.send(d.get("cmd", "")); return jsonify(ok=True)
    except Exception as e: return jsonify(ok=False, error=str(e)), 400

# ------------------------------------------------------------------ tablet settings from IFS
import re                      # needed at import time below; the module-level import is further down
# Everything an operator types into the tablet's main screen, readable and settable from here, so
# someone at a SCADA PC never has to walk to the touch screen. The tablet's command channel
# already answers "MISTDEPTH" with "Misting depth: 10 mm" and sets it with "MISTDEPTH 12" by
# driving its own keypad - so its own limits and saving apply, exactly as if typed there. That
# works on every tablet build since 2.00; nothing new is needed on the tablet.
PT_PARAMS = [
    # key            command        label on the tablet   unit
    ("mist_depth",   "MISTDEPTH",   "Misting depth",      "mm"),
    ("mist_power",   "MISTPOWER",   "Misting strength",   "%"),
    ("mist_cycles",  "MISTCYCLES",  "Misting cycles",     ""),
    ("mist_on",      "MISTON",      "Misting on time",    "s"),
    ("mist_off",     "MISTOFF",     "Misting off time",   "s"),
    ("clean_depth",  "CLEANDEPTH",  "Cleaning depth",     "mm"),
    ("clean_power",  "CLEANPOWER",  "Cleaning strength",  "%"),
    ("clean_cycles", "CLEANCYCLES", "Cleaning cycles",    ""),
    ("clean_on",     "CLEANON",     "Cleaning on time",   "s"),
    ("clean_off",    "CLEANOFF",    "Cleaning off time",  "s"),
]
_PT_KEYS = {k: (cmd, label, unit) for k, cmd, label, unit in PT_PARAMS}
PT_PRESETS_FILE = os.path.join(CONN_DIR, "puretip_presets.json")
_pt_ask_lock = threading.Lock()          # one conversation with the tablet at a time
_PT_NUM = re.compile(r"^\d{1,5}(\.\d{1,2})?$")
_ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def _pt_ask(cmd, want, timeout=6.0):
    """Send one command and return the first reply line that `want(line)` accepts, else None.
    Replies arrive on the same console stream the Puretip screen shows, so this listens to it."""
    q = ptlink.subscribe()
    ptlink.quiet = True
    try:
        ptlink.send(cmd, quiet=True)
        end = time.time() + timeout
        while time.time() < end:
            try:
                item = q.get(timeout=max(0.05, end - time.time()))
            except queue.Empty:
                break
            # The tablet colours its console (ANSI escapes); the words are what we match.
            line = _ANSI.sub("", item.get("line") or "").strip()
            if line.lower().startswith("puretip>"):
                line = line[8:].strip()
            if not line or line.startswith("> "):
                continue
            if line.upper() == cmd.strip().upper():
                continue            # the tablet echoes the command back; that is not the answer
            if want(line):
                return line
        return None
    finally:
        ptlink.quiet = False
        ptlink.unsubscribe(q)


def _pt_read_one(key):
    cmd, label, unit = _PT_KEYS[key]
    pre = label.lower() + ":"
    line = _pt_ask(cmd, lambda l: l.lower().startswith(pre) or l.upper().startswith("ERR"))
    if not line or line.upper().startswith("ERR"):
        return None
    m = re.search(r"-?\d+(\.\d+)?", line[len(pre):])
    return m.group(0) if m else None


def _pt_set_many(vals, abort=None):
    """Type each value in on the tablet, in screen order. Caller holds _pt_ask_lock."""
    results = {}
    for key, _c, _l, _u in PT_PARAMS:
        if key not in vals:
            continue
        if abort is not None and abort.is_set():
            break
        line = _pt_ask("%s %s" % (_PT_KEYS[key][0], vals[key]),
                       lambda l: l.upper().startswith("OK") or l.upper().startswith("ERR"),
                       timeout=8.0)
        results[key] = "ok" if (line and line.upper().startswith("OK")) else (line or "no reply")
    return results


def _pt_read_all():
    """All ten values. Tablet 2.06+ answers PARAMS in one line; older builds one by one."""
    line = _pt_ask("PARAMS", lambda l: "[PARAMS]" in l or l.upper().startswith("ERR"), timeout=4.0)
    if line and "[PARAMS]" in line:
        got = {}
        for tok in line.split("[PARAMS]", 1)[1].split():
            if "=" in tok:
                k, v = tok.split("=", 1); got[k] = v
        if all(k in got for k, _c, _l, _u in PT_PARAMS):
            ptlink.pushed["params"] = {k: got[k] for k, _c, _l, _u in PT_PARAMS}
            return {k: got[k] for k, _c, _l, _u in PT_PARAMS}
    out = {}
    for key, _c, _l, _u in PT_PARAMS:
        out[key] = _pt_read_one(key)
    return out


def _pt_check_values(vals):
    """Only known keys with plain numbers; anything else is refused before it reaches the tablet."""
    clean, bad = {}, []
    if not isinstance(vals, dict):                 # a string or a list is not a set of values
        return clean, bad
    for k, v in vals.items():
        if k not in _PT_KEYS:
            continue
        sv = _s(v, "").strip()
        if sv == "":
            continue
        if not _PT_NUM.match(sv):
            bad.append(_PT_KEYS[k][1])
            continue
        clean[k] = sv
    return clean, bad


@app.route("/api/pt/params")
def api_pt_params():
    if not ptlink.connected:
        return jsonify(ok=False, error="Connect the Puretip One tablet first."), 400
    with _pt_ask_lock:
        try:
            vals = _pt_read_all()
        except Exception as e:
            return jsonify(ok=False, error=str(e)), 400
    if all(v is None for v in vals.values()):
        return jsonify(ok=False, error="The tablet did not report its settings. Make sure the "
                                       "Puretip app is on its main screen, then try again."), 502
    return jsonify(ok=True, values=vals,
                   fields=[{"key": k, "label": l, "unit": u} for k, _c, l, u in PT_PARAMS])


@app.route("/api/pt/params", methods=["POST"])
def api_pt_params_apply():
    """Apply values to the tablet, one at a time, then read them all back: the tablet clamps to
    its own limits, and what it kept is what the operator must see."""
    if not ptlink.connected:
        return jsonify(ok=False, error="Connect the Puretip One tablet first."), 400
    vals, bad = _pt_check_values(_body().get("values"))
    if bad:
        return jsonify(ok=False, error="Numbers only for: " + ", ".join(bad)), 400
    if not vals:
        return jsonify(ok=False, error="Nothing to apply."), 400
    results = {}
    with _pt_ask_lock:
        try:
            results = _pt_set_many(vals)
            readback = _pt_read_all()
        except Exception as e:
            return jsonify(ok=False, error=str(e), results=results), 400
    failed = {k: v for k, v in results.items() if v != "ok"}
    differs = [_PT_KEYS[k][1] for k, v in vals.items()
               if readback.get(k) is not None and _num_eq(readback[k], v) is False]
    _ev("pt_settings", "info" if not (failed or differs) else "warn", "app", label="apply",
        detail={"set": vals, "failed": failed, "not_kept": differs})
    # "OK" from the tablet only means the keypad was driven. What it read back is the truth: a
    # system prompt or another screen in front of the app swallows the typing, and that must not
    # be reported as applied.
    err = None
    if failed:
        def why(k):
            r = failed[k] or ""
            m = re.search(r"\(([^)]*)\)", r)
            if "OUT_OF_RANGE" in r and m:
                return "%s must be %s" % (_PT_KEYS[k][1], m.group(1))
            if "whole numbers" in r:
                return "%s takes whole numbers only" % _PT_KEYS[k][1]
            return _PT_KEYS[k][1]
        err = "Not applied: " + "; ".join(why(k) for k in failed) + "."
    elif differs:
        err = ("The tablet did not keep: " + ", ".join(differs) + ". Something may be open on the "
               "tablet screen (a popup, a prompt or another screen), or the value is outside the "
               "tablet's limits. Close it and apply again.")
    return jsonify(ok=not (failed or differs), results=results, values=readback, adjusted=differs,
                   error=err)


def _num_eq(a, b):
    try:
        return abs(float(a) - float(b)) < 1e-6
    except Exception:
        return None


def _pt_presets():
    d = _json_read(PT_PRESETS_FILE)
    items = d.get("presets") if isinstance(d, dict) else None
    return items if isinstance(items, list) else []


@app.route("/api/pt/ack", methods=["POST"])
def api_pt_ack():
    """Acknowledge the popup on the tablet from here: silences a fault alarm and presses the
    popup's safe button (Cancel / No / Later, else OK). Needs tablet build 2.05."""
    if not ptlink.connected:
        return jsonify(ok=False, error="Connect the Puretip One tablet first."), 400
    # Popups stack (a message screen can open the next one when it closes), so keep going until
    # the tablet says nothing is showing - one Acknowledge in IFS clears the tablet's screen.
    line, left, rounds = None, None, 0
    with _pt_ask_lock:
        try:
            for rounds in range(1, 5):
                got = _pt_ask("ACK", lambda l: l.upper().startswith("OK") or l.upper().startswith("ERR"),
                              timeout=5.0)
                if not got or got.upper().startswith("ERR"):
                    line = line or got
                    break
                line = got if line is None or "NOTHING" in line.upper() else line + "; " + got.split(" - ", 1)[-1]
                time.sleep(0.35)                   # let the next screen, if any, come up
                pop = _pt_ask("POPUP", lambda l: l.upper().startswith("POPUP"), timeout=3.0) or ""
                left = pop[5:].strip() if pop.upper().startswith("POPUP") else None
                if not left or left.upper() == "NONE":
                    left = None
                    break
        except Exception as e:
            return jsonify(ok=False, error=str(e)), 400
    if not line:
        return jsonify(ok=False, error="The tablet did not answer."), 502
    if line.upper().startswith("ERR"):
        return jsonify(ok=False, error=line), 502
    old = "SILENCE" in line.upper()            # builds before 2.05 only silence the alarm
    _ev("pt_ack", "info", "app", label=line[:80])
    return jsonify(ok=True, result=line, remaining=left,
                   note=("This tablet build only silences the alarm; update it to 2.05 to close "
                         "popups from here.") if old else
                        (("A popup is still showing on the tablet: " + left) if left else None))


# ------------------------------------------------------------------ odometer: lifetime totals
# Like a car's odometer: what each unit has done in its life, kept on disk so it survives restarts
# and updates. Counted once a second from what the units themselves report:
#   Puretip (per tablet)  misting / cleaning runs and seconds - from the tablet's own countdown
#                         counters, which are only shown while that phase runs - and time connected
#   Plasma StandAlone     cycles and running seconds - from the STATE the controller reports
#   Tip Charger           plasma runs and plasma-on seconds - from the power it reports
ODO_FILE = os.path.join(CONN_DIR, "odometer.json")
_odo_lock = threading.Lock()
_odo = {"units": {}}
_odo_prev = {}
_odo_loaded = [False]       # never save before the totals on disk are read, or an early exit wipes them

def _odo_load():
    d = _json_read(ODO_FILE)              # {} when there is no file yet - a first run
    if isinstance(d, dict) and isinstance(d.get("units"), dict):
        _odo["units"] = d["units"]
    _odo_loaded[0] = True

def _odo_unit(key, name):
    u = _odo["units"].get(key)
    if not isinstance(u, dict):
        u = {"name": name, "since": time.strftime("%Y-%m-%d")}
        _odo["units"][key] = u
    if name:
        u["name"] = name
    return u

def _odo_add(u, field, v):
    u[field] = round(float(u.get(field, 0) or 0) + v, 2)

def _odo_tick(dt):
    changed = False
    # Puretip
    if ptlink.connected and pt_auto.get("serial"):
        serial = pt_auto["serial"]
        u = _odo_unit("pt:" + serial, _pt_name(serial) or ("Puretip One " + serial))
        _odo_add(u, "connected_s", dt); changed = True
        run = ptlink.pushed.get("run") or {}
        for phase, keys in (("mist", ("mon", "moff")), ("clean", ("con", "coff"))):
            on = run.get(keys[0], "-") not in ("-", "")
            active = on or run.get(keys[1], "-") not in ("-", "")
            if on:
                _odo_add(u, phase + "_s", dt)
            prev = _odo_prev.get("pt:" + phase, False)
            if active and not prev:
                _odo_add(u, phase + "_runs", 1)
            _odo_prev["pt:" + phase] = active
    # Plasma StandAlone
    if link.connected:
        u = _odo_unit("opta", "Plasma StandAlone")
        _odo_add(u, "connected_s", dt); changed = True
        st = str((link.last_status or {}).get("STATE", "")).upper()
        running = st not in ("", "IDLE", "READY", "ERROR", "ESTOP", "FAULT", "OFF", "--")
        if running:
            _odo_add(u, "run_s", dt)
        if running and not _odo_prev.get("opta", False):
            _odo_add(u, "cycles", 1)
        _odo_prev["opta"] = running
    # Tip Charger
    if tclink.connected:
        u = _odo_unit("tc", "Tip Charger")
        _odo_add(u, "connected_s", dt); changed = True
        c = tclink.last_csv or {}
        plasma = (c.get("power") or 0) > 0 and time.time() - (c.get("t") or 0) < 3
        if plasma:
            _odo_add(u, "plasma_s", dt)
        if plasma and not _odo_prev.get("tc", False):
            _odo_add(u, "plasma_runs", 1)
        _odo_prev["tc"] = plasma
    return changed

def _odo_save():
    if not _odo_loaded[0]:
        return
    with _odo_lock:
        snap = json.loads(json.dumps(_odo))
    try:
        _json_merge_write(ODO_FILE, snap)
    except Exception:
        pass

def _odo_loop():
    _odo_load()
    last, dirty, saved = time.time(), False, time.time()
    while True:
        time.sleep(1.0)
        now = time.time()
        dt = min(5.0, now - last); last = now          # a sleeping PC does not add hours
        try:
            with _odo_lock:
                dirty = _odo_tick(dt) or dirty
            if dirty and now - saved >= 5:
                _odo_save(); dirty = False; saved = now
        except Exception:
            pass

atexit.register(_odo_save)


@app.route("/api/odometer")
def api_odometer():
    with _odo_lock:
        units = json.loads(json.dumps(_odo["units"]))
    return jsonify(ok=True, units=units)


@app.route("/api/pt/live")
def api_pt_live():
    """What the tablet last pushed - answered from memory, nothing is sent to the tablet."""
    p = ptlink.pushed if ptlink.connected else {"params": None, "popup": None, "t": 0}
    pop = p.get("popup")
    return jsonify(ok=True, connected=ptlink.connected, params=p.get("params"),
                   popup=None if pop is None else (None if pop.upper() == "NONE" else pop),
                   teach=p.get("teach"), run=p.get("run"), unit=p.get("unit"),
                   pushes=pop is not None or p.get("params") is not None)


# Tip Calibration from IFS (tablet 2.06+). Stop and "still held" go straight out, never queued
# behind another exchange: a release must not wait. Everything else returns the tablet's answer.
PT_TEACH_CMDS = {"UP", "DOWN", "LEFT", "RIGHT", "HOMEZ", "EJECT", "NEXT", "PREV",
                 "CONTUP", "CONTDN", "KEEP", "STOP", "JOG", "STATE", "NAME", "EJECTTIPS", "CLOSE"}
PT_TEACH_JOGS = {"0.1", "1", "10", "20", "50"}


@app.route("/api/pt/teach", methods=["POST"])
def api_pt_teach():
    d = _body()
    cmd = _s(d.get("cmd"), "").strip().upper()
    if cmd not in PT_TEACH_CMDS:
        return jsonify(ok=False, error="Unknown Tip Calibration command."), 400
    if not ptlink.connected:
        return jsonify(ok=False, error="Connect the Puretip One tablet first."), 400
    line = "TEACH " + cmd
    if cmd == "JOG":
        v = _s(d.get("value"), "").strip()
        if v not in PT_TEACH_JOGS:
            return jsonify(ok=False, error="Jog step must be 0.1, 1, 10, 20 or 50 mm."), 400
        line += " " + v
    if cmd == "NAME":
        v = re.sub(r"[\x00-\x1f]", "", _s(d.get("value"), "")).strip()[:40]
        if not v:
            return jsonify(ok=False, error="Type a tip name."), 400
        line += " " + v
    if cmd in ("STOP", "KEEP"):
        try:
            ptlink.send(line, quiet=True)
        except Exception as e:
            return jsonify(ok=False, error=str(e)), 400
        return jsonify(ok=True, result="sent")
    if not _pt_ask_lock.acquire(timeout=3.0):
        return jsonify(ok=False, error="The tablet is busy; try again."), 409
    try:
        # a state push can arrive in the middle; only STATE takes one as its answer, so a real
        # ERR for a move is never masked by it
        reply = _pt_ask(line, lambda l: l.upper().startswith("OK TEACH") or l.upper().startswith("ERR")
                        or (cmd == "STATE" and "[TEACH]" in l), timeout=4.0)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400
    finally:
        _pt_ask_lock.release()
    if not reply:
        return jsonify(ok=False, error="The tablet did not answer. It needs Puretip build 2.06 or newer."), 502
    if reply.upper().startswith("ERR"):
        msg = reply.split(" - ", 1)[-1] if " - " in reply else reply
        if "UNKNOWN_COMMAND" in reply.upper():
            msg = "This tablet build cannot do Tip Calibration from IFS. Update it to 2.06."
        return jsonify(ok=False, error=msg), 409
    _ev("pt_teach", "info", "app", label=cmd)
    return jsonify(ok=True, result=reply)


@app.route("/api/pt/popup")
def api_pt_popup():
    """Is a popup showing on the tablet? showing=None when the tablet build cannot say (pre-2.05)."""
    if not ptlink.connected:
        return jsonify(ok=False, showing=None)
    pop = ptlink.pushed.get("popup")
    if pop is not None:                              # the tablet keeps us told: no need to ask
        return jsonify(ok=True, showing=pop.upper() != "NONE", title=None if pop.upper() == "NONE" else pop)
    if not _pt_ask_lock.acquire(timeout=1.0):        # busy applying settings: ask again later
        return jsonify(ok=True, showing=None)
    try:
        line = _pt_ask("POPUP", lambda l: l.upper().startswith("POPUP") or l.upper().startswith("ERR"),
                       timeout=3.0)
    except Exception:
        line = None
    finally:
        _pt_ask_lock.release()
    if not line or not line.upper().startswith("POPUP"):
        return jsonify(ok=True, showing=None)
    rest = line[5:].strip()
    return jsonify(ok=True, showing=rest.upper() != "NONE", title=None if rest.upper() == "NONE" else rest)


@app.route("/api/pt/presets")
def api_pt_presets():
    return jsonify(ok=True, presets=_pt_presets())


@app.route("/api/pt/presets", methods=["POST"])
def api_pt_presets_save():
    d = _body()
    name = re.sub(r"\s+", " ", _s(d.get("name"), "")).strip()[:40]
    if not name:
        return jsonify(ok=False, error="Give the preset a name."), 400
    vals, bad = _pt_check_values(d.get("values"))
    if bad:
        return jsonify(ok=False, error="Numbers only for: " + ", ".join(bad)), 400
    if not vals:
        return jsonify(ok=False, error="There are no values to save."), 400
    items = [p for p in _pt_presets() if (p.get("name") or "").lower() != name.lower()]
    items.append({"name": name, "values": vals, "saved": time.strftime("%Y-%m-%d %H:%M")})
    items.sort(key=lambda p: (p.get("name") or "").lower())
    try:
        _json_merge_write(PT_PRESETS_FILE, {"presets": items})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True, presets=items)


@app.route("/api/pt/presets/delete", methods=["POST"])
def api_pt_presets_delete():
    name = _s(_body().get("name"), "").strip().lower()
    items = [p for p in _pt_presets() if (p.get("name") or "").lower() != name]
    try:
        _json_merge_write(PT_PRESETS_FILE, {"presets": items})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True, presets=items)


@app.route("/api/pt/stream")
def api_pt_stream():
    def gen():
        q = ptlink.subscribe()
        try:
            for item in list(ptlink.buffer)[-200:]:   # inside try so a mid-replay disconnect unsubscribes
                if not item.get("q"): yield "data: %s\n\n" % json.dumps(item)
            while True:
                try:
                    item = q.get(timeout=15)
                    if not item.get("q"): yield "data: %s\n\n" % json.dumps(item)
                except queue.Empty: yield ": keepalive\n\n"
        finally: ptlink.unsubscribe(q)
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# PASTE THIS WHOLE BLOCK into the real 1.0.80 backend.py, anywhere after `app = Flask(...)`
# and after ptlink is defined (e.g. right before the self-update section). Self-contained:
# adds the read-only /api/by/* endpoints the Live View tab polls. Requires no new pip packages.

# ------------------------------------------------------------------ Bioyond robot (Rob INTF) - Live View
# Read-only status poller for the Bioyond robot controller. Protocol per Bioyond's
# "Specification - Rob INTF v1.1": TCP, port FIXED at 56788, newline-framed JSON tagged
# BRCAPI 1.0, and the robot accepts ONE client at a time - so we hold a single socket and
# reconnect lazily. Only get* queries are ever sent: this code can NEVER move the robot.
import re as _re
BY_PORT = 56788
BY_CFG  = os.path.expanduser("~/.ifs_live.json")   # user-writable (Program Files is not)

def _by_cfg_read():
    return _json_read(BY_CFG)

# Every config write goes through here. Two bugs lived in the old copy-pasted version:
#
#   1. one SHARED temp path per file. Two requests arriving together both opened "<file>.tmp",
#      and on Windows the second os.replace hit a sharing violation while the first still had
#      the handle - a 500 straight out of the endpoint. Measured: 44 of 80 concurrent writes
#      failed. The temp name now carries the writer's own thread id.
#   2. an unserialised read-modify-write. Two writers could read the same state and the later
#      one would silently drop the earlier one's key.
_CFG_LOCK = threading.RLock()

def _json_merge_write(path, patch):
    """Merge `patch` into the JSON at `path` and replace it atomically. Serialised, so a
    concurrent writer cannot lose an update or collide on the temp file."""
    with _CFG_LOCK:
        d = _json_read(path)                      # RLock: re-entrant, we already hold it
        d.update(patch)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        tmp = "%s.%d.tmp" % (path, threading.get_ident())
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f, indent=1)
            _replace_retry(tmp, path)
        except Exception:
            try:
                if os.path.exists(tmp): os.remove(tmp)
            except Exception: pass
            raise
        return d

def _json_read(path):
    """Read a config file under the same lock the writers use.

    Windows will not rename over a file that another handle has open, so an unsynchronised READ
    happening at the instant of os.replace made the WRITE fail. That is the last of the concurrent
    500s: the writers were already serialised against each other, but not against readers.
    """
    with _CFG_LOCK:
        try:
            with open(path, encoding="utf-8-sig") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}


def _replace_retry(tmp, path, tries=6):
    """os.replace, retried briefly. Even with our own access serialised, a virus scanner or the
    search indexer can hold the destination open for a few milliseconds after we close it."""
    for i in range(tries):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if i == tries - 1: raise
            time.sleep(0.02 * (i + 1))


def _json_write_atomic(path, obj, indent=None):
    """Replace `path` with `obj` atomically. For the callers that own the whole document and so
    must NOT merge - they already snapshot their state under their own lock. Same unique temp
    name, because two of these colliding used to lose a save silently: they swallow exceptions."""
    with _CFG_LOCK:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        tmp = "%s.%d.tmp" % (path, threading.get_ident())
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(obj, f, indent=indent)
            _replace_retry(tmp, path)
        except Exception:
            try:
                if os.path.exists(tmp): os.remove(tmp)
            except Exception: pass
            raise

def _by_cfg_write(patch):
    """MERGE into the config. Writing the whole dict from one caller silently dropped the other
    caller's key - saving the robot IP would erase a cell layout the operator had just drawn."""
    _json_merge_write(BY_CFG, patch)

class ByLink:
    def __init__(self):
        self.sock = None
        self.connected = False
        self.ip = ""
        self.err = ""
        self._id = 0
        self._rx = b""            # bytes that arrived past the end of the last message
        self.lock = threading.RLock()
        try:
            self.ip = (_by_cfg_read().get("robot_ip") or "")
        except Exception: pass

    def _save(self):
        try:
            _by_cfg_write({"robot_ip": self.ip})
        except Exception: pass

    def connect(self, ip):
        with self.lock:
            self.disconnect()
            self.sock = socket.create_connection((ip, BY_PORT), timeout=3)
            self.sock.settimeout(1.2)
            self._rx = b""
            self.ip = ip; self.connected = True; self.err = ""
            self._save()

    def disconnect(self):
        with self.lock:
            try:
                if self.sock: self.sock.close()
            except Exception: pass
            self.sock = None; self.connected = False; self._rx = b""

    def ask(self, cmd):
        """One BRCAPI query -> the 'ret' payload, or None.

        Two things the specification asks for that this used to get wrong.

        A reply carries back the id it was sent, and 2.3.1 says that is exactly so the client can
        tell which command a reply belongs to. This did not check it, so a reply left in the socket
        after an earlier timeout would be handed back as the answer to the NEXT question - the
        program state read as the system state, and nobody any the wiser. A reply that does not
        match is now discarded, and an id of -1 is the robot reporting a parse error (2.3.2).

        And messages are newline-delimited, so one TCP segment can carry two of them. The old
        reader took everything that arrived up to the last newline and parsed it as a single
        object - two replies in one segment was a JSON error, which dropped the link. It now keeps
        a carry-over buffer and takes one line at a time, which is what a line protocol requires.

        Every query this app sends is marked "not need a result reply" in Table 2-5, so exactly one
        reply per request is correct.
        """
        with self.lock:
            if not self.sock:
                return None
            self._id += 1
            want = self._id
            try:
                self.sock.sendall((json.dumps({"BRCAPI": "1.0", "cmd": cmd, "id": want}) + "\n").encode())
                for _ in range(8):                       # bounded: never spin on a chatty peer
                    m = json.loads(self._readline().decode("utf-8", "replace"))
                    mid = m.get("id")
                    if mid == -1:
                        self.err = "the robot could not parse the request"
                        return None
                    if mid != want:
                        continue                         # a leftover from an earlier question
                    if m.get("error"):
                        e = m["error"] if isinstance(m["error"], dict) else {}
                        code, msg = e.get("code"), e.get("message")
                        self.err = ("%s (error %s)" % (msg, code)) if code is not None \
                                   else str(msg or m["error"])
                        return None
                    return m.get("ret")
                self.err = "no reply carrying id %d" % want
                return None
            except Exception as e:
                self.err = str(e)
                self.disconnect()
                return None

    def _readline(self):
        """One newline-delimited message, keeping whatever else arrived with it."""
        while b"\n" not in self._rx:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise OSError("connection closed by robot")
            self._rx += chunk
            if len(self._rx) > 65536:
                raise OSError("oversized reply")
        line, self._rx = self._rx.split(b"\n", 1)
        return line

bylink = ByLink()
BY_SYS  = {0: "init", 1: "idle", 2: "running", 3: "error", 4: "paused", 5: "enabled"}
BY_PROG = {0: "stopped", 1: "running", 2: "paused", 3: "error"}
# Rob INTF 3.3.1: control mode is 0 = manual, 1 = auto, and "other values are illegal". This read
# 0 as "teach" and invented a third value, so a robot in MANUAL was labelled with a word the
# specification does not use.
BY_CTRL = {0: "manual", 1: "auto"}

# Which optional queries this robot actually answers. A BRCAPI *protocol* error returns
# None without dropping the socket (see ask()), so an unsupported command is survivable -
# we just stop asking for it, instead of retrying six times a second forever.
BY_UNSUPPORTED = set()

def by_try(cmd):
    """An optional query. Returns None if the robot does not implement it, and remembers
    that so later polls skip it."""
    if cmd in BY_UNSUPPORTED or not bylink.connected:
        return None
    r = bylink.ask(cmd)
    if r is None and bylink.connected:            # answered, but with an error -> unsupported
        BY_UNSUPPORTED.add(cmd)
    return r

def _by_errors(ret):
    """Rob INTF 3.3.5: getRobotErr answers with a LIST of {errCode, errMsg}, and a HEALTHY robot
    answers [{"errCode":null,"errMsg":null}] - a non-empty list. Passing that straight through
    reported a fault on a robot that has none, because a non-empty list is truthy. Only entries
    that actually carry a code or a message are errors."""
    if isinstance(ret, dict):
        for key in ("value", "errors", "data"):
            if isinstance(ret.get(key), (list, dict)):
                ret = ret[key]; break
    if isinstance(ret, dict):
        ret = [ret]
    if not isinstance(ret, list):
        return None
    out = []
    for e in ret:
        if not isinstance(e, dict):
            continue
        code, msg = e.get("errCode"), e.get("errMsg")
        if code is None and not _s(msg):
            continue                       # the "no error" row
        text = _s(msg)
        named = BY_ALARMS.get(code if isinstance(code, int) else None)
        if named and not text:
            text = named                   # the robot said nothing; the manual does
        out.append({"errCode": code, "errMsg": text})
    return out or None


def by_xyz(frame):
    """getFrameWithU0T0 shapes vary by controller build: a dict of named axes, or a bare
    list [x,y,z,rx,ry,rz]. Accept both, return None if it is neither."""
    if isinstance(frame, dict):
        for key in ("pose", "frame", "value", "data"):        # sometimes wrapped one deep
            if isinstance(frame.get(key), (dict, list)):
                frame = frame[key]; break
    if isinstance(frame, dict):
        got = {}
        for a in ("x", "y", "z", "rx", "ry", "rz"):
            v = frame.get(a, frame.get(a.upper()))
            if isinstance(v, (int, float)): got[a] = float(v)
        return got if {"x", "y", "z"} <= set(got) else None
    if isinstance(frame, list) and len(frame) >= 3 and all(isinstance(v, (int, float)) for v in frame[:3]):
        names = ("x", "y", "z", "rx", "ry", "rz")
        return {names[i]: float(frame[i]) for i in range(min(6, len(frame)))}
    return None

def by_joints(ji):
    if isinstance(ji, dict):
        for key in ("joints", "value", "data", "pos"):
            if isinstance(ji.get(key), list): ji = ji[key]; break
    if isinstance(ji, list):
        out = [float(v) for v in ji if isinstance(v, (int, float))]
        return out[:8] or None
    return None

@app.route("/api/by/state")
def api_by_state():
    """Everything the Live View's cell graphic needs, in ONE poll. Strictly read-only:
    every command here is a get*, so this endpoint can never move the robot."""
    if not bylink.connected:
        return jsonify(connected=False, ip=bylink.ip, error=bylink.err)
    sysr  = bylink.ask("getSysState")
    progr = bylink.ask("getProgState") if bylink.connected else None
    if not bylink.connected:                      # a query above dropped the link
        return jsonify(connected=False, ip=bylink.ip, error=bylink.err)
    sysv  = sysr.get("value")  if isinstance(sysr, dict)  else None
    progv = progr.get("value") if isinstance(progr, dict) else None

    # The real motion: where the tool actually is. This is what makes the cell graphic
    # show what the plate system is DOING rather than a canned "something is happening".
    pose   = by_xyz(by_try("getFrameWithU0T0"))
    joints = by_joints(by_try("getJointInfo"))
    ctrlr  = by_try("getCtrlMode")
    enr    = by_try("getEnableStatus")
    errr   = _by_errors(by_try("getRobotErr"))
    luar   = by_try("getLuaAppStatus")

    def val(r):
        return r.get("value") if isinstance(r, dict) and "value" in r else r

    return jsonify(connected=True, ip=bylink.ip,
                   sys=BY_SYS.get(sysv, "?"), prog=BY_PROG.get(progv, "?"),
                   pose=pose, joints=joints,
                   ctrl=BY_CTRL.get(val(ctrlr), None),
                   enabled=(bool(val(enr)) if val(enr) is not None else None),
                   roboterr=errr,
                   lua=(val(luar) if isinstance(val(luar), (str, int)) else None),
                   unsupported=sorted(BY_UNSUPPORTED))

# The plan's fixture placement is a SKETCH - the robot never reports where its fixtures are -
# so the operator draws their own cell here and it is kept on this PC. Stored and validated
# server-side rather than in browser storage so it survives a reinstall of the WebView data and
# can be backed up with the rest of the config.
BY_LAYOUT_MAX = 24

@app.route("/api/by/layout")
def api_by_layout_get():
    # The version belongs to the LAYOUT, not to each fixture: the per-fixture field never survived
    # this endpoint's whitelist, so the page could never tell a current layout from an old one and
    # threw the operator's saved cell away on every load.
    cfg = _by_cfg_read()
    return jsonify(ok=True, layout=cfg.get("layout"), v=int(cfg.get("layout_v") or 0))

@app.route("/api/by/layout", methods=["POST"])
def api_by_layout_set():
    d = _body()
    items = d.get("layout")
    if items is None:                                  # explicit reset -> forget it, fall back to default
        try:
            _by_cfg_write({"layout": None, "layout_v": 0})
        except Exception as e:
            return jsonify(ok=False, error="could not save: %s" % e), 500
        return jsonify(ok=True, layout=None, v=0)
    if not isinstance(items, list):
        return jsonify(ok=False, error="layout must be a list of fixtures."), 400
    if len(items) > BY_LAYOUT_MAX:
        return jsonify(ok=False, error="too many fixtures (max %d)." % BY_LAYOUT_MAX), 400
    clean = []
    for it in items:
        if not isinstance(it, dict):
            return jsonify(ok=False, error="each fixture must be an object."), 400
        try:
            f = {"label": str(it.get("label", ""))[:28],
                 "x": float(it["x"]), "y": float(it["y"]),
                 "w": float(it["w"]), "h": float(it["h"])}
        except (KeyError, TypeError, ValueError):
            return jsonify(ok=False, error="each fixture needs numeric x, y, w and h."), 400
        # keep it inside the plan and big enough to grab again once saved
        if not all(-500 <= v <= 1500 for v in (f["x"], f["y"])) or not (6 <= f["w"] <= 1000 and 6 <= f["h"] <= 1000):
            return jsonify(ok=False, error="fixture is off the plan or too small."), 400
        clean.append(f)
    try:
        ver = int(d.get("v") or 0)
    except (TypeError, ValueError):
        ver = 0
    ver = max(0, min(999, ver))
    try:
        _by_cfg_write({"layout": clean, "layout_v": ver})
    except Exception as e:
        return jsonify(ok=False, error="could not save: %s" % e), 500
    return jsonify(ok=True, layout=clean, v=ver, saved=len(clean))

@app.route("/api/by/connect", methods=["POST"])
def api_by_connect():
    d = _body()
    ip = _s(d.get("ip"), "")
    if not _re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip):
        return jsonify(ok=False, error="Enter the robot's IP address (e.g. 192.168.1.220)."), 400
    try:
        bylink.connect(ip)
        return jsonify(ok=True)
    except Exception as e:
        # Rob INTF (BY-RD-02-003 v1.1, 2. Overview): the robot controller is the SERVER and it
        # "only supports the connection with one client at a time". So the usual reason this
        # fails on a working cell is that Bioyond's own scheduler already holds that one socket -
        # worth saying, because otherwise it reads as a network fault and sends people hunting.
        others = ", ".join(a["ip"] for a in BY_DOC_ADDRS if a["ip"] != ip)
        return jsonify(ok=False,
                       error="Could not reach the robot at %s:%d - %s. The robot accepts one "
                             "client at a time, so this also fails while Bioyond's own scheduler "
                             "is connected to it. The manuals also give %s."
                             % (ip, BY_PORT, e, others)), 502

@app.route("/api/by/disconnect", methods=["POST"])
def api_by_disconnect():
    bylink.disconnect()
    return jsonify(ok=True)

# ------------------------------------------------------------------ IFS Suite Pro licensing
# IFS Suite runs one instrument and is free with it. IFS Suite Pro adds the fleet, the records and
# the integration, and is unlocked by a licence file we sign. Checked entirely offline, because the
# labs this sells into run locked-down and sometimes air-gapped machines.
#
# Nothing below can stop an instrument. The gate is only ever consulted by Pro features.
LICENCE_FILE = os.path.join(CONN_DIR, "licence.ifslic")
_lic_lock = threading.RLock()
_lic = None


def _licence(refresh=False):
    """This station's licence, re-read when asked. Cheap: the signature check is a few ms."""
    global _lic
    with _lic_lock:
        if _lic is None or refresh:
            try:
                _lic = licence.read_licence(LICENCE_FILE, _station_cfg().get("station_id", ""))
            except Exception as e:
                _boot_log("licence: could not be read (%s)" % e)
                _lic = {"ok": False, "tiers": [], "features": [], "state": "error",
                        "reason": "The licence could not be read.", "host_id": ""}
        return dict(_lic)


def _pro(feature):
    """Is this Pro feature unlocked? Never call this on anything that runs an instrument."""
    return feature in (_licence().get("features") or ())


def _needs_pro(feature, what):
    """The refusal a locked Pro endpoint returns. Says plainly that the instrument is unaffected."""
    lic = _licence()
    return jsonify(ok=False, pro_required=True, feature=feature, state=lic.get("state"),
                   error="%s is part of IFS Suite Pro. %s The instrument is unaffected and keeps "
                         "running." % (what, lic.get("reason") or "")), 402


@app.route("/api/licence")
def api_licence():
    """What this station is licensed for. Readable without a licence, by design: somebody has to be
    able to find the station id in order to be sent one."""
    lic = _licence(refresh=request.args.get("refresh") == "1")
    lic["days_left"] = licence.days_left(lic)
    lic["product"] = "IFS Suite Pro"
    lic["tiers_available"] = list(licence.TIERS)
    return jsonify(ok=True, licence=lic)


@app.route("/api/licence", methods=["POST"])
def api_licence_install():
    """Install a licence. Takes the file's text, so it can be pasted on a machine with no way to
    move files about. It is written only after it verifies, so a bad paste cannot displace a
    working licence."""
    d = _body()
    text = _s(d.get("text"))
    if not text:
        return jsonify(ok=False, error="Paste the licence file's contents."), 400

    tmp = LICENCE_FILE + ".check"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        checked = licence.read_licence(tmp, _station_cfg().get("station_id", ""))
        if not checked["ok"]:
            os.remove(tmp)
            return jsonify(ok=False, error=checked["reason"] or "That licence was refused.",
                           state=checked["state"]), 400
        _replace_retry(tmp, LICENCE_FILE)
    except Exception as e:
        try:
            os.remove(tmp)
        except Exception:
            pass
        return jsonify(ok=False, error="Could not save the licence: %s" % e), 500

    lic = _licence(refresh=True)
    lic["days_left"] = licence.days_left(lic)
    _boot_log("licence: installed %s for %s, tiers %s"
              % (lic.get("id"), lic.get("issued_to"), ",".join(lic.get("tiers") or [])))
    return jsonify(ok=True, licence=lic)


@app.route("/api/licence", methods=["DELETE"])
def api_licence_remove():
    """Take the licence off this station, for moving it to another one."""
    try:
        if os.path.isfile(LICENCE_FILE):
            os.remove(LICENCE_FILE)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    _licence(refresh=True)
    return jsonify(ok=True)


# ------------------------------------------------------------------ Pro: activation and the fleet
FN_BASE = "https://xrhwilnjbqykazbjbdie.supabase.co/functions/v1/"


def _fn(name, payload, timeout=15):
    """Call one of our edge functions. Returns (ok, body-or-error)."""
    import urllib.request
    import urllib.error
    req = urllib.request.Request(
        FN_BASE + name, data=json.dumps(payload).encode("utf-8"), method="POST",
        headers={"apikey": FLEET_KEY, "Authorization": "Bearer " + FLEET_KEY,
                 "Content-Type": "application/json"})
    try:
        with _ota_open(req, timeout=timeout) as r:
            return True, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return False, json.loads(e.read().decode("utf-8"))
        except Exception:
            return False, {"ok": False, "error": "The licence service answered %s." % e.code}
    except Exception as e:
        return False, {"ok": False, "error": "Could not reach the licence service: %s" % e}


def _lic_friendly(err):
    """The licence service's short answers as a sentence with the next step in it. ("This licence
    is void." was shown as-is, which read like the feature itself was broken.)"""
    e = (err or "").strip()
    low = e.lower()
    if "not recognised" in low:
        return ("That licence key was not found. Check it against the email it came in - keys look "
                "like XXXX-XXXX-XXXX-XXXX - and try again.")
    if "is void" in low or "is revoked" in low or "withdrawn" in low:
        return ("This licence key has been withdrawn and can no longer be activated. Ask Augeas "
                "for a replacement key.")
    if "is suspended" in low:
        return "This licence key is suspended. Contact Augeas to have it restored."
    if "ended on" in low:
        return e + " Ask Augeas to renew it."
    if "seat" in low and "in use" in low:
        return (e + " On the PC that no longer needs it, press Move to another PC first, then "
                "activate here.")
    if "could not reach" in low or "timed out" in low or "urlopen" in low or "getaddrinfo" in low \
            or "connection" in low or not e:
        return ("Could not reach the Augeas licence service. Check this PC's internet connection, "
                "or use 'Activating a station without internet?' below.")
    return e


@app.route("/api/licence/activate", methods=["POST"])
def api_licence_activate():
    """Activate with a key, the way a product key is entered. The signed licence comes back and is
    verified here before it is kept, so a wrong answer from the service cannot unlock anything."""
    d = _body()
    key = _s(d.get("key"))
    if not key:
        return jsonify(ok=False, error="Enter your licence key."), 400
    # A key is exactly 16 letters and digits; sent on in the XXXX-XXXX-XXXX-XXXX form.
    chars = re.sub(r"[^A-Z0-9]", "", key.upper())
    if len(chars) != 16:
        return jsonify(ok=False, error="A licence key is 16 letters and digits; %d entered." % len(chars)), 400
    key = "-".join(chars[i:i + 4] for i in range(0, 16, 4))
    cfg = _station_cfg()
    ok, body = _fn("ifs-licence", {"action": "activate", "key": key,
                                   "station_id": cfg.get("station_id", ""),
                                   "station_name": cfg.get("station_name") or socket.gethostname()})
    if not ok or not body.get("ok"):
        return jsonify(ok=False, error=_lic_friendly((body or {}).get("error") or ""),
                       raw=(body or {}).get("error")), 400

    text = json.dumps(body["licence"], indent=1)
    tmp = LICENCE_FILE + ".check"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        checked = licence.read_licence(tmp, cfg.get("station_id", ""))
        if not checked["ok"]:
            os.remove(tmp)
            return jsonify(ok=False, error="The licence that came back did not verify: %s"
                                           % checked["reason"]), 502
        _replace_retry(tmp, LICENCE_FILE)
    except Exception as e:
        try:
            os.remove(tmp)
        except Exception:
            pass
        return jsonify(ok=False, error="Could not save the licence: %s" % e), 500

    lic = _licence(refresh=True)
    lic["days_left"] = licence.days_left(lic)
    _boot_log("licence: activated %s for %s" % (lic.get("id"), lic.get("issued_to")))
    return jsonify(ok=True, licence=lic, reactivated=bool(body.get("reactivated")))


@app.route("/api/licence/release", methods=["POST"])
def api_licence_release():
    """Hand the seat back so this licence can be used on another PC. The licence is removed here
    only after the service has accepted the release, so a seat can never be lost by a failed call."""
    lic = _licence()
    key = lic.get("id", "")
    if not key:
        return jsonify(ok=False, error="There is no licence on this station."), 400
    cfg = _station_cfg()
    ok, body = _fn("ifs-licence", {"action": "release", "key": key,
                                   "station_id": cfg.get("station_id", "")})
    if not ok or not body.get("ok"):
        return jsonify(ok=False, error=(body or {}).get("error")
                       or "Could not release the seat. The licence has been left in place."), 502
    try:
        if os.path.isfile(LICENCE_FILE):
            os.remove(LICENCE_FILE)
    except Exception as e:
        return jsonify(ok=False, error="The seat was released but the file could not be "
                                       "removed: %s" % e), 500
    _licence(refresh=True)
    _boot_log("licence: released %s" % key)
    return jsonify(ok=True, message="Released. Activate this key on the other PC.")


@app.route("/api/fleet/map")
def api_fleet_map():
    if not _pro("fleet_dashboard"):
        return _needs_pro("fleet_dashboard", "The fleet map")
    ok, body = _fn("ifs-fleet", {"action": "list", "key": _licence().get("id", "")})
    if not ok or not body.get("ok"):
        return jsonify(ok=False, error=(body or {}).get("error") or "Could not read the fleet."), 502
    body["me"] = _station_cfg().get("station_id", "")
    return jsonify(body)


@app.route("/api/fleet/station", methods=["POST"])
def api_fleet_station():
    """Rename a station, move it on the map, or forget one that has been retired."""
    if not _pro("fleet_dashboard"):
        return _needs_pro("fleet_dashboard", "The fleet map")
    d = _body()
    action = _s(d.get("action"), "rename")
    if action not in ("rename", "move", "forget"):
        return jsonify(ok=False, error="rename, move or forget"), 400
    payload = {"action": action, "key": _licence().get("id", ""),
               "station_id": _s(d.get("station_id"))}
    if action == "rename":
        payload["name"] = _s(d.get("name"))[:80]
    if action == "move":
        try:
            payload["x"] = round(float(d.get("x")), 1)
            payload["y"] = round(float(d.get("y")), 1)
        except (TypeError, ValueError):
            return jsonify(ok=False, error="Where to?"), 400
    ok, body = _fn("ifs-fleet", payload)
    if not ok or not body.get("ok"):
        return jsonify(ok=False, error=(body or {}).get("error") or "That did not work."), 502
    return jsonify(ok=True)


# ------------------------------------------------------------------ Pro: usage totals
def _usage_totals(since="", until=""):
    """Totals over the run history. Dry runs are counted apart from real ones throughout: a dry
    run touches no hardware, and folding the two together would overstate how hard a station has
    actually worked."""
    runs = _read_store(PROTO_RUNS_FILE)
    tot = {"runs": 0, "real": 0, "dry": 0, "finished": 0, "failed": 0, "stopped": 0,
           "seconds": 0.0, "real_seconds": 0.0}
    by_op, by_proto, by_day = {}, {}, {}

    for r in runs:
        when = _s(r.get("when"))
        day = when[:10]
        if since and day and day < since:
            continue
        if until and day and day > until:
            continue

        dry = bool(r.get("dry"))
        secs = float(r.get("secs") or 0)
        res = _s(r.get("result"), "unknown")
        who = _s(r.get("who")) or "not signed in"
        proto = _s(r.get("protocol")) or "unnamed"

        tot["runs"] += 1
        tot["dry" if dry else "real"] += 1
        tot["seconds"] += secs
        if not dry:
            tot["real_seconds"] += secs
        if res in ("finished", "failed", "stopped"):
            tot[res] += 1

        for bucket, key in ((by_op, who), (by_proto, proto), (by_day, day or "unknown")):
            e = bucket.setdefault(key, {"runs": 0, "real": 0, "dry": 0, "seconds": 0.0,
                                        "finished": 0, "failed": 0, "stopped": 0})
            e["runs"] += 1
            e["dry" if dry else "real"] += 1
            e["seconds"] += secs
            if res in ("finished", "failed", "stopped"):
                e[res] += 1

    for d in (tot,):
        d["seconds"] = round(d["seconds"], 1)
        d["real_seconds"] = round(d["real_seconds"], 1)
    for bucket in (by_op, by_proto, by_day):
        for e in bucket.values():
            e["seconds"] = round(e["seconds"], 1)

    cfg = _station_cfg()
    return {"station": cfg.get("name") or socket.gethostname(),
            "station_id": cfg.get("station_id", ""),
            "since": since, "until": until,
            "totals": tot,
            "by_operator": [dict(name=k, **v) for k, v in
                            sorted(by_op.items(), key=lambda kv: -kv[1]["runs"])],
            "by_protocol": [dict(name=k, **v) for k, v in
                            sorted(by_proto.items(), key=lambda kv: -kv[1]["runs"])],
            "by_day": [dict(day=k, **v) for k, v in sorted(by_day.items())]}


@app.route("/api/pro/usage")
def api_pro_usage():
    if not _pro("usage_totals"):
        return _needs_pro("usage_totals", "Usage reporting")
    return jsonify(ok=True, usage=_usage_totals(_s(request.args.get("since")),
                                                _s(request.args.get("until"))))


@app.route("/api/pro/usage.csv")
def api_pro_usage_csv():
    """The same totals as a file, for a service review or an audit."""
    if not _pro("usage_totals"):
        return _needs_pro("usage_totals", "Usage reporting")
    u = _usage_totals(_s(request.args.get("since")), _s(request.args.get("until")))

    def q(v):
        v = "" if v is None else str(v)
        return '"%s"' % v.replace('"', '""') if any(c in v for c in ',"\n\r') else v

    rows = [["IFS Suite Pro usage report"], ["station", u["station"]],
            ["station id", u["station_id"]],
            ["from", u["since"] or "the beginning"], ["to", u["until"] or "now"],
            ["generated", time.strftime("%Y-%m-%d %H:%M")], []]
    t = u["totals"]
    rows += [["totals"], ["runs", t["runs"]], ["on hardware", t["real"]], ["dry", t["dry"]],
             ["finished", t["finished"]], ["failed", t["failed"]], ["stopped", t["stopped"]],
             ["seconds on hardware", t["real_seconds"]], []]
    for title, key, first in (("by operator", "by_operator", "name"),
                              ("by protocol", "by_protocol", "name"),
                              ("by day", "by_day", "day")):
        rows.append([title])
        rows.append([first, "runs", "on hardware", "dry", "finished", "failed", "stopped", "seconds"])
        for e in u[key]:
            rows.append([e[first], e["runs"], e["real"], e["dry"], e["finished"], e["failed"],
                         e["stopped"], e["seconds"]])
        rows.append([])

    body = "\r\n".join(",".join(q(c) for c in r) for r in rows) + "\r\n"
    name = "IFS-usage-%s-%s.csv" % (u["station_id"][:8] or "station", time.strftime("%Y%m%d"))
    return Response(body, mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="%s"' % name})


# ------------------------------------------------------------------ fleet heartbeat
# Every station posts what it is and what it is talking to, so the fleet can be seen from one
# page instead of by walking the floor. Same shape as the Puretip One heartbeat already running
# on this project (public.device_heartbeat).
#
# The key below is Supabase's PUBLISHABLE key and is meant to ship in the client. What makes
# that safe is the RLS on public.ifs_heartbeat: anon may INSERT and nothing else. Verified from
# a station's point of view - SELECT returns empty, and UPDATE/DELETE report success while
# changing zero rows.
#
# Nothing here can affect the machine. It is one outbound POST on a daemon thread, wrapped so a
# failure is logged and dropped: a station with no network, or a Supabase outage, must run the
# plasma cycle exactly as it does now.
FLEET_URL   = "https://xrhwilnjbqykazbjbdie.supabase.co/rest/v1/ifs_heartbeat"
FLEET_KEY   = "sb_publishable_Fa7xAxYXpi8-vAwaNM3jnQ_eDm0BYfD"
FLEET_EVERY = 300.0                       # 5 minutes; the dashboard calls a station stale at 15
STATION_FILE = os.path.join(CONN_DIR, "station.json")

def _station_cfg():
    """Stable identity for this install. The id is generated once and kept; the name is the
    operator's label and falls back to the machine name so a station is findable on site."""
    cfg = _json_read(STATION_FILE)
    if not cfg.get("station_id"):
        import uuid
        cfg["station_id"] = uuid.uuid4().hex[:16]
        try:
            _json_merge_write(STATION_FILE, cfg)
        except Exception:
            pass                          # unwritable profile: keep a per-run id rather than fail
    return cfg

def _fleet_links():
    """The same six links the Home map draws, computed from the same state the UI polls, so the
    dashboard and the station can never tell different stories."""
    try:
        age = link.rx_age()
        opta = bool(link.connected and age is not None and age < 6.0)
    except Exception:
        opta, age = False, None
    st = {}
    try: st = link.last_status or {}
    except Exception: pass
    def _c(o):
        try: return bool(getattr(o, "connected", False))
        except Exception: return False
    ota = False
    try:
        import urllib.request
        ota = bool(_ota_manifest(OTA_MANIFEST, 6).get("version"))
    except Exception:
        ota = False
    links = {"opta": opta,
             "disp": _c(tclink),
             "pt":   _c(ptlink),
             "by":   _c(bylink),
             "servo": bool(opta and str(st.get("SERVO", "")).upper() == "READY"),
             "ota":  ota}
    return links, st

def _insight_brief():
    """A small, cheap summary for the heartbeat. Seven days rather than twenty-eight so a station
    that has just been fixed stops looking broken within a week rather than within a month."""
    try:
        d = insight.summary(_store(), 7)
        return {"score": d.get("score"), "util": d.get("utilisation"),
                "quality": d.get("quality"), "avail": d.get("availability"),
                "good": d.get("good"), "bad": d.get("bad"), "samples": d.get("samples")}
    except Exception:
        return {}                      # a station with no history still beats


def _station_place():
    """Where this station is, as cheaply as it can honestly be known.

    The timezone comes off the operating system, so there is no lookup service, no permission
    prompt and no IP address leaving the network. It is coarse by nature - a timezone is a band,
    not an address - which is the right trade for a fleet list that only needs to tell one site
    from another. `site` is whatever the operator typed on the Configuration screen, and is
    simply absent when they typed nothing.
    """
    out = {}
    try:
        import time as _t
        out["tz"] = _t.tzname[_t.daylight and _t.localtime().tm_isdst > 0] or _t.tzname[0]
    except Exception:
        pass
    try:
        import datetime as _dt                  # not imported at module scope in this file
        off = _dt.datetime.now().astimezone().strftime("%z")        # e.g. +0530
        if len(off) == 5:
            out["utc"] = "%s%s:%s" % (off[0], off[1:3], off[3:5])
    except Exception:
        pass
    try:
        site = (_station_cfg().get("site") or "").strip()
        if site:
            out["site"] = site[:80]
    except Exception:
        pass
    return out


def _fleet_beat():
    import urllib.request, socket, platform
    cfg = _station_cfg()
    links, st = _fleet_links()
    _lic_state = _licence()
    body = {
        "station_id":   cfg.get("station_id", "unknown"),
        "station_name": cfg.get("station_name") or socket.gethostname(),
        "version":      APP_VERSION,
        "host":         socket.gethostname(),
        "os":           platform.platform(),
        "links":        links,
        "links_up":     sum(1 for v in links.values() if v),
        # Licence state rides inside detail, which is already free-form. Sending it as columns of
        # its own had ifs_heartbeat reject every beat with a 400, because those columns do not
        # exist, and the fleet went quiet without saying why.
        # Where it is running. Timezone off the OS, plus the operator's own site label if they
        # set one. Nothing here costs a network call or a permission.
        "detail":       dict(_station_place(), **{"mode": link.mode, "info": link.info,
                         "state": st.get("STATE"), "servo": st.get("SERVO"),
                         "frozen": bool(getattr(sys, "frozen", False)),
                         "licence": _lic_state.get("state", "none"),
                         "licence_id": _lic_state.get("id", ""),
                         "licence_days": licence.days_left(_lic_state),
                         # The seven-day score, so a desk can rank a fleet without anyone
                         # opening each station. It rides inside detail for the reason the
                         # licence fields do: ifs_heartbeat has no column for it, and adding
                         # one as a top-level key had the table reject every beat with a 400.
                         "insight": _insight_brief()}),
    }
    req = urllib.request.Request(
        FLEET_URL, data=json.dumps(body).encode("utf-8"), method="POST",
        headers={"apikey": FLEET_KEY, "Authorization": "Bearer " + FLEET_KEY,
                 "Content-Type": "application/json", "Prefer": "return=minimal"})
    with _ota_open(req, timeout=10) as r:
        return r.status

def _fleet_loop():
    cfg = _station_cfg()
    if cfg.get("telemetry") is False or os.environ.get("IFS_NO_TELEMETRY"):
        _boot_log("fleet: heartbeat disabled by configuration")
        return
    time.sleep(20)                        # let the app finish booting and settle first
    while True:
        try:
            _fleet_beat()
        except Exception as e:
            _boot_log("fleet: heartbeat failed (%s)" % e)   # never fatal; the station keeps running
        time.sleep(FLEET_EVERY)


# ------------------------------------------------------------------ Insight: the sampler
# One row every INSIGHT_EVERY seconds describing the conditions right now. This is the whole
# feature: everything downstream is SQL over rows this loop wrote. It samples only what the app
# already holds in memory for the dashboard, so it costs no serial traffic and cannot disturb a
# cycle.
INSIGHT_EVERY = 30.0


def _insight_sample():
    st = {}
    try: st = link.last_status or {}
    except Exception: pass
    csv = {}
    try: csv = tclink.last_csv or {}
    except Exception: pass

    def _num(v):
        try: return float(v)
        except Exception: return None

    try:
        links, _ = _fleet_links()
        up = sum(1 for v in links.values() if v)
    except Exception:
        up = None
    try:
        busy = 1 if _run_state.get("active") else 0
    except Exception:
        busy = 0
    # The display's CSV goes stale when the panel stops talking. A reading from twenty minutes ago
    # recorded as if it were current is worse than no reading, so it is dropped past two minutes.
    fresh = (time.time() - csv.get("t", 0)) < 120 if csv.get("t") else False
    return {
        "ts": time.time(),
        "state": _s(st.get("STATE"), ""),
        "servo": _s(st.get("SERVO"), ""),
        "temp_f": _num(st.get("TEMP_F")),
        "power":  _num(csv.get("power")) if fresh else None,
        "temp_c": _num(csv.get("temp")) if fresh else None,
        "vacuum": _num(csv.get("vac")) if fresh else None,
        "carriage": _num(st.get("POS") or st.get("CARRIAGE")),
        "links_up": up,
        "busy": busy,
        "mode": _s(getattr(link, "mode", ""), ""),
    }


def _insight_loop():
    time.sleep(25)                       # after the fleet beat, so boot stays quiet
    last_links, last_prune = None, 0.0
    while True:
        try:
            row = _insight_sample()
            _store().add_sample(row)
            # Links changing state is an event in its own right - it is the single most common
            # thing an operator reports, and without this it leaves no trace between samples.
            up = row.get("links_up")
            if last_links is not None and up is not None and up != last_links:
                if up < last_links:
                    _ev("link_lost", "warn", "app", label="%d of 6 up" % up,
                        detail={"from": last_links, "to": up})
                else:
                    _ev("link_up", "info", "app", label="%d of 6 up" % up,
                        detail={"from": last_links, "to": up})
            last_links = up
            if time.time() - last_prune > 86400:
                _store().prune()
                last_prune = time.time()
        except Exception as e:
            _boot_log("insight: sample failed (%s)" % e)      # never fatal
        time.sleep(INSIGHT_EVERY)


# ------------------------------------------------------------------ Insight: the API
# Reading the station's own history needs no licence. Charging for a machine's account of itself
# would be a strange thing to do, and the data is already on the customer's disk. IFS AI is the
# Pro part, because it costs us money per question.
@app.route("/api/insight/summary")
def api_insight_summary():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    st = _store()
    out = insight.summary(st, days)
    out["span"] = st.span()
    out["ok"] = True
    _cfg = _ai_cfg()
    _has_key = insight.have_key(_ai_key())
    _lt = _json_read(STATION_FILE).get("ai_last_test") or {}
    _reach = _local_up(_cfg["url"]) if _cfg["provider"] in ("local", "both") else None
    out["ai"] = {"available": _ai_ready(_cfg),
                 "reachable": _reach, "url": _cfg["url"] if _cfg["provider"] in ("local", "both") else None,
                 "last_test": _lt if _lt.get("provider") == _cfg["provider"] else None,
                 "pro": _pro("insight_ai"), "provider": _cfg["provider"],
                 "cloud_ready": _has_key,
                 "model": (_cfg["model"] if _cfg["provider"] in ("local", "both")
                           else _cfg["openai_model"] if _cfg["provider"] == "openai" else insight.MODEL),
                 "cloud_model": insight.MODEL}
    if st.last_error:
        out["warning"] = st.last_error
    return jsonify(out)


@app.route("/api/insight/series")
def api_insight_series():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    field = _s(request.args.get("field"), "temp_f")
    return jsonify(ok=True, field=field, points=insight.series(_store(), field, days))


@app.route("/api/insight/findings")
def api_insight_findings():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    return jsonify(ok=True, **insight.findings(_store(), days))


@app.route("/api/insight/events")
def api_insight_events():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    since = time.time() - days * 86400.0
    rows = _store().q("SELECT ts,kind,severity,source,secs,label FROM event "
                      "WHERE ts >= ? ORDER BY ts DESC LIMIT 200", (since,))
    return jsonify(ok=True, items=rows)


@app.route("/api/insight/tiles")
def api_insight_tiles():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    return jsonify(ok=True, **insight.tiles(_store(), days))


@app.route("/api/insight/daily")
def api_insight_daily():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    return jsonify(ok=True, items=insight.daily(_store(), days))


@app.route("/api/insight/heat")
def api_insight_heat():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    metric = "fail" if _s(request.args.get("metric"), "") == "fail" else "busy"
    return jsonify(ok=True, **insight.heat(_store(), days, metric))


@app.route("/api/insight/dist")
def api_insight_dist():
    days = max(1, min(400, _i(request.args.get("days"), 28)))
    field = _s(request.args.get("field"), "temp_f")
    return jsonify(**insight.distribution(_store(), field, days))


# ------------------------------------------------------------------ Insight: MCP servers
# A lab's own systems - their LIMS, their ticketing, an inventory service - speak MCP or can be
# made to. Rather than guess which ones matter, the station lets the customer point IFS AI at
# theirs.
#
# These are tool surfaces we did not write and cannot see inside, so three rules hold:
#   * A server is OFF until somebody turns it on. Nothing is enabled by adding it.
#   * HTTPS only. The token is a bearer credential and does not go over plaintext.
#   * The token is never read back. It is written once and masked thereafter, the same way every
#     other credential field in this application behaves.
MCP_FILE = "mcp-servers.json"
MCP_MASK = "----------------"


def _mcp_all():
    return _read_store(MCP_FILE)


def _mcp_public(items):
    """What the UI is allowed to see. Everything except the token."""
    out = []
    for r in items:
        out.append({"id": r.get("id", ""), "name": r.get("name", ""), "url": r.get("url", ""),
                    "note": r.get("note", ""), "enabled": bool(r.get("enabled")),
                    "has_token": bool(r.get("token"))})
    return out


@app.route("/api/insight/mcp")
def api_insight_mcp():
    return jsonify(ok=True, items=_mcp_public(_mcp_all()))


@app.route("/api/insight/mcp", methods=["POST"])
def api_insight_mcp_save():
    d = _body()
    name = _s(d.get("name"), "")[:60]
    url = _s(d.get("url"), "")[:500]
    sid = _s(d.get("id"), "")
    if not name:
        return jsonify(ok=False, error="Give it a name."), 400
    if not url.lower().startswith("https://"):
        return jsonify(ok=False, error="The address must start with https://"), 400
    items = _mcp_all()
    row = None
    for r in items:
        if r.get("id") == sid:
            row = r
            break
    if row is None:
        row = {"id": "mcp-" + uuid.uuid4().hex[:10]}
        items.append(row)
    row["name"] = name
    row["url"] = url
    row["note"] = _s(d.get("note"), "")[:200]
    row["enabled"] = bool(d.get("enabled"))
    tok = _s(d.get("token"), "")
    if tok and tok != MCP_MASK:
        row["token"] = tok                      # a fresh secret
    elif d.get("clear_token"):
        row["token"] = ""
    # An absent or masked token leaves whatever is already stored alone, so editing the name of a
    # server does not silently wipe its credential.
    warn = _write_store(MCP_FILE, items)
    return jsonify(ok=True, id=row["id"], items=_mcp_public(items), warning=warn)


@app.route("/api/insight/mcp", methods=["DELETE"])
def api_insight_mcp_delete():
    sid = _s(request.args.get("id") or _body().get("id"), "")
    items = [r for r in _mcp_all() if r.get("id") != sid]
    warn = _write_store(MCP_FILE, items)
    return jsonify(ok=True, items=_mcp_public(items), warning=warn)


# ------------------------------------------------------------------ Insight: the key
# The customer's own Anthropic key, held on their station. Augeas's key is deliberately NOT
# shipped: it would mean Augeas paying for every customer's questions, and a key inside an exe is
# a key anyone holding the exe can read. Written once, masked thereafter, and sent nowhere except
# to Anthropic.
def _ai_key():
    return _s(_json_read(STATION_FILE).get("anthropic_key"), "")


def _ai_cfg():
    """Which model answers. Local is offered first in the UI for a reason: a lab with no internet,
    or a lab not allowed to send anything out of it, is the normal case rather than the exception."""
    c = _json_read(STATION_FILE)
    return {"provider": _s(c.get("ai_provider"), "") or "anthropic",
            "url": _s(c.get("ollama_url"), "") or ollama.DEFAULT_URL,
            "model": _s(c.get("ollama_model"), "") or ollama.DEFAULT_MODEL,
            "openai_url": _s(c.get("openai_url"), "") or openai_chat.DEFAULT_URL,
            "openai_model": _s(c.get("openai_model"), "")}


def _openai_key():
    """The customer's own OpenAI (or compatible) key, held on their station. Never sent to the page."""
    return _s(_json_read(STATION_FILE).get("openai_key"), "")


_local_probe = {"url": "", "t": 0.0, "up": False}

def _local_up(url):
    """Is anything answering at the network model's address? Cached for 20 s - the status line
    asks every few seconds and a dead address must not cost a timeout each time."""
    now = time.time()
    if _local_probe["url"] == url and now - _local_probe["t"] < 20:
        return _local_probe["up"]
    up = False
    try:
        import urllib.request
        with urllib.request.urlopen(url.rstrip("/") + "/api/version", timeout=2.0) as r:
            up = r.status == 200
    except Exception:
        up = False
    _local_probe.update(url=url, t=now, up=up)
    return up


def _ai_ready(c=None):
    """Can the configured provider answer at all? (key present / model chosen)"""
    c = c or _ai_cfg()
    p = c["provider"]
    if p in ("local", "both"):
        return True
    if p == "openai":
        return bool(_openai_key() and c["openai_model"])
    return bool(_ai_key() or os.environ.get("ANTHROPIC_API_KEY"))


@app.route("/api/insight/warm", methods=["POST"])
def api_insight_warm():
    """Called when the assistant is opened. Loading a 35B takes 6.6s and asking it something takes
    0.6s, so the whole difference between fast and slow is whether this ran first."""
    c = _ai_cfg()
    if c["provider"] != "local":
        return jsonify(ok=True, warmed=False, reason="not a local model")
    t = threading.Thread(target=insight.warm_local, args=(c["url"], c["model"], _ui_tools()), daemon=True)
    t.start()
    return jsonify(ok=True, warmed=True, model=c["model"])


@app.route("/api/insight/key")
def api_insight_key():
    k = _ai_key()
    return jsonify(ok=True, set=bool(k), tail=(k[-4:] if len(k) > 8 else ""),
                   env=bool(os.environ.get("ANTHROPIC_API_KEY")))


@app.route("/api/insight/provider")
def api_insight_provider():
    c = _ai_cfg()
    out = dict(c)
    out["ok"] = True
    out["key_set"] = bool(_ai_key() or os.environ.get("ANTHROPIC_API_KEY"))
    if request.args.get("probe") == "1":
        out["models"], out["probe_error"] = ollama.models(c["url"])
    return jsonify(out)


@app.route("/api/insight/provider", methods=["POST"])
def api_insight_provider_save():
    d = _body()
    prov = _s(d.get("provider"), "anthropic")
    if prov not in ("anthropic", "local", "both", "openai"):
        return jsonify(ok=False, error="Unknown provider."), 400
    url = _s(d.get("url"), "") or ollama.DEFAULT_URL
    if not (url.startswith("http://") or url.startswith("https://")):
        return jsonify(ok=False, error="The address must start with http:// or https://"), 400
    try:
        _json_merge_write(STATION_FILE, {"ai_provider": prov, "ollama_url": url,
                                         "ollama_model": _s(d.get("model"), "")
                                                         or ollama.DEFAULT_MODEL})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    # The two providers speak different message shapes, so a thread cannot be carried across.
    with _chat_lock:
        _chat["messages"] = []
    return jsonify(ok=True, provider=prov)


@app.route("/api/insight/openai")
def api_insight_openai():
    c = _ai_cfg(); k = _openai_key()
    return jsonify(ok=True, set=bool(k), tail=(k[-4:] if len(k) > 8 else ""),
                   url=c["openai_url"], model=c["openai_model"])


@app.route("/api/insight/openai", methods=["POST"])
def api_insight_openai_save():
    """Key, address and model for OpenAI or a compatible service. A blank key keeps the stored one."""
    d = _body()
    patch = {}
    if "url" in d:
        url = _s(d.get("url"), "").strip() or openai_chat.DEFAULT_URL
        if not (url.startswith("https://") or url.startswith("http://")):
            return jsonify(ok=False, error="The address must start with https:// (or http:// on your own network)."), 400
        patch["openai_url"] = url.rstrip("/")
    if d.get("key"):
        k = _s(d.get("key"), "").strip()
        if len(k) < 20 or any(ch.isspace() for ch in k):
            return jsonify(ok=False, error="That does not look like an API key. Copy it again from the provider."), 400
        patch["openai_key"] = k
    if d.get("clear") is True:
        patch["openai_key"] = ""
    if "model" in d:
        patch["openai_model"] = _s(d.get("model"), "").strip()[:120]
    if not patch:
        return jsonify(ok=False, error="Nothing to save."), 400
    try:
        _json_merge_write(STATION_FILE, patch)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True)


@app.route("/api/insight/openai/models")
def api_insight_openai_models():
    c = _ai_cfg(); k = _openai_key()
    if not k:
        return jsonify(ok=False, error="Save your key first."), 400
    ids, err = openai_chat.models(c["openai_url"], k)
    if err:
        return jsonify(ok=False, error=err), 502
    # Chat models first; embeddings, audio and image models cannot answer questions.
    skip = ("embedding", "whisper", "tts", "dall-e", "moderation", "image", "audio", "transcribe", "realtime", "search")
    chat_ids = [i for i in ids if not any(s in i.lower() for s in skip)]
    return jsonify(ok=True, models=chat_ids or ids)


@app.route("/api/insight/test", methods=["POST"])
def api_insight_test():
    """Ask the configured provider one tiny question, so the setup wizard can say it works."""
    c = _ai_cfg()
    p = _s(_body().get("provider"), "") or c["provider"]
    t0 = time.time()
    reply, err = None, None
    try:
        if p == "openai":
            if not _openai_key():
                err = "No key saved."
            elif not c["openai_model"]:
                err = "Choose a model first."
            else:
                reply, err = openai_chat.test(c["openai_url"], _openai_key(), c["openai_model"])
        elif p in ("local", "both"):
            r = ollama._post(c["url"], "/api/generate",
                             {"model": c["model"], "prompt": "Reply with the single word OK.",
                              "stream": False, "think": False, "options": {"num_predict": 8}}, timeout=120)
            with r:
                reply = (json.loads(r.read().decode("utf-8", "replace")).get("response") or "").strip() or "(empty reply)"
        else:
            k = _ai_key() or os.environ.get("ANTHROPIC_API_KEY", "")
            if not k:
                err = "No key saved."
            else:
                import anthropic
                client = anthropic.Anthropic(api_key=k)
                m = client.messages.create(model=insight.MODEL, max_tokens=16,
                                           messages=[{"role": "user", "content": "Reply with the single word OK."}])
                reply = "".join(getattr(b, "text", "") for b in m.content).strip() or "(empty reply)"
    except Exception as e:
        err = insight._friendly(e) if p not in ("local", "both", "openai") else (
            ollama._unreachable(c["url"], e) if p in ("local", "both") else openai_chat.friendly(e))
    ms = int((time.time() - t0) * 1000)
    try:
        _json_merge_write(STATION_FILE, {"ai_last_test": {"ok": not err, "provider": p, "t": time.time(),
                                                          "error": (err or "")[:200]}})
    except Exception:
        pass
    if p in ("local", "both"):
        _local_probe["t"] = 0.0                     # re-check reachability on the next status
    if err:
        return jsonify(ok=False, error=err, ms=ms), 200
    return jsonify(ok=True, reply=reply[:200], ms=ms, provider=p)


@app.route("/api/insight/setup", methods=["POST"])
def api_insight_setup():
    """Remember that this person has seen the AI setup (finished or 'Not now'), so it is offered
    once at first sign-in rather than at every one."""
    who = _session.get("id") or "station"
    seen = _json_read(STATION_FILE).get("ai_setup_seen") or []
    if not isinstance(seen, list):
        seen = []
    if who not in seen:
        seen.append(who)
        _json_merge_write(STATION_FILE, {"ai_setup_seen": seen[-200:]})
    return jsonify(ok=True)


@app.route("/api/insight/setup")
def api_insight_setup_state():
    who = _session.get("id") or "station"
    seen = _json_read(STATION_FILE).get("ai_setup_seen") or []
    return jsonify(ok=True, seen=isinstance(seen, list) and who in seen, ready=_ai_ready(),
                   pro=_pro("insight_ai"), provider=_ai_cfg()["provider"])


@app.route("/api/insight/key", methods=["POST"])
def api_insight_key_save():
    d = _body()
    k = _s(d.get("key"), "").strip()
    # A blank save used to store "" over the real key - any stray POST wiped it. Removing the key
    # is now its own explicit request.
    if not k and d.get("clear") is not True:
        return jsonify(ok=False, error="Paste a key that starts with sk-ant-."), 400
    if k and not k.startswith("sk-ant-"):
        return jsonify(ok=False, error="An Anthropic API key starts with sk-ant-."), 400
    try:
        _json_merge_write(STATION_FILE, {"anthropic_key": k})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True, set=bool(k))


# ------------------------------------------------------------------ Insight: what screen, and
# the one thing the assistant is allowed to change.
# (Superseded: it now presses and fills the application's own controls too. Anything that moves,
# heats, energises or erases asks the operator unless the owner switched "operate" on, and its
# own settings, the licence, updates and signing in are never reachable - see _AI_NEVER.)
#
# NAVIGATE is on the list because a view is inert: nothing happens to the instrument because
# somebody looked at a screen. Nothing else that acts is on the list at all.
#
# There is no tool to move the carriage, open the actuator, strike plasma, start or abort a cycle,
# or flash firmware - and that is not an oversight waiting for a confirmation dialog. The
# assistant's context carries text from the lab's own MCP services, which Augeas does not control
# and cannot audit, so anything reachable from the tool list is reachable by a sentence arriving
# in that text. The dangerous things are therefore absent rather than guarded.
SCREENS = {
    "home":  "Home - every link this application has, and whether it is up.",
    "fleet": "Fleet - every station on site, Pro only.",
    "insight": "Insight - this station's recorded history, the score, findings and charts.",
    "dash":  "Plasma StandAlone overview - the chamber, telemetry and subsystem health.",
    "mon":   "Serial Monitor - the raw controller serial stream, and a box to type commands.",
    "log":   "Data Log - temperature and power charted per run.",
    "tune":  "Tuning - live power, electrode temperature and vacuum.",
    "cfg":   "Configuration - network addresses, positions, plasma time, licence, workspaces.",
    "ctl":   "Control - the cycle and the manual outputs. A person drives this, not you.",
    "fw":    "Firmware - the controller firmware update.",
    "tc":    "Tip Charger - the touch display's settings and its firmware.",
    "pt":    "Puretip One - the tablet station and the scheduler bridge.",
    "live":  "Live View - the automation cell.",
    "proto": "Protocol - building a run as a sequence of steps.",
}

# Every inert thing the assistant may change, and the only things it may change. Each one alters
# what is on display and nothing else; each is undone with a click. Adding a row here is adding a
# capability, so the question to ask of a candidate is not "is it useful" but "what is the worst
# a wrong call does" - and for everything in this list the answer is "shows the wrong chart".
VIEW_ACTIONS = {
    "go_to_screen":  ("screen", sorted(SCREENS), "Show one of the application's screens."),
    "set_range":     ("days", ["7", "28", "90"], "Set the window the Insight charts cover."),
    "set_heatmap":   ("metric", ["busy", "fail"],
                      "Plot hours running, or failures, on the Insight heatmap."),
    "set_spread":    ("field", ["temp_f", "temp_c", "power", "vacuum"],
                      "Choose the measure the good-against-bad histograms compare."),
    "refresh":       ("", [], "Re-read the history and redraw."),
}

# --------------------------------------------------------------- every control in the application
# Parsed out of the markup rather than listed by hand. The hand-written list reached 18 of 106
# buttons and none of the 93 fields, because keeping a second copy of the UI in a Python dict is
# a job nobody remembers to do. This cannot drift: it IS the UI.
import re                      # module-level: the file only had a local "re as _re" further down

_CTL_TAG = re.compile(r'<(button|input|select|textarea)\b([^>]*?)>(?:(.*?)</\1>)?', re.S | re.I)
_CTL_ATTR = re.compile(r'(\w[\w-]*)\s*=\s*"([^"]*)"')
_CTL_VIEW = re.compile(r'<section class="view[^"]*" id="view-([a-z]+)"')

# Moves, heats, energises, erases, or writes firmware. Greedy on purpose: a false positive costs
# the operator one click, a false negative starts a plasma nobody asked for.
_HAZ = re.compile(
    r"plasma|pump|vacuum|hv\b|high.?volt|carriage|actuator|servo|motor|move|jog|"
    r"cycle|run\b|start|flash|firmware|erase|clear|delete|reset|factory|wipe|purge|"
    r"relay|heater|arm\b|fire|strike|calibrat", re.I)
_STOPPY = re.compile(r"stop|abort|halt|estop|e-stop|cancel", re.I)

# The screens that reach the instrument. On these, a control nobody has classified asks first.
_INSTRUMENT_SCREENS = {"dash", "mon", "tune", "ctl", "fw", "tc", "pt", "live", "proto"}

# Verbs that are inert wherever they appear. Without these the flip below would put a confirmation
# in front of Refresh and Export on the Tuning screen, and a confirmation that appears for
# everything is not a safety feature - it is training people to click through them unread.
_INERT = re.compile(r"refresh|reload|export|download|copy|rescan|scan\b|check|view|show|open|"
                    r"close|back|next|prev|search|find|filter|zoom|tidy|save|rename|print|help",
                    re.I)

# Where the keyword pass is wrong, in both directions. Every one of these was found by reading
# the survey, and both kinds were in it.
_HAZ_PIN = {
    # --- flagged dangerous, is not. Mostly the word "power" or "start" sitting in a label.
    "in-dist-field": False,       # a chart selector; its OPTIONS contain "Power"
    "in-heat-metric": False,
    "st-name": False,             # a text box whose placeholder says "plasma station"
    "lw-rule-type": False,        # "Starts with" matched "start"
    "lw-scan-last": False,
    "pr-dry": False,              # a dry run is the safe one; that is the point of it
    "pr-runs-refresh": False,
    "set-cooltime": False,
    "dl-scan": False, "dl-auto": False, "dl-name": False,
    "b-robotport": False, "b-subnet": False,
    # --- NOT flagged, and should be. These reach the instrument.
    "sendBtn": True,              # puts an arbitrary command on the wire to the controller
    "ptSendBtn": True,            # the same, to the tablet station
    "set-apply": True,            # writes pump and plasma times into the display
    "dl-serial-set": True,        # writes the serial number onto the device
    "connectBtn": True, "tcConnectBtn": True, "byConnectBtn": True, "ptConnectBtn": True,
    "lw-scan-conn": True,
    "appfw-update": True,         # replaces the running application
    "optafw-check": False,
    # The Tip Charger's settings boxes do not reach the display when you type in them: they sit
    # locally until "Apply to display", which asks. Making each box ask as well would put four
    # confirmations in front of one action, which is how confirmations stop being read.
    "set-bright": False, "set-vac": False, "set-pumpon": False, "set-pumpoff": False,
    "set-plasmatime": False, "tc-otype": False, "tc-oindex": False, "tc-oval": False,
    "tc-baud": False, "tc-host": False, "tc-port": False, "tc-serial": False,
    "cfg-unlock-pos": True, "cfg-unlock-lem": True,   # unlock the calibration numbers
}


def _discover_controls():
    """Every control in the UI: id -> what it is, what it says, where it lives, is it dangerous."""
    try:
        with open(os.path.join(STATIC, "index.html"), encoding="utf-8") as fh:
            html = fh.read()
    except Exception:
        return {}

    views = sorted((m.start(), m.group(1)) for m in _CTL_VIEW.finditer(html))

    def screen_at(pos):
        cur = ""
        for start, name in views:
            if start <= pos:
                cur = name
            else:
                break
        return cur

    out = {}
    for m in _CTL_TAG.finditer(html):
        tag = m.group(1).lower()
        attrs = dict(_CTL_ATTR.findall(m.group(2) or ""))
        el = attrs.get("id")
        if not el or el in out:
            continue
        inner = "" if tag == "select" else (m.group(3) or "")
        label = re.sub(r"<[^>]+>", " ", inner)
        label = " ".join(re.sub(r"&[a-z]+;", " ", label).split())
        if not label:
            label = (attrs.get("title") or attrs.get("placeholder")
                     or attrs.get("aria-label") or "")
        label = label.strip()[:70]
        txt = el + " " + label + " " + attrs.get("class", "")
        screen = screen_at(m.start())
        if el in _HAZ_PIN:
            haz = _HAZ_PIN[el]                      # a human decided this one; nothing overrides it
        elif _STOPPY.search(txt):
            haz = False                             # stopping is always allowed, everywhere
        elif _HAZ.search(txt):
            haz = True
        elif _INERT.search(txt):
            haz = False
        else:
            # Nothing matched. On an instrument screen that is a reason to ask, not a reason to
            # assume: the controls this will meet are the ones not yet written, and an opaque id
            # with an icon for a label matches none of the patterns above.
            haz = screen in _INSTRUMENT_SCREENS
        out[el] = {
            "tag": tag, "label": label, "screen": screen,
            "hazard": haz, "stop": bool(_STOPPY.search(txt)),
            "kind": "button" if tag == "button" else "field",
            "type": attrs.get("type", ""),
        }
    return out


CONTROLS = _discover_controls()
BUTTONS = {k: v for k, v in CONTROLS.items() if v["kind"] == "button"}
FIELDS = {k: v for k, v in CONTROLS.items() if v["kind"] == "field"}


def _ctl_exact(name):
    """Only an exact id, an old hand-written name, or a label/id that matches word for word."""
    n = _s(name, "").strip()
    if not n:
        return None
    if n in CONTROLS:
        return n
    if n in PRESS_SAFE:
        return PRESS_SAFE[n][0]
    if n in PRESS_CONFIRM:
        return PRESS_CONFIRM[n][0]
    low = n.lower().replace("_", " ").replace("-", " ").strip()
    hits = [el for el, c in CONTROLS.items()
            if low in (el.lower().replace("-", " "), (c["label"] or "").lower().strip())]
    return hits[0] if len(hits) == 1 else None


def _ctl_find(name):
    """Resolve what the model asked for to a real control id.

    It will not always send an id. It sends "the connect button", or "start_plasma" from the old
    list, or the label off the screen. Refusing those is refusing on a technicality, which is the
    behaviour being removed.
    """
    n = _s(name, "").strip()
    if not n:
        return None
    if n in CONTROLS:
        return n
    low = n.lower().replace("_", " ").replace("-", " ").strip()
    # the old hand-written names, so nothing that used to work stops working
    legacy = dict(PRESS_SAFE)
    legacy.update(PRESS_CONFIRM)
    if n in legacy:
        return legacy[n][0]
    best = None
    for el, c in CONTROLS.items():
        for cand in (el.lower().replace("-", " "), c["label"].lower()):
            if not cand:
                continue
            if cand == low:
                return el
            if best is None and low and (low in cand or cand in low):
                best = el
    if best:
        return best
    # "plasma time" against the id "set-plasmatime": the words are right and the space is not.
    tight = low.replace(" ", "")
    for el, c in CONTROLS.items():
        if tight and (tight in el.lower().replace("-", "").replace("_", "")
                      or tight in c["label"].lower().replace(" ", "")):
            return el
    # Last resort: how many of their words does this control contain? "station name" is not a
    # substring of anything, but both its words are in st-name's id and label. Scored rather
    # than matched, because the alternative is telling them there is no such field when there is.
    words = [w for w in low.split() if len(w) > 2]
    if not words:
        return None
    best, score = None, 0
    for el, c in CONTROLS.items():
        hay = (el.lower().replace("-", " ").replace("_", " ") + " " + c["label"].lower())
        parts = [x for x in re.split(r"[^a-z0-9]+", hay) if x]
        hit = 0
        for w in words:
            # Prefix either way, so "licence" finds "lic-key" and "brightness" finds "set-bright".
            # Plain containment alone matched "licence key" to the Anthropic key box, because the
            # only word that landed was "key".
            if any(x == w or (len(w) >= 3 and x.startswith(w[:4]))
                   or (len(x) >= 3 and w.startswith(x[:4])) for x in parts):
                hit += 1
        if hit:
            idparts = [x for x in re.split(r"[^a-z0-9]+",
                                           el.lower().replace("-", " ")) if x]
            if any(x == w or (len(w) >= 3 and x.startswith(w[:4])) for w in words for x in idparts):
                hit += 0.5          # the id itself says so, not just some text inside it
        if hit > score:
            best, score = el, hit
    return best if score else None


# Buttons the assistant may press itself. Each entry is (element id, what to say afterwards).
# The test for being on this list is not "is it useful" - it is "what is the worst a wrong press
# does", and for everything here the answer is "redraws something" or "makes the machine safer".
PRESS_SAFE = {
    # Drawings and views. Blocking these was the mistake that started this.
    "show_animation":        ("demoBtn",        "Toggled the chamber animation."),
    "show_cell_animation":   ("byDemoBtn",      "Toggled the cell animation."),
    # Reading things. None of these change anything.
    "rescan_ports":          ("dispfw-rescan",  "Rescanned the ports."),
    "check_for_updates":     ("appfw-check",    "Checked for an update."),
    # Redrawing.
    "refresh":               ("in-refresh",     "Redrew the page."),
    "refresh_fleet":         ("fleet-refresh",  "Re-read the fleet."),
    "tidy_fleet":            ("fleet-tidy",     "Tidied the fleet layout."),
    # Writing a file out. Nothing is lost by it.
    "export_data_log":       ("dl-export",      "Exported the data log."),
    # STOPPING. On this list deliberately: an assistant that may start a thing but not stop it
    # is the wrong way round, and there is no case where pressing stop is the dangerous choice.
    "stop_plasma":           ("ts-plasma-off",  "Stopped the plasma."),
    "stop_pump":             ("ts-pump-off",    "Stopped the pump."),
    "stop_run":              ("pr-stop",        "Stopped the run."),
    "emergency_stop":        ("ts-estop",       "Pressed E-STOP."),
}

# Buttons the assistant may SET UP but not press. It fills the control in and puts a button in
# the conversation; the operator taps it. The label is what that button says.
PRESS_CONFIRM = {
    "run_protocol":     ("pr-run",        "Run the protocol"),
    "start_plasma":     ("ts-plasma-on",  "Start the plasma"),
    "start_pump":       ("ts-pump-on",    "Start the pump"),
    "connect_display":  ("tcConnectBtn",  "Connect the display"),
    "clear_data_log":   ("dl-clear",      "Clear the whole data log"),
    "flash_controller": ("flashBtn",      "Flash the controller firmware"),
}

PRESS_TOOL = {
    "name": "press_button",
    # Worded as an instruction to CALL it, not as a description of a permission. The first
    # version said the dangerous ones "are set up for the operator and they press it", which the
    # model read as a prohibition - it explained where the button was and never called the tool,
    # so no confirmation button ever appeared. Measured: three times out of three.
    "description": "Press a button in the application. ALWAYS call this when the operator asks "
                   "for something on this list - including starting, running, connecting or "
                   "flashing. For those, calling it does not press the button: it puts a "
                   "confirmation button in front of the operator, which is how they get one. "
                   "Never answer 'you need to press it yourself' without calling this first, and "
                   "never answer 'I cannot' - call it and let the reply tell you what happened. "
                   "Buttons that only change the display, read something, export, or STOP "
                   "something are always pressed immediately. The reply tells you which happened.",
    "input_schema": {
        "type": "object",
        "properties": {
            # No enum. An enum of 18 names was the cage: everything else came back "no such
            # button", which reads as a refusal. Any id or label in the application works, and
            # a wrong one comes back with the near misses rather than a flat no.
            "button": {"type": "string",
                       "description": "The button's id, or the words on it. Any button in the "
                                      "application. Call read_screen if you need the list."},
        },
        "required": ["button"],
        "additionalProperties": False,
    },
    "strict": True,
}


def _ai_operates():
    """May the assistant work the instrument itself, rather than asking first?

    Off unless the station turns it on, so a site decides rather than inheriting a default.

    One override, and it is not about trusting the operator: with an MCP service enabled, text
    from a system Augeas does not control enters the model's context, and a sentence arriving in
    it must not be able to strike plasma. The instruction might not have come from the person at
    the bench. So hardware goes back to asking.
    """
    if not bool(_json_read(STATION_FILE).get("ai_operate")):
        return False, "off"
    try:
        if any(m.get("enabled") for m in _mcp_all()):
            return False, "mcp"
    except Exception:
        pass
    return True, "on"


# What every field on every screen currently holds. The browser posts this before each question;
# it is the only way anything on the server can know what is in a text box. Kept out of the
# prompt and served through read_screen, because 199 values is 6KB and 6KB of prompt on a local
# 35B is most of ten seconds before the first word.
_ui_state = {}
_ui_state_lock = threading.Lock()


@app.route("/api/insight/state", methods=["POST"])
def api_insight_state():
    d = _body() or {}
    vals = d.get("values") or {}
    if not isinstance(vals, dict):
        return jsonify(ok=False, error="values must be an object."), 400
    with _ui_state_lock:
        _ui_state.clear()
        for k, v in list(vals.items())[:400]:
            _ui_state[_s(k, "")[:80]] = _s(v, "")[:200]
    return jsonify(ok=True, n=len(_ui_state))


# The assistant's own settings, the licence, the update, and signing in. Changing any of these is
# the operator's decision about the assistant or about who is using the station - never the
# assistant's. Without this, set_field("in-operate", "on") switched off its own confirmations and
# an injected instruction could point it at another model server or wipe the Anthropic key.
_AI_NEVER = {"in-operate", "in-key", "in-keysave", "in-ourl", "in-omodel", "in-osave",
             "in-oprobe", "in-prov", "in-mcp", "in-mcp-add", "in-newchat", "in-q", "in-ask",
             "st-telemetry", "updateBtn"}
_AI_NEVER_PREFIX = ("lic-", "lg-", "in-mcp")

def _ai_forbidden(el):
    return bool(el) and (el in _AI_NEVER or el.startswith(_AI_NEVER_PREFIX))

_AI_FORBIDDEN_MSG = ("That control belongs to the operator - the assistant's own settings, the "
                     "licence, updates and signing in are never changed by the assistant. Tell "
                     "the operator where it is instead.")

# Names of people and places. The model is told the station's state, not who runs it or where.
_AI_PRIVATE = {"st-name", "ts-op", "fleet-name", "pr-name", "lg-name", "lg-su-name",
               "lg-fg-name", "by-fx-label"}


def _read_screen(screen):
    """Every control on one screen, with what it currently holds."""
    sc = _s(screen, "").strip()
    if sc not in SCREENS:
        return {"error": "No screen called '%s'. The screens are: %s"
                         % (sc, ", ".join(sorted(SCREENS)))}
    with _ui_state_lock:
        vals = dict(_ui_state)
    out = []
    for el, c in sorted(CONTROLS.items()):
        if c["screen"] != sc:
            continue
        row = {"id": el, "kind": c["kind"], "label": c["label"]}
        if _ai_forbidden(el):
            continue
        if c["kind"] == "field":
            row["value"] = "(private)" if el in _AI_PRIVATE else vals.get(el, "")
        if c["hazard"]:
            row["asks_first"] = True
        out.append(row)
    live = {}
    try:
        for k, v in (link.last_status or {}).items():
            live[k] = v
    except Exception:
        pass
    return {"screen": sc, "about": SCREENS[sc], "controls": out,
            "controller": live or "not connected"}


def _set_field(el, value):
    """Type a value into a field. Returns (event_payload, message_for_the_model)."""
    target = _ctl_find(el)
    if not target or target not in FIELDS:
        near = [k for k in FIELDS if _s(el, "").lower() in k.lower()][:6]
        return None, ("No field called '%s'.%s" %
                      (el, (" Did you mean: " + ", ".join(near) + "?") if near else ""))
    if _ai_forbidden(target):
        _ev("ai_action", "warn", "ai", label=target, detail={"el": target, "mode": "refused"})
        return None, _AI_FORBIDDEN_MSG
    c = FIELDS[target]
    val = _s(value, "")[:200]
    logged = "(private)" if target in _AI_PRIVATE else val
    name = c["label"]
    if not name or name.lower().startswith(("e.g", "eg.", "(", "minimum", "at least", "http")):
        name = target            # a placeholder is a hint for the operator, not a name for it
    say = "Set %s to %s." % (name, val or "(blank)")
    if c["hazard"]:
        allowed, why = _ai_operates()
        if not allowed:
            _ev("ai_action", "info", "ai", label=target,
                detail={"el": target, "mode": "asked", "set": logged})
            return ({"action": "confirm_field", "el": target, "value": val, "label": say},
                    "Put that change in front of the operator to approve. It has not happened yet.")
    _ev("ai_action", "info", "ai", label=target, detail={"el": target, "set": logged})
    return {"action": "set_field", "el": target, "value": val, "say": say}, say


def _press(button):
    """Decide what happens to a press. Returns (event_payload, message_for_the_model)."""
    b = _s(button, "")
    if b in PRESS_SAFE:
        el, say = PRESS_SAFE[b]
        _ev("ai_action", "info", "ai", label=b, detail={"el": el, "mode": "direct"})
        return {"action": "press", "el": el, "say": say}, say
    if b in PRESS_CONFIRM:
        el, label = PRESS_CONFIRM[b]
        allowed, why = _ai_operates()
        return _press_decide(b, el, label, allowed, why)
    # Anything else in the application. This is the change: the two lists above were 18 buttons
    # out of 106, and everything not on them came back "No such button" - which read to the
    # operator as the assistant refusing, because that is what it is.
    el = _ctl_exact(b)
    if el and _ai_forbidden(el):
        _ev("ai_action", "warn", "ai", label=el, detail={"el": el, "mode": "refused"})
        return None, _AI_FORBIDDEN_MSG
    if not el or el not in BUTTONS:
        # "stop the pump" used to resolve to the protocol Stop and report "Pressed Stop" while the
        # pump kept running. A wrong press reported as done is worse than asking again.
        guess = _ctl_find(b)
        if guess in BUTTONS and not _ai_forbidden(guess):
            return None, ("No button is called exactly '%s'. The nearest is '%s' (%s). If that is "
                          "the one, press it by that id; if not, ask the operator which they mean."
                          % (b, guess, BUTTONS[guess]["label"] or guess))
        el = None
    if el and el in BUTTONS:
        c = BUTTONS[el]
        label = c["label"] or el
        if c["hazard"]:
            allowed, why = _ai_operates()
            return _press_decide(b, el, label, allowed, why)
        _ev("ai_action", "info", "ai", label=el, detail={"el": el, "mode": "direct"})
        say = "Pressed %s." % label
        return {"action": "press", "el": el, "say": say}, say
    near = [k for k in BUTTONS if b.lower() in k.lower()][:6]
    return None, ("No button called '%s'.%s"
                  % (b, (" Did you mean: " + ", ".join(near) + "?") if near else ""))


def _press_decide(name, el, label, allowed, why):
    """A control that moves, heats, energises or erases. Pressed, or offered."""
    if allowed:
        # The owner has said the assistant works the instrument. Recorded either way: the
        # event log is what makes an automated instrument an accountable one.
        _ev("ai_action", "warn", "ai", label=name, detail={"el": el, "mode": "direct"})
        return {"action": "press", "el": el, "say": label + "."}, label + "."
    _ev("ai_action", "info", "ai", label=name, detail={"el": el, "mode": "asked", "why": why})
    extra = ("" if why == "off" else
             " (an MCP service is enabled, so instrument actions always ask)")
    return ({"action": "confirm", "el": el, "label": label},
            "Put a '%s' button in front of the operator%s. It has not happened yet."
            % (label, extra))


@app.route("/api/insight/operate")
def api_insight_operate():
    allowed, why = _ai_operates()
    return jsonify(ok=True, on=bool(_json_read(STATION_FILE).get("ai_operate")),
                   effective=allowed, why=why)


@app.route("/api/insight/operate", methods=["POST"])
def api_insight_operate_save():
    want = _body().get("on") is True             # "false", "nan", 1 - none of them mean yes
    try:
        _json_merge_write(STATION_FILE, {"ai_operate": want})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    _ev("ai_operate", "warn", "app", label="on" if want else "off")
    allowed, why = _ai_operates()
    return jsonify(ok=True, on=want, effective=allowed, why=why)


NAV_TOOL = {
    "name": "control_view",
    # The screen list lives here rather than in the per-turn note. Here it is sent once and
    # cached; there it was fourteen bare keys repeated every turn, which cost prompt time and
    # told the model nothing - it could not know "mon" was the serial stream it was being asked
    # about, so it answered that the serial stream was not accessible.
    "description": "Change what the operator is looking at: which screen, which time window, "
                   "which measure a chart plots. These only alter the display.\n\n"
                   "USE go_to_screen WHENEVER THE SUBJECT OF THE QUESTION IS ON ANOTHER SCREEN. "
                   "Open it, then answer. Never reply with where to click - you can go there and "
                   "they asked you so they would not have to.\n\n"
                   "The screens, as values for go_to_screen:\n"
                   + "\n".join("  %-8s %s" % (k, v) for k, v in sorted(SCREENS.items())) +
                   "\n\nset_range, set_heatmap and set_spread CHANGE a setting on the Insight "
                   "charts. Use them when asked to change what a chart plots, not when asked to "
                   "see it - to show a chart, go to its screen and leave its settings alone.\n\n"
                   "You have no tool here that touches the instrument - no carriage, actuator, "
                   "plasma, cycle, port or firmware. Those are on press_button.",
    "input_schema": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": sorted(VIEW_ACTIONS)},
            "value": {"type": "string",
                      "description": "The setting for that action. Omit for refresh."},
        },
        "required": ["action", "value"],
        "additionalProperties": False,
    },
    "strict": True,
}


def _view_action(action, value):
    """Validate one view change. Returns (event_payload, message) or (None, why not).

    Validated here rather than in the browser: the browser is where it is APPLIED, and a check
    that only exists at the point of application is a check anything bypassing the UI skips.
    """
    spec = VIEW_ACTIONS.get(action)
    if not spec:
        return None, "No such action."
    key, allowed, _ = spec
    if not key:
        return {"action": action}, "Redrew the page."
    v = _s(value, "")
    if allowed and v not in allowed:
        return None, "%s must be one of: %s" % (key, ", ".join(allowed))
    return {"action": action, key: v}, "Done."


# What is actually being displayed, per screen, as short as it can be said. The screen name alone
# was not enough: "is that temperature normal?" asked on the Tuning screen arrived with no
# temperature in it, and the only honest answer was another question.
_SCREEN_READS = {
    "dash":  ("TEMP_F", "TEMP_C", "POWER", "VACUUM", "STATE"),
    "tune":  ("POWER", "TEMP_C", "TEMP_F", "VACUUM"),
    "ctl":   ("STATE", "POWER", "TEMP_C", "VACUUM"),
    "mon":   ("STATE",),
    "live":  ("STATE",),
    "proto": ("STATE",),
}


def _screen_reads(v):
    """The figures on the screen they are looking at, so a question about them has an answer."""
    keys = _SCREEN_READS.get(v)
    if not keys:
        return ""
    try:
        st = link.last_status or {}
    except Exception:
        return ""
    got = []
    for k in keys:
        val = st.get(k)
        if val is not None and val != "":
            got.append("%s=%s" % (k, val))
    return ("On screen now: " + ", ".join(got) + ".") if got else ""


def _screen_note(v):
    """What the operator is looking at, and what the machine is doing, in a few lines."""
    bits = []
    if v in SCREENS:
        bits.append("The operator is on: %s" % SCREENS[v])
    try:
        st = link.last_status or {}
        age = link.rx_age()
        live = bool(link.connected and age is not None and age < 6.0)
        bits.append("Controller: %s%s." % ("connected" if live else "not connected",
                                           (", state " + str(st.get("STATE"))) if st.get("STATE") else ""))
        reads = _screen_reads(v)
        if reads:
            bits.append(reads)
    except Exception:
        pass
    # Said every turn and on purpose. Told once, it drifts back to treating navigation as the
    # operator's job and answers "that is on the Insight screen" instead of going and looking.
    # What the screens ARE is in the control_view description, sent once and cached.
    bits.append("If the question is about another screen, go there with control_view first, "
                "then answer. Do not tell them where to click.")
    return "\n".join(bits)


FIELD_TOOL = {
    "name": "set_field",
    "description": "Type a value into any box, or choose an option in any dropdown, anywhere in "
                   "the application - a temperature, a time, an address, a name, a port. Use it "
                   "whenever the operator wants a value changed; do not describe the box to them. "
                   "Fields that feed the instrument put the change in front of them to approve "
                   "instead, and the reply says which happened. Go to the screen first.",
    "input_schema": {
        "type": "object",
        "properties": {
            "field": {"type": "string",
                      "description": "The field's id, or the words labelling it."},
            "value": {"type": "string", "description": "What to put in it."},
        },
        "required": ["field", "value"],
        "additionalProperties": False,
    },
    "strict": True,
}

READ_TOOL = {
    "name": "read_screen",
    "description": "Look at a screen: every button and box on it, what each one currently holds, "
                   "and the controller's live readings. Call this before answering anything "
                   "about what is on screen, what a setting is, or what the operator can do "
                   "here - you cannot see the screen otherwise, and guessing at it is how you "
                   "end up describing the manual instead of the machine.",
    "input_schema": {
        "type": "object",
        "properties": {
            "screen": {"type": "string", "enum": sorted(SCREENS)},
        },
        "required": ["screen"],
        "additionalProperties": False,
    },
    "strict": True,
}


def _ui_tools():
    """What the assistant may do to the application, offered to both providers."""
    return [NAV_TOOL, PRESS_TOOL, FIELD_TOOL, READ_TOOL]


# ------------------------------------------------------------------ Insight: the conversation
# One conversation per station, in memory. This is a single-operator desktop application, so a
# session table would be ceremony; and keeping it in memory rather than on disk means a question
# about the machine is not quietly accumulating on the customer's filesystem.
_chat = {"messages": [], "started": 0.0}     # plain text turns only: user, assistant, user...
_chat_lock = threading.Lock()
CHAT_MAX_TURNS = 24          # trimmed from the front in pairs, so it always starts on a question


def _chat_history():
    with _chat_lock:
        h = [{"role": m["role"], "content": m["content"]} for m in _chat["messages"]
             if isinstance(m.get("content"), str) and m["content"]]
    while h and h[0]["role"] != "user":
        h.pop(0)
    return h


def _chat_remember(question, answer):
    with _chat_lock:
        m = _chat["messages"]
        m.append({"role": "user", "content": question})
        m.append({"role": "assistant", "content": answer or "(answered without text)"})
        if len(m) > CHAT_MAX_TURNS:
            del m[:len(m) - CHAT_MAX_TURNS]


@app.route("/api/insight/chat/reset", methods=["POST"])
def api_insight_chat_reset():
    with _chat_lock:
        _chat["messages"] = []
        _chat["started"] = time.time()
    return jsonify(ok=True)


@app.route("/api/insight/chat")
def api_insight_chat():
    """Streams the answer as it is written. A GET so EventSource can carry it, which is how every
    other live view in this application already works."""
    # EventSource cannot read the body of a 400 or a 402 - it only sees "the connection failed",
    # which the operator was then told. So a refusal goes back as the stream's own error event.
    def refuse(msg):
        return Response(sse("error", msg), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache"})
    if not _pro("insight_ai"):
        return refuse(_needs_pro("insight_ai", "IFS AI")[0].get_json().get("error"))
    q = _s(request.args.get("q"), "").strip()
    if not q:
        return refuse("Ask something.")
    if len(q) > 2000:
        return refuse("That question is too long - keep it under 2,000 characters.")
    view = _s(request.args.get("view"), "")
    want = _s(request.args.get("engine"), "")      # "cloud" sends this one question to Anthropic

    st = _store()
    sp = st.span()
    first = not _chat["messages"]
    ctx = ""
    if first:
        # The station's own situation, once per conversation rather than on every turn: repeating
        # it would push the cached prefix out of shape for no benefit.
        # Deliberately no station name and no host name. This database holds one station, so
        # naming it tells the model nothing it can use and tells Anthropic which site is asking.
        ctx = ("IFS Control Suite %s. The history holds %d samples; the oldest is %s "
               "and the newest %s (unix seconds). Today is %s.\n\n"
               % (APP_VERSION, sp.get("n") or 0, sp.get("a"), sp.get("b"),
                  time.strftime("%Y-%m-%d %H:%M")))

    # The screen rides on every turn rather than once, because the operator moves between them
    # mid-conversation and an answer about the wrong screen is worse than no answer.
    here = _screen_note(view)
    question = ctx + here + "\n\n" + q

    def _work():
        return _chat_history() + [{"role": "user", "content": question}]

    servers = _mcp_all()
    key = _ai_key()
    cfg = _ai_cfg()

    def gen():
        _sse_open()
        try:
            def _ui_run(name, a):
                if name == PRESS_TOOL["name"]:
                    return _press(a.get("button"))
                if name == FIELD_TOOL["name"]:
                    return _set_field(a.get("field"), a.get("value"))
                if name == READ_TOOL["name"]:
                    # Reading changes nothing, so there is no event for the browser to apply -
                    # only an answer for the model.
                    return None, json.dumps(_read_screen(a.get("screen")))
                return _view_action(_s(a.get("action"), ""), a.get("value"))

            ui = {"names": (NAV_TOOL["name"], PRESS_TOOL["name"], FIELD_TOOL["name"],
                            READ_TOOL["name"]),
                  "tools": _ui_tools(), "run": _ui_run}

            def _local():
                return insight.chat_local(INSIGHT_DB, _work(), cfg["url"], cfg["model"], ui=ui)

            def _cloud():
                return insight.chat(INSIGHT_DB, _work(), servers, api_key=key, ui=ui)

            def _openai():
                return insight.chat_openai(INSIGHT_DB, _work(), cfg["openai_url"], _openai_key(),
                                           cfg["openai_model"], ui=ui)

            # In "both", the box on the LAN answers unless this question was sent to the cloud
            # deliberately. The operator decides which answers are worth paying for; they know
            # whether they are curious or about to act on it, and a router does not.
            if cfg["provider"] == "both":
                use_cloud = want == "cloud"
            else:
                use_cloud = cfg["provider"] != "local"

            if cfg["provider"] == "openai":
                use_cloud = True
            yield sse("engine", "cloud" if use_cloud else "local")
            failed = None
            answer, acted = [], False
            engine = _openai() if cfg["provider"] == "openai" else (_cloud() if use_cloud else _local())
            for ev, payload in engine:
                # Escalate only if nothing was done yet: the cloud answers the whole question
                # again, and would press again what the local model already pressed.
                if ev == "error" and not use_cloud and cfg["provider"] == "both" and not acted:
                    failed = payload          # hold it: there may be a second chance
                    break
                if ev == "delta":
                    answer.append(payload)
                elif ev == "view" and isinstance(payload, dict) and \
                        payload.get("action") in ("press", "set_field"):
                    acted = True
                elif ev == "done":
                    _chat_remember(question, "".join(answer))
                yield sse(ev, payload)

            # One automatic escalation, and only this one: the local model failed outright, so
            # there is no answer to weigh against the cost of a better one.
            if failed is not None:
                yield sse("status", "The local model could not. Asking Anthropic.")
                yield sse("engine", "cloud")
                answer = []
                for ev, payload in _cloud():
                    if ev == "delta":
                        answer.append(payload)
                    elif ev == "done":
                        _chat_remember(question, "".join(answer))
                    yield sse(ev, payload)
        except Exception as e:
            yield sse("error", str(e))
        finally:
            _sse_close()

    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/api/insight/ask", methods=["POST"])
def api_insight_ask():
    if not _pro("insight_ai"):
        return _needs_pro("insight_ai", "IFS AI")
    q = _s(_body().get("q"), "").strip()
    if not q:
        return jsonify(ok=False, error="Ask something."), 400
    if len(q) > 2000:
        return jsonify(ok=False, error="That question is too long."), 400
    st = _store()
    sp = st.span()
    ctx = ("IFS Control Suite %s. The history holds %d samples; the oldest is %s and "
           "the newest %s (unix seconds). Today is %s."
           % (APP_VERSION, sp.get("n") or 0, sp.get("a"), sp.get("b"),
              time.strftime("%Y-%m-%d %H:%M")))
    r = insight.ask(INSIGHT_DB, q, ctx, servers=_mcp_all(), api_key=_ai_key())
    return jsonify(**r) if r.get("ok") else (jsonify(**r), 502)


# ------------------------------------------------------------------ operators, recipes, runs
# Signing in IDENTIFIES someone; it does not lock anything. The station stays fully usable when
# nobody is signed in - an operator must always be able to see what the machine is doing. What a
# sign-in buys is that cycles are stamped with who ran them, and that person's own recipes load.
#
# Two places hold the same shape of file. The LOCAL one always works, with no network and no
# server. A SHARED folder is optional: point several stations at one path and they see the same
# operators and recipes. The local copy is still authoritative for reading, so an unreachable
# share degrades to "this station's own list" instead of failing.
DEFAULT_PIN  = "1536"          # the station PIN as shipped; changeable per station
USERS_FILE   = os.path.join(CONN_DIR, "operators.json")
RECIPES_FILE = os.path.join(CONN_DIR, "recipes.json")

def _shared_dir():
    """The optional shared folder, or "" when this station is standalone."""
    return _s(_json_read(STATION_FILE).get("shared_dir"), "")

def _shared_path(name):
    d = _shared_dir()
    return os.path.join(d, name) if d else ""

def _card_hash(card):
    """Match a card without keeping a list of badge numbers lying about in a shared folder.
    Identification only - this is not a password, and it is not treated as one."""
    c = _s(card, "").upper()
    if not c:
        return ""
    return hashlib.sha256(("ifs-operator-card:" + c).encode("utf-8")).hexdigest()[:32]

def _read_store(local_name):
    """Merge the shared list into the local one, keyed by id. Local wins on a clash, so a station
    can correct an entry without the share overwriting it again."""
    out = {}
    sp = _shared_path(local_name)
    if sp:
        for r in (_json_read(sp).get("items") or []):
            if isinstance(r, dict) and r.get("id"):
                out[r["id"]] = r
    for r in (_json_read(os.path.join(CONN_DIR, local_name)).get("items") or []):
        if isinstance(r, dict) and r.get("id"):
            out[r["id"]] = r
    return list(out.values())

def _write_store(local_name, items):
    """Write locally, and mirror to the share when there is one. A share that cannot be written
    is reported, not silently ignored - otherwise two stations quietly diverge."""
    _json_write_atomic(os.path.join(CONN_DIR, local_name), {"items": items}, indent=1)
    sp = _shared_path(local_name)
    if not sp:
        return ""
    try:
        _json_write_atomic(sp, {"items": items}, indent=1)
        return ""
    except Exception as e:
        return "saved on this station, but the shared folder could not be written: %s" % e

# Who is signed in on THIS station right now. Deliberately not persisted across a restart: the
# next shift should not inherit the last shift's name on the data they collect.
_session = {"id": "", "name": "", "since": 0, "workspace": "", "workspace_name": ""}

@app.route("/api/fleet/whoami")
def api_fleet_whoami():
    """What this station reports as. Lets an operator read their station id off the app instead
    of hunting for the file, and lets the name be set without editing JSON by hand."""
    cfg = _station_cfg()
    import socket
    return jsonify(ok=True, station_id=cfg.get("station_id"),
                   station_name=cfg.get("station_name") or socket.gethostname(),
                   telemetry=cfg.get("telemetry", True), version=APP_VERSION)

@app.route("/api/fleet/whoami", methods=["POST"])
def api_fleet_set():
    d = _body()
    cfg = _station_cfg()
    if "station_name" in d:
        cfg["station_name"] = str(d.get("station_name") or "")[:60]
    if "telemetry" in d:
        cfg["telemetry"] = bool(d.get("telemetry"))
    try:
        _json_merge_write(STATION_FILE, cfg)
    except Exception as e:
        return jsonify(ok=False, error="could not save: %s" % e), 500
    return jsonify(ok=True, station_id=cfg.get("station_id"),
                   station_name=cfg.get("station_name"), telemetry=cfg.get("telemetry", True))


@app.route("/api/operators")
def api_operators():
    """The operator list, without the card hashes - the page never needs those."""
    ops = [{"id": o.get("id"), "name": o.get("name", ""), "has_card": bool(o.get("card")),
            "admin": bool(o.get("admin"))}
           for o in _read_store("operators.json")]
    ops.sort(key=lambda o: (o.get("name") or "").lower())
    return jsonify(ok=True, operators=ops, shared=_shared_dir(),
                   session=_session_public())

@app.route("/api/operators", methods=["POST"])
def api_operators_set():
    d = _body()
    name = _s(d.get("name"))[:60]
    if not name:
        return jsonify(ok=False, error="Give the operator a name."), 400
    oid = _s(d.get("id")) or ("op-" + uuid.uuid4().hex[:10])
    items = _read_store("operators.json")
    card = _s(d.get("card"))
    rec = next((o for o in items if o.get("id") == oid), None)
    if rec is None:
        rec = {"id": oid}
        items.append(rec)
    rec["name"] = name
    if "card" in d:                       # blank clears the card, so a lost badge can be unlinked
        rec["card"] = _card_hash(card) if card else ""
    warn = _write_store("operators.json", items)
    return jsonify(ok=True, id=oid, warning=warn or None)

@app.route("/api/operators/delete", methods=["POST"])
def api_operators_del():
    oid = _s(_body().get("id"))
    items = [o for o in _read_store("operators.json") if o.get("id") != oid]
    warn = _write_store("operators.json", items)
    if _session["id"] == oid:
        _session.update({"id": "", "name": "", "since": 0, "workspace": "", "workspace_name": ""})
    return jsonify(ok=True, warning=warn or None)

@app.route("/api/session", methods=["POST"])
def api_session():
    """Sign in by card or by picking a name; an empty body signs out.

    The card arrives as text because the reader is a keyboard - it types the badge number and
    presses Enter. So this is identification, not authentication, and it is not dressed up as
    authentication anywhere in the UI.
    """
    d = _body()
    if d.get("out"):
        _session.update({"id": "", "name": "", "since": 0, "workspace": "", "workspace_name": ""})
        return jsonify(ok=True, session={"id": "", "name": ""})
    items = _read_store("operators.json")
    who = None
    pin = _s(d.get("pin"))
    if pin:
        # The station PIN is for someone who has no profile of their own - a visitor, or a shift
        # that has not been set up yet. It identifies them as an unnamed operator so the data is
        # still stamped with something honest, rather than pretending to be a named person.
        want = _s(_json_read(STATION_FILE).get("station_pin"), DEFAULT_PIN)
        if pin != want:
            return jsonify(ok=False, error="That PIN is not right."), 403
        _session.update({"id": "guest", "name": "Operator (PIN)", "since": time.time()})
        return jsonify(ok=True, session=_session_public())
    card = _s(d.get("card"))
    if card:
        h = _card_hash(card)
        who = next((o for o in items if o.get("card") and o["card"] == h), None)
        if who is None:
            return jsonify(ok=False, error="This card is not registered."), 404
    else:
        oid = _s(d.get("id"))
        who = next((o for o in items if o.get("id") == oid), None)
        if who is None:
            return jsonify(ok=False, error="Pick an operator."), 404
    _session.update({"id": who["id"], "name": who.get("name", ""), "since": time.time()})
    return jsonify(ok=True, session=_session_public())


def _session_public():
    """What the page is allowed to know about the session. Never the id of anything secret."""
    return {"id": _session["id"], "name": _session["name"],
            "workspace": _session.get("workspace", ""),
            "workspace_name": _session.get("workspace_name", "")}


# ------------------------------------------------------------------ workspaces and passwords
# Signing in is now a real gate, so passwords are treated as passwords: PBKDF2-HMAC-SHA256 with a
# per-user salt and a fixed iteration count, compared in constant time. Nothing here ever stores or
# returns a password, and the operator list never carries a hash.
#
# A WORKSPACE is a group of people who share a station's protocols and recipes - a lab, a bench, a
# shift. Operators belong to one, so two teams can use the same machine without seeing each other's
# work.
WORKSPACES_FILE = "workspaces.json"
PBKDF2_ROUNDS   = 200_000

def _pw_hash(password, salt=None):
    salt = salt or os.urandom(16).hex()
    dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                             bytes.fromhex(salt), PBKDF2_ROUNDS)
    return {"salt": salt, "hash": dk.hex(), "rounds": PBKDF2_ROUNDS}

def _pw_check(password, rec):
    """Constant-time compare. A missing or malformed record fails closed."""
    if not isinstance(rec, dict) or not rec.get("salt") or not rec.get("hash"):
        return False
    try:
        dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                                 bytes.fromhex(rec["salt"]), int(rec.get("rounds") or PBKDF2_ROUNDS))
    except Exception:
        return False
    return hmac.compare_digest(dk.hex(), rec["hash"])

def _admin_rec():
    """The admin password that authorises a reset. Ships as 1536 and can be changed per station."""
    cfg = _json_read(STATION_FILE)
    rec = cfg.get("admin_pw")
    if not isinstance(rec, dict) or not rec.get("hash"):
        rec = _pw_hash(DEFAULT_PIN)                 # first run: the shipped default
        try:
            _json_merge_write(STATION_FILE, {"admin_pw": rec})
        except Exception:
            pass
    return rec

def _default_ws_path():
    """Where a brand-new station keeps its work: a folder in Documents, made on first run.

    "Inside the app's own folder" was a poor default - it is a place nobody thinks to look, it is
    not backed up with the rest of someone's files, and an uninstall takes it. Documents is where
    a person expects their own work to be. If it cannot be made, the station falls back to keeping
    it internally rather than refusing to start."""
    try:
        d = os.path.join(os.path.expanduser("~"), "Documents", "IFS Workspaces", "Default")
        os.makedirs(d, exist_ok=True)
        probe = os.path.join(d, "_ifs_probe.tmp")
        with open(probe, "w") as f:
            f.write("x")
        os.remove(probe)
        return d
    except Exception:
        return ""


def _workspaces():
    ws = _read_store(WORKSPACES_FILE)
    if not ws:
        ws = [{"id": "ws-default", "name": "Default", "path": _default_ws_path()}]
        try:
            _write_store(WORKSPACES_FILE, ws)
        except Exception:
            pass
    return ws



DEFAULT_ADMINS = ("Adi", "Paul", "Mike")

def _seed_default_admins():
    """Every station ships with three administrator accounts in the Default workspace - Adi, Paul
    and Mike - each signing in with the shipped station password. Done once per station: an
    account someone later deletes or renames stays gone, and an existing account with the same
    name is promoted to admin rather than duplicated or having its password overwritten."""
    try:
        if _json_read(STATION_FILE).get("default_admins_seeded"):
            return
        _workspaces()                                  # make sure the Default workspace exists
        items = _read_store("operators.json")
        changed = False
        for name in DEFAULT_ADMINS:
            rec = next((o for o in items
                        if (o.get("name") or "").lower() == name.lower()
                        and (o.get("workspace") or "ws-default") == "ws-default"), None)
            if rec is None:
                items.append({"id": "op-" + uuid.uuid4().hex[:10], "name": name,
                              "workspace": "ws-default", "pw": _pw_hash(DEFAULT_PIN),
                              "card": "", "admin": True})
                changed = True
            elif not rec.get("admin"):
                rec["admin"] = True
                changed = True
        if changed:
            _write_store("operators.json", items)
        _json_merge_write(STATION_FILE, {"default_admins_seeded": True})
    except Exception as e:
        _boot_log("seed default admins failed: %s" % e)   # never fatal


def _storage_candidates():
    """Folders this machine could keep a workspace in.

    A workspace is a folder, so a team decides where their protocols and recipes actually live -
    on this PC, or in OneDrive or Dropbox where they sync to everyone else. Only places that
    really exist here are offered; nothing is created until a workspace is made.
    """
    home = os.path.expanduser("~")
    out, seen = [], set()

    def add(label, path, note):
        if not path:
            return
        p = os.path.normpath(path)
        # On a Mac ~/Dropbox is often a link into ~/Library/CloudStorage; offer the place once.
        key = os.path.realpath(p).lower() if IS_MAC else p.lower()
        if key in seen or not os.path.isdir(p):
            return
        seen.add(key)
        out.append({"label": label, "path": p, "note": note})

    # OneDrive and Dropbox announce themselves through the environment or their own config
    for var, label in (("OneDriveCommercial", "OneDrive"), ("OneDriveConsumer", "OneDrive"),
                       ("OneDrive", "OneDrive")):
        add(label, os.environ.get(var), "syncs to everyone signed into this OneDrive")
    for d in sorted(glob.glob(os.path.join(home, "*Dropbox*"))):
        add(os.path.basename(d), d, "syncs to everyone sharing this Dropbox")
    try:
        info = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Dropbox", "info.json")
        if os.path.isfile(info):
            for v in (json.load(open(info, encoding="utf-8")) or {}).values():
                if isinstance(v, dict):
                    add("Dropbox", v.get("path"), "syncs to everyone sharing this Dropbox")
    except Exception:
        pass
    if IS_MAC and not IS_MAS:
        # On a Mac, OneDrive, Dropbox and Google Drive all live under ~/Library/CloudStorage.
        for d in sorted(glob.glob(os.path.join(home, "Library", "CloudStorage", "*"))):
            add(os.path.basename(d).split("-")[0], d, "syncs to everyone sharing this folder")
    if IS_MAS:
        # The sandbox can only reach folders the operator has picked in a Finder panel.
        for d in _mac_granted_folders():
            add(os.path.basename(d) or d, d, "chosen in Finder")

    add("Documents", os.path.join(home, "Documents"), "this Mac only" if IS_MAC else "this PC only")
    add("This PC", os.path.join(os.environ.get("SystemDrive", "C:") + os.sep, "IonField"),
        "this PC only")
    # the fallback always offered, even on a machine with nothing else
    out.append({"label": "This station only", "path": "", "note": "kept inside the app's own folder"})
    return out


@app.route("/api/storage")
def api_storage():
    return jsonify(ok=True, places=_storage_candidates())


@app.route("/api/workspaces")
def api_workspaces():
    ops = _read_store("operators.json")
    out = []
    for w in _workspaces():
        people = [o for o in ops if (o.get("workspace") or "ws-default") == w["id"]]
        out.append({"id": w["id"], "name": w.get("name", ""), "people": len(people),
                    "path": w.get("path", "")})
    return jsonify(ok=True, workspaces=out)


def _ws_folder(base, name):
    """Where a workspace's data lives, or (None, reason). The base must be a folder that already
    exists, given in full: a relative path landed next to the program - which is how folders
    called "nan" and "null" appeared beside it - and a name like "..\\.." walked out of it."""
    base = _s(base, "").strip()
    if not os.path.isabs(base) or not os.path.isdir(base):
        return None, "Choose an existing folder (a full path such as D:\\Lab data)."
    leaf = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", _s(name, "")).strip(" .")
    if not leaf or leaf.upper().split(".")[0] in ("CON", "PRN", "AUX", "NUL") or \
            re.match(r"^(COM|LPT)[0-9]$", leaf.upper().split(".")[0]):
        return None, "That workspace name cannot be used as a folder name."
    return os.path.join(base, "IFS Workspaces", leaf), None


@app.route("/api/workspaces", methods=["POST"])
def api_workspaces_set():
    d = _body()
    name = _s(d.get("name"))[:60]
    path = _s(d.get("path"))
    if not name:
        return jsonify(ok=False, error="Enter a workspace name."), 400
    if path:
        # Prove it before storing it: a folder that cannot be written would fail on every later
        # save instead of here, where someone is looking.
        target, why = _ws_folder(path, name)
        if not target:
            return jsonify(ok=False, error=why), 400
        try:
            os.makedirs(target, exist_ok=True)
            probe = os.path.join(target, "_ifs_probe.tmp")
            with open(probe, "w") as f: f.write("x")
            os.remove(probe)
            path = target
        except Exception as e:
            return jsonify(ok=False, error="That folder cannot be used: %s" % e), 400
    items = _workspaces()
    if any((w.get("name") or "").lower() == name.lower() for w in items):
        return jsonify(ok=False, error="A workspace with that name already exists."), 409
    wid = "ws-" + uuid.uuid4().hex[:10]
    items.append({"id": wid, "name": name, "path": path})
    warn = _write_store(WORKSPACES_FILE, items)
    return jsonify(ok=True, id=wid, warning=warn or None)


# ------------------------------------------------------------------ a workspace IS a folder
# The data location chosen when a workspace is made was being stored and then ignored: everything
# went to the one station-wide shared folder, so two workspaces on the same PC could not actually
# keep their work in different places. These make the choice real for the thing that matters most,
# a workspace's protocols.
def _ws_rec(wid):
    for w in _workspaces():
        if w.get("id") == wid:
            return w
    return {}


def _ws_safe_name(name):
    """A folder name from a workspace name. The name is what a person means by the workspace, so
    two stations that share a folder and both call it "Bench A" land in the same place."""
    keep = "".join(c for c in _s(name) if c.isalnum() or c in " -_()")
    return keep.strip().rstrip(".") or "Workspace"


def _ws_dir(wid):
    """Where this workspace keeps its own files.

    Its own folder if it names one. Otherwise a folder of its OWN inside the station's shared
    folder - NOT the shared folder itself. Falling back to the shared root meant every workspace
    without a folder wrote the same file, so two of them overwrote each other's protocols and each
    saw the other's. Otherwise nothing but this PC."""
    rec = _ws_rec(wid)
    p = _s(rec.get("path"))
    if p:
        return p
    shared = _shared_dir()
    if shared:
        return os.path.join(shared, "IFS Workspaces", _ws_safe_name(rec.get("name") or wid))
    return ""


def _proto_read(wid):
    """This workspace's protocols: the station's own copy merged with whatever is in the
    workspace folder, keyed by id, the local copy winning a clash - the same rule the rest of
    the stores use, so a station can correct an entry without the share putting it back."""
    out = {}
    d = _ws_dir(wid)
    if d:
        for r in (_json_read(os.path.join(d, PROTO_FILE)).get("items") or []):
            # A folder is one workspace's, but a file can still carry another's id - an older
            # file, or a folder two workspaces were once pointed at. Only this workspace's are
            # taken; an entry with no workspace at all is adopted, which migrates older files.
            if isinstance(r, dict) and r.get("id") and (r.get("workspace") or wid) == wid:
                r = dict(r); r["workspace"] = wid
                out[r["id"]] = r
    for r in (_json_read(os.path.join(CONN_DIR, PROTO_FILE)).get("items") or []):
        if isinstance(r, dict) and r.get("id") and (r.get("workspace") or "") == wid:
            out[r["id"]] = r
    return list(out.values())


def _proto_all():
    return [r for r in (_json_read(os.path.join(CONN_DIR, PROTO_FILE)).get("items") or [])
            if isinstance(r, dict) and r.get("id")]


def _proto_write(wid, items):
    """Replace this workspace's protocols. The station's own file keeps every workspace's, the
    workspace folder keeps only its own."""
    others = [r for r in _proto_all() if (r.get("workspace") or "") != wid]
    _json_write_atomic(os.path.join(CONN_DIR, PROTO_FILE), {"items": others + items}, indent=1)
    d = _ws_dir(wid)
    if not d:
        return ""
    try:
        os.makedirs(d, exist_ok=True)
        _json_write_atomic(os.path.join(d, PROTO_FILE), {"items": items}, indent=1)
        return ""
    except Exception as e:
        return "saved on this station, but the workspace folder could not be written: %s" % e


# ------------------------------------------------------------------ browsing for a folder
# The data location used to be a short list of places this PC happens to have. A team whose share
# is a mapped drive or a nested folder could not choose it at all, so this walks the filesystem -
# directories only, never file contents, and it says up front whether a folder can be written.
BROWSE_MAX = 400

# ---- macOS: folders chosen in a Finder panel
# Inside the App Sandbox (a Mac App Store build) the app cannot list or write a folder the operator
# has not picked themselves in an NSOpenPanel. Picking one grants access for this run; a
# security-scoped bookmark, kept here, carries that grant across launches. Outside the sandbox the
# Finder panel is simply a quicker way to choose than walking the tree.
MAC_GRANTS_FILE = os.path.join(CONN_DIR, "mac-folder-access.json")
_mac_granted = []
_mac_grants_lock = threading.Lock()
_mac_grants_loaded = False
_BM_CREATE_SCOPE = 1 << 11     # NSURLBookmarkCreationWithSecurityScope
_BM_RESOLVE_SCOPE = 1 << 10    # NSURLBookmarkResolutionWithSecurityScope


def _mac_grants_read():
    try:
        with open(MAC_GRANTS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _mac_granted_folders():
    """Folders the sandbox currently lets us reach, restoring saved grants on first call."""
    global _mac_grants_loaded
    if not IS_MAS:
        return []
    with _mac_grants_lock:
        if not _mac_grants_loaded:
            _mac_grants_loaded = True
            try:
                import base64
                from Foundation import NSURL, NSData
                for path, b64 in _mac_grants_read().items():
                    raw = base64.b64decode(b64)
                    data = NSData.dataWithBytes_length_(raw, len(raw))
                    url, _stale, _err = NSURL.URLByResolvingBookmarkData_options_relativeToURL_bookmarkDataIsStale_error_(
                        data, _BM_RESOLVE_SCOPE, None, None, None)
                    if url is not None and url.startAccessingSecurityScopedResource():
                        _mac_granted.append(str(url.path()))
            except Exception as e:
                _boot_log("mac grants: could not restore (%r)" % e)
        return list(_mac_granted)


def _mac_grant_keep(path):
    """Remember a Finder-picked folder across launches (store build only). Best effort."""
    if not IS_MAS:
        return
    _mac_granted_folders()            # make sure saved grants are loaded before adding to them
    try:
        import base64
        from Foundation import NSURL
        url = NSURL.fileURLWithPath_(path)
        data, _err = url.bookmarkDataWithOptions_includingResourceValuesForKeys_relativeToURL_error_(
            _BM_CREATE_SCOPE, None, None, None)
        if data is None:
            return
        with _mac_grants_lock:
            d = _mac_grants_read()
            d[path] = base64.b64encode(bytes(data)).decode("ascii")
            os.makedirs(CONN_DIR, exist_ok=True)
            with open(MAC_GRANTS_FILE, "w", encoding="utf-8") as f:
                json.dump(d, f)
            if path not in _mac_granted:
                _mac_granted.append(path)
    except Exception as e:
        _boot_log("mac grants: could not keep %r (%r)" % (path, e))


@app.route("/api/browse/native", methods=["POST"])
def api_browse_native():
    """Open the Finder folder panel (macOS only) and return what the operator chose."""
    if not IS_MAC:
        return jsonify(ok=False, error="The Finder panel is only on a Mac."), 400
    try:
        import webview
        if not webview.windows:
            return jsonify(ok=False, error="No app window to open the Finder panel from."), 409
        kind = getattr(getattr(webview, "FileDialog", None), "FOLDER", None)
        if kind is None:
            kind = webview.FOLDER_DIALOG
        start = _s(_body().get("path")) or os.path.expanduser("~")
        picked = webview.windows[0].create_file_dialog(kind, directory=start)
    except Exception as e:
        return jsonify(ok=False, error="The Finder panel could not be opened: %s" % e), 500
    if not picked:
        return jsonify(ok=True, path="", cancelled=True)
    path = picked[0] if isinstance(picked, (list, tuple)) else str(picked)
    _mac_grant_keep(path)
    return jsonify(ok=True, path=path, writable=_writable(path))


def _browse_roots():
    out = []
    if os.name == "nt":
        import string
        for letter in string.ascii_uppercase:
            root = letter + ":\\"
            if os.path.isdir(root):
                out.append({"name": root, "path": root, "kind": "drive"})
    elif IS_MAS:
        pass        # the sandbox sees almost nothing from "/"; folders come from the Finder panel
    else:
        out.append({"name": "/", "path": "/", "kind": "drive"})
        if IS_MAC:
            # Mounted disks and network shares (SMB/AFP) appear under /Volumes on a Mac.
            for v in sorted(glob.glob("/Volumes/*")):
                # skip the startup disk's alias of "/" and macOS's own snapshot mounts
                if os.path.basename(v).startswith("com.apple.") or os.path.realpath(v) == "/":
                    continue
                if os.path.isdir(v):
                    out.append({"name": os.path.basename(v), "path": v, "kind": "drive"})
    for p in _storage_candidates():
        if p.get("path") and os.path.isdir(p["path"]):
            out.append({"name": p["label"], "path": p["path"], "kind": "place", "note": p.get("note", "")})
    return out


def _writable(path):
    try:
        probe = os.path.join(path, "_ifs_probe.tmp")
        with open(probe, "w") as f:
            f.write("x")
        os.remove(probe)
        return True
    except Exception:
        return False


@app.route("/api/browse")
def api_browse():
    path = _s(request.args.get("path"))
    if not path:
        return jsonify(ok=True, path="", parent=None, roots=_browse_roots(), folders=[],
                       writable=False, native=IS_MAC)
    path = os.path.normpath(path)
    if not os.path.isdir(path):
        return jsonify(ok=False, error="That folder is not there any more."), 404
    folders = []
    try:
        with os.scandir(path) as it:
            for e in it:
                if len(folders) >= BROWSE_MAX:
                    break
                try:
                    if e.is_dir() and not e.name.startswith("."):
                        folders.append({"name": e.name, "path": os.path.join(path, e.name)})
                except OSError:
                    continue          # a folder we are not allowed to stat is simply not offered
    except PermissionError:
        return jsonify(ok=False, error="This folder cannot be opened on this account."), 403
    except OSError as e:
        return jsonify(ok=False, error=str(e)), 400
    folders.sort(key=lambda f: f["name"].lower())
    parent = os.path.dirname(path.rstrip(os.sep)) or None
    if parent == path:
        parent = None
    return jsonify(ok=True, path=path, parent=parent, roots=_browse_roots(),
                   folders=folders, writable=_writable(path),
                   truncated=len(folders) >= BROWSE_MAX)


# ------------------------------------------------------------------ managing workspaces
@app.route("/api/workspaces/detail")
def api_workspaces_detail():
    """Everything the management view needs: who is in it, how many protocols, where it keeps
    them, and whether that folder can actually be written right now."""
    ops = _read_store("operators.json")
    every = _proto_all()
    out = []
    for w in _workspaces():
        wid = w["id"]
        d = _ws_dir(wid)
        out.append({"id": wid, "name": w.get("name", ""), "path": _s(w.get("path")),
                    "folder": d, "shared": bool(d and not _s(w.get("path"))),
                    "exists": bool(d) and os.path.isdir(d),
                    "writable": bool(d) and os.path.isdir(d) and _writable(d),
                    "people": len([o for o in ops if (o.get("workspace") or "ws-default") == wid]),
                    "protocols": len([p for p in every if (p.get("workspace") or "") == wid])})
    return jsonify(ok=True, workspaces=out, current=_session.get("workspace", ""))


@app.route("/api/workspaces/update", methods=["POST"])
def api_workspaces_update():
    """Rename a workspace, or move where it keeps its work. Renaming is harmless. Moving is not -
    it changes where a team's protocols live - so it needs the administrator password, and the
    protocols are copied to the new folder before the move is recorded."""
    d = _body()
    wid = _s(d.get("id"))
    items = _workspaces()
    rec = next((w for w in items if w.get("id") == wid), None)
    if rec is None:
        return jsonify(ok=False, error="That workspace is not here."), 404

    name = _s(d.get("name"))[:60]
    if name and name.lower() != (rec.get("name") or "").lower():
        if any((w.get("name") or "").lower() == name.lower() for w in items if w is not rec):
            return jsonify(ok=False, error="A workspace with that name already exists."), 409

    moving = "path" in d
    if moving:
        if not _pw_check(_s(d.get("admin")), _admin_rec()):
            return jsonify(ok=False, error="Administrator authorisation failed."), 403
        raw = _s(d.get("path"))
        newp = ""
        if raw:
            newp, why = _ws_folder(raw, name or rec.get("name") or "Workspace")
            if not newp:
                return jsonify(ok=False, error=why), 400
            try:
                os.makedirs(newp, exist_ok=True)
                if not _writable(newp):
                    raise OSError("it cannot be written")
            except Exception as e:
                return jsonify(ok=False, error="That folder cannot be used: %s" % e), 400
        carried = _proto_read(wid)
        rec["path"] = newp
        if name:
            rec["name"] = name
        warn = _write_store(WORKSPACES_FILE, items)
        # the protocols follow the workspace to its new home
        w2 = _proto_write(wid, carried)
        return jsonify(ok=True, moved=newp, carried=len(carried), warning=(w2 or warn) or None)

    if not name:
        return jsonify(ok=True)
    # A workspace with no folder of its own keeps its work in a folder NAMED after it, so a
    # rename moves where it looks. Carry the protocols across, or the rename would look like
    # every protocol had vanished.
    carried = _proto_read(wid) if not _s(rec.get("path")) else None
    was = _ws_dir(wid)
    rec["name"] = name
    warn = _write_store(WORKSPACES_FILE, items)
    if carried is not None and _ws_dir(wid) != was:
        w2 = _proto_write(wid, carried)
        warn = w2 or warn
    if _session.get("workspace") == wid:
        _session["workspace_name"] = name
    return jsonify(ok=True, carried=(len(carried) if carried else 0), warning=warn or None)


@app.route("/api/workspaces/delete", methods=["POST"])
def api_workspaces_delete():
    """Remove a workspace. Needs the administrator password, refuses to remove the last one, and
    refuses one that still holds people or protocols unless that is asked for explicitly.

    It never deletes the folder on disk. That folder is the team's own, may be shared with other
    stations, and an app removing a directory of someone's work is not a thing this should do."""
    d = _body()
    if not _pw_check(_s(d.get("admin")), _admin_rec()):
        return jsonify(ok=False, error="Administrator authorisation failed."), 403
    wid = _s(d.get("id"))
    items = _workspaces()
    rec = next((w for w in items if w.get("id") == wid), None)
    if rec is None:
        return jsonify(ok=False, error="That workspace is not here."), 404
    if len(items) <= 1:
        return jsonify(ok=False, error="This is the only workspace. Make another one first."), 409

    folder = _ws_dir(wid)          # read BEFORE the record goes, or there is nothing to name
    ops   = _read_store("operators.json")
    mine  = [o for o in ops if (o.get("workspace") or "ws-default") == wid]
    props = [p for p in _proto_all() if (p.get("workspace") or "") == wid]
    if (mine or props) and not d.get("force"):
        return jsonify(ok=False, holds={"people": len(mine), "protocols": len(props)},
                       error="This workspace still holds %d account%s and %d protocol%s."
                             % (len(mine), "" if len(mine) == 1 else "s",
                                len(props), "" if len(props) == 1 else "s")), 409

    warn = ""
    if props:
        warn = _proto_write(wid, [])          # drops them from this station; the folder copy too
    if mine:
        _write_store("operators.json", [o for o in ops
                                        if (o.get("workspace") or "ws-default") != wid])
    w2 = _write_store(WORKSPACES_FILE, [w for w in items if w.get("id") != wid])
    if _session.get("workspace") == wid:      # whoever was signed into it is signed out
        _session.update({"id": "", "name": "", "since": 0, "workspace": "", "workspace_name": ""})
    return jsonify(ok=True, removed={"people": len(mine), "protocols": len(props)},
                   folder=folder, warning=(warn or w2) or None)


@app.route("/api/people")
def api_people():
    """Names in one workspace, for the sign-in page. No hashes, no card numbers."""
    wid = _s(request.args.get("workspace"), "ws-default")
    ops = [o for o in _read_store("operators.json")
           if (o.get("workspace") or "ws-default") == wid]
    ops.sort(key=lambda o: (o.get("name") or "").lower())
    return jsonify(ok=True, people=[{"id": o.get("id"), "name": o.get("name", ""),
                                     "has_card": bool(o.get("card")),
                                     "needs_password": not bool(o.get("pw"))} for o in ops])


@app.route("/api/signup", methods=["POST"])
def api_signup():
    """Create an operator inside a workspace. Open by design: this is a shared bench tool, and an
    admin password is what gates a RESET, not who may have an account."""
    d = _body()
    name = _s(d.get("name"))[:60]
    pw   = _s(d.get("password"))
    wid  = _s(d.get("workspace"), "ws-default")
    if not name:
        return jsonify(ok=False, error="Enter a user name."), 400
    if len(pw) < 4:
        return jsonify(ok=False, error="Password must be at least four characters."), 400
    if pw == DEFAULT_PIN:
        return jsonify(ok=False, error="Pick a password that is not the shipped one."), 400
    if not any(w["id"] == wid for w in _workspaces()):
        return jsonify(ok=False, error="Pick a workspace."), 400
    items = _read_store("operators.json")
    if any((o.get("name") or "").lower() == name.lower()
           and (o.get("workspace") or "ws-default") == wid for o in items):
        return jsonify(ok=False, error="That user name is already in use in this workspace."), 409
    # A card presented during sign-up is linked to the new account, so the next swipe signs them
    # straight in. Only its hash is kept - a shared folder full of badge numbers is not something
    # to leave lying about.
    card = _s(d.get("card"))
    if card:
        h = _card_hash(card)
        if any(o.get("card") == h for o in items):
            return jsonify(ok=False, error="That card is already linked to an account."), 409
    rec = {"id": "op-" + uuid.uuid4().hex[:10], "name": name, "workspace": wid,
           "pw": _pw_hash(pw), "card": _card_hash(card) if card else ""}
    items.append(rec)
    warn = _write_store("operators.json", items)
    return jsonify(ok=True, id=rec["id"], warning=warn or None)


@app.route("/api/login", methods=["POST"])
def api_login():
    d = _body()
    wid  = _s(d.get("workspace"), "ws-default")
    name = _s(d.get("name"))
    pw   = _s(d.get("password"))
    items = _read_store("operators.json")
    who = next((o for o in items
                if (o.get("name") or "").lower() == name.lower()
                and (o.get("workspace") or "ws-default") == wid), None)
    # One message for a wrong name and a wrong password, so this cannot be used to find out who
    # has an account here.
    if who is None or not _pw_check(pw, who.get("pw")):
        return jsonify(ok=False, error="Invalid user name or password."), 403
    # The shipped password is the same on every station, so it only gets someone as far as
    # choosing their own. No session starts until they have.
    if _pw_check(DEFAULT_PIN, who.get("pw")):
        return jsonify(ok=False, must_change=True, admin_default=_admin_is_default(),
                       error="Choose your own password to finish signing in."), 200
    ws = next((w for w in _workspaces() if w["id"] == wid), {})
    _session.update({"id": who["id"], "name": who.get("name", ""), "since": time.time(),
                     "workspace": wid, "workspace_name": ws.get("name", "")})
    return jsonify(ok=True, session=_session_public())


def _admin_is_default():
    return _pw_check(DEFAULT_PIN, _admin_rec())


@app.route("/api/password/first", methods=["POST"])
def api_password_first():
    """First sign-in on the shipped password: the person proves they know it, picks their own,
    and is signed in. If the station's administrator password is also still the shipped one, a
    new one is required here too - otherwise anyone who knows 1536 could reset any account."""
    d = _body()
    wid  = _s(d.get("workspace"), "ws-default")
    name = _s(d.get("name"))
    cur  = _s(d.get("current"))
    new  = _s(d.get("password"))
    items = _read_store("operators.json")
    who = next((o for o in items
                if (o.get("name") or "").lower() == name.lower()
                and (o.get("workspace") or "ws-default") == wid), None)
    if who is None or not _pw_check(cur, who.get("pw")):
        return jsonify(ok=False, error="Invalid user name or password."), 403
    if len(new) < 6:
        return jsonify(ok=False, error="Use a password of at least six characters."), 400
    if new == DEFAULT_PIN or new == cur:
        return jsonify(ok=False, error="Pick a password that is not the shipped one."), 400
    if _admin_is_default():
        adm = _s(d.get("admin_new"))
        if len(adm) < 6 or adm == DEFAULT_PIN:
            return jsonify(ok=False, admin_default=True,
                           error="Also set a new administrator password (at least six characters)."), 400
        _json_merge_write(STATION_FILE, {"admin_pw": _pw_hash(adm)})
    who["pw"] = _pw_hash(new)
    warn = _write_store("operators.json", items)
    ws = next((w for w in _workspaces() if w["id"] == wid), {})
    _session.update({"id": who["id"], "name": who.get("name", ""), "since": time.time(),
                     "workspace": wid, "workspace_name": ws.get("name", "")})
    return jsonify(ok=True, session=_session_public(), warning=warn or None)


@app.route("/api/password/reset", methods=["POST"])
def api_password_reset():
    """Forgot a password: an admin sets a new one. The admin password is checked with the same
    constant-time comparison, and a failure says nothing about which part was wrong."""
    d = _body()
    if not _pw_check(_s(d.get("admin")), _admin_rec()):
        return jsonify(ok=False, error="Administrator authorisation failed."), 403
    wid  = _s(d.get("workspace"), "ws-default")
    name = _s(d.get("name"))
    new  = _s(d.get("password"))
    if len(new) < 4:
        return jsonify(ok=False, error="Password must be at least four characters."), 400
    if new == DEFAULT_PIN:
        return jsonify(ok=False, error="Pick a password that is not the shipped one."), 400
    items = _read_store("operators.json")
    who = next((o for o in items
                if (o.get("name") or "").lower() == name.lower()
                and (o.get("workspace") or "ws-default") == wid), None)
    if who is None:
        return jsonify(ok=False, error="No such user in this workspace."), 404
    who["pw"] = _pw_hash(new)
    warn = _write_store("operators.json", items)
    return jsonify(ok=True, warning=warn or None)


@app.route("/api/password/admin", methods=["POST"])
def api_password_admin():
    """Change the admin password itself. Requires the current one."""
    d = _body()
    if not _pw_check(_s(d.get("current")), _admin_rec()):
        return jsonify(ok=False, error="That admin password is not right."), 403
    new = _s(d.get("password"))
    if len(new) < 4:
        return jsonify(ok=False, error="Use a password of at least four characters."), 400
    if new == DEFAULT_PIN:
        return jsonify(ok=False, error="Pick a password that is not the shipped one."), 400
    _json_merge_write(STATION_FILE, {"admin_pw": _pw_hash(new)})
    return jsonify(ok=True)


@app.route("/api/recipes")
def api_recipes():
    """Recipes belong to an operator. With nobody signed in you get the station's shared ones."""
    who = request.args.get("owner") or _session["id"] or ""
    rs = [r for r in _read_store("recipes.json") if (r.get("owner") or "") in ("", who)]
    rs.sort(key=lambda r: (r.get("name") or "").lower())
    return jsonify(ok=True, recipes=rs, owner=who)

@app.route("/api/recipes", methods=["POST"])
def api_recipes_set():
    d = _body()
    name = _s(d.get("name"))[:60]
    if not name:
        return jsonify(ok=False, error="Give the recipe a name."), 400
    vals = d.get("values")
    if not isinstance(vals, dict):
        return jsonify(ok=False, error="A recipe needs its values."), 400
    if len(json.dumps(vals)) > 20000:
        return jsonify(ok=False, error="That recipe is too large."), 400
    rid = _s(d.get("id")) or ("rp-" + uuid.uuid4().hex[:10])
    items = _read_store("recipes.json")
    rec = next((r for r in items if r.get("id") == rid), None)
    if rec is None:
        rec = {"id": rid}
        items.append(rec)
    rec.update({"name": name, "values": vals, "owner": _s(d.get("owner"), _session["id"]),
                "saved": time.strftime("%Y-%m-%d %H:%M")})
    warn = _write_store("recipes.json", items)
    return jsonify(ok=True, id=rid, warning=warn or None)

@app.route("/api/recipes/delete", methods=["POST"])
def api_recipes_del():
    rid = _s(_body().get("id"))
    warn = _write_store("recipes.json", [r for r in _read_store("recipes.json") if r.get("id") != rid])
    return jsonify(ok=True, warning=warn or None)

# ------------------------------------------------------------------ protocols
# A PROTOCOL is a run written down: an ordered list of steps that this station performs on the
# Puretip One, the Plasma StandAlone and the Tip Charger, interleaved with waits on the Bioyond
# cell. It is the thing an operator actually repeats, so it is saved with the workspace rather
# than in the browser, stamped with who wrote it, and it can be handed to the next shift.
#
# The op catalogue lives HERE, not in the page. The page asks for it and builds itself from the
# answer, so what the editor offers and what the executor will do cannot drift apart - the class
# of bug where a page offers a step the station cannot perform.
#
# The Bioyond robot is deliberately absent from the actions. Our link to it is read-only by
# design (see /api/by/state), and in the real cell Bioyond's own scheduler is the master that
# drives Puretip as a device. So a protocol WAITS on the cell; it never commands it.
PROTO_FILE      = "protocols.json"
PROTO_RUNS_FILE = "protocol-runs.json"
PROTO_MAX_STEPS = 200
PROTO_MAX_RUNS  = 200

def _op(key, station, label, hint, fields=(), secs=1.0, danger=False):
    return {"key": key, "station": station, "label": label, "hint": hint,
            "fields": list(fields), "secs": secs, "danger": danger}

def _f(name, label, kind, **kw):
    d = {"name": name, "label": label, "kind": kind}
    d.update(kw)
    return d

# station keys map to the link that must be up for the step to run
PROTO_STATIONS = [
    {"key": "flow",  "label": "Sequence",           "needs": None},
    {"key": "pt",    "label": "Puretip One",        "needs": "pt"},
    {"key": "opta",  "label": "Plasma StandAlone",  "needs": "opta"},
    {"key": "tc",    "label": "Tip Charger",        "needs": "tc"},
    {"key": "by",    "label": "Bioyond cell",       "needs": "by"},
]

PT_STEPS = [("start", "Initialize"), ("clamp", "Open clamp"), ("autorun", "Auto run"),
            ("load", "Load tips"), ("mist", "Mist"), ("clean", "Clean"),
            ("unload", "Eject tips"), ("flush", "Flush mode"), ("home", "Z-home"),
            ("test", "Self test")]

PROTO_OPS = [
    # --- sequence ------------------------------------------------------------------------
    _op("flow.note", "flow", "Note", "A line of text for whoever runs this. Does nothing.",
        [_f("text", "Text", "text", max=140)], secs=0),
    _op("flow.wait", "flow", "Wait", "Hold for a fixed time before the next step.",
        [_f("secs", "Seconds", "number", min=0.1, max=3600, step=0.1, value=5, sum="{v}s")], secs=5),
    _op("flow.confirm", "flow", "Ask the operator", "Stop until someone confirms in the app.",
        [_f("text", "Question", "text", max=140, value="Ready to continue?")], secs=0),
    _op("flow.repeat", "flow", "Repeat from here", "Run the steps above again, from the marked start.",
        [_f("times", "Times", "number", min=1, max=99, step=1, value=2, sum="{v} times")], secs=0),
    _op("flow.mark", "flow", "Repeat start", "Marks where a repeat goes back to.", [], secs=0),

    # --- Puretip One ---------------------------------------------------------------------
    _op("pt.step", "pt", "Puretip step", "One step of the Puretip cycle.",
        [_f("step", "Step", "choice", options=[{"v": v, "label": l} for v, l in PT_STEPS],
            value="mist")], secs=8),
    _op("pt.cycle", "pt", "Puretip full cycle",
        "Run the whole cycle with a gap between stations, and hold until it has had time to finish.",
        [_f("gap", "Gap (s)", "number", min=1, max=600, step=1, value=30, sum="gap {v}s"),
         _f("hold", "Wait for it", "choice",
            options=[{"v": "yes", "label": "Hold until it should be done"},
                     {"v": "no",  "label": "Start it and carry on"}], value="yes")],
        secs=120),
    _op("pt.stop", "pt", "Puretip stop", "Stop the Puretip immediately.", [], secs=1),
    _op("pt.setting", "pt", "Puretip setting",
        "Change one of the tablet's settings, as if typed on its screen. Its own limits apply.",
        [_f("param", "Setting", "choice",
            options=[{"v": k, "label": l + (" (%s)" % u if u else "")} for k, _c, l, u in PT_PARAMS],
            value="mist_power"),
         _f("value", "Value", "number", min=0, max=99999, step=0.01, value=50, sum="= {v}")],
        secs=3),
    # A saved set of tablet settings, by name - the same presets the Puretip screen saves.
    _op("pt.preset", "pt", "Puretip preset",
        "Apply a saved set of tablet settings (saved on the Puretip screen), then carry on.",
        [_f("name", "Preset", "ptpreset", max=40)], secs=15),

    # --- Plasma StandAlone ---------------------------------------------------------------
    _op("opta.home", "opta", "Home carriage", "Send the carriage to its home position.", [], secs=12),
    _op("opta.start", "opta", "Start clean", "Run the controller's clean cycle.", [], secs=60),
    _op("opta.actuator", "opta", "Actuator", "Open or close the chamber door.",
        [_f("on", "Position", "choice", options=[{"v": "open", "label": "Open"},
                                                 {"v": "close", "label": "Close"}], value="open")],
        secs=3),
    _op("opta.fan", "opta", "Exhaust fan", "Turn the exhaust on or off.",
        [_f("on", "State", "choice", options=[{"v": "on", "label": "On"},
                                              {"v": "off", "label": "Off"}], value="on")], secs=1),
    _op("opta.wait_idle", "opta", "Wait until idle", "Hold until the controller reports it has finished.",
        [_f("timeout", "Give up after (s)", "number", min=5, max=1800, step=5, value=180, sum="up to {v}s")], secs=60),
    _op("opta.abort", "opta", "Abort", "Stop the controller's cycle.", [], secs=1, danger=True),

    # --- Tip Charger ---------------------------------------------------------------------
    _op("tc.form", "tc", "Show panel form", "Switch the touch panel to a form.",
        [_f("form", "Form", "number", min=0, max=25, step=1, value=0, sum="form {v}")], secs=1),
    _op("tc.pump", "tc", "Cooling pump", "Run or stop the cooling pump.",
        [_f("on", "State", "choice", options=[{"v": "on", "label": "On"},
                                              {"v": "off", "label": "Off"}], value="on")], secs=1),
    _op("tc.pump_for", "tc", "Run the pump for a time",
        "Run the cooling pump for a set time, then stop it.",
        [_f("secs", "Seconds", "number", min=1, max=3600, step=1, value=30, sum="{v}s")],
        secs=30),
    _op("tc.plasma", "tc", "Plasma on or off",
        "Request plasma on or off and move straight on. The panel's own interlocks still apply.",
        [_f("on", "State", "choice", options=[{"v": "on", "label": "On"},
                                              {"v": "off", "label": "Off"}], value="off")],
        secs=1, danger=True),
    # The step an operator actually means. It writes the time to the panel first, so the station
    # itself knows how long it is meant to run, then fires, HOLDS for that long, and stops. Firing
    # and moving straight on left the next step - or the end of the run - to cut it immediately.
    # The panel's own applyWSetting clamps plasma time to TC_PLASMA_S. Offering more would let a
    # protocol ask for 45 s, hold for 45 s, and have the hardware cut at 30 - the app and the
    # machine disagreeing with nothing to show for it.
    _op("tc.plasma_for", "tc", "Plasma for a time",
        "Set the panel's plasma time, fire, hold for that long, then stop. Always stops, even if "
        "the run is stopped part way. The panel accepts %d to %d seconds."
        % (TC_PLASMA_S[0], TC_PLASMA_S[1]),
        [_f("secs", "Seconds", "number", min=TC_PLASMA_S[0], max=TC_PLASMA_S[1], step=1,
            value=min(30, TC_PLASMA_S[1]), sum="{v}s")],
        secs=30, danger=True),
    _op("tc.setting", "tc", "Panel setting", "Write one operating parameter to the panel.",
        [_f("sel", "Parameter", "choice", options=[
                {"v": 0, "label": "Pump on %"}, {"v": 1, "label": "Pump off %"},
                {"v": 2, "label": "Plasma time (s)"}, {"v": 3, "label": "Cooling time (s)"},
                {"v": 4, "label": "Brightness %"}, {"v": 5, "label": "Vacuum"}], value=2),
         _f("value", "Value", "number", min=0, max=9999, step=1, value=0, sum="= {v}")], secs=1),

    # --- Bioyond cell (read-only: we wait on it, we never drive it) ------------------------
    _op("by.wait_state", "by", "Wait for the cell", "Hold until the Bioyond robot reports a state.",
        [_f("state", "State", "choice", options=[{"v": "idle", "label": "Idle"},
                                                 {"v": "running", "label": "Running"},
                                                 {"v": "paused", "label": "Paused"}], value="idle"),
         _f("timeout", "Give up after (s)", "number", min=5, max=3600, step=5, value=300, sum="up to {v}s")], secs=30),
    _op("by.wait_prog", "by", "Wait for the cell program",
        "Hold until the robot's program reports a state.",
        [_f("state", "Program", "choice", options=[{"v": "stopped", "label": "Stopped"},
                                                   {"v": "running", "label": "Running"},
                                                   {"v": "paused", "label": "Paused"}], value="stopped"),
         _f("timeout", "Give up after (s)", "number", min=5, max=3600, step=5, value=300, sum="up to {v}s")], secs=30),
]

PROTO_BY_KEY = {o["key"]: o for o in PROTO_OPS}
PROTO_NEEDS  = {s["key"]: s["needs"] for s in PROTO_STATIONS}
PROTO_LABEL  = {s["key"]: s["label"]  for s in PROTO_STATIONS}


def _proto_link_up(needs):
    """Is the station a step targets actually connected right now?"""
    if needs is None:
        return True
    if needs == "opta":
        return bool(link.connected)
    if needs == "tc":
        return bool(tclink.connected)
    if needs == "pt":
        return bool(ptlink.connected)
    if needs == "by":
        return bool(bylink.connected)
    return False


def _proto_check(steps):
    """Validate a protocol. Returns (clean_steps, problems). A problem names the step INDEX, so
    the editor can point at the step rather than saying 'something is wrong'."""
    problems = []
    clean = []
    if not isinstance(steps, list):
        return [], [{"i": -1, "text": "A protocol is a list of steps."}]
    if len(steps) > PROTO_MAX_STEPS:
        return [], [{"i": -1, "text": "Too many steps (limit %d)." % PROTO_MAX_STEPS}]
    depth = 0
    for i, st in enumerate(steps):
        if not isinstance(st, dict):
            problems.append({"i": i, "text": "This step is not readable."}); continue
        spec = PROTO_BY_KEY.get(_s(st.get("op")))
        if spec is None:
            problems.append({"i": i, "text": "Unknown step '%s'." % _s(st.get("op"))[:40]}); continue
        args = st.get("args") if isinstance(st.get("args"), dict) else {}
        out  = {}
        for f in spec["fields"]:
            v = args.get(f["name"], f.get("value"))
            if f["kind"] == "number":
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    problems.append({"i": i, "text": "%s needs a number." % f["label"]}); v = f.get("value", 0)
                lo, hi = f.get("min"), f.get("max")
                if lo is not None and v < lo or hi is not None and v > hi:
                    problems.append({"i": i, "text": "%s must be between %s and %s."
                                                     % (f["label"], lo, hi)})
                    v = min(max(v, lo), hi)
                if f.get("step") == 1:
                    v = int(round(v))
            elif f["kind"] == "choice":
                allowed = [o["v"] for o in f["options"]]
                if v not in allowed:
                    # a number that arrived as a string is the same choice
                    match = [a for a in allowed if str(a) == str(v)]
                    if match:
                        v = match[0]
                    else:
                        problems.append({"i": i, "text": "%s is not one of the choices." % f["label"]})
                        v = f.get("value", allowed[0])
            else:
                v = _s(v)[:int(f.get("max", 140))]
            out[f["name"]] = v
        if spec["key"] == "flow.mark":
            depth += 1
        if spec["key"] == "flow.repeat":
            if depth <= 0:
                problems.append({"i": i, "text": "This repeat has no 'Repeat start' above it."})
            else:
                depth -= 1
        # Every step can hold for a moment after it before the next command goes out. Some
        # hardware needs it - a panel settling, a valve closing - and putting a separate Wait
        # between every pair of steps made a protocol twice as long to read.
        try:
            after = float(st.get("after") or 0)
        except (TypeError, ValueError):
            problems.append({"i": i, "text": "Delay after must be a number."}); after = 0.0
        if after < 0 or after > 3600:
            problems.append({"i": i, "text": "Delay after must be between 0 and 3600 seconds."})
            after = min(max(after, 0.0), 3600.0)
        clean.append({"op": spec["key"], "args": out, "off": bool(st.get("off")),
                      "after": round(after, 1)})
    if depth > 0:
        problems.append({"i": -1, "text": "A 'Repeat start' has no matching repeat below it."})
    return clean, problems


def _proto_secs(steps):
    """A rough duration, so an operator knows whether this is a two-minute or a two-hour run."""
    total, stack = 0.0, []
    for i, st in enumerate(steps):
        if st.get("off"):
            continue
        spec = PROTO_BY_KEY.get(st.get("op"))
        if not spec:
            continue
        if spec["key"] == "flow.mark":
            stack.append((i, total)); continue
        if spec["key"] == "flow.repeat":
            if stack:
                _, at = stack.pop()
                total += (total - at) * max(0, int(st["args"].get("times", 1)) - 1)
            continue
        if spec["key"] == "flow.wait":
            total += float(st["args"].get("secs", 0)) + float(st.get("after") or 0); continue
        if spec["key"] == "pt.cycle":
            total += (float(st["args"].get("gap", 30)) * 4 + 20) \
                     if st["args"].get("hold") != "no" else 2
            continue
        if spec["key"] in ("tc.plasma_for", "tc.pump_for"):
            total += float(st["args"].get("secs", 0)); continue
        total += spec["secs"]
    for st in steps:
        if not st.get("off"):
            total += float(st.get("after") or 0)
    return round(total, 1)


@app.route("/api/protocol/ops")
def api_protocol_ops():
    names = [{"v": x.get("name"), "label": x.get("name")} for x in _pt_presets() if x.get("name")]
    ops = []
    for o in PROTO_OPS:
        if any(f["kind"] == "ptpreset" for f in o["fields"]):
            o = dict(o)
            o["fields"] = [dict(f, kind="choice", options=names or [{"v": "", "label": "(save a preset on the Puretip screen first)"}],
                                value=(names[0]["v"] if names else ""))
                           if f["kind"] == "ptpreset" else f for f in o["fields"]]
        ops.append(o)
    return jsonify(ok=True, ops=ops, stations=PROTO_STATIONS,
                   links={s["key"]: _proto_link_up(s["needs"]) for s in PROTO_STATIONS})


# Three runs that are actually performed on this bench, so a station that has never saved a
# protocol still opens onto something real to start from rather than a blank page.
PROTO_TEMPLATES = [
    {"name": "Puretip tip clean",
     "what": "Load, mist, clean, unload - the ordinary Puretip pass.",
     "steps": [
        {"op": "flow.note",  "args": {"text": "Puretip One tip clean"}},
        {"op": "pt.step",    "args": {"step": "start"}},
        {"op": "flow.wait",  "args": {"secs": 3}},
        {"op": "pt.step",    "args": {"step": "load"}},
        {"op": "pt.step",    "args": {"step": "mist"}},
        {"op": "flow.wait",  "args": {"secs": 10}},
        {"op": "pt.step",    "args": {"step": "clean"}},
        {"op": "flow.wait",  "args": {"secs": 10}},
        {"op": "pt.step",    "args": {"step": "unload"}},
        {"op": "pt.step",    "args": {"step": "home"}}]},
    {"name": "Plasma clean cycle",
     "what": "Home, close, run the clean, exhaust, then open when it is idle.",
     "steps": [
        {"op": "flow.note",     "args": {"text": "Plasma StandAlone clean"}},
        {"op": "opta.home",     "args": {}},
        {"op": "opta.actuator", "args": {"on": "close"}},
        {"op": "opta.fan",      "args": {"on": "on"}},
        {"op": "opta.start",    "args": {}},
        {"op": "opta.wait_idle","args": {"timeout": 300}},
        {"op": "flow.wait",     "args": {"secs": 15}},
        {"op": "opta.fan",      "args": {"on": "off"}},
        {"op": "opta.actuator", "args": {"on": "open"}}]},
    {"name": "Cell handover",
     "what": "Wait for the Bioyond cell to go idle, run a Puretip pass, hand it back.",
     "steps": [
        {"op": "flow.note",     "args": {"text": "Runs between two Bioyond cell moves"}},
        {"op": "by.wait_state", "args": {"state": "idle", "timeout": 600}},
        {"op": "flow.confirm",  "args": {"text": "Plate is on the Puretip deck?"}},
        {"op": "flow.mark",     "args": {}},
        {"op": "pt.step",       "args": {"step": "mist"}},
        {"op": "flow.wait",     "args": {"secs": 12}},
        {"op": "pt.step",       "args": {"step": "clean"}},
        {"op": "flow.wait",     "args": {"secs": 12}},
        {"op": "flow.repeat",   "args": {"times": 2}},
        {"op": "pt.step",       "args": {"step": "home"}},
        {"op": "by.wait_state", "args": {"state": "running", "timeout": 600}}]},
]


@app.route("/api/protocol/templates")
def api_protocol_templates():
    out = []
    for t in PROTO_TEMPLATES:
        clean, problems = _proto_check(t["steps"])
        # a template that does not validate is a bug in this file, not something to hand out
        if problems:
            continue
        out.append({"name": t["name"], "what": t["what"], "steps": clean,
                    "secs": _proto_secs(clean)})
    return jsonify(ok=True, templates=out)


@app.route("/api/protocols")
def api_protocols():
    """A workspace's protocols come from ITS folder, so where a team chose to keep their work is
    where their work actually is. With nobody signed in, the station's own copies are shown."""
    wid = _s(request.args.get("workspace")) or _session.get("workspace") or ""
    rs = _proto_read(wid) if wid else _proto_all()
    rs.sort(key=lambda p: (p.get("name") or "").lower())
    return jsonify(ok=True, protocols=rs, folder=_ws_dir(wid) if wid else "")


@app.route("/api/protocols", methods=["POST"])
def api_protocols_save():
    d = _body()
    name = _s(d.get("name"))[:60]
    if not name:
        return jsonify(ok=False, error="Give the protocol a name."), 400
    clean, problems = _proto_check(d.get("steps"))
    if problems:
        return jsonify(ok=False, error="Fix the steps before saving.", problems=problems), 400
    if not clean:
        return jsonify(ok=False, error="A protocol needs at least one step."), 400
    wid = _s(d.get("workspace"), _session.get("workspace") or "")
    pid = _s(d.get("id")) or ("pr-" + uuid.uuid4().hex[:10])
    items = _proto_read(wid)
    rec = next((p for p in items if p.get("id") == pid), None)
    if rec is None:
        rec = {"id": pid, "created": time.strftime("%Y-%m-%d %H:%M")}
        items.append(rec)
    rec.update({"name": name, "steps": clean, "workspace": wid,
                "owner": _session.get("id") or rec.get("owner", ""),
                "owner_name": _session.get("name") or rec.get("owner_name", ""),
                "saved": time.strftime("%Y-%m-%d %H:%M"),
                "secs": _proto_secs(clean)})
    warn = _proto_write(wid, items)
    return jsonify(ok=True, id=pid, saved=rec["saved"], secs=rec["secs"], warning=warn or None)


@app.route("/api/protocols/delete", methods=["POST"])
def api_protocols_del():
    d = _body()
    pid = _s(d.get("id"))
    wid = _s(d.get("workspace"), _session.get("workspace") or "")
    warn = _proto_write(wid, [p for p in _proto_read(wid) if p.get("id") != pid])
    return jsonify(ok=True, warning=warn or None)


@app.route("/api/protocols/validate", methods=["POST"])
def api_protocols_validate():
    clean, problems = _proto_check(_body().get("steps"))
    return jsonify(ok=not problems, problems=problems, secs=_proto_secs(clean),
                   needs=sorted({PROTO_BY_KEY[s["op"]]["station"] for s in clean if not s.get("off")}))


# ------------------------------------------------------------------ running a protocol
# One run at a time, in a worker thread. Every step is announced before and after it happens, so
# the page shows what the station is doing rather than a spinner, and the record of the run is
# kept whether it finished, failed or was stopped.
_run_lock  = threading.RLock()
_run_state = {"active": False, "dry": False, "name": "", "id": "", "i": -1, "k": -1, "n": 0,
              "started": 0.0, "ended": 0.0, "result": "", "error": "", "paused": False,
              "await_confirm": "", "by": ""}
_run_events = deque(maxlen=400)
# What this run has energised. A protocol that fires plasma and is then stopped, or fails on a
# later step, must not walk away leaving it on - so the run drops whatever it turned on, on every
# path out, including the ones nobody plans for.
_run_hot = set()
_run_abort  = threading.Event()
_run_confirm = threading.Event()
_run_subs   = []


def _run_emit(kind, text, i=None):
    ev = {"t": round(time.time(), 3), "kind": kind, "text": text, "i": i}
    _run_events.append(ev)
    for q in list(_run_subs):
        try:
            q.put_nowait(ev)
        except Exception:
            pass


def _run_sleep(secs):
    """Sleep in slices so abort and pause are felt at once rather than at the end of a long wait."""
    end = time.time() + max(0.0, secs)
    while time.time() < end:
        if _run_abort.is_set():
            return False
        while _run_state["paused"] and not _run_abort.is_set():
            time.sleep(0.15)
            end += 0.15
        time.sleep(min(0.12, max(0.0, end - time.time())))
    return not _run_abort.is_set()


_opta_kick_at = 0.0   # when the protocol last told the Opta to start or home

def _run_do(step, dry):
    """Perform one step. Returns (ok, message). In a dry run nothing is sent - the step is
    reported exactly as it would be performed, which is the point of a dry run."""
    global _opta_kick_at
    spec = PROTO_BY_KEY[step["op"]]
    a    = step["args"]
    k    = spec["key"]

    if k == "flow.note":
        return True, a.get("text", "")
    if k in ("flow.mark",):
        return True, ""
    if k == "flow.wait":
        if dry:
            return True, "would wait %gs" % a["secs"]
        if _run_sleep(a["secs"]):
            return True, "waited %gs" % a["secs"]
        return False, "stopped during the wait"
    if k == "flow.confirm":
        if dry:
            return True, "would ask: %s" % a.get("text", "")
        _run_confirm.clear()
        _run_state["await_confirm"] = a.get("text", "Continue?")
        while not _run_confirm.is_set():
            if _run_abort.is_set():
                _run_state["await_confirm"] = ""
                return False, "stopped while waiting for the operator"
            time.sleep(0.15)
        _run_state["await_confirm"] = ""
        return True, "operator confirmed"

    if dry:
        if not _proto_link_up(PROTO_NEEDS[spec["station"]]):
            return True, "would run, but the %s is not connected" % PROTO_LABEL[spec["station"]]
        return True, "would run"

    try:
        if k == "pt.step":
            ptlink.send(a["step"]); return True, "sent %s" % a["step"]
        if k == "pt.cycle":
            gap = int(a["gap"])
            # Tablet 2.06+ runs the cycle in the background, waits out each step, and announces
            # "[CYCLE] DONE | STOPPED | FAIL ..." - so the protocol holds for the real end rather
            # than a guess. Older builds answer only when the whole cycle has finished.
            q = ptlink.subscribe()
            try:
                ptlink.send("run %d" % gap)
                end = time.time() + 30 * 60
                started = False
                while time.time() < end:
                    if _run_abort.is_set():
                        try: ptlink.send("stop")
                        except Exception: pass
                        return False, "stopped during the cycle (the tablet was told to stop)"
                    try:
                        item = q.get(timeout=0.5)
                    except queue.Empty:
                        continue
                    line = _ANSI.sub("", item.get("line") or "").strip()
                    if "OK CYCLE STARTED" in line:
                        started = True
                        if a.get("hold") == "no":
                            return True, "cycle started"
                    elif "[CYCLE]" in line and ("DONE" in line or "STOPPED" in line or "FAIL" in line):
                        msg = line.split("[CYCLE]", 1)[1].strip()
                        return ("DONE" in line), "cycle " + msg.lower()
                    elif line.startswith("OK CYCLE ") and not started:
                        return ("FAIL" not in line), line          # an older tablet: finished
                    elif line.upper().startswith("ERR CYCLE"):
                        return False, line
                return False, "the cycle did not finish within 30 minutes"
            finally:
                ptlink.unsubscribe(q)
        if k == "pt.stop":
            ptlink.send("stop"); return True, "stopped"
        if k == "pt.setting":
            key = a.get("param")
            if key not in _PT_KEYS:
                return False, "unknown setting"
            v = ("%.2f" % float(a["value"])).rstrip("0").rstrip(".")
            with _pt_ask_lock:
                res = _pt_set_many({key: v}, _run_abort)
            if res.get(key) != "ok":
                return False, "%s not set: %s" % (_PT_KEYS[key][1], res.get(key, "stopped"))
            return True, "%s = %s" % (_PT_KEYS[key][1], v)
        if k == "pt.preset":
            want = _s(a.get("name"), "").strip().lower()
            pre = next((x for x in _pt_presets() if (x.get("name") or "").lower() == want), None)
            if not pre:
                return False, "no saved preset called '%s'" % a.get("name")
            vals, bad = _pt_check_values(pre.get("values"))
            with _pt_ask_lock:
                res = _pt_set_many(vals, _run_abort)
            failed = [_PT_KEYS[x][1] for x, r in res.items() if r != "ok"]
            if failed or len(res) < len(vals):
                return False, "preset '%s' not fully applied: %s" % (pre["name"], ", ".join(failed) or "stopped")
            return True, "applied preset '%s' (%d values)" % (pre["name"], len(res))

        if k == "opta.home":
            link.send("home"); _opta_kick_at = time.time(); return True, "homing"
        if k == "opta.start":
            link.send("start"); _opta_kick_at = time.time(); return True, "clean started"
        if k == "opta.actuator":
            link.send("act %s" % a["on"]); return True, "actuator %s" % a["on"]
        if k == "opta.fan":
            link.send("fan %s" % a["on"]); return True, "fan %s" % a["on"]
        if k == "opta.abort":
            link.send("abort"); return True, "aborted"
        if k == "opta.wait_idle":
            # Right after Start or Home the controller can still report the idle it was in a moment
            # ago, so a stale or pre-start "idle" must not count. Only a status the device sent
            # after this step began counts, and after a kick the controller must first be seen
            # busy - unless it never leaves idle within a grace window (it finished at once, or
            # refused the command), in which case a fresh idle is accepted.
            t0 = time.time()
            end = t0 + float(a["timeout"])
            seen_busy = (t0 - _opta_kick_at) >= 15
            while time.time() < end:
                if _run_abort.is_set():
                    return False, "stopped"
                st = (link.last_status or {})
                fresh = getattr(link, "status_at", 0) > max(t0, _opta_kick_at)
                state = str(st.get("state", st.get("STATE", ""))).lower()
                idle = bool(state) and ("idle" in state or "ready" in state or "done" in state)
                if fresh and state and not idle:
                    seen_busy = True
                if fresh and idle and (seen_busy or time.time() - _opta_kick_at > 8):
                    return True, "controller idle"
                if not _run_sleep(0.4):
                    return False, "stopped"
            return False, "the controller did not report idle within %gs" % a["timeout"]

        if k == "tc.form":
            n = int(a["form"])
            if n not in TC_VALID_FORMS:
                return False, "form %d does not exist on the panel" % n
            if _tc_is_standalone():
                tclink.send_raw(("S%d\n" % n).encode())
            else:
                tclink.send_raw(genie_write_obj(GENIE_OBJ_FORM, n, 0))
            return True, "form %d" % n
        if k == "tc.pump":
            tclink.send_raw(b"b" if a["on"] == "on" else b"a"); return True, "pump %s" % a["on"]
        if k == "tc.pump_for":
            secs = int(a["secs"])
            tclink.send_raw(b"b")
            try:
                if not _run_sleep(secs):
                    return False, "stopped during the pump run"
            finally:
                try: tclink.send_raw(b"a")           # the pump stops however this step ends
                except Exception: pass
            return True, "pump ran %ds" % secs
        if k == "tc.plasma_for":
            secs = int(a["secs"])
            if flashing.is_set():
                return False, "a firmware flash is in progress - plasma is locked out"
            # The value goes to the STATION first: the panel's own plasma-time setting, so its
            # hardware timer agrees with what this protocol asked for rather than whatever was
            # last set by hand. Unknown frames are ignored by older display firmware, so this is
            # safe to send to any build.
            secs = min(TC_PLASMA_S[1], max(TC_PLASMA_S[0], secs))
            try:
                # Twice, paced, exactly as /api/tc/settings does: the StandAlone parser reads one
                # byte per loop from an unbuffered UART, so a lone frame can lose a byte and be
                # silently ignored. W writes are idempotent, so a second copy is harmless.
                frame = ("W2%d\n" % secs).encode()
                for _pass in range(2):
                    tclink.send_raw(frame)
                    time.sleep(0.12)
            except Exception:
                pass
            _run_hot.add("plasma")
            tclink.send_raw(b"A!")
            try:
                if not _run_sleep(secs):
                    return False, "stopped part way through the plasma run"
            finally:
                try: tclink.send_raw(b"B!")          # plasma stops however this step ends
                except Exception: pass
                _run_hot.discard("plasma")
            return True, "plasma ran %ds" % secs
        if k == "tc.plasma":
            if a["on"] == "on" and flashing.is_set():
                return False, "a firmware flash is in progress - plasma is locked out"
            if a["on"] == "on":
                _run_hot.add("plasma")
            else:
                _run_hot.discard("plasma")
            tclink.send_raw(b"A!" if a["on"] == "on" else b"B!")
            return True, "plasma %s" % a["on"]
        if k == "tc.setting":
            tclink.send_raw(("W%d%d\n" % (int(a["sel"]), int(a["value"]))).encode())
            return True, "parameter written"

        if k in ("by.wait_state", "by.wait_prog"):
            want = a["state"]
            end  = time.time() + float(a["timeout"])
            while time.time() < end:
                if _run_abort.is_set():
                    return False, "stopped"
                if not bylink.connected:
                    return False, "the cell link dropped"
                r = bylink.ask("getSysState" if k == "by.wait_state" else "getProgState")
                v = r.get("value") if isinstance(r, dict) else None
                now = (BY_SYS if k == "by.wait_state" else BY_PROG).get(v, "?")
                _run_state["by"] = now
                if now == want:
                    return True, "cell is %s" % want
                if not _run_sleep(0.5):
                    return False, "stopped"
            return False, "the cell was not %s within %gs" % (want, a["timeout"])
    except Exception as e:
        return False, str(e)
    return False, "this step is not implemented"


def _run_worker(steps, dry, name, pid, who):
    result, error = "finished", ""
    try:
        # expand repeats first, so the run is a flat list and the page's step count is the truth
        flat, stack, guard = [], [], 0
        i = 0
        counters = {}
        while i < len(steps):
            st = steps[i]
            if st.get("off"):
                i += 1; continue
            k = st["op"]
            if k == "flow.mark":
                stack.append(i); i += 1; continue
            if k == "flow.repeat":
                guard += 1
                if guard > 5000:
                    raise RuntimeError("this protocol repeats too many times to run")
                if stack:
                    done = counters.get(i, 0) + 1
                    counters[i] = done
                    if done < int(st["args"].get("times", 1)):
                        i = stack[-1] + 1
                        continue
                    counters[i] = 0
                    stack.pop()
                i += 1; continue
            flat.append((st, i)); i += 1

        with _run_lock:
            _run_state.update({"n": len(flat), "i": -1, "k": -1})
        _run_emit("start", "%s%s - %d step%s" % ("Dry run: " if dry else "", name,
                                                 len(flat), "" if len(flat) == 1 else "s"))
        for n, pair in enumerate(flat):
            st, doc = pair
            if _run_abort.is_set():
                result, error = "stopped", "stopped by the operator"; break
            while _run_state["paused"] and not _run_abort.is_set():
                time.sleep(0.15)
            spec = PROTO_BY_KEY[st["op"]]
            with _run_lock:
                _run_state["i"] = doc; _run_state["k"] = n
            _run_emit("step", spec["label"], doc)
            ok, msg = _run_do(st, dry)
            # The step line already carries the label. Repeating it as the outcome told the
            # operator nothing twice, so an outcome with nothing to say is not printed at all.
            if msg or not ok:
                _run_emit("ok" if ok else "fail", msg or spec["label"], doc)
            if not ok:
                result, error = ("stopped", msg) if _run_abort.is_set() else ("failed", msg)
                break
            after = float(st.get("after") or 0)
            if dry:
                # A dry run that finishes in one frame looks like nothing happened. Pace it so
                # the sequence is seen to walk, while staying far quicker than the real thing.
                if after:
                    _run_emit("note", "would then wait %gs" % after, doc)
                if not _run_sleep(0.35):
                    result, error = "stopped", "stopped by the operator"; break
            else:
                if after:
                    if not _run_sleep(after):
                        result, error = "stopped", "stopped during the delay after this step"
                        break
                    _run_emit("note", "waited %gs" % after, doc)
                elif spec["station"] != "flow":
                    if not _run_sleep(0.35):    # let the station act on it before the next line
                        result, error = "stopped", "stopped by the operator"; break
    except Exception as e:
        result, error = "failed", str(e)
    finally:
        if "plasma" in _run_hot and not dry:
            try:
                tclink.send_raw(b"B!")
                _run_emit("note", "plasma stopped as the run ended")
            except Exception as e:
                _run_emit("fail", "could not stop plasma as the run ended: %s" % e)
        _run_hot.clear()
        with _run_lock:
            _run_state.update({"active": False, "ended": time.time(), "result": result,
                               "error": error, "paused": False, "await_confirm": ""})
        _run_emit("end", error or result)
        try:
            # The same outcome, recorded where the history can correlate against it. A dry run is
            # excluded on purpose: it touches no hardware, so counting it would dilute the only
            # number that says whether the machine is working.
            if not dry:
                _ev({"finished": "cycle_ok", "failed": "cycle_fail"}.get(result, "cycle_stopped"),
                    "info" if result == "finished" else ("bad" if result == "failed" else "warn"),
                    "protocol", secs=round(time.time() - _run_state["started"], 1),
                    # No operator name. The assistant can read `detail`, so anything put here
                    # leaves the lab the first time somebody asks it a question. Who ran what is
                    # kept by the usage totals, which stay on this station.
                    label=name, detail={"error": error})
        except Exception:
            pass
        try:
            runs = _read_store(PROTO_RUNS_FILE)
            runs.append({"id": "rn-" + uuid.uuid4().hex[:10], "protocol": name, "protocol_id": pid,
                         "dry": bool(dry), "who": who, "result": result, "error": error,
                         "when": time.strftime("%Y-%m-%d %H:%M"),
                         "secs": round(time.time() - _run_state["started"], 1)})
            _write_store(PROTO_RUNS_FILE, runs[-PROTO_MAX_RUNS:])
        except Exception:
            pass


@app.route("/api/protocols/run", methods=["POST"])
def api_protocols_run():
    d = _body()
    with _run_lock:
        if _run_state["active"]:
            return jsonify(ok=False, error="A run is already going. Stop it first."), 409
    clean, problems = _proto_check(d.get("steps"))
    if problems:
        return jsonify(ok=False, error="Fix the steps first.", problems=problems), 400
    live = [s for s in clean if not s.get("off")]
    if not live:
        return jsonify(ok=False, error="There is nothing to run."), 400
    dry = bool(d.get("dry"))
    if not dry:
        missing = sorted({PROTO_BY_KEY[s["op"]]["station"] for s in live
                          if not _proto_link_up(PROTO_NEEDS[PROTO_BY_KEY[s["op"]]["station"]])})
        if missing:
            names = ", ".join(PROTO_LABEL[m] for m in missing)
            return jsonify(ok=False, error="Not connected: %s. Connect it, or use a dry run." % names,
                           missing=missing), 409
    _run_abort.clear(); _run_confirm.clear(); _run_events.clear(); _run_hot.clear()
    name = _s(d.get("name"), "Untitled protocol")[:60]
    with _run_lock:
        _run_state.update({"active": True, "dry": dry, "name": name, "id": _s(d.get("id")),
                           "i": -1, "k": -1, "n": len(live), "started": time.time(), "ended": 0.0,
                           "result": "", "error": "", "paused": False, "await_confirm": "", "by": ""})
    threading.Thread(target=_run_worker, args=(clean, dry, name, _s(d.get("id")),
                                               _session.get("name") or ""),
                     daemon=True).start()
    return jsonify(ok=True)


@app.route("/api/protocols/run/state")
def api_protocols_run_state():
    with _run_lock:
        st = dict(_run_state)
    st["ok"] = True
    st["events"] = list(_run_events)[-60:]
    return jsonify(st)


@app.route("/api/protocols/run/abort", methods=["POST"])
def api_protocols_run_abort():
    _run_abort.set(); _run_confirm.set()
    return jsonify(ok=True)


@app.route("/api/protocols/run/pause", methods=["POST"])
def api_protocols_run_pause():
    with _run_lock:
        _run_state["paused"] = bool(_body().get("on"))
    _run_emit("note", "paused" if _run_state["paused"] else "resumed")
    return jsonify(ok=True, paused=_run_state["paused"])


@app.route("/api/protocols/run/confirm", methods=["POST"])
def api_protocols_run_confirm():
    _run_confirm.set()
    return jsonify(ok=True)


@app.route("/api/protocols/runs")
def api_protocols_runs():
    runs = _read_store(PROTO_RUNS_FILE)
    runs.sort(key=lambda r: r.get("when", ""), reverse=True)
    return jsonify(ok=True, runs=runs[:40])


@app.route("/api/protocols/runs", methods=["DELETE"])
def api_protocols_runs_clear():
    """Empty the run log.

    Refused while a run is going, so the entry for the run in progress cannot be deleted out from
    under the thread that is still writing it. How many were cleared comes back, because "it did
    nothing" and "there was nothing to do" look the same otherwise.
    """
    with _run_lock:
        if _run_state.get("active"):
            return jsonify(ok=False, error="A run is in progress. Stop it first."), 409
    had = len(_read_store(PROTO_RUNS_FILE))
    warn = _write_store(PROTO_RUNS_FILE, [])
    _boot_log("runs: log cleared (%d removed)" % had)
    return jsonify(ok=True, cleared=had, warning=warn or None)


@app.route("/api/protocols/run/stream")
def api_protocols_run_stream():
    def gen():
        q = queue.Queue(maxsize=200)
        _run_subs.append(q)
        try:
            for ev in list(_run_events)[-40:]:
                yield "data: %s\n\n" % json.dumps(ev)
            while True:
                try:
                    yield "data: %s\n\n" % json.dumps(q.get(timeout=15))
                except queue.Empty:
                    yield ": keep-alive\n\n"
        finally:
            try:
                _run_subs.remove(q)
            except ValueError:
                pass
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@app.route("/api/station-pin", methods=["POST"])
def api_station_pin():
    """Change this station's shared PIN. Four digits or more, so it cannot be set to nothing."""
    pin = _s(_body().get("pin"))
    if not pin.isdigit() or len(pin) < 4:
        return jsonify(ok=False, error="The PIN must be at least four digits."), 400
    _json_merge_write(STATION_FILE, {"station_pin": pin})
    return jsonify(ok=True)

@app.route("/api/shared-dir", methods=["POST"])
def api_shared_dir():
    """Point this station at a shared folder, or clear it. Checked before it is stored - a path
    that cannot be written would otherwise fail silently on every later save."""
    d = _s(_body().get("dir"))
    if d:
        try:
            os.makedirs(d, exist_ok=True)
            probe = os.path.join(d, "_ifs_share_probe.tmp")
            with open(probe, "w") as f: f.write("x")
            os.remove(probe)
        except Exception as e:
            return jsonify(ok=False, error="That folder cannot be written: %s" % e), 400
    _json_merge_write(STATION_FILE, {"shared_dir": d})
    return jsonify(ok=True, shared=d)

# ------------------------------------------------------------------ app self-update (OTA)
def _ota_manifest(url, timeout=8):
    """Fetch an OTA-channel manifest and refuse it unless it is signed by Augeas (ota_sig.py).
    Every manifest - app, Mac app, Opta and display firmware - goes through here, so write access
    to the public channel alone can never put code or firmware on a station."""
    import urllib.request, ota_sig
    req = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
    with _ota_open(req, timeout=timeout) as r:
        m = json.loads(r.read().decode("utf-8-sig"))
    return ota_sig.check_manifest(m)


def _ota_open(req, timeout=8):
    """Open an OTA-channel URL with certificate verification. If this machine's CA store is
    broken or missing (some locked-down Windows images fail CERTIFICATE_VERIFY_FAILED while
    the channel itself is fine), retry once against certifi's bundled public roots. GitHub's
    chain is public-CA signed, so certifi verifies it faithfully - verification is NEVER
    disabled, and a genuinely bad certificate still fails on both attempts."""
    import urllib.request, ssl
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except Exception as e:
        if "CERTIFICATE_VERIFY_FAILED" not in str(e): raise
        import certifi                    # bundled by PyInstaller; pip install certifi for dev runs
        ctx = ssl.create_default_context(cafile=certifi.where())
        return urllib.request.urlopen(req, timeout=timeout, context=ctx)

def _ota_fetch(url, dst, timeout=60):
    """Stream an OTA download to disk through the verified opener. urlretrieve has NO timeout,
    so a connection that stalls mid-transfer hung the update (or a firmware flash) forever with
    no way out but killing the app. This gives up after `timeout` seconds of silence, and never
    leaves a half-written file behind for a checksum to trip over."""
    tmp = dst + ".part"
    try:
        with _ota_open(url, timeout=timeout) as r, open(tmp, "wb") as f:
            for chunk in iter(lambda: r.read(1 << 20), b""): f.write(chunk)
        if os.path.exists(dst): os.remove(dst)
        os.replace(tmp, dst)
    except Exception:
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except Exception: pass
        raise

def _ver_tuple(v):
    """A version as a comparable tuple, padded to three parts.

    The old one split on "." and int()ed the pieces, so ANY suffix took the whole thing to (0,):
    a channel version of "1.1.0-rc1" compared as older than every build and the update would
    silently never be offered. Each part now takes its leading digits. Padding to three also makes
    "1.0" and "1.0.0" compare equal instead of "1.0.0" looking newer than "1.0".
    """
    parts = []
    for chunk in str(v or "").strip().lstrip("vV").split("."):
        m = _re.match(r"\d+", chunk.strip())
        parts.append(int(m.group(0)) if m else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)

def _sac_enforced():
    """True if Windows Smart App Control is ENFORCING.

    Under SAC-enforce a freshly self-updated exe - new, zero-reputation, self-signed - is BLOCKED
    from launching, so an in-place swap would replace the app with something Windows then refuses
    to reopen.

    This used to say such machines "update via a signed release instead". They cannot: SAC refuses
    the signed installer too, on the same grounds. The only artifact it allows is the bundle,
    whose executable is python.org's pythonw.exe, signed by the PSF through a CA Microsoft already
    trusts. That is what the update panel offers when this returns True.
    """
    if sys.platform != "win32":
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SYSTEM\CurrentControlSet\Control\CI\Policy") as k:
            return int(winreg.QueryValueEx(k, "VerifiedAndReputablePolicyState")[0]) == 1
    except Exception:
        return False

@app.route("/api/update/check")
def api_update_check():
    import urllib.request
    if IS_MAS:
        # A Mac App Store build is updated by the App Store and nothing else. It does not even ask
        # the Windows channel, so it can never point an operator at an outside download.
        return jsonify(ok=True, current=APP_VERSION, latest=APP_VERSION, newer=False,
                       notes="", url="", last_result=None, installer="", sac=False,
                       bundle="", bundle_version="", bundle_sha256="",
                       frozen=bool(getattr(sys, "frozen", False)), mac=True, store=True)
    if IS_MAC:
        # A direct (.dmg) Mac build updates itself from the Mac channel (mac/mac-latest.json).
        last_result = None
        try:
            rp = os.path.join(CONN_DIR, "update_result.txt")
            if os.path.exists(rp):
                last_result = open(rp).read().strip()
                os.remove(rp)
        except Exception:
            pass
        try:
            m = _ota_manifest(MAC_MANIFEST, 8)
            latest = m.get("version", "")
            can = bool(getattr(sys, "frozen", False)) and bool(_mac_app_path())
            return jsonify(ok=True, current=APP_VERSION, latest=latest,
                           newer=_ver_tuple(latest) > _ver_tuple(APP_VERSION),
                           notes=m.get("notes", ""), url=m.get("url", "") if can else "",
                           last_result=last_result, installer="", sac=False, bundle="",
                           bundle_version="", bundle_sha256="",
                           frozen=bool(getattr(sys, "frozen", False)), mac=True, store=False,
                           self_update=can)
        except Exception as e:
            return jsonify(ok=False, current=APP_VERSION, error=str(e), last_result=last_result, mac=True)
    # If the previous self-update left a result marker (written by the swap batch), report it ONCE and
    # clear it - so a rolled-back swap ("update said it worked but nothing changed") is never silent.
    last_result = None
    try:
        rp = os.path.join(CONN_DIR, "update_result.txt")
        if os.path.exists(rp):
            last_result = open(rp).read().strip()
            os.remove(rp)
    except Exception:
        pass
    try:
        m = _ota_manifest(OTA_MANIFEST, 8)
        latest = m.get("version", "")
        newer = _ver_tuple(latest) > _ver_tuple(APP_VERSION)
        # The bundle rides along because on a Smart App Control machine it is the ONLY artifact
        # that runs: the exe and the installer are both refused, and without this the SAC branch
        # in the UI had nothing to offer and promised a delivery instead.
        return jsonify(ok=True, current=APP_VERSION, latest=latest, newer=newer,
                       notes=m.get("notes", ""), url=m.get("url", ""), last_result=last_result,
                       installer=m.get("installer", ""), sac=_sac_enforced(),
                       bundle=m.get("bundle", ""),
                       bundle_version=m.get("bundle_version", ""),
                       bundle_sha256=m.get("bundle_sha256", ""),
                       frozen=bool(getattr(sys, "frozen", False)))
    except Exception as e:
        return jsonify(ok=False, current=APP_VERSION, error=str(e), last_result=last_result)

OTA_HOST_PREFIX = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/"


def _on_channel(url):
    """Is this URL really on the IFS channel? A bare startswith() is not enough: it also accepts
    "<prefix>/../../someone-else/repo/IFS.exe", which resolves off the channel entirely. The
    manifest is already the trusted input here, so this is depth rather than a live hole - but it
    costs nothing to make the check say what it means."""
    u = str(url or "")
    if not u.startswith(OTA_HOST_PREFIX):
        return False
    rest = u[len(OTA_HOST_PREFIX):]
    low = rest.lower()
    # A leading slash makes "<prefix>//elsewhere/x" - still on the pinned host, so not an escape,
    # but not a path on this channel either. Reject it so the check means what it says.
    return (not rest.startswith("/") and ".." not in rest
            and "%2e" not in low and "//" not in rest and "\\" not in rest)

# Fixed, IFS-specific WebView2 data folder. We pass this to webview.start(storage_path=...) so EVERY
# WebView2 process this app spawns carries this exact path on its command line - which lets us find
# and kill ONLY our own WebView2 processes at update time (never Windows' or another app's). Without
# a fixed path pywebview uses a random Temp\tmpXXXX\EBWebView folder we can't match, and WebView2
# reparents its children so a process-tree walk misses most of them.
WEBVIEW_DATA = os.path.join(CONN_DIR, "webview2")

MAC_UPDATE_STORE_MSG = "This copy of IFS is updated through the Mac App Store."
MAC_UPDATE_MANUAL_MSG = ("One-click update is Windows-only. To update this Mac, download the new "
                         "IFS Control Suite .dmg from Augeas and drag IFS into Applications - your "
                         "settings, licence and history are kept.")
MAC_MANIFEST = OTA_HOST_PREFIX + "main/mac/mac-latest.json"


def _mac_app_path():
    """The running IFS.app (direct build only), or "" if it can't be replaced in place."""
    if not (IS_MAC and not IS_MAS and getattr(sys, "frozen", False)):
        return ""
    app = os.path.abspath(os.path.join(os.path.dirname(sys.executable), "..", ".."))
    if not app.endswith(".app") or not os.path.isdir(app):
        return ""
    if app.startswith("/Volumes/"):
        return ""                       # running straight from the mounted .dmg
    return app if os.access(os.path.dirname(app), os.W_OK) else ""


def _mac_update_stream():
    """Download the new .dmg named by the Mac manifest, check its SHA-256 and the app inside it,
    then hand over to a small script that swaps IFS.app once this process has exited, relaunches
    it, and rolls back to the old copy if the new one can't be put in place."""
    import urllib.request, hashlib, tempfile, plistlib
    app = _mac_app_path()
    if not app:
        yield sse("upd", "This copy can't replace itself (it is running from the disk image or from "
                         "a folder you can't write to). Drag IFS into Applications, open it from "
                         "there, and update again.")
        yield sse("done", "fail"); return
    try:
        m = _ota_manifest(MAC_MANIFEST, 10)
        url, want, ver = m.get("url", ""), (m.get("sha256") or "").lower(), m.get("version", "")
        if not _on_channel(url) or not url.endswith(".dmg") or len(want) != 64:
            raise ValueError("the Mac manifest is not on the IFS channel or has no checksum")
        if _ver_tuple(ver) <= _ver_tuple(APP_VERSION):
            yield sse("upd", "Already on the latest version (v%s)." % APP_VERSION)
            yield sse("done", "ok"); return
        work = tempfile.mkdtemp(prefix="ifs-update-")
        dmg = os.path.join(work, "IFS.dmg")
        yield sse("upd", "Downloading v%s..." % ver)
        h = hashlib.sha256()
        with _ota_open(urllib.request.Request(url), timeout=60) as r, open(dmg, "wb") as f:
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                h.update(b); f.write(b)
        if h.hexdigest() != want:
            raise ValueError("checksum mismatch - the download was not the published file")
        yield sse("upd", "Checksum OK. Checking the new app...")
        mnt = os.path.join(work, "mnt")
        subprocess.run(["hdiutil", "attach", "-nobrowse", "-readonly", "-noautoopen",
                        "-mountpoint", mnt, dmg], check=True, capture_output=True, timeout=120)
        new_app = os.path.join(mnt, "IFS.app")
        try:
            with open(os.path.join(new_app, "Contents", "Info.plist"), "rb") as f:
                info = plistlib.load(f)
            with open(os.path.join(app, "Contents", "Info.plist"), "rb") as f:
                mine = plistlib.load(f)
            if info.get("CFBundleIdentifier") != mine.get("CFBundleIdentifier"):
                raise ValueError("the downloaded app is a different app (%s)" % info.get("CFBundleIdentifier"))
            if info.get("CFBundleShortVersionString") != ver:
                raise ValueError("the downloaded app says v%s, the channel says v%s"
                                 % (info.get("CFBundleShortVersionString"), ver))
            subprocess.run(["codesign", "--verify", "--deep", "--strict", new_app],
                           check=True, capture_output=True, timeout=120)
        except Exception:
            subprocess.run(["hdiutil", "detach", "-quiet", "-force", mnt], capture_output=True)
            raise
        script = os.path.join(work, "swap.sh")
        res = os.path.join(CONN_DIR, "update_result.txt")
        with open(script, "w") as f:
            f.write("""#!/bin/bash
# IFS Mac self-update: wait for the old app to exit, swap, relaunch; roll back on failure.
APP=%(app)s; NEW=%(new)s; MNT=%(mnt)s; RES=%(res)s; WORK=%(work)s; PID=%(pid)d
for i in $(seq 1 120); do kill -0 $PID 2>/dev/null || break; sleep 0.5; done
BAK="$APP.old-update"
rm -rf "$BAK"
if mv "$APP" "$BAK" && ditto "$NEW" "$APP"; then
    xattr -dr com.apple.quarantine "$APP" 2>/dev/null
    rm -rf "$BAK"
    echo "Updated to v%(ver)s." > "$RES"
else
    rm -rf "$APP"; mv "$BAK" "$APP" 2>/dev/null
    echo "The update to v%(ver)s could not be installed; the previous version was kept." > "$RES"
fi
hdiutil detach -quiet -force "$MNT"
open "$APP"
rm -rf "$WORK"
""" % {"app": _shq(app), "new": _shq(new_app), "mnt": _shq(mnt), "res": _shq(res),
       "work": _shq(work), "pid": os.getpid(), "ver": ver})
        os.chmod(script, 0o700)
        subprocess.Popen(["/bin/bash", script], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
        yield sse("upd", "Installing v%s - IFS will close and reopen in a few seconds." % ver)
        yield sse("done", "ok")
        threading.Thread(target=_shutdown_for_update, daemon=True).start()
    except Exception as e:
        _boot_log("mac update failed: %r" % e)
        yield sse("upd", "Update failed: %s. Nothing was changed." % e)
        yield sse("done", "fail")


def _shq(p):
    import shlex
    return shlex.quote(p)

def _kill_webview_children():
    """Reap THIS app's WebView2 processes before we exit - the crux of making the self-update
    actually complete. A packaged onefile exe stays LOCKED while any of its msedgewebview2.exe
    children live, and a plain os._exit(0) orphans dozens of them that then linger for MINUTES; while
    they live the swap batch's `move` over the exe fails, so the update hangs or rolls back. We match
    on WEBVIEW_DATA in the command line so we kill only our own, reliably and completely. Best-effort:
    any failure just falls through to os._exit (the batch's long retry window is the backstop)."""
    if not IS_WIN:
        return          # WebView2 is Windows-only; a Mac window is WKWebView inside this process
    try:
        marker = WEBVIEW_DATA.replace("'", "''")
        ps = ("Get-CimInstance Win32_Process -Filter \"Name='msedgewebview2.exe'\" | "
              "Where-Object { $_.CommandLine -like '*%s*' } | "
              "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }") % marker
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                       creationflags=NO_WINDOW, timeout=10)
    except Exception:
        pass

def _shutdown_for_update():
    # Give the SSE response time to flush, then release the exe lock and exit so the swap batch can
    # replace the exe. The ORDER matters: reap the WebView2 children FIRST (they hold the exe locked),
    # then os._exit. Without this the update cannot complete no matter how the batch retries.
    time.sleep(1.5)
    _kill_webview_children()
    _boot_log("exit: handing over to the update swap")
    os._exit(0)

@app.route("/api/update/apply", methods=["POST"])
def api_update_apply():
    # Client-supplied URLs are IGNORED. We re-fetch the manifest server-side and
    # only trust its https URL on the pinned channel, verified by SHA-256, before
    # swapping. Keeps a backup + rolls back on failure.
    import urllib.request, hashlib
    if IS_MAS:
        return jsonify(ok=False, error=MAC_UPDATE_STORE_MSG), 400   # the App Store updates it
    if IS_MAC:
        if not getattr(sys, "frozen", False):
            return jsonify(ok=False, error=MAC_UPDATE_MANUAL_MSG), 400
        return Response(_mac_update_stream(), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
    if not getattr(sys, "frozen", False):
        return jsonify(ok=False, error="Self-update only works on the packaged .exe."), 400
    if _sac_enforced():
        # Smart App Control would block the freshly-swapped exe from reopening. Refuse the in-place
        # swap rather than replace the app with something Windows won't relaunch. This machine updates
        # via a signed release instead.
        def refuse():
            yield sse("upd", "Smart App Control is enforced on this PC - it blocks replacing the app in place. This machine must be updated by Augeas with a signed release, not the one-click updater.")
            yield sse("done", "fail")
        return Response(refuse(), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
    def gen():
        try:
            m = _ota_manifest(OTA_MANIFEST, 10)
            url = (m.get("url") or "")
            sha = (m.get("sha256") or "").lower().strip()
            if _ver_tuple(m.get("version", "")) <= _ver_tuple(APP_VERSION):
                yield sse("upd", "Already up to date."); yield sse("done", "ok"); return
            if not _on_channel(url):
                yield sse("upd", "ERROR: update URL is not on the trusted IFS channel - refusing."); yield sse("done", "fail"); return
            exe = sys.executable; newexe = exe + ".new"
            exedir = os.path.dirname(exe)

            def _verified(src_url, dst, want, what):
                """Download and prove it before it is allowed anywhere near the install."""
                _ota_fetch(src_url, dst)
                if not want:
                    os.remove(dst); raise RuntimeError("manifest has no sha256 for the %s - refusing unverified update." % what)
                h = hashlib.sha256()
                with open(dst, "rb") as f:
                    for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
                if h.hexdigest().lower() != want:
                    os.remove(dst); raise RuntimeError("checksum mismatch on the %s - update REJECTED." % what)
                with open(dst, "rb") as f:
                    head = f.read(2)
                if head != b"MZ":
                    os.remove(dst)
                    raise RuntimeError("the downloaded %s is not a valid executable." % what)

            # PREFLIGHT: can this user actually write where the app lives? IFS-Setup.exe installs
            # under Program Files as admin, but the app then runs as a normal user - so the in-place
            # swap downloaded 27 MB and died on permissions, which is precisely the "it downloads but
            # never installs" report. Probe BEFORE downloading, and when the folder is read-only
            # update through the SIGNED INSTALLER instead, which elevates itself with a normal UAC
            # prompt. Note this is a different failure from Smart App Control (handled above): there
            # the swap would succeed and Windows would then refuse to reopen the result.
            can_write = True
            try:
                probe = os.path.join(exedir, "_ifs_write_probe.tmp")
                with open(probe, "w") as pf: pf.write("x")
                os.remove(probe)
            except Exception:
                can_write = False

            if not can_write:
                inst = (m.get("installer") or ""); inst_sha = (m.get("installer_sha256") or "").lower().strip()
                inst_ver = (m.get("installer_version") or "").strip()
                if inst and inst_sha and _ver_tuple(inst_ver) < _ver_tuple(m.get("version", "")):
                    yield sse("upd", ("This app folder is read-only for your Windows account, so IFS must update through its "
                                      "installer - but the installer on the channel is %s, older than the %s being offered. "
                                      "Installing it would put an older IFS back and offer this update again on every launch. "
                                      "Ask Augeas for the %s installer.")
                                     % (inst_ver or "unversioned", m.get("version", "update"), m.get("version", "new")))
                    yield sse("done", "fail"); return
                if not _on_channel(inst) or not inst_sha:
                    yield sse("upd", "ERROR: this app folder is read-only for your Windows account, and the update channel offers no signed installer to fall back on. Ask Augeas for IFS-Setup.exe, or move IFS.exe somewhere you can write to."); yield sse("done", "fail"); return
                import tempfile
                setup = os.path.join(tempfile.gettempdir(), "IFS-Setup-%s.exe" % m.get("version", "latest"))
                yield sse("upd", "This app folder is read-only for your account, so the in-place update cannot work here. Downloading the signed installer instead...")
                _verified(inst, setup, inst_sha, "installer")
                yield sse("upd", "Installer verified. Launching it now - ACCEPT THE WINDOWS PROMPT to finish the update. IFS will close.")
                yield sse("done", "ok")
                os.startfile(setup)                      # Inno Setup asks for elevation itself
                threading.Thread(target=_shutdown_for_update, daemon=True).start()
                return

            yield sse("upd", "Downloading v%s..." % m.get("version"))
            _verified(url, newexe, sha, "update")     # hashed in 1 MB chunks, not slurped whole
            yield sse("upd", "Checksum verified. Staging swap...")
            bat = os.path.join(os.path.dirname(exe), "_ifs_update.bat")
            name = os.path.basename(exe)
            result = os.path.join(CONN_DIR, "update_result.txt")
            # This swap batch was rebuilt 2026-07-29 after testing it end-to-end against a real locked
            # 26 MB exe. TWO cmd gotchas silently broke it (update "ran" but nothing changed):
            #   1) `timeout` needs a console; this batch is DETACHED (0x08, no console), so `timeout`
            #      fails INSTANTLY instead of waiting -> the retry window collapsed to milliseconds.
            #      -> use `ping -n K 127.0.0.1` (waits ~K-1 s WITHOUT a console).
            #   2) `errorlevel` after `move` is UNRELIABLE - the batch neither advanced nor rolled back,
            #      it just died mid-loop. Also `goto` inside a parenthesized `if(...)` block corrupts
            #      cmd's parsing. -> flat control flow, and detect success DETERMINISTICALLY by whether
            #      the `.new` file still exists (a successful move consumes it), never via errorlevel.
            # Verified: waits for the app to exit, retries the move until the post-exit lock clears,
            # swaps, writes an ok/failed marker, relaunches.
            def bw(line): f.write(line + "\r\n")
            with open(bat, "w") as f:
                bw("@echo off"); bw("setlocal enabledelayedexpansion")
                bw("ping -n 3 127.0.0.1 >nul")                                    # ~2 s: let the app begin exiting
                bw(":wait")
                bw('tasklist /fi "imagename eq %s" | find /i "%s" >nul' % (name, name))
                bw("if errorlevel 1 goto gone")                                   # find not-found -> process is gone
                bw("ping -n 2 127.0.0.1 >nul"); bw("goto wait")
                bw(":gone")
                bw('copy /y "%s" "%s.old" >nul' % (exe, exe))                    # backup
                bw("set n=0")
                bw(":mv")
                bw('move /y "%s" "%s" >nul 2>&1' % (newexe, exe))
                bw('if not exist "%s" goto moved' % newexe)                       # .new consumed -> move succeeded
                bw("set /a n+=1")
                bw("if !n! geq 300 goto rollback")                               # ~5 min of 1 s retries, then give up
                bw("ping -n 2 127.0.0.1 >nul"); bw("goto mv")
                bw(":moved")
                bw('>"%s" echo ok' % result)                                      # marker: the next launch confirms the swap took
                bw('del "%s.old" >nul 2>&1' % exe)
                # ROOT-CAUSE FIX 2026-07-30 (isolated + reproduced): the previous version relaunched with
                # cmd's `start "" exe`. When our WebView2 child processes are still around from the instance
                # we just replaced, launching the onefile exe with `start` from this detached, console-less,
                # parent-already-dead batch leaves the PyInstaller BOOTLOADER stalled - the process exists but
                # Python never even begins (boot_diag stays empty), so the server never binds and the window
                # never comes back. Relaunching the SAME exe via PowerShell Start-Process instead launches it
                # cleanly into the user session and it boots + serves normally. This, not Defender, was the
                # real "update never reopens" cause. (certutil below still pre-reads the fresh exe - harmless.)
                bw('certutil -hashfile "%s" SHA256 >nul 2>&1' % exe)
                # VERIFIED RELAUNCH: launch via Start-Process, then confirm it actually answers on the port
                # (curl) before declaring success. _serve self-heals a slow/contended bind, so we do NOT kill
                # the new instance - only re-launch if it died outright, never a second copy while one lives.
                bw("set rtry=0")
                bw(":relaunch")
                bw('tasklist /fi "imagename eq %s" | find /i "%s" >nul || powershell -NoProfile -Command "Start-Process -FilePath \'%s\'"' % (name, name, exe))
                bw("ping -n 11 127.0.0.1 >nul")                                    # ~10 s, then check
                bw('curl.exe -s -m 3 -o nul "http://127.0.0.1:%d/api/update/check" && goto launched' % APP_PORT)
                bw("set /a rtry+=1")
                bw("if !rtry! geq 6 goto launched")                               # ~60 s total; the file is swapped regardless
                bw("goto relaunch")
                bw(":launched")
                bw('del "%~f0" & exit')
                bw(":rollback")
                bw('copy /y "%s.old" "%s" >nul 2>&1' % (exe, exe))               # restore the old exe
                bw('del "%s" >nul 2>&1' % newexe)
                bw('>"%s" echo failed' % result)                                  # marker: tell the user it could not complete
                bw('powershell -NoProfile -Command "Start-Process -FilePath \'%s\'"' % exe)
                bw('del "%~f0"')
            subprocess.Popen(["cmd", "/c", bat], creationflags=0x00000008)   # DETACHED_PROCESS
            yield sse("upd", "Update verified & staged. Closing to swap...")
            yield sse("done", "ok")
            threading.Thread(target=_shutdown_for_update, daemon=True).start()
        except Exception as e:
            yield sse("upd", "ERROR: %s" % e); yield sse("done", "fail")
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ------------------------------------------------------------------ tools
def find_arduino_cli():
    if IS_MAC:
        return _mac_tool("arduino-cli") or "arduino-cli"
    for p in [os.path.join(FIRMWARE, "arduino-cli.exe"),
              r"C:\Program Files\Arduino CLI\arduino-cli.exe",
              r"C:\Program Files (x86)\Arduino CLI\arduino-cli.exe"]:
        if os.path.exists(p): return p
    return "arduino-cli"   # hope it's on PATH

# ------------------------------------------------------------------ routes
@app.route("/")
def index(): return send_from_directory(STATIC, "index.html")

@app.route("/static/<path:p>")
def static_files(p): return send_from_directory(STATIC, p)

@app.route("/api/platform")
def api_platform():
    """Which desktop this is, so the UI can label and disable what this platform cannot do."""
    return jsonify(ok=True, os=("mac" if IS_MAC else "windows" if IS_WIN else sys.platform),
                   store=IS_MAS, display_flash=DISPLAY_FLASH_OK,
                   display_flash_msg=("" if DISPLAY_FLASH_OK else DISPLAY_FLASH_MAC_MSG),
                   native_folder_picker=IS_MAC)

@app.route("/api/ports")
def api_ports():
    out = []
    for p in serial.tools.list_ports.comports():
        # macOS always lists its own debug console and the Bluetooth listener; neither is a unit.
        if IS_MAC and p.device in ("/dev/cu.debug-console", "/dev/cu.Bluetooth-Incoming-Port"):
            continue
        out.append({"device": p.device, "desc": p.description or "",
                    "opta": ("opta" in (p.description or "").lower()
                             or "2341" in (getattr(p, "hwid", "") or ""))})
    return jsonify(out)

@app.route("/api/scanner/connect", methods=["POST"])
def api_scanner_connect():
    global SCANNER_PORT
    d = _body()
    port = _s(d.get("port"), "")
    if not port: return jsonify(ok=False, error="Pick the scanner's COM port."), 400
    try:
        scanner.connect(port, int(d.get("baud", 9600) or 9600))
    except Exception as e:
        return jsonify(ok=False, error="Could not open %s: %s" % (port, e)), 400
    SCANNER_PORT = port   # keep auto-connect from grabbing it as the display/Opta
    return jsonify(ok=True, **scanner.state())

@app.route("/api/scanner/disconnect", methods=["POST"])
def api_scanner_disconnect():
    global SCANNER_PORT
    scanner.disconnect(); SCANNER_PORT = None
    return jsonify(ok=True)

@app.route("/api/scanner/state")
def api_scanner_state():
    return jsonify(scanner.state())

@app.route("/api/connect", methods=["POST"])
def api_connect():
    if flashing.is_set():
        return jsonify(ok=False, error="A firmware flash is in progress - opening a port now would interrupt it. Wait for the flash to finish."), 409
    d = _body()
    try:
        if d.get("mode") == "tcp":
            host = _s(d.get("host"), "")
            if not host: return jsonify(ok=False, error="Enter the Opta IP (e.g. 192.168.1.100)."), 400
            link.connect_tcp(host, d.get("port", 8080)); where = "IP/port"
            _target = {"mode": "tcp", "host": host, "port": int(d.get("port", 8080))}
        else:
            if not d.get("port"): return jsonify(ok=False, error="Pick the Opta serial port (%s)." % OPTA_PORT_HINT), 400
            if tclink.connected and tclink.mode == "serial" and tclink.ser is not None and getattr(tclink.ser, "port", None) == d["port"]:
                return jsonify(ok=False, error="%s is the 4D DISPLAY's port - it's already connected. The Opta is on a DIFFERENT port, %s." % (d["port"], OPTA_PORT_HINT)), 400
            try:
                link.connect_serial(d["port"], DEVICE_BAUD)   # Opta USB console is 9600 8N1
            except PermissionError:
                return jsonify(ok=False, error="Could not open %s - it's in use by another connection in this app or another program (Workshop 4 / Arduino IDE / dfu-util / a serial terminal). Close that, or select the Opta's port (%s)." % (d["port"], OPTA_PORT_HINT)), 400
            where = "COM port"
            _target = {"mode": "serial", "port": d["port"], "baud": DEVICE_BAUD}
        # The Opta streams status continuously; require REAL bytes before calling it
        # connected, so a wrong port / dead bridge / powered-off Opta fails loudly
        # instead of showing a false green. (Poll link.last_rx OUTSIDE the lock - the
        # reader thread needs the lock to set it.)
        end = time.time() + 3.0
        while time.time() < end and not link.last_rx:
            time.sleep(0.05)
        if not link.last_rx:
            link.disconnect()
            return jsonify(ok=False, error="Link opened but the Opta sent no data - check the %s and that the Opta is powered and streaming." % where), 400
        remember_connection("plasma", _target)   # arm auto-reconnect + remember what worked
        return jsonify(ok=True, info=link.info, mode=link.mode)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.route("/api/disconnect", methods=["POST"])
def api_disconnect():
    set_autoconnect("plasma", False)   # a manual Disconnect stays disconnected (no auto-reconnect)
    link.disconnect(); return jsonify(ok=True)

@app.route("/api/state")
def api_state():
    age = link.rx_age()
    live = bool(link.connected and age is not None and age < 6.0)
    # Ride the auto-reconnect diagnostics along on the poll the UI ALREADY runs (every 1.5 s).
    # These were only ever exposed on /api/autoconnect, which nothing in the UI calls - so the
    # "diagnosable, not silent" intent behind _autoconnect_last_error was not actually met: a
    # persistently failing reconnect loop, or two Tip Chargers plugged in at once, looked
    # identical to "it just will not connect". Cheap to carry here; no second poll needed.
    # Hold the lock: the autoconnect thread mutates _ambiguous, and iterating it unlocked can raise
    # "dictionary changed size during iteration" - which would 500 the poll the whole UI runs on.
    with _conn_lock:
        amb = sorted({p for lst in _ambiguous.values() for p in lst})
    probing = _probing("plasma")
    return jsonify(connected=bool(link.connected and not probing), live=(live and not probing),
                   probing=probing, age=age, mode=link.mode, info=link.info,
                   status=link.last_status,
                   autoconnectError=_autoconnect_last_error,
                   ambiguous=amb)

@app.route("/api/send", methods=["POST"])
def api_send():
    d = _body()
    try: link.send(d.get("cmd", "")); return jsonify(ok=True)
    except Exception as e: return jsonify(ok=False, error=str(e)), 400

@app.route("/api/diag/streams")
def api_diag_streams():
    """How many pages are holding a live stream. The browser fallback keys its shutdown on this,
    so it has to be observable to be trusted rather than assumed."""
    return jsonify(ok=True, clients=_sse_clients, quiet_for=round(time.time() - _last_request_at, 1))


@app.route("/api/stream")
def api_stream():
    def gen():
        q = link.subscribe()
        _sse_open()
        try:
            for item in list(link.buffer)[-200:]:   # inside try so a disconnect mid-replay still unsubscribes
                yield "data: %s\n\n" % json.dumps(item)
            while True:
                try:
                    item = q.get(timeout=15)
                    yield "data: %s\n\n" % json.dumps(item)
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            _sse_close()
            link.unsubscribe(q)
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

DFU_UTIL = os.path.join(FIRMWARE, "tools", "dfu-util.exe")
# A Mac build carries its own dfu-util (built from source with libusb by scripts/build-mac.sh) at
# firmware/tools/mac/dfu-util; a run from source uses Homebrew's.
DFU_UTIL_MAC_BUNDLED = os.path.join(FIRMWARE, "tools", "mac", "dfu-util")
DFU_MISSING_MAC = ("dfu-util was not found. The Mac build carries its own; for a run from source "
                   "install it with:  brew install dfu-util")
# The Mac App Store build carries no dfu-util (it is GPL). It flashes the Opta with dfuse.py, a
# DfuSe writer of our own over IOKit (macusb.py) - same 1200-baud touch, same address, plus a
# read-back verify. IFS_DFU_NATIVE=1 selects it on a direct build / a run from source too, for
# bench testing. Windows and the direct Mac build keep dfu-util exactly as before.
DFU_NATIVE = IS_MAC and (IS_MAS or os.environ.get("IFS_DFU_NATIVE") == "1")


def _dfu_util():
    """The dfu-util this machine will flash with, or "" if there is none. Windows: unchanged."""
    if IS_MAC:
        return _mac_tool("dfu-util", DFU_UTIL_MAC_BUNDLED)
    return DFU_UTIL if os.path.exists(DFU_UTIL) else ""


def _native_dfu_ok():
    """The built-in DFU writer can run here (IOKit loads). Only ever asked when DFU_NATIVE."""
    try:
        import dfuse, macusb  # noqa: F401
        return macusb.available()
    except Exception:
        return False


def _have_dfu():
    """Can this build flash the Opta over DFU? dfu-util everywhere, except the store build."""
    if DFU_NATIVE:
        return _native_dfu_ok()
    return bool(_dfu_util())


FW_BIN   = os.path.join(FIRMWARE, "bin", "plasma_knife.bin")
DFU_VIDPID = "0x2341:0x0364"       # Opta bootloader
DFU_ADDR   = "0x08040000"          # mbed_opta application region

# Opta firmware OTA channel: the app pulls the latest .bin from GitHub, SHA-256-verifies it, and
# flashes it over USB (same DFU path as the bundled bin). This lets the Opta firmware ship
# independently of an app release; the bundled bin is the offline fallback. Parallels the display
# channel. NOTE: the DFU address/vidpid come from THIS build (pinned), never from the manifest.
OPTA_MANIFEST    = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/main/opta/opta-latest.json"
OPTA_HOST_PREFIX = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/"
OPTA_WORK        = os.path.join(CONN_DIR, "opta-work")

def _opta_fetch_manifest():
    import urllib.request
    return _ota_manifest(OPTA_MANIFEST, 8)

def _opta_download_verified(m):
    """Download the channel bin named in manifest m, verify its SHA-256, return the local path.
       Refuses any URL not on the pinned IFS-ota host. Raises on any problem."""
    import urllib.request, hashlib
    url = (m.get("bin") or "")
    sha = (m.get("bin_sha256") or "").lower().strip()
    if not url.startswith(OPTA_HOST_PREFIX):
        raise RuntimeError("firmware URL is not on the trusted IFS channel - refusing")
    if not sha:
        raise RuntimeError("manifest has no bin_sha256 - refusing unverified firmware")
    os.makedirs(OPTA_WORK, exist_ok=True)
    dst = os.path.join(OPTA_WORK, "plasma_opta.bin")
    _ota_fetch(url, dst)
    got = hashlib.sha256(open(dst, "rb").read()).hexdigest()
    if got != sha:
        os.remove(dst)
        raise RuntimeError("firmware checksum mismatch - download REJECTED")
    return dst

def valid_port(port):
    # only allow "COM<n>" - never let arbitrary text reach a subprocess
    import re
    if IS_MAC:
        # macOS names a USB serial port /dev/cu.<name> (usbmodem1101, SLAB_USBtoUART,
        # usbserial-0001). One path segment, no spaces or shell characters.
        return bool(port) and bool(re.fullmatch(r"/dev/cu\.[A-Za-z0-9._-]{1,64}", str(port)))
    return bool(port) and bool(re.fullmatch(r"COM\d{1,3}", str(port)))

def _opta_bootloader_touch(port):
    """Open the Opta's port at 1200 baud and drop DTR: the mbed core resets into its DFU bootloader."""
    yield sse("flash", "1200bps touch on %s to enter the bootloader..." % port)
    try:
        s = serial.Serial(port, 1200)
        try: s.dtr = False
        except Exception: pass
        time.sleep(0.15); s.close()
    except Exception as e:
        yield sse("flash", "touch note: %s" % e)


def flash_dfu_native(port, bin_path, usb_open=None, wait_for=None, settle=1.0):
    """Mac App Store build: the same OTA as flash_dfu, written by dfuse.py over IOKit instead of
       dfu-util. Erases only the sectors the image needs (never below DFU_ADDR - the bootloader),
       writes, reads back and compares, and starts the new firmware only when it matches.
       usb_open / wait_for are for the unit tests (a simulated DfuSe device)."""
    import dfuse
    if usb_open is None or wait_for is None:
        import macusb
        usb_open = usb_open or macusb.Device
        wait_for = wait_for or macusb.wait_for
    vid, pid = (int(x, 16) for x in DFU_VIDPID.split(":"))
    base = int(DFU_ADDR, 16)
    yield sse("flash", "Portable DFU update (built-in DFU writer + firmware)")
    try:
        with open(bin_path, "rb") as f:
            image = f.read()
    except OSError as e:
        yield sse("flash", "ERROR: cannot read the firmware image: %s" % e); yield sse("done", "fail"); return
    yield from _opta_bootloader_touch(port)
    time.sleep(settle)                 # let the application drop off the bus first
    yield sse("flash", "Waiting for the Opta bootloader (USB %s)..." % DFU_VIDPID)
    if not wait_for(vid, pid, 10.0):
        yield sse("flash", "ERROR: the Opta bootloader did not appear on USB within 10 s. Double-press "
                           "the Opta RESET button (the LED pulses green in bootloader mode) and try again.")
        yield sse("done", "fail"); return
    time.sleep(settle)                 # and the bootloader finish enumerating
    yield sse("flash", "Flashing with the built-in DFU writer...")
    ok, dev = False, None
    try:
        dev = usb_open(vid, pid)
        d = dfuse.DfuSe(dev, alt=0)
        yield sse("flash", "Memory layout: %s" % d.layout_string.strip())
        for msg in d.flash(image, base, verify=True, leave=True):
            yield sse("flash", msg)
        ok = True
    except dfuse.GuardError as e:
        yield sse("flash", "REFUSED (bootloader protection): %s" % e)
    except (dfuse.DfuError, dfuse.UsbError) as e:
        yield sse("flash", "ERROR: %s" % e)
    finally:
        if dev is not None:
            try: dev.close()
            except Exception: pass
    yield sse("flash", "DFU write %s" % ("OK" if ok else "FAILED"))
    if ok:
        yield sse("flash", "Flashed OK. The Opta reconnects on its own - if it doesn't within ~15s, press the Opta RESET button once (post-DFU boards sometimes need it), and it will auto-connect.")
    yield sse("done", "ok" if ok else "fail")


def flash_dfu(port, bin_path=None):
    """Portable OTA: 1200bps touch into the bootloader, then dfu-util the given binary
       (defaults to the bundled one). Needs no arduino-cli / core on the target machine."""
    if not bin_path:
        bin_path = FW_BIN
    if DFU_NATIVE:
        yield from flash_dfu_native(port, bin_path); return
    yield sse("flash", "Portable DFU update (bundled dfu-util + firmware)")
    yield from _opta_bootloader_touch(port)
    time.sleep(3.0)
    yield sse("flash", "Flashing with dfu-util...")
    cmd = [_dfu_util() or DFU_UTIL, "-d", DFU_VIDPID, "-a", "0", "-s", "%s:leave" % DFU_ADDR, "-D", bin_path]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=NO_WINDOW)
    for ln in p.stdout:
        ln = ln.rstrip()
        if ln: yield sse("flash", ln)
    rc = p.wait()
    yield sse("flash", "dfu-util %s (rc=%d)" % ("OK" if rc == 0 else "FAILED", rc))
    if rc == 0:
        yield sse("flash", "Flashed OK. The Opta reconnects on its own - if it doesn't within ~15s, press the Opta RESET button once (post-DFU boards sometimes need it), and it will auto-connect.")
    yield sse("done", "ok" if rc == 0 else "fail")

def flash_cli(port):
    """Dev fallback: compile + upload the bundled sketch with arduino-cli."""
    cli = find_arduino_cli()
    sketch = os.path.join(FIRMWARE, "Opta_PlasmaStation_Integrated")
    if not os.path.isdir(sketch):
        yield sse("flash", "ERROR: no dfu binary and no sketch to compile."); yield sse("done", "fail"); return
    yield sse("flash", "Compiling firmware (arduino-cli)...")
    p = subprocess.Popen([cli, "compile", "--fqbn", "arduino:mbed_opta:opta", sketch],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=NO_WINDOW)
    for ln in p.stdout: yield sse("flash", ln.rstrip())
    if p.wait() != 0: yield sse("flash", "Compile FAILED"); yield sse("done", "fail"); return
    yield sse("flash", "Uploading to %s ..." % port)
    p = subprocess.Popen([cli, "upload", "-p", port, "--fqbn", "arduino:mbed_opta:opta", sketch],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=NO_WINDOW)
    for ln in p.stdout: yield sse("flash", ln.rstrip())
    rc = p.wait()
    yield sse("flash", "Upload %s (rc=%d)" % ("OK" if rc == 0 else "FAILED", rc))
    yield sse("done", "ok" if rc == 0 else "fail")

@app.route("/api/flash", methods=["POST"])
def api_flash():
    d = _body()
    port = d.get("port")
    def gen():
        if not valid_port(port):
            yield sse("flash", "ERROR: invalid port '%s'" % port); yield sse("done", "fail"); return
        if not _flash_lock.acquire(blocking=False):
            yield sse("flash", "A firmware flash is already running - wait for it to finish."); yield sse("done", "fail"); return
        flashing.set()   # pause autoconnect so it can't re-grab the port mid-flash
        try:
            yield sse("flash", "Freeing the serial port...")
            link.disconnect(); time.sleep(0.6)
            # Prefer the latest firmware from the OTA channel (SHA-256 verified); fall back to the
            # bundled bin when offline or the channel is unreachable, so a flash always works.
            bin_path = None
            chan_ver = ""
            try:
                m = _opta_fetch_manifest()
                yield sse("flash", "Fetching Opta firmware %s from the update channel..." % m.get("version", "?"))
                bin_path = _opta_download_verified(m)
                yield sse("flash", "Checksum verified. Using channel firmware %s." % m.get("version", "?"))
                chan_ver = m.get("version", "")
            except Exception as e:
                yield sse("flash", "Update channel unavailable (%s) - using the firmware bundled with this app." % e)
                bin_path = None
            if _have_dfu() and (os.path.exists(bin_path) if bin_path else os.path.exists(FW_BIN)):
                yield from _fw_record(flash_dfu(port, bin_path), "opta_fw_flashed", chan_ver)
            else:
                if IS_MAC and not _have_dfu():
                    yield sse("flash", "The built-in DFU writer could not load IOKit." if DFU_NATIVE else DFU_MISSING_MAC)
                yield sse("flash", "(dfu bundle missing; using arduino-cli)")
                yield from flash_cli(port)
        except Exception as e:
            yield sse("flash", "ERROR: %s" % e); yield sse("done", "fail")
        finally:
            flashing.clear(); _flash_lock.release()
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

def sse(event, msg):
    return "event: %s\ndata: %s\n\n" % (event, json.dumps(msg))


def _fw_record(gen, key, version):
    """Pass a flash's SSE stream through unchanged, and when it ends in done/ok remember which
    channel version this station put on the device. The startup firmware notice compares the
    channel against this, so a station is told only about firmware it has not installed yet."""
    for ev in gen:
        if version and ev.startswith("event: done") and '"ok"' in ev:
            try:
                _json_merge_write(STATION_FILE, {key: str(version)})
            except Exception:
                pass
        yield ev

# ------------------------------------------------------------------ 4D display firmware push
# The 4D ViSi-Genie display is reprogrammed with 4D's own redistributable loader (ScriptC),
# bundled under tools/4dloader. A developer compiles the panel program ONCE in Workshop4;
# the publisher stages the .4XE (+ its required .cfg) into the IFS-ota "display" channel; the
# Control Suite pulls it, SHA-256-verifies it, and runs ScriptC to flash it over a DIRECT 4D
# USB programmer (whose DTR pulses the panel RESET into download mode). Logic (.4XE) only -
# graphics (.gci/.dat) live on the panel uSD and are not pushed over serial.
FOURD_DIR     = os.path.join(BASE, "tools", "4dloader")
FOURD_SCRIPTC = os.path.join(FOURD_DIR, "SCRIPTC.EXE")
# ScriptC is a Windows program and 4D Systems publishes no macOS loader and no specification of
# the program-load protocol it speaks (see docs/MACOS.md). So on a Mac display flashing is off -
# cleanly, with a reason - rather than half-working. Downloading the display code still works.
DISPLAY_FLASH_OK = IS_WIN
DISPLAY_FLASH_MAC_MSG = ("Display flashing needs the Windows app: 4D Systems' loader (ScriptC) "
                         "only exists for Windows. Use IFS on a Windows PC, or Workshop 4, to flash "
                         "the display. Download code still works here.")


def _have_display_loader():
    return DISPLAY_FLASH_OK and os.path.exists(FOURD_SCRIPTC)


DISPLAY_OTA  = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/main/display/display-latest.json"
DISPLAY_HOST_PREFIX = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/"

# Two different touch panels share this page, and their programs are NOT interchangeable: each
# opens its own graphics on the panel's uSD by 8.3 name. A Plasma StandAlone program (PLASMA~1.*)
# flashed onto a Universal Controller 4.1 Tip Charger (UNIVER~1.* / Universa.*) finds no images
# and the panel sits on "Mounting..." (IonField, 2026-11-13). So the operator names the panel, each
# family has its own channel, and every .4XE is checked for its family's graphics before flashing.
_OTA_RAW = "https://raw.githubusercontent.com/AugeasTechnologies/IFS-ota/main/"
DISPLAY_CHANNELS = {
    "standalone": {"family": "standalone", "label": "Plasma StandAlone panel",
                   "url": DISPLAY_OTA},
    "uc41":       {"family": "uc41", "label": "Universal Controller 4.1 (Tip Charger) - V4.1.38 shipping",
                   "url": _OTA_RAW + "display-uc41/display-latest.json"},
    "uc41-emi":   {"family": "uc41", "label": "Universal Controller 4.1 (Tip Charger) - EMI-filter test build",
                   "url": _OTA_RAW + "display-uc41/display-emi.json"},
}
DISPLAY_FAMILY_MARKERS = {"standalone": (b"PLASMA~1.gci",),
                          "uc41": (b"UNIVER~1.gci", b"Universa.gci")}
DISPLAY_FAMILY_NAMES = {"standalone": "Plasma StandAlone", "uc41": "Universal Controller 4.1"}
DISPLAY_PICK_MSG = ("Choose which display this unit has first (Universal Controller 4.1 Tip Charger, "
                    "or Plasma StandAlone) - the two programs are not interchangeable.")


def _display_channel(key):
    """The channel entry for a display-type key, or None when unknown/missing."""
    return DISPLAY_CHANNELS.get(_s(key))


def _display_channel_default():
    """The display type this station last chose (for check/download/notices), else None."""
    k = _s(_station_cfg().get("display_channel"))
    return k if k in DISPLAY_CHANNELS else None


def _display_flashed_key(ch):
    return "display_fw_flashed" if ch["family"] == "standalone" else "display_fw_flashed_" + ch["family"]


def _display_family_check(xe_path, family):
    """None if the .4XE loads the chosen family's uSD graphics, else the reason to refuse it."""
    try:
        with open(xe_path, "rb") as f:
            data = f.read()
    except Exception as e:
        return "could not read %s: %s" % (os.path.basename(xe_path), e)
    found = [fam for fam, marks in DISPLAY_FAMILY_MARKERS.items() if any(m in data for m in marks)]
    if found == [family]:
        return None
    if not found:
        return ("%s does not reference any known display graphics - not flashing it." % os.path.basename(xe_path))
    other = [DISPLAY_FAMILY_NAMES[f] for f in found if f != family]
    return ("%s is a %s display program, but this unit was set as %s. Flashing it would leave the panel "
            "blank on 'Mounting...' - REFUSED." % (os.path.basename(xe_path), " / ".join(other) or "different",
                                                     DISPLAY_FAMILY_NAMES[family]))
DISPLAY_WORK  = os.path.join(CONN_DIR, "display-work")

def _sha256_file(p):
    import hashlib
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""): h.update(chunk)
    return h.hexdigest()

_OSS_HEAD = """IFS Control Suite
Copyright (c) 2026 Augeas Technologies. All rights reserved.

IFS Control Suite includes the following open-source software. Each is used under its own licence,
reproduced or referenced below. Source code for the LGPL component (libusb, inside Android adb) is
available from https://github.com/libusb/libusb and https://android.googlesource.com/platform/packages/modules/adb ;
it is linked so that it can be replaced, and Augeas will provide the corresponding source on request
(info@augeastechnologies.com).

  Python                 Python Software Foundation License
  Flask, Werkzeug, Jinja2, MarkupSafe, ItsDangerous, Click, Blinker   BSD-3-Clause
  pySerial               BSD-3-Clause
  pywebview              BSD-3-Clause
  PyObjC (macOS)         MIT
  certifi                MPL-2.0 (unmodified; source at https://github.com/certifi/python-certifi)
  anthropic (Python SDK) MIT
  Android adb            Apache-2.0, includes libusb (LGPL-2.1-or-later) - full text below
  Ed25519 (ota_sig.py)   written from the RFC 8032 reference code

"""

@app.route("/notices")
def notices():
    """Open-source notices, shown from the version label. The adb NOTICE (with the libusb LGPL
    text) is bundled beside adb on the Mac and Windows builds."""
    body = _OSS_HEAD
    for p in (os.path.join(BASE, "tools", "adb-mac", "NOTICE.txt"),
              os.path.join(BASE, "tools", "adb", "NOTICE.txt"),
              os.path.join(BASE, "tools", "NOTICE.txt")):
        if os.path.exists(p):
            try:
                body += "=" * 78 + "\nAndroid adb - NOTICE\n" + open(p, encoding="utf-8", errors="replace").read()
            except Exception:
                pass
            break
    return Response(body, mimetype="text/plain; charset=utf-8")


@app.route("/api/fw/notices")
def api_fw_notices():
    """Station firmware this computer has not installed yet, for the notice at start-up.
    The app cannot read the version off the panel or the controller, so "installed" means
    "flashed from this app"; a device flashed elsewhere (Workshop 4, another PC) is still offered
    the channel version once. Dismissing a notice hides that version until a newer one ships."""
    import urllib.request
    cfg = _station_cfg()
    out = []
    _dch = _display_channel(_display_channel_default())
    feeds = [("opta", OPTA_MANIFEST, "opta_fw_flashed")]
    if _dch:   # no display notice until the operator has said which panel this station drives
        feeds.insert(0, ("display", _dch["url"], _display_flashed_key(_dch)))
    for kind, url, key in feeds:
        try:
            m = _ota_manifest(url, 6)
        except Exception:
            continue
        ver = str(m.get("version") or "")
        if not ver:
            continue
        have = str(cfg.get(key) or "")
        if have and _ver_tuple(have) >= _ver_tuple(ver):
            continue
        if str(cfg.get("fw_notice_dismissed_" + kind) or "") == ver:
            continue
        if kind == "display":
            can = _have_display_loader()
            how = ("Open Firmware to flash it (4D USB programmer)." if can else
                   "Flash it from IFS on a Windows PC - 4D's loader is Windows-only. "
                   "Firmware > Download code saves the files here.")
            label = "Touch display firmware (%s)" % DISPLAY_FAMILY_NAMES[_dch["family"]]
        else:
            can = True
            how = "Open Firmware and click Update Firmware (Opta over USB)."
            label = "Controller (Opta) firmware"
        out.append({"kind": kind, "label": label, "version": ver, "installed": have,
                    "notes": m.get("notes", ""), "can_flash": can, "how": how})
    return jsonify(ok=True, notices=out)


@app.route("/api/fw/notices/dismiss", methods=["POST"])
def api_fw_notices_dismiss():
    d = _body()
    kind = _s(d.get("kind"))
    if kind not in ("display", "opta"):
        return jsonify(ok=False, error="unknown firmware kind"), 400
    _json_merge_write(STATION_FILE, {"fw_notice_dismissed_" + kind: _s(d.get("version"))})
    return jsonify(ok=True)


@app.route("/api/opta/fw/check")
def api_opta_fw_check():
    # Report the latest Opta firmware available on the OTA channel. The Opta itself does not report a
    # firmware version, so this is "what the app would flash", not a diff against the connected board.
    have_dfu = _have_dfu()
    try:
        m = _opta_fetch_manifest()
        return jsonify(ok=True, dfu=have_dfu, version=m.get("version"), name=m.get("name"),
                       board=m.get("board"), notes=m.get("notes"))
    except Exception as e:
        return jsonify(ok=False, dfu=have_dfu, error=str(e))

@app.route("/api/display/fw/check")
def api_display_fw_check():
    import urllib.request
    have_loader = _have_display_loader()
    extra = {} if DISPLAY_FLASH_OK else {"unsupported": DISPLAY_FLASH_MAC_MSG}
    key = _s(request.args.get("channel")) or _display_channel_default() or "standalone"
    ch = _display_channel(key)
    if not ch:
        return jsonify(ok=False, loader=have_loader, error=DISPLAY_PICK_MSG, **extra)
    extra.update(channel=key, family=ch["family"], label=ch["label"])
    try:
        m = _ota_manifest(ch["url"], 10)
        if m.get("family", "standalone") != ch["family"]:
            return jsonify(ok=False, loader=have_loader, error="channel manifest is for a different display family - refusing", **extra)
        return jsonify(ok=True, loader=have_loader,
                       version=m.get("version"), name=m.get("name"), model=m.get("model"),
                       notes=m.get("notes"), baud=m.get("download_baud", 9600), graphics=bool(m.get("graphics")),
                       **extra)
    except Exception as e:
        return jsonify(ok=False, loader=have_loader, error=str(e), **extra)

@app.route("/api/display/fw/download", methods=["POST"])
def api_display_fw_download():
    # Download JUST the display firmware code (the compiled .4XE, and its required .cfg) from the OTA
    # channel - SHA-256 verified - and save it to a folder the user can reach, then open that folder.
    # This does NOT flash anything; it's for archiving the code or flashing it elsewhere (e.g. in 4D
    # Workshop). Same trusted-channel source as Check for update / Flash from channel.
    import urllib.request
    ch = _display_channel(_s(_body().get("channel")) or _display_channel_default() or "standalone")
    if not ch:
        return jsonify(ok=False, error=DISPLAY_PICK_MSG), 400
    try:
        m = _ota_manifest(ch["url"], 10)
    except Exception as e:
        return jsonify(ok=False, error="Could not reach the display firmware channel: %s" % e), 502
    if m.get("family", "standalone") != ch["family"]:
        return jsonify(ok=False, error="channel manifest is for a different display family - refusing"), 400
    name = m.get("name", "plasma_display"); ver = str(m.get("version", "0"))
    xe = m.get("xe", ""); cfg = m.get("cfg", "")
    xesha = (m.get("xe_sha256") or "").lower().strip(); cfgsha = (m.get("cfg_sha256") or "").lower().strip()
    if not (xe.startswith(DISPLAY_HOST_PREFIX) and cfg.startswith(DISPLAY_HOST_PREFIX)):
        return jsonify(ok=False, error="firmware URL is not on the trusted IFS channel - refusing"), 400
    dest = os.path.join(os.path.expanduser("~"), "Downloads", "IFS Display Firmware", "%s_%s" % (name, ver))
    try:
        os.makedirs(dest, exist_ok=True)
        xep = os.path.join(dest, name + ".4XE"); cfgp = os.path.join(dest, name + ".cfg")
        _ota_fetch(xe, xep)
        _ota_fetch(cfg, cfgp)
    except Exception as e:
        return jsonify(ok=False, error="download failed: %s" % e), 502
    if not xesha or _sha256_file(xep) != xesha:
        return jsonify(ok=False, error=".4XE checksum missing or mismatched - download REJECTED"), 400
    if cfgsha and _sha256_file(cfgp) != cfgsha:
        return jsonify(ok=False, error=".cfg checksum mismatch - download REJECTED"), 400
    _reveal(dest)                                                # reveal the folder (best-effort)
    return jsonify(ok=True, version=ver, name=name, folder=dest, files=[name + ".4XE", name + ".cfg"])

@app.route("/api/display/fw/flash", methods=["POST"])
def api_display_fw_flash():
    d = _body()
    port = d.get("port")
    ckey = _s(d.get("channel")); ch = _display_channel(ckey)
    def gen():
        import urllib.request
        if not ch:      # never guess the panel type for a flash - that is how a 4.1 got the StandAlone program
            yield sse("flash", "ERROR: " + DISPLAY_PICK_MSG); yield sse("done", "fail"); return
        if not DISPLAY_FLASH_OK:
            yield sse("flash", DISPLAY_FLASH_MAC_MSG); yield sse("done", "fail"); return
        if not os.path.exists(FOURD_SCRIPTC):
            yield sse("flash", "ERROR: the 4D loader (ScriptC) is not bundled with this build."); yield sse("done", "fail"); return
        if not valid_port(port):
            yield sse("flash", "ERROR: pick the 4D USB programmer's COM port first."); yield sse("done", "fail"); return
        yield sse("flash", "Checking the %s display firmware channel..." % ch["label"])
        try:
            m = _ota_manifest(ch["url"], 10)
        except Exception as e:
            yield sse("flash", "ERROR fetching manifest: %s" % e); yield sse("done", "fail"); return
        if m.get("family", "standalone") != ch["family"]:
            yield sse("flash", "ERROR: channel manifest is for a different display family - REFUSED."); yield sse("done", "fail"); return
        name = m.get("name", "plasma_display"); xe = m.get("xe", ""); cfg = m.get("cfg", "")
        xesha = (m.get("xe_sha256") or "").lower().strip(); cfgsha = (m.get("cfg_sha256") or "").lower().strip()
        baud = int(m.get("download_baud", 9600))
        # trust only files on the pinned IFS channel
        if not (xe.startswith(DISPLAY_HOST_PREFIX) and cfg.startswith(DISPLAY_HOST_PREFIX)):
            yield sse("flash", "ERROR: firmware URL is not on the trusted IFS channel - refusing."); yield sse("done", "fail"); return
        try:
            os.makedirs(DISPLAY_WORK, exist_ok=True)
            xep = os.path.join(DISPLAY_WORK, name + ".4XE"); cfgp = os.path.join(DISPLAY_WORK, name + ".cfg")
            yield sse("flash", "Downloading %s v%s..." % (name, m.get("version")))
            _ota_fetch(xe, xep); _ota_fetch(cfg, cfgp)
        except Exception as e:
            yield sse("flash", "ERROR downloading firmware: %s" % e); yield sse("done", "fail"); return
        if not xesha or _sha256_file(xep) != xesha:
            yield sse("flash", "ERROR: .4XE checksum missing/mismatch - REJECTED (nothing flashed)."); yield sse("done", "fail"); return
        if not cfgsha or _sha256_file(cfgp) != cfgsha:
            yield sse("flash", "ERROR: .cfg checksum missing/mismatch - REJECTED."); yield sse("done", "fail"); return
        bad = _display_family_check(xep, ch["family"])
        if bad:
            yield sse("flash", "ERROR: " + bad); yield sse("done", "fail"); return
        yield sse("flash", "Checksums verified; program matches a %s panel." % DISPLAY_FAMILY_NAMES[ch["family"]])
        try: _json_merge_write(STATION_FILE, {"display_channel": ckey})
        except Exception: pass
        # Delegate to the shared, hardened ScriptC runner (single-flight _flash_lock + child
        # termination on client disconnect). It writes the LoadProgram.4DScript itself.
        yield from _fw_record(_scriptc_flash_gen(port, name, baud), _display_flashed_key(ch), m.get("version", ""))
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ---- one-click LOCAL display flash: flash the .4XE you just compiled in Workshop, straight
# from the project folder (no GitHub staging). Dev convenience; customers use the OTA channel.
def _scriptc_flash_gen(port, name, baud):
    """Run 4D ScriptC to flash <name>.4XE (already staged in DISPLAY_WORK) over <port>. Yields SSE.

    Single-flight across ALL flash paths (shares _flash_lock with the Opta DFU path), and terminates
    the ScriptC child if the SSE client goes away mid-flash so a closed UI window can't orphan a
    flasher that still holds the COM port while autoconnect resumes.
    """
    if not DISPLAY_FLASH_OK:
        yield sse("flash", DISPLAY_FLASH_MAC_MSG); yield sse("done", "fail"); return
    if not _flash_lock.acquire(blocking=False):
        yield sse("flash", "A firmware flash is already running - wait for it to finish."); yield sse("done", "fail"); return
    p = None
    try:
        # FIX 2026-07-20: create the flash script + set the flashing flag INSIDE the try, so a failure
        # here (DISPLAY_WORK missing, permission denied, disk full, AV/indexer holding the file) still
        # reaches the finally that releases _flash_lock. Before, an exception here propagated BEFORE the
        # try, leaking the lock permanently -> every subsequent flash (Opta DFU and display) reported
        # "already running" until the app was restarted: a silent dead-lock of the whole flash subsystem.
        os.makedirs(DISPLAY_WORK, exist_ok=True)
        script = os.path.join(DISPLAY_WORK, "LoadProgram.4DScript")
        with open(script, "w", encoding="ascii", newline="\r\n") as f:
            f.write('#Run(Picaso,%s,%d,5,Wrap)\n' % (port, baud))
            f.write('$4DGLLoadProgram("%s",Flash)\n' % name)
        flashing.set()
        try:
            if tclink.connected and tclink.mode == "serial" and str(port).upper() in (tclink.info or "").upper():
                yield sse("flash", "Freeing the runtime display link on %s..." % port); tclink.disconnect()
        except Exception: pass
        try: os.remove(os.path.join(DISPLAY_WORK, "LoadProgram.log"))
        except Exception: pass
        yield sse("flash", "Flashing %s over %s via the 4D USB programmer..." % (name, port))
        try:
            p = subprocess.Popen([FOURD_SCRIPTC, "LoadProgram.4DScript", "/c" + port, "/s%d" % baud, "/l"],
                                 cwd=DISPLAY_WORK, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, creationflags=NO_WINDOW)
        except Exception as e:
            yield sse("flash", "ERROR launching ScriptC: %s" % e); yield sse("done", "fail"); return
        for ln in p.stdout:
            ln = ln.strip()
            if ln and not set(ln) <= set("-\\|/ "):
                yield sse("flash", ln)
        rc = p.wait()
        try:
            with open(os.path.join(DISPLAY_WORK, "LoadProgram.log"), encoding="utf-8", errors="replace") as f:
                for ln in f.read().splitlines():
                    if ln.strip(): yield sse("flash", "[log] " + ln)
        except Exception: pass
        ok = (rc == 0)
        yield sse("flash", "ScriptC exit=%d -> %s" % (rc, "FLASHED OK" if ok else "FAILED"))
        if not ok:
            yield sse("flash", "If it says 'Device is not responding': confirm the 4D USB programmer is seated on the display's programming header and the panel has power.")
        yield sse("done", "ok" if ok else "fail")
    finally:
        # Runs on normal completion AND on GeneratorExit (client disconnect / window closed). If the
        # child is still running, kill it so it does not keep the COM port after we release the lock.
        try:
            if p is not None and p.poll() is None:
                p.terminate()
                try: p.wait(timeout=3)
                except Exception:
                    try: p.kill()
                    except Exception: pass
        except Exception: pass
        flashing.clear();
        try: _flash_lock.release()
        except RuntimeError: pass

DISPLAY_LOCAL_SRC = os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop", "Plasma StandAlone V0.1")

@app.route("/api/display/fw/flash_local", methods=["POST"])
def api_display_fw_flash_local():
    d = _body()
    port = d.get("port"); src = _s(d.get("src")) or DISPLAY_LOCAL_SRC
    ch = _display_channel(d.get("channel"))
    def gen():
        import shutil
        if not ch:
            yield sse("flash", "ERROR: " + DISPLAY_PICK_MSG); yield sse("done", "fail"); return
        if not DISPLAY_FLASH_OK:
            yield sse("flash", DISPLAY_FLASH_MAC_MSG); yield sse("done", "fail"); return
        if not os.path.exists(FOURD_SCRIPTC):
            yield sse("flash", "ERROR: the 4D loader (ScriptC) is not bundled with this build."); yield sse("done", "fail"); return
        if not valid_port(port):
            yield sse("flash", "ERROR: pick the 4D USB programmer's COM port first."); yield sse("done", "fail"); return
        # Any compiled program: a .4XE file, or the newest .4XE in the chosen (Workshop project) folder.
        if src.lower().endswith(".4xe") and os.path.isfile(src):
            xe = src
        else:
            cands = sorted(glob.glob(os.path.join(src, "*.4XE")) + glob.glob(os.path.join(src, "*.4xe")),
                           key=lambda q: os.path.getmtime(q), reverse=True)
            cands = list(dict.fromkeys(os.path.normcase(os.path.abspath(q)) for q in cands))
            if not cands:
                yield sse("flash", "ERROR: no compiled .4XE in %s - open the project in Workshop 4 and Compile first, "
                                   "or give the path of the .4XE itself." % src)
                yield sse("done", "fail"); return
            xe = cands[0]
            if len(cands) > 1:
                yield sse("flash", "%d .4XE files in that folder - using the newest, %s." % (len(cands), os.path.basename(xe)))
        cfg = os.path.splitext(xe)[0] + ".cfg"
        bad = _display_family_check(xe, ch["family"])
        if bad:
            yield sse("flash", "ERROR: " + bad); yield sse("done", "fail"); return
        try:
            os.makedirs(DISPLAY_WORK, exist_ok=True)
            for ext in (".4XE", ".cfg"):     # never let a stale .cfg from an earlier flash ride along
                try: os.remove(os.path.join(DISPLAY_WORK, "plasma_display" + ext))
                except FileNotFoundError: pass
            shutil.copyfile(xe, os.path.join(DISPLAY_WORK, "plasma_display.4XE"))
            if os.path.exists(cfg): shutil.copyfile(cfg, os.path.join(DISPLAY_WORK, "plasma_display.cfg"))
            mt = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(xe)))
            yield sse("flash", "Your locally-compiled .4XE (built %s) - flashing your latest build." % mt)
        except Exception as e:
            yield sse("flash", "ERROR staging local firmware: %s" % e); yield sse("done", "fail"); return
        yield from _scriptc_flash_gen(port, "plasma_display", int(d.get("baud", 9600)))
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ------------------------------------------------------------------ main
APP_URL = "http://127.0.0.1:%d/" % APP_PORT

@app.route("/api/quit", methods=["POST"])
def api_quit():
    """Shut this instance down. The launcher calls it when it finds a server with no window - a
    zombie left behind by the browser fallback - so the click that follows opens a real app
    instead of a web page. It also frees the serial ports, which a windowless copy is still
    holding: an operator who plugs in the Opta and sees nothing recognised is often looking at
    a stale instance that owns COM.

    Local only: Flask is bound to 127.0.0.1, and the check below refuses anything that did not
    come from this machine even if that ever changes."""
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return jsonify(ok=False, error="local only"), 403
    _boot_log("api_quit: asked to shut down")
    def _bye():
        time.sleep(0.25)          # let this response reach the caller first
        try:
            link.close(); tclink.close()
        except Exception:
            pass
        if IS_MAC:
            _mac_on_quit()        # and stop the bundled adb server, so nothing outlives the app
        os._exit(0)
    threading.Thread(target=_bye, daemon=True).start()
    return jsonify(ok=True)


def _ifs_already_serving(timeout=0.6):
    """Is a live IFS already answering on our port? Only a server that RESPONDS counts: a socket
    that merely accepts could be the copy we are replacing, still shutting down."""
    try:
        import urllib.request
        req = urllib.request.Request(APP_URL + "api/state", headers={"Host": "127.0.0.1:%d" % APP_PORT})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


# Whatever ends this process, the log should say so. A normal interpreter shutdown runs this;
# a kill from outside does not - and that difference is itself the answer when a station reports
# the app "just closing".
@atexit.register
def _say_goodbye():
    try:
        _boot_log("exit: interpreter shutting down after %.0fs" % (time.time() - _BOOT_T0))
    except Exception:
        pass
    if IS_MAC and __name__ == "__main__":
        _mac_on_quit()            # Cmd-Q ends the interpreter normally; leave no adb server behind


def _serve():
    # threaded so SSE + requests + reader coexist; no reloader in frozen app.
    # ROBUST BIND (self-update relaunch): the instance we just replaced may still be releasing
    # 127.0.0.1:8765 when we relaunch (the OS holds a just-closed listen/accept socket briefly),
    # which made "the update completes but the window never comes back" - the new server thread
    # threw "address in use" and died silently. Retry the bind for ~20 s with address reuse, and
    # record what happened so a stuck relaunch is never a mystery again.
    _boot_log("_serve: entered")
    from werkzeug.serving import make_server
    # If a HEALTHY copy is already serving, do not spend 20 seconds retrying a bind that cannot
    # succeed - hand the window to the instance that is already up and stop. The retry below is
    # for the self-update relaunch, where the port is held by a server that is DYING and will let
    # go shortly; that one does not answer. A live one does, so the two cases are distinguishable.
    if _ifs_already_serving():
        _boot_log("_serve: another IFS is already serving %d - not starting a second server" % APP_PORT)
        return
    diag = os.path.join(CONN_DIR, "serve_diag.log")
    def _log(m):
        try:
            with open(diag, "a") as f: f.write("%s  %s\n" % (time.strftime("%H:%M:%S"), m))
        except Exception: pass
    for attempt in range(40):
        try:
            srv = make_server("127.0.0.1", APP_PORT, app, threaded=True)
            try: srv.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            except Exception: pass
            _log("bound 8765 (attempt %d)" % attempt)
            srv.serve_forever()
            return
        except OSError as e:
            _log("bind failed (attempt %d): %s" % (attempt, e))
            time.sleep(0.5)
        except Exception as e:
            _log("server error: %r" % e); return
    _log("gave up binding 8765 after 40 attempts")

def _wait_until_up(timeout=8.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            with socket.create_connection(("127.0.0.1", APP_PORT), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.15)
    return False

def open_browser():
    """Last resort, when no native window can be had.

    Edge and Chrome are named before the system default on purpose. webbrowser.open follows
    whatever Windows has registered for http, and on a machine where that association is stale
    it opens Internet Explorer - which is how a customer ended up looking at an IE window
    instead of the application.
    """
    time.sleep(1.2)
    candidates = [
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                     "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                     "Google", "Chrome", "Application", "chrome.exe"),
    ]
    for exe in candidates:
        if not os.path.isfile(exe):
            continue
        try:
            # --app strips the address bar and tabs, so it reads as the application rather
            # than as a web page someone has been dumped on.
            subprocess.Popen([exe, "--app=" + APP_URL])
            _boot_log("browser fallback: opened %s" % os.path.basename(exe))
            return
        except Exception:
            continue
    try:
        webbrowser.open(APP_URL)
        _boot_log("browser fallback: used the system default")
    except Exception:
        pass

SPLASH_MIN_S = 4.0        # minimum time the splash stays up, however fast the app starts
_SPLASH_T0 = time.time()

def _splash(msg=None, done=False):
    """PyInstaller's boot splash. A onefile exe spends several seconds unpacking before Python
    runs at all, and nothing appeared on screen for that whole window - a cold start looked like
    a launch that had failed, and operators double-clicked again. The bootloader shows
    installer/splash.png across that gap; this drives its progress line and closes it the moment
    the real window is up. No-ops in a dev run, where the pyi_splash module does not exist."""
    try:
        import pyi_splash
    except Exception:
        return
    try:
        if done:
            # Hold it on screen for a moment. On a warm start the app comes up fast enough that
            # the splash flashed past before it could be read, which is worse than none at all.
            held = time.time() - _SPLASH_T0
            if held < SPLASH_MIN_S:
                time.sleep(SPLASH_MIN_S - held)
            pyi_splash.close()
        elif msg:
            pyi_splash.update_text(msg)
    except Exception:
        pass

def _cleanup_stale_update():
    # Remove leftovers from a prior self-update (the fixed batch cleans up after itself, but an
    # OLD buggy batch could leave IFS.exe.old / .new behind). Safe at startup: if either exists,
    # the update is already over. Do NOT touch _ifs_update.bat here - a batch that just relaunched
    # us may still be finishing its own self-delete.
    if not getattr(sys, "frozen", False): return
    exe = sys.executable
    for p in (exe + ".old", exe + ".new"):
        try:
            if os.path.exists(p): os.remove(p)
        except Exception: pass


def _mac_hand_over_to_running_copy():
    """A second IFS on a Mac (opened with `open -n`, from Terminal, or a copy run from the .dmg
    while the installed one is open) would start its own autoconnect and Puretip loops and fight
    the running copy for the same serial ports. Windows has the launcher for this; on a Mac, bring
    the copy that is already running to the front and leave."""
    _boot_log("main: IFS is already running on %d - handing over and exiting" % APP_PORT)
    try:
        from AppKit import NSRunningApplication, NSBundle
        bid = NSBundle.mainBundle().bundleIdentifier()
        for other in NSRunningApplication.runningApplicationsWithBundleIdentifier_(bid) or []:
            if other.processIdentifier() != os.getpid():
                other.activateWithOptions_(1 << 1)     # NSApplicationActivateIgnoringOtherApps
                break
    except Exception as e:
        _boot_log("main: could not raise the running copy (%r)" % e)
    os._exit(0)


def _mac_on_quit():
    """A Mac app that quits leaves nothing running behind it (App Store rule 2.4.5). adb starts
    a background server that would otherwise outlive the app, so stop it - only if it is ours,
    i.e. the adb inside this bundle (or the one this app was using), never by killing processes.
    The serial ports are released too, as the Windows path does on its own exit routes."""
    try:
        link.close(); tclink.close()
    except Exception:
        pass
    try:
        if _adb_server_was_running is not False:
            return              # never used adb, or somebody else's server was already running
        adb = find_adb()
        if adb and adb != "adb":
            subprocess.run([adb, "kill-server"], timeout=5, capture_output=True, env=_adb_env())
    except Exception:
        pass


class _WindowFailed(Exception):
    """The native window could not be opened. Never raised for a window the operator closed."""


def _open_native_window(attempt):
    try:
        import webview  # pywebview -> Microsoft Edge WebView2 on Windows
        if IS_MAC:
            # WKWebView drops every <a download> (CSV / protocol / labware / fleet exports) unless
            # pywebview is told to allow downloads; then it asks where to save in a Finder panel,
            # which is also what grants a sandboxed build the right to write there.
            try:
                webview.settings["ALLOW_DOWNLOADS"] = True
            except Exception:
                pass
        win = webview.create_window(
            "IFS Control Suite",
            APP_URL,
            width=1360, height=900, min_size=(1120, 720),
            background_color="#0b0f14",
        )
        # Did a window ever actually appear? That is what separates "the operator closed it" from
        # "it never opened, or it died" - and only the first should end the application.
        _t0 = time.time()
        _win_shown = {"yes": False, "at": 0.0}

        def _mark_shown():
            _win_shown["yes"] = True
            _win_shown["at"] = time.time()
            _boot_log("window: shown after %.1fs" % (time.time() - _BOOT_T0))

        try:
            win.events.shown += _mark_shown
        except Exception:
            try:
                win.events.loaded += _mark_shown      # older pywebview has no 'shown'
            except Exception:
                # No event to hook: assume a window did open, so behaviour is exactly as before
                # rather than a fallback loop nobody asked for.
                _win_shown["yes"] = True
        # webview.start() blocks on the main thread until the window closes. storage_path pins the
        # WebView2 data folder to WEBVIEW_DATA so a self-update can find + kill our own WebView2
        # processes (they'd otherwise sit in a random temp folder and keep the exe locked). Guarded so
        # an older pywebview without these kwargs still runs (the update then leans on the batch retry).
        _splash(done=True)          # the window is about to take over the screen
        _ico = os.path.join(BASE, "ifs.ico")
        _kw = {"private_mode": False, "storage_path": WEBVIEW_DATA}
        if os.path.exists(_ico):
            _kw["icon"] = _ico
        for _drop in (None, "icon", "storage_path"):
            if _drop: _kw.pop(_drop, None)
            try:
                webview.start(**_kw); break
            except TypeError:
                continue
        else:
            webview.start()
        # start() has returned. If a window was shown and the operator closed it, that is a quit
        # and the whole application should go. If a window was never shown, nothing was closed -
        # WebView2 failed or died - and exiting here is how the app "closes by itself" with the
        # operator never having asked. In that case fall through to the browser, which at least
        # puts the application in front of them.
        if _win_shown["yes"]:
            _boot_log("exit: the window was closed after %.0fs" % (time.time() - _BOOT_T0))
            if IS_MAC:
                _mac_on_quit()
            os._exit(0)          # window closed -> tear the whole app down (server thread too)
        raise _WindowFailed("start() returned after %.1fs with no window on attempt %d"
                            % (time.time() - _t0, attempt))
    except _WindowFailed:
        raise
    except Exception as e:
        raise _WindowFailed(str(e))


def _browser_fallback(why):
    """No native window can be had, so put the application in a browser and keep serving it.

    Only reached after the window has been tried twice. On a machine with no WebView2 runtime
    this is the difference between a usable application and none at all.
    """
    _splash(done=True)          # close the splash too, or it hangs on screen forever
    sys.stderr.write("[IFS] native window unavailable (%s); using browser.\n" % why)
    threading.Thread(target=open_browser, daemon=True).start()

    # A page that is really gone drops its stream; a backgrounded tab keeps it, so the two are
    # never confused. Without this the process outlived its page, kept the port and the serial
    # ports, and every later click on the shortcut found a server with no window.
    IDLE_QUIT_S = 300.0
    try:
        while True:
            time.sleep(5)
            quiet = time.time() - _last_request_at
            if _sse_clients == 0 and quiet > IDLE_QUIT_S:
                _boot_log("browser fallback: no page open and nothing asked for %.0fs - "
                          "shutting down" % quiet)
                try:
                    link.close(); tclink.close()
                except Exception:
                    pass
                os._exit(0)
    except KeyboardInterrupt:
        _boot_log("exit: interrupted at the console")
        os._exit(0)


if __name__ == "__main__":
    # The UI lives in a real desktop WINDOW (native WebView2 shell via pywebview) -
    # not a browser tab. Flask runs in the background; the window is the app.
    _boot_log("main: entered")
    if IS_MAC and getattr(sys, "frozen", False) and _ifs_already_serving():
        _mac_hand_over_to_running_copy()     # never a second copy fighting over the serial ports
    _splash("Starting IFS Control Suite\u2026")
    _cleanup_stale_update()
    if IS_MAS:
        _mac_granted_folders()     # re-open the Finder-chosen folders before anything reads them
    _seed_default_admins()
    _boot_log("main: cleanup done, starting _serve thread")
    _splash("Starting local server\u2026")
    threading.Thread(target=_serve, daemon=True).start()
    threading.Thread(target=_autoconnect_loop, daemon=True).start()   # auto-detect + auto-reconnect serial units
    threading.Thread(target=_pt_auto_loop, daemon=True).start()       # keep the Puretip tablet (adb) connected
    threading.Thread(target=_odo_loop, daemon=True).start()           # lifetime totals per unit, saved to disk
    threading.Thread(target=_fleet_loop, daemon=True).start()          # fleet heartbeat; never fatal
    threading.Thread(target=_insight_loop, daemon=True).start()        # local history; never fatal

    def _warm_model():
        # A local model evicted from VRAM costs 6.6s on the next question. Load it once at boot,
        # after everything that matters has started. Never fatal: this is a convenience.
        time.sleep(35)
        try:
            c = _ai_cfg()
            if c["provider"] == "local" and _pro("insight_ai"):
                insight.warm_local(c["url"], c["model"], _ui_tools())
        except Exception:
            pass
    threading.Thread(target=_warm_model, daemon=True).start()
    _splash("Looking for connected units\u2026")
    _wait_until_up()
    _boot_log("main: _wait_until_up returned")
    _splash("Opening the window\u2026")
    # WebView2 can fail to come up on a cold start - the runtime warming, the data folder still
    # being made - and succeed moments later. That is precisely why clicking the shortcut a second
    # time works. Try twice here so nobody has to.
    for _attempt in (1, 2):
        try:
            _open_native_window(_attempt)
            break                      # it opened; _open_native_window owns the app from here
        except _WindowFailed as _e:
            if _attempt == 1:
                _boot_log("window: attempt 1 failed (%s) - trying once more" % _e)
                time.sleep(1.5)
                continue
            _boot_log("window: attempt 2 failed (%s) - falling back to the browser" % _e)
            _browser_fallback(_e)
