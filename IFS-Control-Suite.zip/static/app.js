/* IFS Control Center - frontend */
/* Edited by Adithya Mallela - 2026-07-17 00:09: Data Log graph + per-run logging,
   tab-scoped serial SSE, banner auto-clear, display firmware flash UI. */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
let mode = "serial", connected = false, es = null, demoActive = false, demoRAF = null;

/* ---------- sidebar navigation + product cards ---------- */
// Per-view topbar title/subtitle, and whether the Opta connection cluster is shown
// (only the Plasma Station views drive the Opta; Tip Charger / Puretip connect in-view).
const VIEWS = {
  home: ["Home", "No unit selected", false],
  fleet:["Fleet", "Every station on site", false],
  insight:["Insight", "What this station has learned about itself", false],
  dash: ["Plasma StandAlone", "Master controller", true],
  mon:  ["Serial Monitor", "Controller serial stream", true],
  log:  ["Data Log", "Temperature & power per run", true],
  tune: ["Tuning", "Live power, electrode temp and vacuum", true],
  cfg:  ["Configuration", "Licence, station, network and machine settings", true],
  ctl:  ["Control", "Cycle and manual outputs", true],
  fw:   ["Firmware", "Controller firmware update", true],
  tc:   ["Tip Charger", "Display settings", false],
  pt:   ["Puretip One", "Tablet station, Bioyond bridge", false],
  live: ["Live View", "Bioyond automation cell", false],
  proto:["Protocol", "Build a run as a sequence of steps", false],
};
let currentView = "home";   // tracked so auto-open-on-connect never overrides deliberate navigation
// One place decides a chart series colour, and it is the stylesheet.
function seriesColor(name) {
  const v = getComputedStyle(document.documentElement).getPropertyValue("--series-" + name).trim();
  return v || "#007bc0";
}
function showView(v) {
  if (!VIEWS[v]) v = "home";
  // Leaving the protocol editor with unsaved steps used to lose them silently, which is the
  // worst of the small losses: the work is gone and nothing said so.
  if (currentView === "proto" && v !== "proto" && typeof prLeaving === "function" && !prLeaving()) return;
  currentView = v;
  $$(".navitem").forEach(x => x.classList.toggle("active", x.dataset.v === v));
  if (v === "fw" && typeof fwNoticesSeen === "function") fwNoticesSeen();
  $$(".view").forEach(x => x.classList.remove("active"));
  const el = $("#view-" + v); if (el) el.classList.add("active");
  const [title, sub, showOpta] = VIEWS[v];
  $("#viewTitle").textContent = title;
  $("#viewSub").textContent = sub;
  $("#optaCluster").style.display = showOpta ? "flex" : "none";
  $(".content").scrollTop = 0;
  if (typeof aiOnView === "function") aiOnView();   // the dock follows the screen behind it
}
$$(".navitem").forEach(b => b.onclick = () => { showView(b.dataset.v); syncStreams(b.dataset.v); });
$$(".htile").forEach(b => b.onclick = () => { showView(b.dataset.goto); syncStreams(b.dataset.goto); });
window.showView = showView;
// Exposed because the assistant navigates too, and showView alone swaps the section
// without starting the view's streams or loading its data - an empty Insight page.
window.syncStreams = syncStreams;
// Hold the Tip Charger / Puretip live SSE ONLY while their tab is visible, so the always-on
// Opta monitor stream is never starved by the browser's per-host connection cap.
let tcReconnectTimer = null, ptReconnectTimer = null;   // pending SSE reconnects; cleared on tab-away so they can't leak a background stream
function syncStreams(v) {
  if (v === "tc") { if (!tcEs) tcStartStream(); }
  else { clearTimeout(tcReconnectTimer); tcReconnectTimer = null; if (tcEs) { tcEs.close(); tcEs = null; } }
  if (v === "pt") { if (!ptEs) ptStartStream(); }   // the Puretip animation lives on its own page now
  else { clearTimeout(ptReconnectTimer); ptReconnectTimer = null; if (ptEs) { ptEs.close(); ptEs = null; } }
  if (v === "log" && typeof dlRedraw === "function") dlRedraw();   // canvas needs a live redraw once visible
  if (v === "tune" && typeof tuneDraw === "function") { tuneReadouts(); tuneDraw(); tsRenderTable(); tsDrawCharts(); tsUpdateCur(); tuneTcPorts(); }   // draw buffers + session + USB list on open
  if (v === "insight" && typeof insightOpen === "function") insightOpen();   // runs SQL, so only on open
  if (v === "mon") { var mc = $("#console"); if (mc) requestAnimationFrame(function () { mc.scrollTop = mc.scrollHeight; }); }   // jump to the newest lines when the monitor opens
  if (v === "cfg" && typeof loadOptaConfig === "function") loadOptaConfig();   // refresh the locked fields from the Opta's flash
  if (v === "cfg" && typeof stLoad === "function") stLoad();
  if (v === "cfg" && typeof wsHere === "function") wsHere();
  if (v === "live" && typeof byAddresses === "function") byAddresses();
  if (v === "cfg" && typeof licLoad === "function") licLoad();
  if (v === "fleet" && typeof flLoad === "function") flLoad();
  if (v === "proto") { if (typeof prSyncOwner === "function") prSyncOwner();
                       if (typeof prRender === "function") prRender();
                       if (typeof prRuns === "function") prRuns();
                       if (typeof prResume === "function") prResume(); }
}

// fill a home-tile live readout safely (device values are untrusted -> textContent).
// pairs: [[key,val],...]; a single [null, msg] renders one muted message line.
function homeLive(sel, pairs) {
  const el = $(sel); if (!el) return;
  el.textContent = "";
  for (const [k, v] of pairs) {
    if (k === null) {
      const m = document.createElement("span"); m.className = "m"; m.textContent = v; el.appendChild(m);
    } else {
      const ks = document.createElement("span"); ks.className = "k"; ks.textContent = k;
      const vs = document.createElement("span"); vs.textContent = (v === undefined || v === null || v === "") ? "--" : v;
      el.appendChild(ks); el.appendChild(vs);
    }
  }
}

/* ---------- connection mode ---------- */
$$("#modeSeg button").forEach(b => b.onclick = () => {
  $$("#modeSeg button").forEach(x => x.classList.remove("active"));
  b.classList.add("active"); mode = b.dataset.mode;
  $("#serialCtrls").style.display = mode === "serial" ? "flex" : "none";
  $("#tcpCtrls").style.display = mode === "tcp" ? "flex" : "none";
});

async function scanPorts() {
  try {
    const ps = await (await fetch("/api/ports")).json();
    for (const sel of [$("#portSel"), $("#fw-port"), $("#tc-serial"), $("#dispfw-port"), $("#lw-scan-port")]) {
      if (!sel) continue;
      sel.innerHTML = "";
      if (!ps.length) sel.innerHTML = "<option value=''>no ports found</option>";
      ps.forEach(p => {
        const o = document.createElement("option");
        o.value = p.device;
        o.textContent = p.device + (p.desc ? "  (" + p.desc + ")" : "") + (p.opta ? "  [controller]" : "");
        if (p.opta) o.selected = true;
        sel.appendChild(o);
      });
    }
  } catch (e) { banner("Cannot list serial ports: " + e); }
  // FIX 2026-07-20: re-arm the display local-flash button. Setting option.selected programmatically
  // fires NO 'change' event, so dispfwArm() (which enables #dispfw-flash-local once a port is picked)
  // never ran after the startup/rescan auto-select - leaving "Flash my compiled build" stuck disabled
  // on a fresh launch. Call it explicitly now that the port <select>s are repopulated.
  if (typeof dispfwArm === "function") dispfwArm();
}
$("#rescan").onclick = scanPorts;

/* ---------- connect / disconnect ---------- */
$("#connectBtn").onclick = async () => {
  if (connected) {
    // Set intentionalDisconnect only AFTER the request succeeds. Setting it first meant a failed
    // POST (backend hung) left the link up but permanently suppressed the later genuine "link LOST"
    // alarm, since the flag is only cleared on a fresh successful connect. Also guard the await.
    try {
      const r = await fetch("/api/disconnect", {method:"POST"});
      if (r.ok) intentionalDisconnect = true;
      else banner("Disconnect request was refused by the app.");
    } catch (e) { banner("Disconnect failed: " + e + " - the link may still be up."); }
    return;
  }
  const body = mode === "tcp"
    ? {mode:"tcp", host:$("#host").value.trim(), port:+$("#tcpport").value}
    : {mode:"serial", port:$("#portSel").value, baud:9600};   // whole station is 9600 8N1 (backend enforces)
  if (mode === "serial" && !body.port) return banner("Pick a serial port first.");
  if (mode === "tcp" && !body.host) return banner("Enter the controller IP.");
  const btn = $("#connectBtn"); btn.disabled = true; btn.textContent = "Connecting...";
  try {
    const r = await (await fetch("/api/connect", {method:"POST",
      headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)})).json();
    if (!r.ok) banner("Connect failed: " + r.error);
  } catch (e) { banner("Connect failed: " + e); }
  finally { btn.disabled = false; if (!connected) btn.textContent = "Connect"; }
};

/* ---------- auto-reconnect diagnostics ----------
   The backend tracks two things the operator otherwise cannot see: a persistently failing
   auto-reconnect tick, and "more than one device matches this role" (two Tip Chargers plugged in,
   so the app will not guess which to attach to). Both were only exposed on /api/autoconnect, which
   nothing ever called - so either one just looked like "it will not connect". They now ride along
   on the /api/state poll. Reported only when the message CHANGES, because that poll runs every
   1.5 s and a banner re-armed continuously would never auto-dismiss and would stomp on other
   messages. Clearing back to null re-arms it, so a fault that recurs is announced again. */
let _lastAutoMsg = null;
function reportAutoconnect(s) {
  if (!s) return;
  let msg = null;
  if (s.ambiguous && s.ambiguous.length > 1) {
    msg = "More than one device matches: " + s.ambiguous.join(", ") +
          ". Pick the right port instead of letting the app choose.";
  } else if (s.autoconnectError) {
    msg = "Auto-reconnect is failing: " + s.autoconnectError;
  }
  if (msg !== _lastAutoMsg) {
    if (msg) banner(msg);
    _lastAutoMsg = msg;
  }
}

/* ---------- live status poll ---------- */
let intentionalDisconnect = false;
let lastState = null;   // most recent /api/state payload, so guards (e.g. "don't flash mid-cycle") can read STATE without a fresh fetch
async function pollState() {
  try {
    const s = await (await fetch("/api/state")).json();
    lastState = s;
    reportAutoconnect(s);
    setConnected(s.connected, s.info, s.mode, s.live);
    if (s.connected && s.live && s.status) renderStatus(s.status);
    else if (!s.connected || !s.live) resetStatus();   // don't leave frozen values
  } catch (e) {
    lastState = null;
    setConnected(false, "", null, false, true);        // backend/app itself not responding
    resetStatus();
  }
}
setInterval(pollState, 1500); pollState();

// Reflect the ACTUAL connection mode (serial vs tcp) in a segmented toggle + its controls,
// so an auto-detected USB serial link shows "USB Serial" (not the manually-picked Ethernet).
function reflectMode(segSel, serialSel, tcpSel, m) {
  if (m !== "serial" && m !== "tcp") return null;
  // Do NOT yank the toggle back to the live link's mode while the operator is mid-edit in this panel.
  // The 1.5 s poll would otherwise flip "Ethernet" back to "serial" and hide the half-typed IP field
  // the moment they clicked into it. If focus is inside this transport panel, leave it alone.
  var ae = document.activeElement;
  var host = $(serialSel), tcp = $(tcpSel), segEl = $(segSel);
  if (ae && ((host && host.contains(ae)) || (tcp && tcp.contains(ae)) || (segEl && segEl.contains(ae)))) return null;
  $$(segSel + " button").forEach(function (x) { x.classList.toggle("active", x.dataset.mode === m); });
  var sc = $(serialSel), tp = $(tcpSel);
  if (sc) sc.style.display = m === "serial" ? "flex" : "none";
  if (tp) tp.style.display = m === "tcp" ? "flex" : "none";
  return m;
}
// c=connected, live=receiving data, backendDown=the app itself isn't answering
let autoOpenedOnConnect = false;   // one-shot per app session: jump to the plasma overview when the Opta first connects
// Every nav item names itself on hover, so the folded (icons-only) sidebar is still readable.
document.querySelectorAll(".navitem").forEach(function (n) { if (!n.title) n.title = n.textContent.trim(); });

function setConnected(c, info, m, live, backendDown) {
  const wasConnected = connected;
  connected = c;
  if (c) mode = reflectMode("#modeSeg", "#serialCtrls", "#tcpCtrls", m) || mode;   // toggle follows the live link
  const dot = $("#connDot"), txt = $("#connText"), li = $("#linkInfo");
  dot.classList.toggle("on", c && live);
  dot.classList.toggle("warn", (c && !live) || backendDown);
  if (backendDown)      txt.textContent = "App not responding";
  else if (c && !live)  txt.textContent = "Connected - no data";
  else                  txt.textContent = c ? "Connected" : "Disconnected";
  const _cb = $("#connectBtn"); if (_cb && !_cb.disabled) _cb.textContent = c ? "Disconnect" : "Connect";   // don't overwrite "Connecting..." mid-connect (this poll runs every 1.5s)
  li.querySelector("span:last-child").textContent = c ? info : "no link";
  // on a narrow bar only the dot shows, so the words are on hover
  const pill = dot.closest(".conn-pill"); if (pill) pill.title = txt.textContent + (c && info ? " - " + info : "");
  setPill("#home-plasma-st", c && live, c ? (live ? "online" : "no data") : "offline");
  topoSet("opta", c && live, c ? (info || "linked") : "not connected");
  if (!(c && live)) topoSet("servo", false, "A6-RS");
  tcSerial2Up = tcLegEval(c && live, tcLastTip);   // decays on its own when traffic stops
  if (!(c && live))   // renderStatus fills the tile when live; otherwise show why not
    homeLive("#home-plasma-live", [[null, backendDown ? "App not responding" : (c ? "Connected - no data" : "Not connected")]]);
  // alert once on an UNexpected drop (was connected, now gone, and user didn't click Disconnect)
  if (wasConnected && !c && !intentionalDisconnect) banner("Controller link LOST - the Plasma Station connection dropped.");
  if (c) intentionalDisconnect = false;
  // Auto-open the plasma overview the first time the Opta connects this session (then leave navigation to the user).
  if (!wasConnected && c && !autoOpenedOnConnect && currentView === "home") {
    autoOpenedOnConnect = true;   // only from the landing view: never yank the operator off a tab they navigated to (or close a live tc/pt stream)
    if (typeof showView === "function") { showView("dash"); syncStreams("dash"); }
  }
  if (!wasConnected && c) setTimeout(function(){ if (typeof loadOptaConfig === "function") loadOptaConfig(); }, 800);   // pull the Opta's stored positions/plasma-time/LEM into the locked config fields
}
// blank the readouts + chamber so stale values never look live
function resetStatus() {
  for (const id of ["#st-state","#st-servo","#st-temp","#st-pos","#st-disp","#st-volts","#st-amps","#st-watts"]) {
    const el = $(id); if (el) el.textContent = "--";
  }
  const h = $("#health");
  if (h) {
    h.textContent = "";
    const m = document.createElement("span");
    m.className = "hint";
    m.textContent = "Servo, display and state appear here once the controller links.";
    h.appendChild(m);
  }
  if (!demoActive) renderSchematic({});
}
// small helper for the home unit status chips + Bioyond chips
function setPill(sel, ok, label) {
  const el = $(sel); if (!el) return;
  el.className = "pill " + (ok ? "ok" : "");
  const t = el.querySelector("span:last-child"); if (t) t.textContent = label;
}
// ---- Tip Charger <-> Plasma StandAlone, live ------------------------------------
// The controller already logs every Serial2 frame to its console as [TIP TX] / [TIP RX], and
// those lines arrive on the same stream the Serial Monitor shows. So this is the real exchange
// as it happens, not a status summary - and a received frame is itself proof the Tip Charger is
// there, which works on the firmware already in the field rather than waiting for a reflash.
let tcLastRx = 0, tcLastTip, tcSerial2Up = false;
const TC_WIRE_ALIVE_MS = 30000;

// A link that is merely green says something is plugged in. A link that PULSES as each exchange
// lands says it is talking. Every link on the map does this now, driven by that device's own data
// arriving - the Opta's status line, the Tip Charger's CSV, the Puretip poll, the robot's reply.
function topoFlash(key) {
  const l = document.getElementById("tl-" + key);
  if (!l || !l.classList.contains("up")) return;   // nothing to show on a link that is not up
  l.classList.remove("wire");
  void l.offsetWidth;                       // restart the animation on a rapid second frame
  l.classList.add("wire");
  setTimeout(function () { l.classList.remove("wire"); }, 600);
}
function tcWireFlash(dir) {
  if (dir === "RX") { tcLastRx = Date.now(); tcWireSetLeg(true); }
  topoFlash("tcopta");
}
function tcWireSetLeg(up) { tcLegSet(up ? "up" : "down", up ? "linked" : "no reply"); }
// The Serial2 leg carries a state of its own, like every other link on the map, instead of being
// a decoration between two boxes. Three states, because there really are three: the Opta reports
// the Tip Charger up, it reports it down, or we cannot see the leg at all because the Opta itself
// is not connected. Re-evaluated on every poll so a link that stops talking goes red on its own.
let tcLegState = "";
function tcLegSet(state, title) {
  const l = document.getElementById("tl-tcopta");
  if (l) { l.classList.toggle("up",   state === "up");     // classList, not setAttribute: a
           l.classList.toggle("down", state === "down");   // rewrite here would drop the pulse
           l.setAttribute("title", "Ethernet over serial - " + title); }
  tcLegState = state;
}
// optaUp: is the Opta itself connected and sending. tip: "UP"/"DOWN"/undefined from its status line.
function tcLegEval(optaUp, tip) {
  const seen = tcLastRx && (Date.now() - tcLastRx) < TC_WIRE_ALIVE_MS;
  if (seen)              tcLegSet("up", "linked");          // a received frame outranks any flag
  else if (!optaUp)      tcLegSet("unknown", "no route");   // cannot see the leg from here at all
  else if (tip === "UP")   tcLegSet("up", "linked");
  else if (tip === "DOWN") tcLegSet("down", "no reply");
  else                   tcLegSet("unknown", "no traffic"); // older controller: it does not report
  return tcLegState === "up";
}
function tcWireFeed(line) {
  const m = /\[TIP (TX|RX)\]\s*(.*)$/.exec(line);
  if (!m) return;
  const msg = (m[2] || "").trim();
  if (!msg) return;
  tcWireFlash(m[1]);      // the link itself pulses; the bytes belong in the Serial Monitor
}
// A frame seen recently outranks the reported flag: traffic is direct evidence. Expire it so a
// Tip Charger unplugged mid-session does not stay green on the strength of an old frame.
setInterval(function () {
  if (tcLastRx && Date.now() - tcLastRx > TC_WIRE_ALIVE_MS) { tcLastRx = 0; tcWireSetLeg(false); }
}, 5000);

// ---- communication map (Home) -------------------------------------------------
// Driven by the SAME polls that fill the status pills, so the picture can never
// disagree with them. `up` paints the box and its link green and starts the dash
// travelling; anything else is red and still.
function topoSet(key, up, sub) {
  const n = document.getElementById("tn-" + key), l = document.getElementById("tl-" + key);
  if (n) { n.classList.toggle("up", !!up); n.classList.toggle("down", !up); }
  if (l) { l.classList.toggle("up", !!up); l.classList.toggle("down", !up); }
  const t = document.getElementById("tn-" + key + "-sub");
  if (t && sub !== undefined) t.textContent = sub;
  topoTally();
}
// Running count on the chassis, so the operator gets the answer to "is anything talking?"
// without reading five boxes. Counts the device links only - the PC itself is not a link.
function topoTally() {
  const keys = ["opta", "disp", "pt", "by", "servo"];   // tcopta is a leg between two of these, not a sixth device
  const up = keys.filter(k => { const n = document.getElementById("tn-" + k); return n && n.classList.contains("up"); }).length;
  const c = document.getElementById("tn-pc-count"); if (c) c.textContent = up + " / " + keys.length;
  for (const id of ["tl-trunk", "tl-bus"]) { const l = document.getElementById(id); if (l) l.classList.toggle("up", up > 0); }   // the PC's own trunk lights once anything talks
  const n = document.getElementById("tn-pc-note");
  if (n) n.textContent = up === 0 ? "nothing connected yet" : (up === keys.length ? "whole stack online" : "partly connected");
}
// Bioyond + the update channel have no other home-tile poll, so give them a light one
// that runs ONLY while Home is on screen.
async function topoPollExtras() {
  if (currentView !== "home") return;
  try {
    const s = await (await fetch("/api/by/state")).json();
    topoSet("by", !!s.connected, s.connected ? (s.ip || "Rob INTF") : "Rob INTF");
    if (s.connected) topoFlash("by");
  } catch (e) { topoSet("by", false, "Rob INTF"); }
}
// Clicking a node opens the tab that owns that device.
function topoBindNav() {
  document.querySelectorAll(".topo .tnode[data-goto]").forEach(function (n) {
    const go = function () {
      const v = n.getAttribute("data-goto");
      if (v && typeof showView === "function") { showView(v); syncStreams(v); }
    };
    n.addEventListener("click", go);
    n.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " " || e.key === "Spacebar") { e.preventDefault(); go(); }
    });
  });
}
topoBindNav();
setInterval(topoPollExtras, 15000);
setTimeout(topoPollExtras, 900);

function setStatePill(sel, ok, label, keepClass) {
  const el = $(sel); if (!el) return;
  el.className = (keepClass || "pill") + " " + (ok ? "ok" : "");
  const t = el.querySelector("span:last-child"); if (t) t.textContent = label;
}

function renderStatus(d) {
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  if (d.STATE) set("#st-state", d.STATE);
  if (d.SERVO) set("#st-servo", d.SERVO);
  topoSet("servo", d.SERVO === "READY", d.SERVO ? String(d.SERVO).toLowerCase() : "A6-RS");
  // The Tip Charger often reaches us THROUGH the Opta rather than its own USB link, so show that
  // leg too. Older Opta firmware does not send TIP=; absent is "not reported", never "down".
  topoFlash("opta");                       // a status line just arrived from the controller
  if (d.SERVO) topoFlash("servo");         // and it carried the servo's answer with it
  if (d.TIP !== undefined) tcLastTip = d.TIP;
  tcSerial2Up = tcLegEval(true, tcLastTip);             // renderStatus only runs when the Opta is live
  if (d.TEMP_F) set("#st-temp", d.TEMP_F + " °F");
  if (d.DISP)  set("#st-disp", d.DISP);
  if (d.POS !== undefined) set("#st-pos", d.POS);
  if (d.VOLTS !== undefined) set("#st-volts", d.VOLTS + " V");
  if (d.AMPS  !== undefined) set("#st-amps",  d.AMPS  + " A");
  if (d.WATTS !== undefined) set("#st-watts", d.WATTS + " W");
  homeLive("#home-plasma-live", [   // live snapshot on the Home tile
    ["State", d.STATE || "--"],
    ["Temp",  d.TEMP_F ? d.TEMP_F + " °F" : "--"],
    ["Power", d.WATTS !== undefined ? d.WATTS + " W" : "--"],
  ]);
  if (!demoActive) renderSchematic(d);   // don't fight the animation preview
  // health pills - built with DOM APIs + textContent so device serial values
  // (untrusted, from the RS232/Waveshare chain) can never inject HTML.
  const h = $("#health"); if (!h) return;
  const pills = [
    [d.SERVO === "READY" ? "ok" : (d.SERVO ? "bad" : "warn"), "Servo " + (d.SERVO||"?")],
    [d.DISP === "UP" ? "ok" : "bad", "Display " + (d.DISP||"?")],
    [d.STATE === "FAULT" ? "bad" : "ok", "State " + (d.STATE || "?")],
  ];
  h.textContent = "";
  for (const [cls, label] of pills) {
    const span = document.createElement("span");
    span.className = "pill " + cls;               // cls is from fixed comparisons, safe
    const dot = document.createElement("span"); dot.className = "d";
    span.appendChild(dot);
    span.appendChild(document.createTextNode(label));   // label via textNode = escaped
    h.appendChild(span);
  }
}

/* ---------- live chamber schematic ----------
   The plasma knife is FIXED at its position; the microplate INDEXES under it - the plate
   slides so the knife sweeps its rows (row 1 -> last row of the plate). Plasma sprays ONLY
   while the plate is under the knife. The actuator is a press that comes down to close; the
   EXHAUST clears the plasma air and runs when plasma is off. Fixed visual anchors (not the
   raw pulse scale) keep the layout readable; POS maps to the plate's leading edge. */
const SCH = { HOME: 83, DOOR: 175, KNIFE: 345, LASTROW: 465, EXHAUST: 575, PLATEW: 120 };
function num(sel, dflt) { const v = parseFloat(($(sel) || {}).value); return isFinite(v) ? v : dflt; }
function schSetX(id, x) { const e = document.getElementById(id); if (e) e.setAttribute("transform", "translate(" + x.toFixed(1) + ",0)"); }
function schSetTxt(id, v) { const e = document.getElementById(id); if (e) e.textContent = v; }
// piecewise-linear map POS -> screen X through the anchor breakpoints
function schInterp(pos, bps) {
  if (!isFinite(pos) || pos <= bps[0][0]) return bps[0][1];
  for (let i = 1; i < bps.length; i++) {
    if (pos <= bps[i][0]) {
      const p0 = bps[i-1][0], x0 = bps[i-1][1], p1 = bps[i][0], x1 = bps[i][1];
      const f = (p1 === p0) ? 0 : (pos - p0) / (p1 - p0);
      return x0 + (x1 - x0) * f;
    }
  }
  return bps[bps.length - 1][1];
}
function renderSchematic(d) {
  const g = document.getElementById("sch-carriage"); if (!g) return;
  const posLast = Math.max(1, num("#c-last", 8800));
  const posStart = num("#c-pos1", 2800);
  const posDoor  = num("#c-door", 800);
  let pos = parseFloat(d.POS); if (!isFinite(pos)) pos = 0; pos = Math.max(0, Math.min(posLast, pos));
  // plate leading edge (row 1) maps home -> door -> knife -> (knife+plateW = last row at knife)
  const HOME_LEAD = SCH.DOOR - 32;   // plate parks behind the door, clear of it (no collision)
  const leadX = schInterp(pos, [[0, HOME_LEAD], [posDoor, SCH.DOOR], [posStart, SCH.KNIFE], [posLast, SCH.LASTROW]]);
  const plateCX = leadX - SCH.PLATEW / 2;
  g.style.transition = demoActive ? "none" : "transform .7s ease";   // demo drives frames; live glides
  g.setAttribute("transform", "translate(" + plateCX.toFixed(1) + ",0)");

  const running = d.STATE === "RUNNING";
  let plasma;
  if (d.PLASMA !== undefined) plasma = (d.PLASMA === "1" || /on|true/i.test(String(d.PLASMA)));
  else plasma = running && pos >= posStart;
  // spray ONLY on the microplate: plasma AND the knife is over the plate (pos in [start,last])
  const spraying = plasma && pos >= posStart - 1 && pos <= posLast + 1;
  let actClosed;
  if (d.ACT !== undefined) actClosed = (d.ACT === "1" || /closed|true/i.test(String(d.ACT)));
  else actClosed = running;
  let exhaustOn;
  if (d.FAN !== undefined) exhaustOn = (d.FAN === "1" || /on|true/i.test(String(d.FAN)));
  else exhaustOn = !plasma;          // exhaust clears the air when plasma is off
  const spray = document.getElementById("sch-spray"); if (spray) spray.classList.toggle("on", !!spraying);
  const fan = document.getElementById("sch-fan");      if (fan) fan.classList.toggle("on", !!exhaustOn);
  const act = document.getElementById("sch-actuator");
  if (act) { act.classList.toggle("closed", !!actClosed); act.classList.toggle("open", !actClosed); }

  // fixed elements + markers, built once (fixed visual anchors)
  const mk = document.getElementById("sch-markers");
  if (mk && !mk.dataset.built) {
    mk.dataset.built = "1";
    schSetX("sch-actuator", SCH.DOOR);
    schSetX("sch-knife",    SCH.KNIFE);
    schSetX("sch-fan",      SCH.EXHAUST);
    const marks = [[SCH.HOME,"Home"],[SCH.DOOR,"Door"],[SCH.KNIFE,"Plasma knife position"],[SCH.LASTROW,"Last row"]];
    mk.textContent = "";
    const ns = "http://www.w3.org/2000/svg";
    for (const [mx, label] of marks) {
      const tick = document.createElementNS(ns, "line");
      tick.setAttribute("x1", mx); tick.setAttribute("y1", 138);
      tick.setAttribute("x2", mx); tick.setAttribute("y2", 148);
      tick.setAttribute("class", "sch-static");
      const t = document.createElementNS(ns, "text");
      t.setAttribute("x", mx); t.setAttribute("y", 162);
      t.setAttribute("text-anchor", "middle"); t.setAttribute("class", "sch-txt");
      t.textContent = label;
      mk.appendChild(tick); mk.appendChild(t);
    }
  }
  // Mark values the device did NOT actually report as inferred (trailing "?"), so an inferred state is
  // never presented as a measured one. This matters for the exact failure seen on this hardware: the
  // display owns the plasma relay, so it can be latched ON while the Opta state machine is not RUNNING
  // - which would otherwise render as a confident "idle / off" while HV is live. Current firmware
  // reports PLASMA/ACT/FAN, so the "?" only appears with older firmware that omits them.
  var q = function (reported) { return reported === undefined ? "?" : ""; };
  schSetTxt("sch-posval", String(pos));
  schSetTxt("sch-state", d.STATE || "--");
  schSetTxt("sch-act", (actClosed ? "closed" : "open") + q(d.ACT));
  schSetTxt("sch-fanstate", (exhaustOn ? "on" : "off") + q(d.FAN));
  // The phase line follows PLASMA, not `spraying`. `spraying` is a drawing test - it asks
  // whether the knife is over the plate - so keying the words to it meant a latched arc with
  // the carriage parked outside the sweep window rendered as a confident "idle" while HV was
  // live. That is the precise failure the note above describes, so say ON whenever the relay
  // is reported on, and say plainly when it is on somewhere it should not be.
  const ph = document.getElementById("sch-phase");
  if (ph) {
    const phase = plasma ? (spraying ? "plasma on" : "PLASMA ON - off plate")
                         : (running ? "running" : "idle");
    ph.textContent = phase + q(d.PLASMA);
    ph.className = plasma ? "act" : "";
  }
}

/* ---------- Show animation: preview one full cycle (no hardware needed) ----------
   The real flow: the plate parks just behind a CLOSED door -> the door OPENS first ->
   the plate slides IN to the plasma-knife position -> the door SHUTS to seal -> plasma
   on -> knife..last SLOW, swiftly back, again -> plasma off -> back toward the door ->
   door OPENS -> plate slides OUT to its park -> door SHUTS (sealed at rest). A short hold
   (from==to) is a pause before each action. Live updates pause while it plays. */
function demoCycle() {
  if (demoActive) { return; }
  const posLast = Math.max(1, num("#c-last", 8800));
  const posStart = num("#c-pos1", 2800);
  const P = 600;  // pause before each action
  // each phase: ms, POS from->to, act (0 open / 1 closed), plasma (0/1), state
  // The door is OPEN whenever the plate is at/near the doorway (parked, entering, exiting)
  // and closes EXACTLY ONCE - only after the plate is fully inside the chamber - so it can
  // never crash the plate. It opens once before the plate comes back out.
  const segs = [
    { ms: 900,  from: 0,        to: 0,        act: 0, plasma: 0, state: "IDLE"    },  // rest: door OPEN, plate parked outside
    { ms: P,    from: 0,        to: 0,        act: 0, plasma: 0, state: "RUNNING" },  // pause (cycle begins)
    { ms: 2400, from: 0,        to: posStart, act: 0, plasma: 0, state: "RUNNING" },  // plate slides IN through the open door
    { ms: P,    from: posStart, to: posStart, act: 0, plasma: 0, state: "RUNNING" },  // pause - plate now fully inside
    { ms: 800,  from: posStart, to: posStart, act: 1, plasma: 0, state: "RUNNING" },  // door CLOSES (only now - plate inside)
    { ms: P,    from: posStart, to: posStart, act: 1, plasma: 0, state: "RUNNING" },  // pause
    { ms: 800,  from: posStart, to: posStart, act: 1, plasma: 1, state: "RUNNING" },  // plasma strikes on row 1
    { ms: P,    from: posStart, to: posStart, act: 1, plasma: 1, state: "RUNNING" },  // pause
    { ms: 3400, from: posStart, to: posLast,  act: 1, plasma: 1, state: "RUNNING" },  // pass 1: row 1 -> last row, SLOW
    { ms: P,    from: posLast,  to: posLast,  act: 1, plasma: 1, state: "RUNNING" },  // pause
    { ms: 900,  from: posLast,  to: posStart, act: 1, plasma: 1, state: "RUNNING" },  // back to row 1, SWIFT
    { ms: P,    from: posStart, to: posStart, act: 1, plasma: 1, state: "RUNNING" },  // pause
    { ms: 3400, from: posStart, to: posLast,  act: 1, plasma: 1, state: "RUNNING" },  // pass 2: row 1 -> last row, SLOW
    { ms: 1000, from: posLast,  to: posLast,  act: 1, plasma: 0, state: "RUNNING" },  // plasma off, pause
    { ms: 900,  from: posLast,  to: posStart, act: 1, plasma: 0, state: "RUNNING" },  // back to row 1 (still sealed inside)
    { ms: P,    from: posStart, to: posStart, act: 1, plasma: 0, state: "RUNNING" },  // pause
    { ms: 800,  from: posStart, to: posStart, act: 0, plasma: 0, state: "RUNNING" },  // door OPENS (plate still inside)
    { ms: P,    from: posStart, to: posStart, act: 0, plasma: 0, state: "RUNNING" },  // pause
    { ms: 2400, from: posStart, to: 0,        act: 0, plasma: 0, state: "RUNNING" },  // plate slides OUT through the open door
    { ms: 700,  from: 0,        to: 0,        act: 0, plasma: 0, state: "IDLE"    },  // rest: door stays OPEN, plate parked
  ];
  demoActive = true;
  const btn = $("#demoBtn"); if (btn) { btn.textContent = "Playing..."; }
  let i = 0, segStart = performance.now();
  function frame(now) {
    if (!demoActive) return;
    if (i >= segs.length) { endDemo(); return; }
    const s = segs[i];
    let t = (now - segStart) / s.ms; if (t > 1) t = 1;
    const pos = Math.round(s.from + (s.to - s.from) * t);
    renderSchematic({ STATE: s.state, POS: String(pos), PLASMA: String(s.plasma), ACT: String(s.act) });
    if (t >= 1) { i++; segStart = now; }
    demoRAF = requestAnimationFrame(frame);
  }
  demoRAF = requestAnimationFrame(frame);
}
function endDemo() {
  demoActive = false;
  if (demoRAF) cancelAnimationFrame(demoRAF);
  const btn = $("#demoBtn"); if (btn) { btn.textContent = "Show animation"; }
}
if ($("#demoBtn")) $("#demoBtn").onclick = () => { if (demoActive) endDemo(); else demoCycle(); };

/* ---------- serial stream (SSE) ---------- */
function startStream() {
  if (es) es.close();
  es = new EventSource("/api/stream");
  es.onmessage = ev => {
    let it; try { it = JSON.parse(ev.data); } catch (e) { return; }   // guard bad frames
    if (it && typeof it.line === "string") addLine(it.line);
  };
  // EventSource auto-reconnects on transient drops; on a hard/failed state,
  // re-open after a short delay so the monitor recovers on its own.
  es.onerror = () => {
    if (es && es.readyState === EventSource.CLOSED) setTimeout(startStream, 2000);
  };
}
// Strip ANSI/VT100 terminal escape sequences. The Puretip One CLI (and any colorized device
// console) emits SGR color codes like ESC[38;5;248m / ESC[0m / ESC[1m and sometimes cursor/erase
// sequences; rendered as plain textContent they show up as garbage boxes around the real data
// ("STATION STATUS" etc). Remove the full CSI form (ESC[ ... final-letter), a bare CSI (0x9b),
// and any stray lone ESC, so the console shows just the text the device meant to print.
function stripAnsi(s) {
  return String(s)
    .replace(/[]\[[0-9;?=]*[ -\/]*[@-~]/g, "")  // CSI: SGR colors, cursor moves, erase (ESC[ ... final)
    .replace(/[@-Z\-_]/g, "")                        // other 2-byte escape sequences (ESC + one char)
    .replace(/[]/g, "");                          // any orphan ESC / CSI byte left over
}
function addLine(line) {
  line = stripAnsi(line);
  parseCfgLine(line);   // capture the Opta's 'show'/'lemraw' values into the (locked) config fields
  tcWireFeed(line);     // and surface the Tip Charger exchange on the Home map
  const c = $("#console"); if (!c) return;
  const atBottom = c.scrollHeight - c.scrollTop - c.clientHeight < 40;
  const div = document.createElement("div");
  let cls = "";
  if (line.startsWith(">")) cls = "tx";
  else if (/\[ERROR\]|\bERR!|^ERR\b|^E[A-Z_]{2,}/.test(line)) { cls = "err"; maybeBanner(line); }
  else if (/\bFAULT\b|\bWARN\b|NO REPLY|\bFAILED\b/.test(line)) cls = "warn";
  else if (line.startsWith("[app]")) cls = "app";
  div.className = cls; div.textContent = line;
  c.appendChild(div);
  while (c.childElementCount > 4000) c.removeChild(c.firstChild);
  if (atBottom) c.scrollTop = c.scrollHeight;
  servoDiagCapture(line);   // mirror into the RS485 diagnostics box while a diagnostic is running
}

/* ---------- Servo RS485 diagnostics ----------
   The servo drive is wired straight to the Opta's native RS485 port, so there is no bridge to
   configure - what the operator actually needs is a way to prove the drive is answering. These
   buttons run the Opta's OWN built-in diagnostics (probe / servostat / selftest) and mirror the
   reply here, so you don't have to hunt for it in the scrolling console. */
let _diagUntil = 0;                 // capture window: console lines up to this time go to the box too
function servoDiagCapture(line) {
  if (Date.now() > _diagUntil) return;
  const o = $("#servo-diag-out"); if (!o) return;
  if (line.startsWith("[app]")) return;              // app chatter isn't part of the drive's answer
  o.textContent += line + "\n";
  o.scrollTop = o.scrollHeight;
}
function servoDiag(cmd) {
  const o = $("#servo-diag-out");
  const label = cmd === "probe" ? "full RS485 probe" : (cmd === "servostat" ? "quick drive status" : "self-test");
  if (o) { o.textContent = "Running " + label + " (" + cmd + ")...\n"; o.scrollTop = 0; }
  // selftest is the slowest (it re-scans servo bauds), so give it a longer capture window.
  _diagUntil = Date.now() + (cmd === "selftest" ? 12000 : 5000);
  send(cmd);
}
window.servoDiag = servoDiag;
startStream();

/* ---------- error banner ---------- */
let lastBannerAt = 0, _bannerTimer = null, _faultTimer = null;
function maybeBanner(line) {
  const now = Date.now();
  // strip a whole error-prefix token only (don't nibble letters off real words)
  const msg = line.replace(/^(\[ERROR\]|ERROR|ERR!?|E)[:\s-]+/i, "").trim() || line.trim();
  $("#lastfault").textContent = "Last fault: " + msg;
  clearTimeout(_faultTimer);   // old faults clear themselves so stale errors don't linger
  _faultTimer = setTimeout(() => { const f = $("#lastfault"); if (f) f.textContent = ""; }, 30000);
  if (now - lastBannerAt > 1500) { banner(msg); lastBannerAt = now; }
}
function banner(msg) {   // ERROR banner (red)
  var lbl = $("#bannerLabel"); if (lbl) lbl.textContent = "Error";
  $("#banner").classList.remove("success"); $("#banner").classList.remove("info");
  $("#bannerMsg").textContent = " " + msg; $("#banner").classList.add("show");
  clearTimeout(_bannerTimer); _bannerTimer = setTimeout(hideBanner, 12000);   // auto-dismiss old errors
}
function info(msg) {   // INFORMATIONAL banner (calm blue) - neutral news like "an update is available", never alarming
  var lbl = $("#bannerLabel"); if (lbl) lbl.textContent = "Update";
  var b = $("#banner"); b.classList.remove("success"); b.classList.add("info");
  $("#bannerMsg").textContent = " " + msg; b.classList.add("show");
  clearTimeout(_bannerTimer); _bannerTimer = setTimeout(hideBanner, 12000);
}
function ok(msg) {   // SUCCESS/info banner (green) - use for confirmations so "it worked" never shows as an error
  var lbl = $("#bannerLabel"); if (lbl) lbl.textContent = "OK";
  $("#banner").classList.remove("info");
  $("#banner").classList.add("success");
  $("#bannerMsg").textContent = " " + msg; $("#banner").classList.add("show");
  clearTimeout(_bannerTimer); _bannerTimer = setTimeout(hideBanner, 5000);
}
function hideBanner() { clearTimeout(_bannerTimer); $("#banner").classList.remove("show"); }

/* ---------- commands ---------- */
async function send(cmd) {
  // Do NOT gate on the local 'connected' flag - it can lag the backend's auto-connect,
  // which silently swallowed button presses. Post and let the backend be the source of truth.
  try {
    const r = await (await fetch("/api/send", {method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({cmd})})).json();
    if (!r.ok) banner("Command not sent (" + (r.error || "controller not linked") + ").");
  } catch (e) { banner("Send failed: " + e); }
}
window.send = send;   // expose right away so inline/attribute handlers resolve it even if a later line throws
$("#sendBtn").onclick = () => { const v = $("#cmd").value.trim(); if (v){ send(v); $("#cmd").value=""; } };
$("#cmd").addEventListener("keydown", e => { if (e.key === "Enter") $("#sendBtn").click(); });
$("#clearBtn").onclick = () => $("#console").innerHTML = "";
$$("#quick button").forEach(b => b.onclick = () => send(b.dataset.c));
// JS-wire every Opta command button (data-cmd) - the same reliable pattern the quick buttons use,
// so control never depends on inline onclick or the connected flag.
$$("button[data-cmd]").forEach(b => b.onclick = () => send(b.dataset.cmd));
// Manual plasma request goes to the DISPLAY as A! (fire) / B! (stop) - the display owns the plasma
// relay (PA11); its own safety-loop gate still applies before it energizes HV.
function plasmaReq(on) {
  // Striking the arc is a single-click action next to "Plasma Off"; require an explicit confirm for
  // the ON direction so a misclick can't energize HV. OFF is never gated (it must always be instant).
  if (on && !confirm("Fire plasma now? This strikes the high-voltage arc. Bench testing only - make sure the chamber is set up correctly.")) return;
  fetch("/api/tc/plasma", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: !!on }) })
    .then(r => r.json()).then(function (r) { if (!r.ok) banner("Plasma " + (on ? "on" : "off") + " not sent: " + (r.error || "display not linked")); else ok(on ? "Plasma ON (A! sent to display)" : "Plasma OFF (B! sent to display)"); })
    .catch(function (e) { banner("Plasma request failed: " + e); });
}
// Abort stops EVERYTHING: the Opta cycle + the Tip Charger (the Opta relays PLASMA_STOP over
// Serial2), AND the display's plasma relay (B!).
function abortAll() { send("abort"); plasmaReq(false); }
window.plasmaReq = plasmaReq; window.abortAll = abortAll;

/* ---------- config ---------- */
function applyNetwork() {
  const wsip = $("#c-wsip").value.trim(), wsport = String($("#c-wsport").value).trim();
  const IPRE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const okIp = s => IPRE.test(s) && s.split(".").every(o => +o >= 0 && +o <= 255);
  const optaip = $("#c-optaip").value.trim();
  const okPort = s => { const n = +s; return s !== "" && Number.isInteger(n) && n >= 1 && n <= 65535; };
  if (!okIp(wsip)) return banner("Display bridge IP is not a valid address.");
  if (!okIp(optaip)) return banner("Controller IP is not a valid address.");   // was sent unvalidated, then persisted; a typo bricked the controller after reboot
  if (!okPort(wsport)) return banner("Display bridge port must be 1-65535.");
  // (Servo is direct native RS485 - no bridge/endpoint to configure.)
  send("setwsip " + wsip);
  setTimeout(() => send("setwsport " + wsport), 150);
  setTimeout(() => send("setoptaip " + optaip), 300);
  setTimeout(() => send("save"), 450);
  // Clear dirty on the applied fields so the read-back below can refresh them from what actually landed.
  ["#c-wsip","#c-wsport","#c-optaip"].forEach(function(id){ const e=$(id); if(e) e.dataset.dirty=""; });
  setTimeout(() => { loadOptaConfig(); send("servostat"); ok("Network settings applied and saved."); }, 700);   // read back what actually landed
}
function applyPositions() {
  // Validate BEFORE sending. These were raw .value strings: a cleared box sent "pos1 " (no argument),
  // and there was no ordering check, so door/row1/last could be saved out of order or with last<row1 -
  // the values that decide where the arc fires relative to the plate.
  const intOf = id => { const e = $(id); if (!e) return null;
                        const raw = String(e.value).trim(); if (!/^-?\d+$/.test(raw)) return null; return parseInt(raw, 10); };
  const door = intOf("#c-door"), pos1 = intOf("#c-pos1"), last = intOf("#c-last");
  if (door === null || pos1 === null || last === null)
    return banner("Positions must all be whole numbers (pulses). Fill every field before applying.");
  if (!(door >= 0 && door <= pos1 && pos1 <= last))
    return banner("Positions must be ordered: 0 <= door (" + door + ") <= row 1 (" + pos1 + ") <= last (" + last + ").");
  // Plasma time: the display firmware clamps to 5-30 s, the Opta to 1-120 s. Use the display's tighter
  // range so all three agree and the operator never sets a value the panel silently overrides.
  const secRaw = Math.round((+$("#c-time").value || 0) / 1000);
  if (!(secRaw >= 5 && secRaw <= 30))
    return banner("Plasma time must be 5-30 s (the display clamps to this range).");
  const ms = secRaw * 1000;
  send("posdoor " + door);
  setTimeout(() => send("pos1 " + pos1), 150);
  setTimeout(() => send("poslast " + last), 300);
  setTimeout(() => send("settime " + ms), 450);   // Opta persists it AND forwards it to the Tip Charger (firmware)
  setTimeout(() => send("save"), 600);
  // Plasma time is the shared operational value: push it to the 4D display too (W2<seconds>) so all three agree.
  const sec = secRaw;
  // Single-source the display plasma-time: mirror into the Tip Charger tab's field so a later
  // "Apply to display" from that tab (which always re-sends W2<value>) can't silently revert the
  // plasma station to that field's stale HTML default. Clear dirty flags so the next read-back syncs.
  const _sp = $("#set-plasmatime"); if (_sp) { _sp.value = sec; _sp.dataset.dirty = ""; }
  ["#c-door","#c-pos1","#c-last","#c-time"].forEach(function(id){ const e=$(id); if(e) e.dataset.dirty=""; });
  fetch("/api/tc/settings", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({plasmaTime: sec})})
    .then(r => r.json())
    .then(r => { if (r && r.ok) ok("Positions and plasma time applied and saved."); else banner("Positions saved on the controller, but the display plasma-time push was not accepted."); })
    .catch(() => banner("Positions saved on the controller, but the display plasma-time push failed (is the panel linked?)."));
}
function applyLem() {
  // Blank/garbage must NEVER become 0 here. '+"" || 0' turned a cleared box into setvscale 0, which
  // zeroes power sensing: Volts/Watts read 0, the Data Log records 0 W, and the power-based plasma
  // inference stops firing - so the station reports drawing nothing while the arc is live. Same
  // class as the settings-field bug; this path was missed when that one was fixed.
  const num = id => { const e = $(id); if (!e) return null;
                      const raw = String(e.value).trim(), v = Number(raw);
                      return (raw === "" || !isFinite(v)) ? null : v; };
  const fields = [["#c-vscale","setvscale"],["#c-voffset","setvoffset"],
                  ["#c-iscale","setiscale"],["#c-ioffset","setioffset"]];
  const bad = fields.filter(f => num(f[0]) === null).map(f => f[0].replace("#c-",""));
  if (bad.length) return banner("Not applied - these calibration fields are blank or invalid: " + bad.join(", "));
  fields.forEach(function (f, i) { setTimeout(() => send(f[1] + " " + num(f[0])), i * 150); });
  setTimeout(function () {
    fields.forEach(function (f) { const e = $(f[0]); if (e) e.dataset.dirty = ""; });
    ok("Power-sensing calibration applied.");
  }, fields.length * 150);
}

/* ---------- Bioyond integration endpoints ----------
   The customer's Bioyond equipment lives at site-specific addresses, so these are configurable and
   persisted server-side. Each row has a Test that actually opens the socket and speaks the real
   protocol (Rob INTF getSysState / Carousel Read System Status), because an address field with no
   proof of life is a trap: one wrong digit is indistinguishable from a wiring fault. */
const BIO_IDS = { robot:    ["#b-robotip",    "#b-robotport"],
                  carousel: ["#b-carouselip", "#b-carouselport"],
                  studio:   ["#b-studioip",   "#b-studioport"] };
function _bioRes(target, good, msg) {
  const e = $("#b-res-" + target); if (!e) return;
  e.textContent = msg || "";
  e.style.color = msg ? (good ? "var(--ok)" : "var(--bad)") : "";
}
async function bioLoad() {
  try {
    const r = await (await fetch("/api/bioyond/config")).json();
    if (!r || !r.ok || !r.cfg) return;
    Object.keys(BIO_IDS).forEach(function (k) {
      const c = r.cfg[k]; if (!c) return;
      const ip = $(BIO_IDS[k][0]), po = $(BIO_IDS[k][1]);
      if (ip && document.activeElement !== ip) ip.value = c.ip || "";
      if (po && document.activeElement !== po) po.value = c.port;
    });
  } catch (e) { /* app not up yet - the panel keeps its defaults */ }
}
function _bioBody() {
  const b = {};
  Object.keys(BIO_IDS).forEach(function (k) {
    const ip = $(BIO_IDS[k][0]), po = $(BIO_IDS[k][1]);
    b[k] = { ip: ip ? ip.value.trim() : "", port: po ? (+po.value || 0) : 0 };
  });
  return b;
}
// Refuse an address that is already one of OUR devices - same collision class as the two Waveshare
// bridges. Two devices answering on one address is a miserable fault to chase after the fact.
function _bioClash(ip) {
  if (!ip) return null;
  const mine = [["#c-optaip", "the controller"], ["#c-wsip", "the display bridge"]];
  for (let i = 0; i < mine.length; i++) {
    const e = $(mine[i][0]);
    if (e && e.value.trim() === ip) return mine[i][1];
  }
  return null;
}
async function bioSave() {
  const body = _bioBody();
  const keys = Object.keys(body);
  for (let i = 0; i < keys.length; i++) {
    const clash = _bioClash(body[keys[i]].ip);
    if (clash) return banner("That address is already " + clash + ". Give the Bioyond " + keys[i] + " its own address.");
  }
  try {
    const r = await (await fetch("/api/bioyond/config", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r.ok) { ok("Bioyond endpoints saved."); bioLoad(); }
    else banner("Not saved: " + (r.error || "unknown error"));
  } catch (e) { banner("Save failed: " + e); }
}
async function bioTest(target) {
  const b = _bioBody()[target] || {};
  _bioRes(target, true, "testing...");
  try {
    const r = await (await fetch("/api/bioyond/test", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: target, ip: b.ip, port: b.port }) })).json();
    _bioRes(target, r.ok, (r.ok ? "OK. " : "") + (r.message || r.error || "no answer")
                          + (r.ms != null && r.ok ? " (" + r.ms + " ms)" : ""));
  } catch (e) { _bioRes(target, false, "Test failed: " + e); }
}
async function netScan() {
  const e = $("#b-res-scan");
  if (e) { e.textContent = "scanning subnet, this takes a few seconds..."; e.style.color = ""; }
  try {
    // Let the operator name the subnet. Auto-detect uses THIS PC's own network, which is not the
    // lab network when the equipment sits behind a second Ethernet card (bench PC on 10.0.0.x while
    // the station is on 192.168.1.x - an auto sweep would then silently find nothing).
    const sn = $("#b-subnet"), snv = sn ? sn.value.trim() : "";
    const r = await (await fetch("/api/net/scan", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(snv ? { subnet: snv } : {}) })).json();
    if (!e) return;
    if (!r.ok) { e.textContent = r.error || "scan failed"; e.style.color = "var(--bad)"; return; }
    if (!r.found || !r.found.length) {
      e.textContent = "Nothing answered on " + r.subnet + ".x for ports " + (r.ports || []).join(", ") + ".";
      return;
    }
    e.textContent = "Found " + r.found.map(function (f) {
      return f.ip + ":" + f.port + (f.guess ? " (" + f.guess + ")" : "");
    }).join("    ");
  } catch (ex) { if (e) { e.textContent = "Scan failed: " + ex; e.style.color = "var(--bad)"; } }
}
window.bioSave = bioSave; window.bioTest = bioTest; window.netScan = netScan;
bioLoad();

/* ---------- Config lock (password 1536) + live-read of the Opta's stored values ---------- */
const CFG_PW = "1536";
const cfgLocked = { pos: true, lem: true };
function applyCfgLock() {
  ["#c-door","#c-pos1","#c-last"].forEach(id => { const e = $(id); if (e) e.disabled = cfgLocked.pos; });
  ["#c-vscale","#c-voffset","#c-iscale","#c-ioffset"].forEach(id => { const e = $(id); if (e) e.disabled = cfgLocked.lem; });
  describeLockedFields();
  const bp = $("#cfg-unlock-pos"); if (bp) bp.textContent = cfgLocked.pos ? "Locked – unlock to edit" : "Unlocked – click to lock";
  const bl = $("#cfg-unlock-lem"); if (bl) bl.textContent = cfgLocked.lem ? "Locked – unlock to edit" : "Unlocked – click to lock";
}
function cfgUnlock(group) {
  if (cfgLocked[group]) {
    const pw = prompt("Enter the 4-digit password to unlock these values:");
    if (pw === null) return;
    if (String(pw).trim() !== CFG_PW) { banner("Wrong password."); return; }
    cfgLocked[group] = false;
  } else { cfgLocked[group] = true; }   // click again to re-lock
  applyCfgLock();
}
// Read the ACTUAL stored values from the Opta flash so the locked fields always mirror reality
// (someone may have changed them from the console/display) - never trust the HTML defaults.
function loadOptaConfig() { if (connected) { send("show"); setTimeout(function(){ send("lemraw"); }, 200); } }
function _setIfIdle(id, v) { const e = $(id); if (e && document.activeElement !== e && e.dataset.dirty !== "1" && v != null && v !== "") e.value = v; }
function parseCfgLine(line) {
  let m = line.match(/posDoor=(\d+)\s+pos1=(\d+)\s+posLast=(\d+)/);
  if (m) { _setIfIdle("#c-door", m[1]); _setIfIdle("#c-pos1", m[2]); _setIfIdle("#c-last", m[3]); }
  m = line.match(/plasmaTimeMs=(\d+)/);           if (m) _setIfIdle("#c-time", m[1]);
  m = line.match(/vScale=([\-\d.]+)\s+vOffset=([\-\d.]+)\s+iScale=([\-\d.]+)\s+iOffset=([\-\d.]+)/);
  if (m) { _setIfIdle("#c-vscale", m[1]); _setIfIdle("#c-voffset", m[2]); _setIfIdle("#c-iscale", m[3]); _setIfIdle("#c-ioffset", m[4]); }
  // NETWORK read-back. These fields previously showed only the page's HTML defaults, so the panel
  // could claim 192.168.1.200 while the Opta's flash held something else entirely. Now BOTH Waveshare
  // bridges (and the Opta's own IP) mirror what is actually stored, same as the positions/LEM fields.
  m = line.match(/waveshareIP=(\d+\.\d+\.\d+\.\d+):(\d+)/);
  if (m) { _setIfIdle("#c-wsip", m[1]); _setIfIdle("#c-wsport", m[2]); }
  m = line.match(/optaIP=(\d+\.\d+\.\d+\.\d+)/);   if (m) _setIfIdle("#c-optaip", m[1]);
  // (servoBridge readback removed - the servo is direct native RS485, no bridge endpoint.)
}
applyCfgLock();
// Mark a config field "dirty" the moment the operator types into it, so a background read-back
// (loadOptaConfig re-sends `show`/`lemraw` on every Configuration re-entry) can't silently clobber
// an unsaved edit via _setIfIdle. The dirty flag is cleared when the value is Applied.
// Network + servo-transport fields need the dirty flag too. Without it, a background read-back
// (loadOptaConfig re-sends `show` on every Configuration re-entry and 1.15 s after any Apply) rewrote
// a field the operator had typed but not yet Applied - e.g. typing the display-bridge IP, clicking
// into the servo-IP box, and watching the first edit revert. Marking dirty on input, and honouring it
// in the read-back (_setIfIdle also skips the focused element), stops the clobber.
["#c-door","#c-pos1","#c-last","#c-vscale","#c-voffset","#c-iscale","#c-ioffset","#c-time",
 "#c-wsip","#c-wsport","#c-optaip"].forEach(function(id){
  const e = $(id); if (e) { const ev = (e.tagName === "SELECT") ? "change" : "input"; e.addEventListener(ev, function(){ e.dataset.dirty = "1"; }); }
});
// Display settings write ON DEMAND only: 'change' fires ONCE when the operator commits a value
// (releases the slider / blurs the field / presses Enter), NOT continuously while dragging. One
// single write per changed value - the app otherwise just LISTENS to the display, never streaming
// writes at it (that flooding is what jammed the panel).
[["pumpOn","#set-pumpon"],["pumpOff","#set-pumpoff"],["plasmaTime","#set-plasmatime"],
 ["coolTime","#set-cooltime"],["brightness","#set-bright"],["vacuum","#set-vac"]].forEach(function (f) {
  var key = f[0], e = $(f[1]);
  if (!e) return;
  e.addEventListener("input", function () { e.dataset.dirty = "1"; });   // guard against a CFG read-back clobbering an in-progress edit
  e.addEventListener("change", function () {
    e.dataset.dirty = "";                                                // committed -> clear so the next CFG snapshot can refresh it
    // NEVER push a blank/garbage field. Both '+"" || 0' and '+NaN || 0' collapse to 0, and 'change'
    // fires on blur - so clearing a box to retype it and then clicking away silently POSTed 0, the
    // server clamped that to its floor, and the display clamped again to ITS floor. Net effect: an
    // operator who merely CLEARED "Cooling time" reprogrammed the station to 5 s and persisted it to
    // display flash. Send only a real number; a blank box is left for the next CFG read-back to refill.
    var raw = String(e.value).trim();
    var n = Number(raw);
    if (raw === "" || !isFinite(n)) return;
    n = Math.round(n);
    // Enforce the field's OWN declared range here. HTML min/max are not applied to a scripted
    // .value read, so an out-of-range number was POSTed, silently clamped by the server and again
    // by the panel, and the box kept displaying a value the hardware never ran. Clamp visibly.
    var lo = (e.min !== "" && e.min != null) ? +e.min : null;
    var hi = (e.max !== "" && e.max != null) ? +e.max : null;
    if (lo !== null && n < lo) { n = lo; e.value = n; }
    if (hi !== null && n > hi) { n = hi; e.value = n; }
    // NEVER report success by silence. This is the primary editing path, and it used to be
    // fire-and-forget: no link check, no response check, and a .catch that swallowed failures. With
    // the panel unplugged the operator could retype cooling time, watch the field hold the new
    // number, and have nothing whatsoever reach the hardware - which is exactly what "I set it but
    // it did not change" looks like from the bench.
    if (!tcConnected) { banner("Not sent: the display is not connected. Reconnect, then set it again."); return; }
    var body = {}; body[key] = n;
    fetch("/api/tc/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (res) { return res.json(); })
      .then(function (r) { if (!r || !r.ok) banner("Setting NOT applied: " + ((r && r.error) || "the display did not accept it")); })
      .catch(function (ex) { banner("Setting NOT applied: " + ex); });
  });
  e.addEventListener("blur", function () { e.dataset.dirty = ""; });      // FIX: clear dirty on leaving the field even if the value was typed-then-reverted (no 'change' fires) - otherwise dirty stuck '1' froze this field from every future CFG refresh for the session
});
window.cfgUnlock = cfgUnlock; window.loadOptaConfig = loadOptaConfig;

window.applyNetwork = applyNetwork; window.applyPositions = applyPositions; window.applyLem = applyLem;
window.send = send; window.hideBanner = hideBanner;

/* ---------- OTA flash ---------- */
function flashOpta() {
  const port = $("#fw-port").value;
  if (!port) return banner("Pick the controller port on the Firmware tab.");
  // Never reflash the master controller mid-cycle. The display firmware push already requires a
  // confirm; this one went straight to POST on a single click, so a misclick could reflash the Opta
  // with a plate in the chamber and the arc live. Refuse while RUNNING and confirm otherwise.
  const st = (lastState && lastState.status) || {};
  if (st.STATE === "RUNNING") return banner("A cleaning cycle is RUNNING - abort it before flashing the controller.");
  if (!confirm("Reflash the master controller now? The station will stop responding for ~30 s during the flash. Make sure no cycle is running and the chamber is clear.")) return;
  const log = $("#flashlog"); log.textContent = "";
  $("#flashBtn").disabled = true;
  // stream the flash progress via fetch (EventSource can't POST)
  fetch("/api/flash", {method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({port})}).then(async resp => {
    const rd = resp.body.getReader(); const dec = new TextDecoder(); let buf = "";
    while (true) {
      const {done, value} = await rd.read(); if (done) break;
      buf += dec.decode(value, {stream:true});
      let idx;
      while ((idx = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, idx); buf = buf.slice(idx + 2);
        const m = chunk.match(/data: (.*)/s);
        if (m) { try { log.textContent += JSON.parse(m[1]) + "\n"; } catch(e){}; log.scrollTop = log.scrollHeight; }
        if (/event: done/.test(chunk)) { $("#flashBtn").disabled = false; }
      }
    }
    $("#flashBtn").disabled = false;
  }).catch(e => { log.textContent += "\nERROR: " + e; $("#flashBtn").disabled = false; });
}
window.flashOpta = flashOpta;

/* ---------- 4D display firmware push (bundled ScriptC + a direct 4D USB programmer) ---------- */
let dispfwReady = false;
let dispfwUnsupported = "";   // set on a Mac: 4D's loader is Windows-only, so flashing is off there
function dispfwChannel() { const c = $("#dispfw-channel"); return c ? c.value : ""; }
function dispfwArm() {
  const port = $("#dispfw-port") && $("#dispfw-port").value;
  const ch = dispfwChannel();   // never flash without the operator naming the panel type
  const b = $("#dispfw-flash"); if (b) b.disabled = !!dispfwUnsupported || !(dispfwReady && port && ch);   // channel flash needs a checked manifest
  const bl = $("#dispfw-flash-local"); if (bl) bl.disabled = !!dispfwUnsupported || !(port && ch);           // local flash needs port + display type
  if (dispfwUnsupported) { for (const x of [b, bl]) if (x) x.title = dispfwUnsupported; }
}
// Controller (Opta) firmware: report the latest version on the OTA channel. The Update Firmware
// button always pulls + verifies the latest from the channel (bundled bin is the offline fallback),
// so this is informational - it does not gate the flash.
async function optaFwCheck() {
  const pill = $("#optafw-pill"), info = $("#optafw-info"), btn = $("#optafw-check");
  if (!pill) return;
  btn.disabled = true; btn.textContent = "Checking...";
  try {
    const r = await (await fetch("/api/opta/fw/check")).json();
    info.style.display = "block";
    if (!r.ok) {
      pill.className = "pill warn"; pill.querySelector("span:last-child").textContent = "channel unreachable";
      info.className = "warnbox";
      info.textContent = "Could not reach the controller firmware channel: " + (r.error || "")
        + (r.dfu ? "  The Update Firmware button will use the copy bundled with this app." : "  (The USB flasher is also not bundled in this build.)");
    } else {
      pill.className = "pill ok";
      pill.querySelector("span:last-child").textContent = "v" + r.version + " available";
      info.className = "okbox";
      info.textContent = (r.board || "Controller") + "   channel version: " + (r.version || "none") + ".  " + (r.notes || "");
    }
  } catch (e) { info.style.display = "block"; info.className = "warnbox"; info.textContent = "Check failed: " + e; }
  btn.disabled = false; btn.textContent = "Check for update";
}
window.optaFwCheck = optaFwCheck;
async function dispfwCheck() {
  const pill = $("#dispfw-pill"), info = $("#dispfw-info"), btn = $("#dispfw-check");
  const ch = dispfwChannel();
  if (!ch) { info.style.display = "block"; info.className = "warnbox"; info.textContent = "Choose this unit's display type first - a Universal Controller 4.1 (Tip Charger) and a Plasma StandAlone panel need different programs."; dispfwReady = false; dispfwArm(); return; }
  btn.disabled = true; btn.textContent = "Checking...";
  try {
    const r = await (await fetch("/api/display/fw/check?channel=" + encodeURIComponent(ch))).json();
    info.style.display = "block";
    dispfwUnsupported = (r && r.unsupported) || "";
    if (dispfwUnsupported) {
      // Mac: show what the channel has (Download code still works), and say plainly why the
      // flash buttons are off instead of a misleading "loader missing".
      pill.className = "pill warn"; pill.querySelector("span:last-child").textContent = "flash on Windows";
      info.className = "warnbox";
      info.textContent = (r.ok ? ("Display: " + (r.model || "-") + "   channel version: " + (r.version || "none") + ".  ") : "")
        + dispfwUnsupported;
      dispfwReady = false;
    } else if (!r.ok) {
      pill.className = "pill warn"; pill.querySelector("span:last-child").textContent = "channel unreachable";
      info.className = "warnbox";
      info.textContent = "Could not reach the display firmware channel: " + (r.error || "") + (r.loader ? "" : "  (The display loader is also not bundled in this build.)");
      dispfwReady = false;
    } else {
      const ok = !!(r.loader && r.version);
      pill.className = "pill " + (ok ? "ok" : "warn");
      pill.querySelector("span:last-child").textContent = ok ? ("v" + r.version + " available") : (r.loader ? "none published" : "loader missing");
      info.className = "okbox";
      info.textContent = (r.label ? r.label + " - " : "") + "Display: " + (r.model || "-") + "   channel version: " + (r.version || "none")
        + "   " + (r.graphics ? "includes graphics" : "logic-only (.4XE)") + "   download baud " + (r.baud || 9600) + ".  "
        + (r.notes || "") + (r.loader ? "" : "  WARNING: display loader not bundled - cannot flash from this build.");
      dispfwReady = ok;
    }
  } catch (e) { info.style.display = "block"; info.className = "warnbox"; info.textContent = "Check failed: " + e; dispfwReady = false; }
  btn.disabled = false; btn.textContent = "Check for update"; dispfwArm();
}
async function dispfwStreamFlash(endpoint, btn) {
  const port = $("#dispfw-port").value;
  if (!port) return banner("Pick the USB programmer's COM port first.");
  const chSel = $("#dispfw-channel"), channel = dispfwChannel();
  if (!channel) return banner("Choose this unit's display type first.");
  const chLabel = chSel.options[chSel.selectedIndex].text;
  const src = ($("#dispfw-src") && $("#dispfw-src").value.trim()) || "";
  if (!confirm("Flash the display over the USB programmer on " + port + " ?\n\nDisplay type: " + chLabel + "\nOnly continue if this unit really has that display.\n\nConfirm the programmer is seated on the display's programming header and the panel has power.")) return;
  try { localStorage.setItem("ifs.dispfw.src", src); } catch (e) {}
  const log = $("#dispfw-console"); log.style.display = "block"; log.textContent = "";
  // single-flight: disable BOTH display-flash buttons while one runs so their shared staged
  // files + the programmer port can't be clobbered by a second flash.
  [$("#dispfw-flash"), $("#dispfw-flash-local")].forEach(function (b) { if (b) b.disabled = true; });
  const label = btn.textContent; btn.textContent = "Flashing...";
  try {
    const resp = await fetch(endpoint, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({port, channel, src})});
    const rd = resp.body.getReader(); const dec = new TextDecoder(); let buf = "";
    while (true) {
      const {done, value} = await rd.read(); if (done) break;
      buf += dec.decode(value, {stream:true});
      let idx;
      while ((idx = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, idx); buf = buf.slice(idx + 2);
        const m = chunk.match(/data: (.*)/s);
        if (m) { try { log.textContent += JSON.parse(m[1]) + "\n"; } catch (e) {}; log.scrollTop = log.scrollHeight; }
      }
    }
  } catch (e) { log.textContent += "\nERROR: " + e; }
  btn.textContent = label; dispfwArm();   // dispfwArm re-enables both buttons per port/manifest
}
function dispfwFlash()      { return dispfwStreamFlash("/api/display/fw/flash",       $("#dispfw-flash")); }
function dispfwFlashLocal() { return dispfwStreamFlash("/api/display/fw/flash_local", $("#dispfw-flash-local")); }
// Download JUST the published display code (.4XE + .cfg) from the channel - checksum-verified -
// into Downloads, and open the folder. No programmer/port needed; nothing is flashed.
async function dispfwDownload() {
  const btn = $("#dispfw-download"), info = $("#dispfw-info");
  if (btn) { btn.disabled = true; btn.textContent = "Downloading..."; }
  try {
    if (!dispfwChannel()) throw "choose this unit's display type first";
    const r = await (await fetch("/api/display/fw/download", { method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({channel: dispfwChannel()}) })).json();
    if (info) {
      info.style.display = "block";
      if (r.ok) { info.className = "okbox";
        info.textContent = "Saved display firmware v" + r.version + " (" + (r.files || []).join(", ") + ") to:  " + r.folder + "   - the folder has been opened."; }
      else { info.className = "warnbox"; info.textContent = "Download failed: " + (r.error || "unknown error"); }
    }
  } catch (e) { if (info) { info.style.display = "block"; info.className = "warnbox"; info.textContent = "Download failed: " + e; } }
  if (btn) { btn.disabled = false; btn.textContent = "Download code"; }
}
window.dispfwDownload = dispfwDownload;
if ($("#dispfw-check"))  $("#dispfw-check").onclick  = dispfwCheck;
if ($("#dispfw-rescan")) $("#dispfw-rescan").onclick = scanPorts;
if ($("#dispfw-port"))   $("#dispfw-port").onchange  = dispfwArm;
if ($("#dispfw-flash"))  $("#dispfw-flash").onclick  = dispfwFlash;
if ($("#dispfw-flash-local")) $("#dispfw-flash-local").onclick = dispfwFlashLocal;
if ($("#dispfw-channel")) {
  // Deliberately NOT remembered across launches: the same PC may service both panel types, and a
  // remembered wrong choice is exactly the mistake this selector exists to stop.
  $("#dispfw-channel").onchange = function () {
    dispfwReady = false; const i = $("#dispfw-info"); if (i) i.style.display = "none";
    const p = $("#dispfw-pill"); if (p) { p.className = "pill"; p.querySelector("span:last-child").textContent = "not checked"; }
    dispfwArm();
  };
}
try { const s0 = localStorage.getItem("ifs.dispfw.src"); if (s0 && $("#dispfw-src")) $("#dispfw-src").value = s0; } catch (e) {}

/* ---------- Tip Charger (Genie screen control) ---------- */
let tcMode = "tcp", tcConnected = false, tcEs = null;
$$("#tcModeSeg button").forEach(b => b.onclick = () => {
  $$("#tcModeSeg button").forEach(x => x.classList.remove("active"));
  b.classList.add("active"); tcMode = b.dataset.mode;
  $("#tcTcpCtrls").style.display = tcMode === "tcp" ? "flex" : "none";
  $("#tcSerialCtrls").style.display = tcMode === "serial" ? "flex" : "none";
});
$("#tcConnectBtn").onclick = async () => {
  if (tcConnected) {   // FIX 2026-07-20: wrap the disconnect (was a bare await -> unhandled rejection + no feedback if the backend hung). Mirror the Opta disconnect handler.
    try { const r = await fetch("/api/tc/disconnect", {method:"POST"}); if (!r.ok) banner("Disconnect refused."); }
    catch (e) { banner("Disconnect failed: " + e + " - the link may still be up."); }
    return;
  }
  const body = tcMode === "serial"
    ? {mode:"serial", port:$("#tc-serial").value, baud:+$("#tc-baud").value}
    : {mode:"tcp", host:$("#tc-host").value.trim(), port:+$("#tc-port").value};
  if (tcMode === "serial" && !body.port) return banner("Pick a serial port for the Tip Charger.");
  if (tcMode === "tcp" && !body.host) return banner("Enter the Tip Charger bridge IP.");
  const btn = $("#tcConnectBtn"); btn.disabled = true; btn.textContent = "Connecting...";
  try {
    const r = await (await fetch("/api/tc/connect", {method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify(body)})).json();
    if (!r.ok) banner("Tip Charger connect failed: " + r.error);
  } catch (e) { banner("Tip Charger connect failed: " + e); }
  finally { btn.disabled = false; if (!tcConnected) btn.textContent = "Connect"; }
};
var _tcSetFilled = 0;
function tcFillSettings(cf) {
  // Fill the Settings fields from the display's boot CFG snapshot, ONCE per snapshot (keyed on its
  // timestamp so a live poll doesn't re-clobber every 1.5s) and never over a field being edited.
  if (!cf || cf.t == null || cf.t === _tcSetFilled) return;
  _tcSetFilled = cf.t;
  [["pumpOn","#set-pumpon"],["pumpOff","#set-pumpoff"],["plasmaTime","#set-plasmatime"],
   ["coolTime","#set-cooltime"],["brightness","#set-bright"]].forEach(function (f) {
    var e = $(f[1]); if (e && cf[f[0]] != null && !e.dataset.dirty) e.value = cf[f[0]];
  });
}
async function tcPoll() {
  try {
    const s = await (await fetch("/api/tc/state")).json();
    tcConnected = s.connected;
    if (s.connected && s.csv && s.csv.settings) tcFillSettings(s.csv.settings);   // populate the Settings panel from the display's boot CFG snapshot
    if (s.connected) tcMode = reflectMode("#tcModeSeg", "#tcSerialCtrls", "#tcTcpCtrls", s.mode) || tcMode;   // toggle follows the live link
    // FRESHNESS GATE (fix 2026-07-20): a socket/serial link can stay "connected" while the panel is
    // hung, wedged on a form, or powered off behind a live adapter - it just stops streaming its CSV.
    // The backend now reports `live` (connected AND rx age < 6 s); use it so a dead panel shows an
    // amber "connected - no data" instead of a reassuring green. The display owns the plasma relay, so
    // a green pill on a silent panel would mislead the operator into thinking commands are landing.
    const live = (s.live === undefined) ? s.connected : s.live;   // tolerate an older backend without `live`
    // The station tells us when a port is open only to be TESTED. That is not a connection, and
    // showing it as one is what made a bare adapter look like an intermittent Tip Charger.
    const probing = !!s.probing;
    const pill = $("#tcLinkInfo");
    if (pill) { pill.className = "pill " + (live ? "ok" : (s.connected ? "warn" : ""));
      pill.querySelector("span:last-child").textContent =
        s.connected ? (live ? (s.mode + " : " + s.info) : (s.mode + " : connected - no data"))
                    : (probing ? "checking" : "no link"); }
    const btn = $("#tcConnectBtn"); if (btn && !btn.disabled) btn.textContent = s.connected ? "Disconnect" : "Connect";
    setPill("#home-tc-st", live, live ? "online"
                                     : (s.connected ? "no data" : (probing ? "checking" : "offline")));
    // A station often has no USB to the Tip Charger at all: it answers through the Plasma
    // StandAlone over Serial2. That is still the Tip Charger being reachable, so say so rather
    // than showing it dead next to a green Serial2 leg.
    if (live)                  { topoSet("disp", true, s.mode || "linked"); topoFlash("disp"); }
    else if (tcSerial2Up)      topoSet("disp", true,  "via Serial2");
    else                       topoSet("disp", false, s.connected ? "no data"
                                                    : (probing ? "checking" : "not connected"));
    homeLive("#home-tc-live", s.connected
      ? [["Link", ((s.mode||"") + " " + (s.info||"")).trim() + (live ? "" : " (no data)")]]
      : [[null, probing ? "Checking the port" : "Not connected"]]);
  } catch (e) {   // app/backend not answering -> don't leave a stale green pill
    tcConnected = false;
    const pill = $("#tcLinkInfo"); if (pill) { pill.className = "pill warn";
      pill.querySelector("span:last-child").textContent = "app not responding"; }
    setPill("#home-tc-st", false, "offline");
    if (tcSerial2Up) topoSet("disp", true, "via Serial2");
    else             topoSet("disp", false, "not connected");
    homeLive("#home-tc-live", [[null, "App not responding"]]);
  }
}
setInterval(tcPoll, 1500); tcPoll();
async function tcForm(n) {
  if (!tcConnected) return banner("Connect to the Tip Charger first.");
  try { const r = await (await fetch("/api/tc/form", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({form:n})})).json();
    if (!r.ok) banner("Screen change not sent: " + (r.error || "link error")); }
  catch (e) { banner("Screen change failed: " + e); }
}
// REMOVED 2026-07-23: tcGoForm(). It read an input, #tc-form, that was deleted from index.html back
// in 1.0.22 (fa344eb) while this function and its window export were left behind - so every call
// hit the "No form selector on this screen" guard and did nothing. Nothing referenced it either.
// Not restoring the input: the panel REFUSES a remote screen change while it is showing Form4, and
// Form4 is where it sits during normal operation, so the control would be inert in the field
// anyway. tcForm() below is kept - /api/tc/form is a working route worth keeping callable.
async function tcWrite() {
  if (!tcConnected) return banner("Connect to the Tip Charger first.");
  const body = {objType:+$("#tc-otype").value, objIndex:+$("#tc-oindex").value, value:+$("#tc-oval").value};
  try { const r = await (await fetch("/api/tc/write", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)})).json();
    if (!r.ok) banner("Write not sent: " + (r.error || "link error")); }
  catch (e) { banner("Write failed: " + e); }
}
var TC_SET_IDS = { pumpOn:"#set-pumpon", pumpOff:"#set-pumpoff", plasmaTime:"#set-plasmatime",
                   coolTime:"#set-cooltime", brightness:"#set-bright", vacuum:"#set-vac" };
async function tcSettings() {
  // Return null (not 0) for a missing/blank/garbage box. The old '+(e.value || 0)' turned every empty
  // field into a 0, and since this button sends ALL six at once, ONE blank box silently reprogrammed
  // the station to floor values (cooling/plasma 5 s, pump 25 %, brightness 10 %) - and persisted them.
  var v = function (id) {
    var e = $(id); if (!e) return null;
    var raw = String(e.value).trim(); var n = Number(raw);
    return (raw === "" || !isFinite(n)) ? null : Math.round(n);
  };
  // Full RE-SYNC: re-send ALL current settings at once (e.g. after the display rebooted and lost
  // them). Normal edits already go live per-field as you change them; the backend paces these.
  var body = {}, skipped = [];
  Object.keys(TC_SET_IDS).forEach(function (k) {
    var val = v(TC_SET_IDS[k]);
    if (val === null) skipped.push(k); else body[k] = val;   // omitted keys are ignored server-side
  });
  if (!Object.keys(body).length) return banner("Nothing to send - every settings field is blank.");
  if (skipped.length) banner("Skipped blank field(s): " + skipped.join(", ") + " - left unchanged on the display.");
  try {
    var r = await (await fetch("/api/tc/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (!r.ok) banner("Settings not sent (" + (r.error || "display not linked") + ").");
    else ok("Re-sent all settings to the display.");
  } catch (e) { banner("Settings failed: " + e); }
}
// Hardware-reset the panel. It has no software reboot, so if the screen ever wedges - blank, or
// stuck on a warning form whose Acknowledge button will not draw - this reset line is the only way
// back short of power-cycling the station.
async function tcReset() {
  if (!tcConnected) return banner("Connect to the Tip Charger first.");
  const e = $("#tc-reset-res");
  if (e) { e.textContent = "resetting..."; e.style.color = ""; }
  try {
    const r = await (await fetch("/api/tc/reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (e) { e.textContent = r.ok ? "Panel reset - it reboots in a few seconds." : (r.error || "reset failed");
             e.style.color = r.ok ? "var(--ok)" : "var(--bad)"; }
    if (r.ok) ok("Panel reset."); else banner("Reset failed: " + (r.error || "unknown"));
  } catch (ex) { if (e) { e.textContent = "Reset failed: " + ex; e.style.color = "var(--bad)"; } }
}
window.tcReset = tcReset;
if ($("#set-apply")) $("#set-apply").onclick = tcSettings;
window.tcWrite = tcWrite;   // tcGoForm removed 2026-07-23 - its input was deleted in 1.0.22
function tcStartStream() {
  if (tcEs) tcEs.close();
  tcEs = new EventSource("/api/tc/stream");
  tcEs.onmessage = ev => {
    let it; try { it = JSON.parse(ev.data); } catch (e) { return; }
    const c = $("#tcConsole"); if (!c || !it || typeof it.line !== "string") return;
    const atBottom = c.scrollHeight - c.scrollTop - c.clientHeight < 40;
    const div = document.createElement("div"); div.textContent = it.line; c.appendChild(div);
    while (c.childElementCount > 2000) c.removeChild(c.firstChild);
    if (atBottom) c.scrollTop = c.scrollHeight;
  };
  tcEs.onerror = () => { if (tcEs && tcEs.readyState === EventSource.CLOSED) tcReconnectTimer = setTimeout(tcStartStream, 2000); };
}
// (opened on demand by syncStreams when the Tip Charger tab is shown)

/* ---------- Puretip One (adb-bridged tablet) ---------- */
let ptConnected = false, ptEs = null;
$("#ptConnectBtn").onclick = async () => {
  if (ptConnected) {   // FIX 2026-07-20: wrap the disconnect (was a bare await -> unhandled rejection + no feedback if the backend hung).
    try { const r = await fetch("/api/pt/disconnect", {method:"POST"}); if (!r.ok) banner("Disconnect refused."); }
    catch (e) { banner("Disconnect failed: " + e + " - the link may still be up."); }
    return;
  }
  $("#ptConnectBtn").disabled = true; $("#ptConnectBtn").textContent = "Connecting...";
  try {
    const r = await (await fetch("/api/pt/connect", {method:"POST"})).json();
    if (!r.ok) banner("Puretip connect: " + r.error);
  } catch (e) { banner("Puretip connect failed: " + e); }
  $("#ptConnectBtn").disabled = false;
};
// ---- which station: several tablets on one PC, picked by nickname ---------------------------
let ptDevices = [];
function ptDevLabel(d) {
  const base = d.name || d.model || "Tablet";
  const st = d.state === "device" ? "" : " (" + d.state + ")";
  return base + " \u00b7 " + d.serial + st + (d.active ? "  - connected" : "");
}
async function ptLoadDevices() {
  try {
    const r = await (await fetch("/api/pt/devices")).json();
    ptDevices = r.devices || [];
    const sel = $("#ptStation"); if (!sel) return;
    const keep = r.chosen || "";
    sel.innerHTML = '<option value="">Station: any single tablet</option>';
    ptDevices.forEach(d => { const o = document.createElement("option"); o.value = d.serial; o.textContent = ptDevLabel(d); sel.appendChild(o); });
    // a chosen station that is unplugged still shows, so it is clear what IFS is waiting for
    if (keep && !ptDevices.some(d => d.serial === keep)) {
      const o = document.createElement("option"); o.value = keep; o.textContent = keep + " (not plugged in)"; sel.appendChild(o);
    }
    sel.value = keep;
    const cur = ptDevices.find(d => d.serial === keep);
    if (document.activeElement !== $("#ptNick")) $("#ptNick").value = cur ? (cur.name || "") : "";
  } catch (e) {}
}
if ($("#ptStation")) {
  $("#ptStation").onchange = async () => {
    const serial = $("#ptStation").value;
    const r = await (await fetch("/api/pt/select", {method: "POST", headers: {"Content-Type": "application/json"},
                                                  body: JSON.stringify({serial})})).json();
    if (!r.ok) banner(r.error || "Could not switch station.");
    ptLoadDevices();
  };
  $("#ptNickSave").onclick = async () => {
    const serial = $("#ptStation").value;
    if (!serial) return banner("Choose a station in the list first, then name it.");
    const r = await (await fetch("/api/pt/nickname", {method: "POST", headers: {"Content-Type": "application/json"},
                                                    body: JSON.stringify({serial, name: $("#ptNick").value})})).json();
    if (!r.ok) banner(r.error || "Name not saved.");
    ptLoadDevices();
  };
  $("#ptStationRefresh").onclick = ptLoadDevices;
  ptLoadDevices();
  setInterval(ptLoadDevices, 8000);     // tablets come and go on the USB hub
}
async function ptPoll() {
  try {
    const s = await (await fetch("/api/pt/state")).json();
    ptConnected = s.connected;
    ptSerial = s.serial || ptSerial;
    // the status line under the animation says what is true when no cycle has spoken yet
    const ev = $("#pt-lastevt");
    if (ev && /^(waiting for the Puretip stream|Connected and idle|Tablet not connected)/.test(ev.textContent) && !ptDemoOn) {
      ev.textContent = s.connected ? "Connected and idle - nothing running." : "Tablet not connected.";
    }
    const pill = $("#ptLinkInfo");
    if (pill) { pill.className = "pill " + (s.connected ? "ok" : "");
      pill.querySelector("span:last-child").textContent = s.connected ? ((s.name || s.serial || "USB") + " : " + s.info) : (s.autoStatus || "no link"); }
    const btn = $("#ptConnectBtn"); if (btn && !btn.disabled) btn.textContent = s.connected ? "Disconnect" : "Connect (USB)";
    setPill("#home-pt-st", s.connected, s.connected ? "online" : "offline");
    // link speed (as Windows enumerated the tablet) and the data actually flowing right now
    const sp = $("#tl-pt-speed");
    if (sp) {
      if (!s.connected) sp.textContent = "";
      else {
        const link = s.usb && s.usb.mbps ? (s.usb.mbps >= 1000 ? (s.usb.mbps / 1000) + " Gb/s" : s.usb.mbps + " Mb/s") + " link" : "";
        const b = s.traffic || 0;
        const live = b >= 1024 ? (b / 1024).toFixed(1) + " KB/s" : Math.round(b) + " B/s";
        sp.textContent = live;                         // the data flowing now; the link speed is in the tooltip
        sp.setAttribute("data-tip", "Data flowing over the tablet link right now" + (link ? " (" + (s.usb ? s.usb.label + ", " : "") + link + ")" : "") + ".");
      }
    }
    topoSet("pt", s.connected, s.connected ? "tablet, adb" : "not connected");
    if (s.connected) topoFlash("pt");
    // Bioyond bridge chips
    const b = s.bioyond || {};
    const rp = (s.robPort || 56788), hp = (s.httpPort || 8080);
    setStatePill("#ptRobPill",  !!b.rob,  "127.0.0.1:" + rp);
    setStatePill("#ptHttpPill", !!b.http, "127.0.0.1:" + hp);
    const both = b.rob && b.http, some = b.rob || b.http;
    const bp = $("#ptBioyondPill");
    if (bp) { bp.className = "pill " + (both ? "ok" : (some ? "warn" : ""));
      bp.querySelector("span:last-child").textContent = both ? "servers reachable" : (some ? "partial" : "not reachable"); }
    homeLive("#home-pt-live", s.connected
      ? [["Link", "USB " + (s.info||"")], ["Bioyond servers", both ? "reachable" : (some ? "partial" : "not reachable")]]
      : [[null, s.autoStatus || "Not connected"]]);
  } catch (e) {   // app/backend not answering -> don't leave stale green
    ptConnected = false;
    const pill = $("#ptLinkInfo"); if (pill) { pill.className = "pill warn";
      pill.querySelector("span:last-child").textContent = "app not responding"; }
    setPill("#home-pt-st", false, "offline");
    topoSet("pt", false, "not connected");
    setStatePill("#ptRobPill", false, "--"); setStatePill("#ptHttpPill", false, "--");
    const bp = $("#ptBioyondPill"); if (bp) { bp.className = "pill";
      bp.querySelector("span:last-child").textContent = "not reachable"; }
    homeLive("#home-pt-live", [[null, "App not responding"]]);
  }
}
setInterval(ptPoll, 1500); ptPoll();

/* Test the forwarded Bioyond servers (proves the scheduler can reach the station) */
$("#ptBioyondCheck").onclick = async () => {
  const box = $("#ptBioyondState");
  const btn = $("#ptBioyondCheck"); btn.disabled = true; btn.textContent = "Testing...";
  try {
    const r = await (await fetch("/api/pt/bioyond/check")).json();
    setStatePill("#ptRobPill",  !!r.rob,  "127.0.0.1:56788");
    setStatePill("#ptHttpPill", !!r.http, "127.0.0.1:8080");
    box.style.display = "block";
    box.className = (r.rob && r.http) ? "okbox" : "warnbox";
    if (r.rob && r.http) {
      box.textContent = "Tablet's Bioyond servers are reachable from this PC (Rob INTF :56788 + HTTP :8080). "
        + "These servers run on the Puretip One tablet itself - the station is now READY for a Bioyond Studio/LIMS scheduler to connect at 127.0.0.1. "
        + "No Bioyond scheduler is connected yet. "
        + (r.state ? ("(Tablet answered getSysState: " + r.state + " - value 1 = idle.)") : "");
    } else if (r.rob || r.http) {
      box.textContent = "Partial: " + (r.rob ? "Rob INTF up" : "Rob INTF down")
        + ", " + (r.http ? "HTTP up" : "HTTP down") + ". Reconnect the tablet, then test again.";
    } else {
      box.textContent = "No Bioyond servers reachable. Connect the Puretip One tablet first, then test.";
    }
  } catch (e) { box.style.display = "block"; box.className = "warnbox"; box.textContent = "Test failed: " + e; }
  btn.disabled = false; btn.textContent = "Test bridge";
};
async function ptSend(cmd) {
  if (!ptConnected) return banner("Connect the Puretip One tablet first.");
  try { const r = await (await fetch("/api/pt/send", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({cmd})})).json();
    if (!r.ok) banner("Command not sent: " + (r.error || "link error")); }
  catch (e) { banner("Send failed: " + e); }
}
// Once per warning: the same text again within two minutes (a fault that repeats, or the same
// popup raised twice) does not bring the banner back.
const ptAlertSeen = {};
let ptAlertHidden = false;      // Hide pressed: stay hidden until the popup is gone from the tablet
function ptShowAlert(msg) {
  const box = $("#ptAlert"); if (!box) return;
  if (ptAlertHidden) return;
  msg = (msg || "").replace(/\x1b\[[0-9;]*[A-Za-z]/g, "").trim();
  if (!msg) return;                       // a banner with nothing in it was the bug
  const now = Date.now();
  if (ptAlertSeen[msg] && now - ptAlertSeen[msg] < 120000) return;
  ptAlertSeen[msg] = now;
  $("#ptAlertMsg").textContent = msg; box.hidden = false;
}
// If OK is tapped on the tablet itself, the banner here clears too.
setInterval(async () => {
  const box = $("#ptAlert");
  if (!box || box.hidden || !ptConnected || ptsPushes) return;   // pushes keep the banner right
  try {
    const r = await (await fetch("/api/pt/popup")).json();
    if (r.showing === false) box.hidden = true;
  } catch (e) {}
}, 3000);
async function ptAck() {
  if (!ptConnected) return banner("Connect the Puretip One tablet first.");
  try {
    const r = await (await fetch("/api/pt/ack", {method: "POST"})).json();
    if (!r.ok) return banner("Not acknowledged: " + (r.error || "no answer"));
    if (r.remaining) {                             // still something on the tablet: keep the banner
      const t = $("#ptAlertMsg"); if (t) t.textContent = r.remaining;
      return banner(r.note);
    }
    $("#ptAlert").hidden = true; ptAlertHidden = false;
    info(r.note || r.result.replace(/^OK ACK - /, "Tablet: "));
  } catch (e) { banner("Acknowledge failed: " + e); }
}
if ($("#ptAckBtn")) {
  $("#ptAckBtn").onclick = ptAck; $("#ptAlertAck").onclick = ptAck;
  $("#ptAlertHide").onclick = () => { $("#ptAlert").hidden = true; ptAlertHidden = true;
    setTimeout(() => { ptAlertHidden = false; }, 120000); };   // older tablets cannot say when it is gone
}
// ---- Tip Calibration from IFS ----------------------------------------------------------------
// Everything shown comes from the tablet's pushes (/api/pt/live, read from IFS's own memory), so
// it is exactly what the tablet's screen says. Moves go through the tablet's own buttons.
let pttOpen = false, pttHoldTimer = null, pttCont = null, pttLastName = null;
function pttMsg(t, kind) { const m = $("#pttMsg"); if (m) { m.textContent = t || ""; m.className = "ptm-msg" + (kind ? " " + kind : ""); } }
async function pttSend(cmd, value) {
  try {
    const r = await (await fetch("/api/pt/teach", {method: "POST", headers: {"Content-Type": "application/json"},
                                                 body: JSON.stringify({cmd, value})})).json();
    if (!r.ok) pttMsg(r.error || "Not done.", "err"); else if (cmd !== "KEEP" && cmd !== "STOP") pttMsg("");
    return r.ok;
  } catch (e) { pttMsg("Not sent: " + e, "err"); return false; }
}
function pttVal(v) { return v && v !== "-" && v !== "?" ? v : "-"; }
function pttShow(t) {
  const box = $("#ptTeach"); if (!box) return;
  pttOpen = !!(t && t.open === "1");
  box.classList.toggle("closed", !pttOpen);
  const st = $("#pttState");
  st.textContent = pttOpen ? "open on the tablet" : "open it on the tablet: Load Tips, then Add New Tip or Edit Tip";
  st.classList.toggle("on", pttOpen);
  t = t || {};
  $("#pttZ").textContent = pttOpen ? pttVal(t.z) : "-";
  $("#pttX").textContent = pttOpen ? pttVal(t.x) : "-";
  $("#pttLoadX").textContent = pttOpen ? pttVal(t.loadx) : "-";
  $("#pttLoadZ").textContent = pttOpen ? pttVal(t.loadz) : "-";
  $("#pttEjectZ").textContent = pttOpen ? pttVal(t.ejectz) : "-";
  $("#pttCleanZ").textContent = pttOpen ? pttVal(t.cleanz) : "-";
  $$("#ptTeach .ptt-step").forEach(s => s.classList.toggle("on", pttOpen && s.dataset.s === String(t.step || "")));
  $$("#pttJog button").forEach(b => b.classList.toggle("on", pttOpen && b.dataset.j === (t.jog || "")));
  $("#pttPrev").disabled = !(pttOpen && t.prev === "1");
  $("#pttNext").textContent = pttOpen && t.next ? t.next : "Next Step";
  const nm = $("#pttName");
  if (pttOpen && document.activeElement !== nm && (t.name || "") !== pttLastName) { nm.value = t.name || ""; pttLastName = t.name || ""; }
  if (!pttOpen && pttCont) pttStopCont();
}
function pttStopCont() {
  if (pttHoldTimer) { clearInterval(pttHoldTimer); pttHoldTimer = null; }
  if (pttCont) { pttCont = null; pttSend("STOP"); }
  const j = $("#pttJoy"); if (j) j.classList.remove("cont");
}
async function pttStartCont(cmd) {
  if (pttCont === cmd) return;
  if (pttCont) pttStopCont();
  pttCont = cmd; $("#pttJoy").classList.add("cont");
  const ok = await pttSend(cmd);
  if (!ok || pttCont !== cmd) { if (pttCont === cmd) pttStopCont(); return; }
  pttHoldTimer = setInterval(() => pttSend("KEEP"), 250);   // the tablet releases after 700 ms without this
}
// The joystick: flick = one jog of the chosen step; hold up or down past 0.45 s = continuous.
(function () {
  const joy = $("#pttJoy"), knob = $("#pttKnob");
  if (!joy) return;
  let down = false, dir = null, since = 0, holdTimer = null, cx = 0, cy = 0, R = 1;
  function dirOf(dx, dy) {
    const m = Math.hypot(dx, dy);
    if (m < R * 0.35) return null;
    return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "RIGHT" : "LEFT") : (dy > 0 ? "DOWN" : "UP");
  }
  function place(dx, dy) {
    const m = Math.hypot(dx, dy), k = m > R ? R / m : 1;
    knob.style.transform = "translate(" + (dx * k) + "px," + (dy * k) + "px)";
  }
  function arm(d) {
    clearTimeout(holdTimer);
    since = Date.now();
    if (d === "UP" || d === "DOWN") holdTimer = setTimeout(() => { if (down && dir === d) pttStartCont(d === "UP" ? "CONTUP" : "CONTDN"); }, 450);
  }
  joy.addEventListener("pointerdown", e => {
    if (!pttOpen) return;
    e.preventDefault(); joy.setPointerCapture(e.pointerId);
    const r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; R = r.width / 2 - 20;
    down = true; dir = null; joy.classList.add("held");
    const dx = e.clientX - cx, dy = e.clientY - cy; place(dx, dy); dir = dirOf(dx, dy); if (dir) arm(dir);
  });
  joy.addEventListener("pointermove", e => {
    if (!down) return;
    const dx = e.clientX - cx, dy = e.clientY - cy; place(dx, dy);
    const d = dirOf(dx, dy);
    if (d !== dir) { if (pttCont) pttStopCont(); dir = d; if (d) arm(d); }
  });
  function end() {
    if (!down) return;
    down = false; clearTimeout(holdTimer); joy.classList.remove("held");
    knob.style.transform = "translate(0,0)";
    if (pttCont) pttStopCont();                 // a held move ends on release
    else if (dir) pttSend(dir);                 // a flick is one jog
    dir = null;
  }
  ["pointerup", "pointercancel", "lostpointercapture"].forEach(ev => joy.addEventListener(ev, end));
  window.addEventListener("blur", () => { end(); pttStopCont(); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) { end(); pttStopCont(); } });
})();
if ($("#ptTeach")) {
  $$("#pttJog button").forEach(b => b.onclick = () => pttSend("JOG", b.dataset.j));
  $("#pttHome").onclick = () => pttSend("HOMEZ");
  $("#pttEject").onclick = () => pttSend("EJECT");
  $("#pttEjectTips").onclick = () => pttSend("EJECTTIPS");
  $("#pttPrev").onclick = () => pttSend("PREV");
  $("#pttNext").onclick = () => pttSend("NEXT");
  $("#pttClose").onclick = () => pttSend("CLOSE");
  const setName = () => { const v = $("#pttName").value.trim(); if (!v) return pttMsg("Type a tip name first.", "err"); pttSend("NAME", v); };
  $("#pttNameSet").onclick = setName;
  $("#pttName").addEventListener("keydown", e => { if (e.key === "Enter") setName(); });
  pttShow(null);
  setInterval(async () => {
    if (!ptConnected) { pttShow(null); return; }
    if ($("#ptTeach").offsetParent === null) return;
    try { const r = await (await fetch("/api/pt/live")).json(); pttShow(r.teach); } catch (e) {}
  }, 300);
}
// ---- odometer digits ----------------------------------------------------------------------------
// Each digit is a column 0-9 that rolls to its value, like a mechanical counter.
function odoSet(el, text) {
  if (!el) return;
  text = String(text);
  if (el.dataset.v === text) return;
  if (el.children.length !== text.length || (el.dataset.shape || "") !== text.replace(/\d/g, "9")) {
    el.innerHTML = "";
    for (const ch of text) {
      if (/\d/.test(ch)) {
        const d = document.createElement("span"); d.className = "od";
        const col = document.createElement("span");
        for (let i = 0; i <= 9; i++) { const b = document.createElement("b"); b.textContent = i; col.appendChild(b); }
        d.appendChild(col); el.appendChild(d);
      } else { const s = document.createElement("span"); s.className = "os"; s.textContent = ch; el.appendChild(s); }
    }
    el.dataset.shape = text.replace(/\d/g, "9");
  }
  [...text].forEach((ch, i) => {
    const c = el.children[i];
    if (c && c.classList.contains("od")) c.firstChild.style.transform = "translateY(calc(" + (-parseInt(ch, 10)) + " * var(--dh, 1em)))";   // rolls by the digit box height
  });
  el.dataset.v = text;
}
function odoDur(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
  return String(h).padStart(4, "0") + ":" + String(m).padStart(2, "0") + ":" + String(sec).padStart(2, "0");
}
function odoNum(n, w) { return String(Math.floor(n || 0)).padStart(w || 6, "0"); }
const ODO_FIELDS = {
  pt:   [["mist_runs", "Misting runs", "n"], ["mist_s", "Misting time", "t"], ["clean_runs", "Cleaning runs", "n"],
         ["clean_s", "Cleaning time", "t"], ["connected_s", "Connected", "t"]],
  opta: [["cycles", "Cycles", "n"], ["run_s", "Running time", "t"], ["connected_s", "Connected", "t"]],
  tc:   [["plasma_runs", "Plasma runs", "n"], ["plasma_s", "Plasma time", "t"], ["connected_s", "Connected", "t"]]
};
let ptSerial = "";
function odoPlain(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
  if (h) return h + " h " + String(m).padStart(2, "0") + " m";
  if (m) return m + " m";
  return (s % 60) + " s";
}
function odoRender(strip, unit) {
  // One quiet line of totals; the rolling digits are kept for the countdown only.
  const kind = strip.dataset.kind;
  if (!unit) { strip.innerHTML = '<span class="odoline-empty">Nothing counted yet. Totals start as soon as this unit is connected.</span>'; return; }
  strip.innerHTML = ODO_FIELDS[kind].map(f =>
    '<span class="odoitem"><span class="ol">' + f[1] + '</span> <b>' +
    (f[2] === "t" ? odoPlain(unit[f[0]]) : String(Math.floor(unit[f[0]] || 0))) + '</b></span>').join("");
}
setInterval(async () => {
  const strips = $$(".odostrip").filter(s => s.offsetParent !== null);
  if (!strips.length) return;
  let d; try { d = await (await fetch("/api/odometer")).json(); } catch (e) { return; }
  const u = d.units || {};
  strips.forEach(s => odoRender(s, s.dataset.kind === "pt" ? u["pt:" + ptSerial] : u[s.dataset.kind]));
}, 2000);

// ---- countdown on the animation, and the tablet's own status -----------------------------------
// Misting / cleaning: the tablet's own countdown counters, shown exactly as it reads them.
// Plasma: the Tip Charger's plasma time, counted from the moment the plasma stage starts.
let ptPlasmaT0 = 0;
setInterval(async () => {
  const box = $("#ptCount"); if (!box || !$("#lane-pt") || $("#lane-pt").offsetParent === null) return;
  if (!ptConnected) { box.hidden = true; return; }
  let live; try { live = await (await fetch("/api/pt/live")).json(); } catch (e) { return; }
  const unit = live.unit || {};
  if (unit.ble !== undefined) {
    const on = /connected/i.test(unit.ble) && !/dis/i.test(unit.ble);
    setPill("#ptBle", on, unit.ble || "unknown");
    const ut = $("#ptUnit"); if (ut) ut.textContent = "Tablet app v" + (unit.ver || "?") + (unit.mode ? " \u00b7 " + unit.mode : "");
  }
  const run = live.run || {}, has = k => run[k] && run[k] !== "-";
  let label = "", val = null;
  if (has("mon")) { label = "Misting on"; val = run.mon; }
  else if (has("moff")) { label = "Misting pause"; val = run.moff; }
  else if (has("con")) { label = "Cleaning on"; val = run.con; }
  else if (has("coff")) { label = "Cleaning pause"; val = run.coff; }
  const plasmaOn = $("#ptc-plasma") && $("#ptc-plasma").classList.contains("active");
  if (!val && plasmaOn) {
    if (!ptPlasmaT0) ptPlasmaT0 = Date.now();
    const total = +(($("#set-plasmatime") || {}).value || 15);
    const left = Math.max(0, total - (Date.now() - ptPlasmaT0) / 1000);
    label = "Plasma \u00b7 Tip Charger"; val = left.toFixed(1);
  } else if (!plasmaOn) ptPlasmaT0 = 0;
  if (!val) { box.hidden = true; return; }
  $("#ptCountL").textContent = label;
  odoSet($("#ptCountV"), val);
  box.hidden = false;
}, 250);
function ptRun() {                  // 0 is a valid pause; it used to become 30
  const g = Math.max(0, Math.min(600, parseInt($("#pt-gap").value, 10) || 0));
  ptSend("run " + g);
}
// ---- the tablet's settings, read and applied from here --------------------------------------
// Only the values that differ from what the tablet last reported are sent: each one is typed in
// on the tablet's own keypad (so its limits apply), which takes a second or two apiece.
const ptsLast = {};
function ptsInputs() { return $$("#ptMods input[data-k]"); }
function ptsMsg(t, kind) { const m = $("#ptsMsg"); if (!m) return; m.textContent = t; m.className = "ptm-msg" + (kind ? " " + kind : ""); }
function ptsFill(vals, markChanged) {
  ptsInputs().forEach(i => {
    const v = vals[i.dataset.k];
    if (v === undefined || v === null) return;
    i.value = v;
    i.classList.toggle("changed", !!markChanged && String(v) !== String(ptsLast[i.dataset.k] ?? ""));
    i.classList.remove("bad");
  });
}
function ptsCollect(onlyChanged) {
  const out = {}; let bad = false;
  ptsInputs().forEach(i => {
    const v = i.value.trim(); i.classList.remove("bad");
    if (!v) return;
    if (!/^\d{1,5}(\.\d{1,2})?$/.test(v)) { i.classList.add("bad"); bad = true; return; }
    if (onlyChanged && String(v) === String(ptsLast[i.dataset.k] ?? "")) return;
    out[i.dataset.k] = v;
  });
  return bad ? null : out;
}
// Read automatically: as soon as the tablet connects, and every 20 s while this screen is open -
// but never over a value the operator is in the middle of changing.
let ptsLastRead = 0, ptsWasConnected = false, ptsBusy = false;
function ptsEditing() {
  return ptsInputs().some(i => i.classList.contains("changed") || document.activeElement === i);
}
// Tablet 2.06+ pushes its values and popups when they change; IFS just reads its own memory
// (/api/pt/live sends nothing to the tablet). Older tablets are asked quietly every 20 s.
let ptsPushes = false, ptsLiveKey = "";
async function ptsAuto() {
  if (!ptConnected) { ptsWasConnected = false; ptsPushes = false; return; }
  let live = null;
  try { live = await (await fetch("/api/pt/live")).json(); } catch (e) {}
  if (live && live.pushes) {
    ptsPushes = true;
    if (live.params && !ptsBusy && !ptsEditing()) {
      const key = JSON.stringify(live.params);
      if (key !== ptsLiveKey) {
        ptsLiveKey = key;
        Object.keys(live.params).forEach(k => { ptsLast[k] = live.params[k]; });
        ptsFill(live.params, false);
        ptsInputs().forEach(i => i.classList.remove("changed"));
        ptsMsg("These are the values the tablet is using now.", "ok");
      }
    }
    if (live.popup) ptShowAlert(live.popup);
    else {
      if ($("#ptAlert")) $("#ptAlert").hidden = true;
      Object.keys(ptAlertSeen).forEach(k => delete ptAlertSeen[k]);   // gone: the next one shows
      ptAlertHidden = false;
    }
    ptsWasConnected = true;
    return;
  }
  const onScreen = $("#ptMods") && $("#ptMods").offsetParent !== null;
  if (!ptsWasConnected) { ptsWasConnected = true; ptsRead(true); return; }
  if (onScreen && !ptsBusy && !ptsEditing() && Date.now() - ptsLastRead > 20000) ptsRead(true);
}
async function ptsRead(quiet) {
  if (ptsBusy) return;
  if (!ptConnected) return quiet ? null : ptsMsg("Connect the Puretip One tablet first.", "err");
  if (quiet === true && ptsEditing()) return;
  ptsBusy = true;
  const b = $("#ptsRead"); b.disabled = true; if (quiet !== true) ptsMsg("Reading the tablet's settings...");
  try {
    const r = await (await fetch("/api/pt/params")).json();
    if (!r.ok) return quiet === true ? null : ptsMsg(r.error || "The tablet did not answer.", "err");
    if (quiet === true && ptsEditing()) return;      // the operator started typing meanwhile
    Object.keys(r.values).forEach(k => { if (r.values[k] !== null) ptsLast[k] = r.values[k]; });
    ptsFill(r.values, false);
    ptsInputs().forEach(i => i.classList.remove("changed"));
    ptsLastRead = Date.now();
    const missing = Object.keys(r.values).filter(k => r.values[k] === null).length;
    ptsMsg(missing ? "Read, but " + missing + " value(s) did not report. Read again in a moment."
                   : "These are the values the tablet is using now.", missing ? "err" : "ok");
  } catch (e) { if (quiet !== true) ptsMsg("Read failed: " + e, "err"); }
  finally { b.disabled = false; ptsBusy = false; }
}
async function ptsApply() {
  if (!ptConnected) return ptsMsg("Connect the Puretip One tablet first.", "err");
  const vals = ptsCollect(Object.keys(ptsLast).length > 0);
  if (vals === null) return ptsMsg("Numbers only. Fix the boxes outlined in red.", "err");
  const n = Object.keys(vals).length;
  if (!n) return ptsMsg("Nothing has changed since the last read.");
  const b = $("#ptsApply"); b.disabled = true;
  ptsMsg("Applying " + n + " value" + (n === 1 ? "" : "s") + " on the tablet. Leave it on its main screen...");
  try {
    const r = await (await fetch("/api/pt/params", {method: "POST", headers: {"Content-Type": "application/json"},
                                                   body: JSON.stringify({values: vals})})).json();
    if (r.values) {
      Object.keys(r.values).forEach(k => { if (r.values[k] !== null) ptsLast[k] = r.values[k]; });
      ptsFill(r.values, false);
      ptsInputs().forEach(i => i.classList.remove("changed"));
    }
    if (!r.ok) return ptsMsg(r.error || "Some values were not applied.", "err");
    ptsMsg("Applied. The tablet confirmed every value.", "ok");
  } catch (e) { ptsMsg("Apply failed: " + e, "err"); }
  finally { b.disabled = false; }
}
let ptsPresets = [];
async function ptsLoadPresets(select) {
  try {
    const r = await (await fetch("/api/pt/presets")).json();
    ptsPresets = r.presets || [];
    const s = $("#ptsPreset"); if (!s) return;
    s.innerHTML = '<option value="">Saved presets</option>';
    ptsPresets.forEach(p => { const o = document.createElement("option"); o.value = p.name; o.textContent = p.name; s.appendChild(o); });
    if (select) s.value = select;
  } catch (e) {}
}
async function ptsSavePreset() {
  const name = $("#ptsName").value.trim();
  if (!name) return ptsMsg("Type a name for the preset first.", "err");
  const vals = ptsCollect(false);
  if (vals === null) return ptsMsg("Numbers only. Fix the boxes outlined in red.", "err");
  if (!Object.keys(vals).length) return ptsMsg("Read from the tablet or fill the values in first.", "err");
  const r = await (await fetch("/api/pt/presets", {method: "POST", headers: {"Content-Type": "application/json"},
                                                 body: JSON.stringify({name, values: vals})})).json();
  if (!r.ok) return ptsMsg(r.error || "Not saved.", "err");
  $("#ptsName").value = ""; await ptsLoadPresets(name);
  ptsMsg("Saved \u201c" + name + "\u201d. Load it any time, then Apply to tablet.", "ok");
}
function ptsLoadPreset() {
  const p = ptsPresets.find(x => x.name === $("#ptsPreset").value);
  if (!p) return ptsMsg("Choose a saved preset first.", "err");
  ptsFill(p.values, true);
  ptsMsg("Loaded \u201c" + p.name + "\u201d. Changed values are highlighted; press Apply to tablet to use them.");
}
async function ptsDeletePreset() {
  const name = $("#ptsPreset").value;
  if (!name) return ptsMsg("Choose a saved preset first.", "err");
  await fetch("/api/pt/presets/delete", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({name})});
  await ptsLoadPresets(); ptsMsg("Deleted \u201c" + name + "\u201d.");
}
if ($("#ptMods")) {
  ptsInputs().forEach(i => i.addEventListener("input", () => {
    i.classList.toggle("changed", i.value.trim() !== String(ptsLast[i.dataset.k] ?? ""));
  }));
  $("#ptsRead").onclick = () => ptsRead(false); $("#ptsApply").onclick = ptsApply;
  setInterval(ptsAuto, 2000);
  $("#ptsSave").onclick = ptsSavePreset; $("#ptsLoad").onclick = ptsLoadPreset; $("#ptsDel").onclick = ptsDeletePreset;
  $("#ptsTcBtn").onclick = () => { const n = document.querySelector('.navitem[data-v="tc"]'); if (n) n.click(); };
  ptsLoadPresets();
}
window.ptSend = ptSend; window.ptRun = ptRun;
$$("#ptCmds button").forEach(b => b.onclick = () => ptSend(b.dataset.c));
$("#ptSendBtn").onclick = () => { const v = $("#pt-cmd").value.trim(); if (v){ ptSend(v); $("#pt-cmd").value=""; } };
$("#pt-cmd").addEventListener("keydown", e => { if (e.key === "Enter") $("#ptSendBtn").click(); });
function ptStartStream() {
  if (ptEs) ptEs.close();
  ptEs = new EventSource("/api/pt/stream");
  ptEs.onmessage = ev => {
    let it; try { it = JSON.parse(ev.data); } catch (e) { return; }
    const c = $("#ptConsole"); if (!c || !it || typeof it.line !== "string") return;
    const line = stripAnsi(it.line);
    // A popup raised on the tablet in the last minute (not an old one replayed on reconnect)
    if (line.indexOf("[ALERT]") !== -1 && Date.now() / 1000 - (it.t || 0) < 60) ptShowAlert(line.replace(/^.*\[ALERT\]\s*/, ""));
    ptLiveFeed(line);   // Live View stage animation rides the same stream   // the Puretip CLI colorizes with ANSI codes; strip so the console shows clean text
    const atBottom = c.scrollHeight - c.scrollTop - c.clientHeight < 40;
    const div = document.createElement("div");
    // Styled by class, like the main console, so the console's own CSS governs it. This used to
    // set #7ee787 inline - a green from the old DARK console, left behind when the console went
    // light. On white it measures 1.54:1, so a transmitted line was all but invisible, and only
    // ever on screen with a device actually echoing.
    if (line.startsWith(">")) div.className = "tx";
    else if (/^ERR/i.test(line)) div.className = "err";
    div.textContent = line; c.appendChild(div);
    while (c.childElementCount > 2000) c.removeChild(c.firstChild);
    if (atBottom) c.scrollTop = c.scrollHeight;
  };
  ptEs.onerror = () => { if (ptEs && ptEs.readyState === EventSource.CLOSED) ptReconnectTimer = setTimeout(ptStartStream, 2000); };
}
// (opened on demand by syncStreams when the Puretip One tab is shown)

/* ---------- app self-update (OTA) ---------- */
let updateUrl = null, _updateNotified = false;

function _pillSet(el, cls, text) {
  if (!el) return;
  el.className = "pill " + cls;
  const s = el.querySelector("span:last-child"); if (s) s.textContent = text;
}

// Reflect the app-update state everywhere at once: the dedicated App update panel (Firmware tab),
// the amber Update button in the top connection bar, the version label, and a one-time notification
// banner the first time an update is auto-detected in a session.
function renderUpdateState(u, manual) {
  const cur = (u && u.current) || "?";
  const vl = $("#verLabel"); if (vl) vl.textContent = "v" + cur;
  if (vl && !vl.dataset.oss) {
    vl.dataset.oss = "1"; vl.style.cursor = "pointer"; vl.title = "Version and open-source notices";
    vl.onclick = ossNotices;
  }
  const curEl = $("#appfw-cur"); if (curEl) curEl.textContent = "installed v" + cur;
  const pill = $("#appfw-pill"), infoEl = $("#appfw-info"), upBtn = $("#appfw-update"), topBtn = $("#updateBtn");
  const available = !!(u && u.ok && u.newer);

  if (u && u.mac && !(u.self_update && available)) {
    // macOS: a direct (.dmg) copy with a newer release falls through to the normal one-click
    // update below (backend swaps IFS.app). Otherwise: A Mac App Store copy is updated by the store; a
    // direct (.dmg) copy is replaced by downloading the new Mac build. The Windows channel is
    // only read to say whether a newer release exists.
    updateUrl = null;
    if (upBtn)  upBtn.style.display = "none";
    if (topBtn) topBtn.style.display = "none";
    if (u.store) {
      _pillSet(pill, "ok", "App Store");
      if (infoEl) {
        if (manual) { infoEl.style.display = "block"; infoEl.className = "hint";
          infoEl.textContent = "This copy of IFS is updated through the Mac App Store."; }
        else { infoEl.style.display = "none"; }
      }
    } else if (available) {
      _pillSet(pill, "info", "v" + u.latest + " released");
      if (infoEl) { infoEl.style.display = "block"; infoEl.className = "infobox";
        infoEl.textContent = "Version " + u.latest + " has been released." + (u.notes ? "  " + u.notes : "") +
          "  To update, open IFS from the Applications folder and click Update. Settings, licence and history are kept."; }
    } else if (u.ok) {
      _pillSet(pill, "ok", "up to date");
      if (infoEl) {
        if (manual) { infoEl.style.display = "block"; infoEl.className = "hint"; infoEl.textContent = "You're on the latest version (v" + cur + ")."; }
        else { infoEl.style.display = "none"; }
      }
    } else {
      _pillSet(pill, "warn", "check failed");
      if (infoEl && manual) { infoEl.style.display = "block"; infoEl.className = "warnbox";
        infoEl.textContent = "Could not reach the update channel" + (u.error ? ": " + u.error : "") + "."; }
    }
    return;
  }

  if (available && u.sac) {
    // Smart App Control is enforced here, so the one-click swap would replace the app with a file
    // Windows then refuses to reopen. It refuses the signed installer too, for the same reason -
    // which is why this used to promise "Augeas will update this machine with a signed release"
    // and then nothing ever arrived. The bundle is the artifact SAC allows, because the program
    // it launches is python.org's pythonw.exe rather than anything we built.
    updateUrl = "";
    _pillSet(pill, "info", "v" + u.latest + " available");
    if (upBtn)  upBtn.style.display = "none";
    if (topBtn) topBtn.style.display = "none";
    if (infoEl) {
      infoEl.style.display = "block"; infoEl.className = "infobox";
      infoEl.textContent = "";
      const line = document.createElement("div");
      line.textContent = "Version " + u.latest + " is available." +
        (u.notes ? "  " + u.notes : "");
      infoEl.appendChild(line);
      const why = document.createElement("div");
      why.style.marginTop = "6px";
      why.textContent = "Windows Smart App Control blocks the one-click update on this PC, and " +
        "the installer with it. Download the folder version instead - it needs no install and " +
        "Windows allows it.";
      infoEl.appendChild(why);
      if (u.bundle) {
        const a = document.createElement("a");
        a.href = u.bundle;
        a.textContent = "Download IFS Control Suite " + (u.bundle_version || u.latest) + " (zip)";
        a.style.display = "inline-block";
        a.style.marginTop = "8px";
        a.setAttribute("download", "");
        infoEl.appendChild(a);
        const how = document.createElement("div");
        how.className = "hint";
        how.style.marginTop = "6px";
        how.textContent = "Unzip it anywhere, close this app, then run \u0022Add shortcut.cmd\u0022 " +
          "inside the new folder. Your settings, licence and history are kept - they live outside " +
          "the program folder.";
        infoEl.appendChild(how);
      } else {
        const no = document.createElement("div");
        no.style.marginTop = "6px";
        no.textContent = "The update channel did not offer a folder version. Ask Augeas for one.";
        infoEl.appendChild(no);
      }
    }
  } else if (available) {
    updateUrl = u.url;
    _pillSet(pill, "info", "v" + u.latest + " available");   // calm blue, NOT a warning - an update is good news
    if (upBtn)  upBtn.style.display = "";
    if (topBtn) { topBtn.style.display = ""; topBtn.title = "New: v" + u.latest; }
    if (infoEl) { infoEl.style.display = "block"; infoEl.className = "infobox";
      infoEl.textContent = "Version " + u.latest + " is available." + (u.notes ? "  " + u.notes : ""); }
    // Notify once per session on the automatic startup check (manual checks don't re-nag). Uses the
    // INFO banner (blue "Update"), never the red "Error" banner - an available update isn't a problem.
    if (!manual && !_updateNotified) {
      _updateNotified = true;
      info("IFS v" + u.latest + " is available - open the Firmware tab (App update), or click Update up top, to install.");
    }
  } else if (u && u.ok) {
    _pillSet(pill, "ok", "up to date");
    if (upBtn)  upBtn.style.display = "none";
    if (topBtn) topBtn.style.display = "none";
    if (infoEl) {
      // Up to date is a calm state: a small muted line on a manual check, and no box at all
      // otherwise (the green pill already says it) - so there's no big empty panel sitting there.
      if (manual) { infoEl.style.display = "block"; infoEl.className = "hint"; infoEl.textContent = "You're on the latest version (v" + cur + ")."; }
      else { infoEl.style.display = "none"; }
    }
  } else {
    _pillSet(pill, "warn", "check failed");
    if (infoEl) {
      if (manual) { infoEl.style.display = "block"; infoEl.className = "warnbox";
        infoEl.textContent = "Could not reach the update channel" + (u && u.error ? ": " + u.error : "") + "."; }
      else { infoEl.style.display = "none"; }
    }
  }
}

async function checkUpdate(manual) {
  if (manual) _pillSet($("#appfw-pill"), "", "checking...");
  try {
    const u = await (await fetch("/api/update/check")).json();
    renderUpdateState(u, manual);
    // Report the outcome of a previous self-update (the swap batch leaves a one-shot marker), so a
    // rolled-back update is never silent.
    if (u && u.last_result === "failed" && typeof banner === "function")
      banner("The last update could not finish - the program file was locked, so it rolled back. Close other IFS windows and try Update again, or download the installer from the release page.");
    else if (u && u.last_result === "ok" && typeof ok === "function")
      ok("Update installed - now running v" + (u.current || "") + ".");
  } catch (e) {
    if (manual) {
      _pillSet($("#appfw-pill"), "warn", "check failed");
      const info = $("#appfw-info"); if (info) { info.style.display = "block"; info.className = "warnbox"; info.textContent = "Check failed: " + e; }
    }
  }
}
function appUpdateCheck() { checkUpdate(true); }
window.appUpdateCheck = appUpdateCheck;

async function appUpdateApply() {
  if (!updateUrl) return banner("No update to install - click Check for update first.");
  if (!confirm("Install the update now? The app will close and reopen on the new version.\n\nNote: on some PCs the swap can take a minute or two while antivirus scans the new file - please wait for it to reopen.")) return;
  for (const id of ["#appfw-update", "#updateBtn"]) { const b = $(id); if (b) { b.disabled = true; b.textContent = "Updating..."; } }
  try {
    const resp = await fetch("/api/update/apply", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({url:updateUrl})});
    const rd = resp.body.getReader(); const dec = new TextDecoder(); let buf = "";
    while (true) { const {done, value} = await rd.read(); if (done) break; buf += dec.decode(value,{stream:true}); }
  } catch (e) { /* the app exits mid-stream on success, so errors here are expected */ }
}
window.appUpdateApply = appUpdateApply;
if ($("#updateBtn")) $("#updateBtn").onclick = appUpdateApply;
checkUpdate(false);
// Station firmware notices: once per launch, tell the operator when the channel carries display or
// Opta firmware this computer has not installed. A dot stays on Firmware until that page is opened.
let _fwNotices = [];
async function fwNotices() {
  try {
    const r = await (await fetch("/api/fw/notices")).json();
    _fwNotices = (r && r.ok && r.notices) || [];
    if (!_fwNotices.length) return;
    const nav = document.querySelector('.navitem[data-v="fw"]'); if (nav) nav.classList.add("has-new");
    const msg = _fwNotices.map(n => n.label + " " + n.version + " is available. " + n.how).join("   ");
    setTimeout(() => info(msg), _updateNotified ? 13000 : 600);   // never on top of the app-update notice
  } catch (e) { /* offline: say nothing */ }
}
function fwNoticesSeen() {
  const nav = document.querySelector('.navitem[data-v="fw"]'); if (nav) nav.classList.toggle("has-new", false);
  for (const n of _fwNotices) {
    fetch("/api/fw/notices/dismiss", {method: "POST", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({kind: n.kind, version: n.version})}).catch(() => {});
  }
  _fwNotices = [];
  if (typeof optaFwCheck === "function") optaFwCheck();   // fill both pills with the channel version
  if (typeof dispfwCheck === "function") dispfwCheck();
}
setTimeout(fwNotices, 2500);
// What this desktop can do. On a Mac the display flash buttons are off from the first paint
// (4D's loader is Windows-only) rather than only after a channel check.
fetch("/api/platform").then(r => r.json()).then(p => {
  if (!p || !p.ok) return;
  document.documentElement.dataset.os = p.os || "";
  if (!p.display_flash) {
    dispfwUnsupported = p.display_flash_msg || "Display flashing needs the Windows app.";
    dispfwArm();
    const pill = $("#dispfw-pill"), info = $("#dispfw-info");
    if (pill) { pill.className = "pill warn"; pill.querySelector("span:last-child").textContent = "flash on Windows"; }
    if (info) { info.style.display = "block"; info.className = "warnbox"; info.textContent = dispfwUnsupported; }
  }
}).catch(() => {});

scanPorts();
showView("home");   // set topbar title + hide the Opta cluster on the landing view
renderSchematic({});   // draw the empty chamber + travel markers before any connection

/* ---------- Data Log: electrode temperature / plasma power per run ---------- */
var DL_KEY = "ifs_dl_runs_v1";
var dlRuns = [], dlActive = null, dlView = null, dlLastPlasma = 0, dlSerial = "", dlAutoStarted = false;
function dlLoad() { try { dlRuns = JSON.parse(localStorage.getItem(DL_KEY) || "[]"); } catch (e) { dlRuns = []; } if (!Array.isArray(dlRuns)) dlRuns = []; dlRuns = dlRuns.filter(function (r) { return r && Array.isArray(r.samples); }); }   // drop malformed/legacy entries so one bad run can't break the whole list
function dlSave() { try { localStorage.setItem(DL_KEY, JSON.stringify(dlRuns.slice(-50))); return true; } catch (e) { try { banner("Could not save the run - browser storage is full. Export it to CSV to keep the data."); } catch (_) {} return false; } }
function dlRecPill(on) { var p = $("#dl-rec-pill"); if (p) { p.className = "pill " + (on ? "warn" : ""); p.querySelector("span:last-child").textContent = on ? "recording" : "idle"; } var b = $("#dl-rec"); if (b) b.textContent = on ? "Stop recording" : "Start recording"; }
function dlStart(name) { var nm = (name && name.trim()); if (!nm) nm = (dlSerial ? ("SN" + dlSerial + " ") : "Run ") + new Date().toLocaleString(); dlActive = { name: nm, started: Date.now(), samples: [], labware: (typeof lwCurrent === "function" ? lwCurrent() : null) }; dlView = null; var t = $("#dl-graph-title"); if (t) t.textContent = " (live)"; dlRecPill(true); }
function dlStop() { if (dlActive && dlActive.samples.length) { dlActive.ended = Date.now(); dlRuns.push(dlActive); dlSave(); dlRenderRuns(); } else if (dlActive) { banner("Run too short - no samples were captured."); } dlActive = null; dlRecPill(false); }
function dlRedraw() { dlDrawChart(dlView != null ? dlRuns[dlView] : dlActive); }
var _dlSampleBusy = false;
async function dlSample() {
  // In-flight guard: driven by a bare setInterval(1000). If a fetch takes >1 s (busy backend / slow
  // adb bridge) two invocations overlapped, both evaluated !dlActive before either set it, and the
  // second dlStart() replaced the run with a fresh empty one - discarding the first run's samples.
  // Also produced out-of-order sample timestamps. Skip a tick if the previous one is still running.
  if (_dlSampleBusy) return;
  _dlSampleBusy = true;
  try {
    await _dlSampleInner();
  } finally { _dlSampleBusy = false; }
}
async function _dlSampleInner() {
  var temp = null, pwr = null, vac = null, plasma = 0, optaSN = null;
  try { var s = await (await fetch("/api/state")).json(); if (s && s.live && s.status) { var st = s.status;   // s.live gate: on a connected-but-hung link the backend still returns the last (frozen) status; without this the Data Log would keep logging stale temp/power and hold plasma inferred ON while Overview correctly shows "no data"
    if (st.TEMP_F != null) temp = parseFloat(st.TEMP_F);
    if (st.WATTS != null) pwr = parseFloat(st.WATTS);
    if (st.PLASMA != null) plasma = (st.PLASMA === "1" || /on|true/i.test(st.PLASMA)) ? 1 : 0;
    if (st.SN != null && st.SN !== "") { optaSN = st.SN; dlSerial = st.SN; var se = $("#dl-serial"); if (se && document.activeElement !== se) se.value = st.SN; } } } catch (e) {}
  try { var tc = await (await fetch("/api/tc/state")).json(); if (tc && tc.csv) {
    // The Opta (reliable USB) is the AUTHORITATIVE serial. The display's own serial is unreliable
    // on the un-reflashed firmware - a 16-bit var wraps the real 6-digit serial to a garbage
    // NEGATIVE (e.g. -31024). Only use the display serial as a FALLBACK when the Opta gave none,
    // and only if it's a sane positive number - never let it flash over the Opta's value.
    if (optaSN == null && tc.csv.serial != null && tc.csv.serial > 0) { dlSerial = tc.csv.serial; var se2 = $("#dl-serial"); if (se2 && document.activeElement !== se2) se2.value = tc.csv.serial; }
    if (tc.csv.t && (Date.now()/1000 - tc.csv.t) < 6) {   // display CSV, only if FRESH (<6s): a hung display must not record stale power/vac or hold plasma inferred ON
      if (tc.csv.power != null && (pwr == null || pwr === 0)) pwr = tc.csv.power;
      if (tc.csv.vac != null) vac = tc.csv.vac;
      if (tc.csv.power > 5) plasma = 1; } } } catch (e) {}
  var set = function (id, v) { var e = $(id); if (e) e.textContent = v; };
  set("#dl-cur-temp", temp == null ? "--" : Math.round(temp));
  set("#dl-cur-pwr",  pwr  == null ? "--" : Math.round(pwr));
  set("#dl-cur-vac",  vac  == null ? "--" : Math.round(vac));
  set("#dl-cur-plasma", plasma ? "ON" : "off");
  // Auto-record: START a NEW run on each plasma rising edge, and STOP (persist) on the falling edge.
  // FIX 2026-07-20: there was no auto-stop, so every cycle appended to ONE run with a continuous clock
  // (idle gaps included), and the whole session lived only in memory until a manual Stop - closing the
  // app discarded it silently. Now each cycle is its own saved run. dlStop() calls dlSave() so it
  // persists to localStorage the moment a cycle ends.
  if ($("#dl-auto") && $("#dl-auto").checked) {
    if (plasma && !dlLastPlasma) { if (dlActive) dlStop(); dlStart(($("#dl-name") || {}).value); dlAutoStarted = true; }
    else if (!plasma && dlLastPlasma && dlActive && dlAutoStarted) { dlStop(); dlAutoStarted = false; }
  }
  dlLastPlasma = plasma;
  if (dlActive) {
    var tsec = (Date.now() - dlActive.started) / 1000;
    dlActive.samples.push({ t: +tsec.toFixed(1), temp: temp, pwr: pwr, vac: vac, plasma: plasma });
    if (dlActive.samples.length > 7200) dlActive.samples.shift();   // cap ~2h @1Hz
    set("#dl-cur-elapsed", Math.round(tsec) + "s");
    if (dlView == null && document.querySelector("#view-log.active")) dlDrawChart(dlActive);
  } else set("#dl-cur-elapsed", "--");
}
function dlDrawChart(run) {
  var c = $("#dl-chart"); if (!c) return; var W = c.clientWidth, H = c.clientHeight; if (W < 10) return;
  var dpr = window.devicePixelRatio || 1; c.width = W * dpr; c.height = H * dpr;
  var g = c.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);   // transparent -> the white panel shows through
  var dark = window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches;
  var ink = dark ? "#8a94a3" : "#6b7280", grid = dark ? "#2a3440" : "#d0d5dd";
  // Read from the stylesheet: these used to be literals here AND in the CSS, and the charts
  // were still drawing the accent from two palettes ago after the tokens changed.
  var TEMPC = seriesColor("temp"), PWRC = seriesColor("power");
  var padL = 48, padR = 48, padT = 24, padB = 32, s = (run && run.samples) || [];
  if (!s.length) { g.fillStyle = ink; g.font = "12px sans-serif"; g.textAlign = "center"; g.fillText("No data yet - start plasma, or press Start recording.", W / 2, H / 2); return; }
  var maxT = Math.max(10, ...s.map(p => p.t)), maxTemp = Math.max(100, ...s.map(p => p.temp || 0)), maxPwr = Math.max(10, ...s.map(p => p.pwr || 0));
  var x = t => padL + (t / maxT) * (W - padL - padR);
  var yT = v => H - padB - ((v || 0) / maxTemp) * (H - padT - padB);
  var yP = v => H - padB - ((v || 0) / maxPwr) * (H - padT - padB);
  // dotted light-grey horizontal grid lines (inner only); background stays white
  g.strokeStyle = grid; g.lineWidth = 1; g.setLineDash([1, 4]);
  g.beginPath(); for (var k = 1; k < 4; k++) { var yy = padT + k * (H - padT - padB) / 4; g.moveTo(padL, yy); g.lineTo(W - padR, yy); } g.stroke();
  g.setLineDash([]);
  // plasma-ON as a slim track along the TOP, not a full-height background wash
  var tY = 6, tH = 7;
  g.fillStyle = dark ? "#2a1d1d" : "#f0dede"; g.fillRect(padL, tY, W - padL - padR, tH);   // faint track baseline
  g.fillStyle = TEMPC; var on = null;
  for (var i = 0; i < s.length; i++) { if (s[i].plasma && on == null) on = s[i].t; if (!s[i].plasma && on != null) { g.fillRect(x(on), tY, Math.max(1, x(s[i].t) - x(on)), tH); on = null; } }
  if (on != null) g.fillRect(x(on), tY, Math.max(1, x(maxT) - x(on)), tH);
  g.fillStyle = ink; g.font = "9px ui-monospace,monospace"; g.textAlign = "right"; g.fillText("plasma on", W - padR, tY - 1);
  // axis frame (solid, thin)
  g.strokeStyle = ink; g.lineWidth = 1; g.beginPath(); g.moveTo(padL, padT); g.lineTo(padL, H - padB); g.lineTo(W - padR, H - padB); g.moveTo(W - padR, padT); g.lineTo(W - padR, H - padB); g.stroke();
  // tick labels: left = temperature (red), right = power (blue)
  g.font = "10px ui-monospace,monospace";
  g.fillStyle = TEMPC; g.textAlign = "right"; for (var a = 0; a <= 4; a++) { var y2 = padT + a * (H - padT - padB) / 4; g.fillText(Math.round(maxTemp * (1 - a / 4)), padL - 5, y2 + 3); }
  g.fillStyle = PWRC; g.textAlign = "left"; for (var b2 = 0; b2 <= 4; b2++) { var y3 = padT + b2 * (H - padT - padB) / 4; g.fillText(Math.round(maxPwr * (1 - b2 / 4)), W - padR + 5, y3 + 3); }
  // axis titles
  g.fillStyle = ink; g.font = "10px sans-serif"; g.textAlign = "center";
  g.fillText("seconds", W / 2, H - padB + 24);
  g.fillText("0", padL, H - padB + 13); g.fillText(String(Math.round(maxT)), W - padR, H - padB + 13);
  g.save(); g.translate(12, H / 2); g.rotate(-Math.PI / 2); g.fillStyle = TEMPC; g.textAlign = "center"; g.fillText("Temperature (F)", 0, 0); g.restore();
  g.save(); g.translate(W - 9, H / 2); g.rotate(Math.PI / 2); g.fillStyle = PWRC; g.textAlign = "center"; g.fillText("Power (W)", 0, 0); g.restore();
  // data lines
  var line = function (col, yf, key) { g.strokeStyle = col; g.lineWidth = 1.8; g.beginPath(); var started = false; for (var q = 0; q < s.length; q++) { var p = s[q]; if (p[key] == null) continue; var X = x(p.t), Y = yf(p[key]); if (!started) { g.moveTo(X, Y); started = true; } else g.lineTo(X, Y); } g.stroke(); };
  line(TEMPC, yT, "temp"); line(PWRC, yP, "pwr");
  // feedback when a saved run captured no temperature/power (device wasn't streaming)
  if (!s.some(p => p.temp != null || p.pwr != null)) { g.fillStyle = ink; g.font = "11px sans-serif"; g.textAlign = "center"; g.fillText("(this run captured no temperature/power - the Opta was not streaming)", W / 2, (padT + H - padB) / 2); }
}
function dlEsc(s) { var d = document.createElement("div"); d.textContent = s == null ? "" : s; return d.innerHTML; }
function dlRenderRuns() {
  var el = $("#dl-runs"); if (!el) return;
  if (!dlRuns.length) { el.innerHTML = '<p class="sub" style="margin:0">No runs recorded yet.</p>'; return; }
  el.innerHTML = "";
  dlRuns.slice().reverse().forEach(function (r, ri) {
    var idx = dlRuns.length - 1 - ri, dur = ((r.ended || Date.now()) - r.started) / 1000;
    var maxTemp = Math.max(0, ...r.samples.map(p => p.temp || 0)), onCnt = r.samples.filter(p => p.plasma).length;
    var row = document.createElement("div"); row.style = "display:flex;align-items:center;gap:12px;padding:7px 0;border-bottom:1px solid var(--line)";
    var info = document.createElement("div"); info.style = "flex:1";
    info.innerHTML = "<b>" + dlEsc(r.name) + "</b> <span style='font-size:12px;color:var(--muted)'>" + (r.labware && r.labware.label ? dlEsc(r.labware.label) + " &middot; " : "") + Math.round(dur) + "s &middot; max " + Math.round(maxTemp) + "&deg;F &middot; plasma ~" + onCnt + "s</span>";
    var view = document.createElement("button"); view.className = "ghost"; view.textContent = "View"; view.style = "padding:3px 10px";
    view.onclick = function () { dlView = idx; var t = $("#dl-graph-title"); if (t) t.textContent = " - " + r.name; dlDrawChart(r); };
    var del = document.createElement("button"); del.className = "ghost"; del.textContent = "Delete"; del.style = "padding:3px 10px";
    del.onclick = function () { dlRuns.splice(idx, 1); dlSave(); dlRenderRuns(); if (dlView === idx) { dlView = null; dlRedraw(); } else if (dlView != null && dlView > idx) { dlView--; } };
    row.appendChild(info); row.appendChild(view); row.appendChild(del); el.appendChild(row);
  });
}
// Per-plate (per-run) HEAT + PROCESS analysis, computed from the recorded samples
// (each sample = {t seconds, temp F, pwr W, vac %, plasma 0/1}). Energy is the integral of power
// over time (watt-seconds = joules); durations sum the gap to the next sample so a slow/uneven
// sample rate still totals correctly.
function dlAnalyze(r) {
  var s = (r && r.samples) || [], n = s.length;
  var o = { name: r ? r.name : "", samples: n, duration_s: 0, plasma_on_s: 0,
            temp_min: null, temp_max: null, temp_avg: null, peak_temp_at_s: null,
            power_peak: 0, power_avg: null, energy_J: 0, vacuum_avg: null };
  if (!n) return o;
  o.duration_s = +(s[n - 1].t - s[0].t).toFixed(1);
  var tsum = 0, tc = 0, psum = 0, pc = 0, vsum = 0, vc = 0;
  for (var i = 0; i < n; i++) {
    var p = s[i], dt = (i < n - 1) ? Math.max(0, s[i + 1].t - p.t) : 0;   // seconds to the next sample
    if (p.temp != null) {
      if (o.temp_min == null || p.temp < o.temp_min) o.temp_min = p.temp;
      if (o.temp_max == null || p.temp > o.temp_max) { o.temp_max = p.temp; o.peak_temp_at_s = p.t; }
      tsum += p.temp; tc++;
    }
    if (p.pwr != null) {
      if (p.pwr > o.power_peak) o.power_peak = p.pwr;
      o.energy_J += p.pwr * dt;                      // integral P dt
      if (p.plasma) { psum += p.pwr; pc++; }         // average power WHILE firing
    }
    if (p.vac != null) { vsum += p.vac; vc++; }
    if (p.plasma) o.plasma_on_s += dt;
  }
  o.temp_avg   = tc ? +(tsum / tc).toFixed(1) : null;
  o.power_avg  = pc ? +(psum / pc).toFixed(1) : null;
  o.vacuum_avg = vc ? +(vsum / vc).toFixed(1) : null;
  o.energy_J   = +o.energy_J.toFixed(1);
  o.plasma_on_s = +o.plasma_on_s.toFixed(1);
  return o;
}
// CSV quoting, which is not JSON quoting. JSON.stringify escapes a quote as a backslash-quote
// and a newline as backslash-n, and a spreadsheet renders both literally: a run named  Bay "3"
// came out as  Bay \"3\" . CSV doubles the quote instead, and a newline inside the quotes is
// simply itself.
// The leading-apostrophe guard is for spreadsheets that EXECUTE a cell starting with = + - or @.
// An operator's run name lands in this file, so it must not be able to arrive as a formula.
function _dlCell(v) {
  if (v == null) return "";
  if (typeof v !== "string") return v;
  var s = /^[=+\-@\t\r]/.test(v) ? "'" + v : v;
  return '"' + s.replace(/"/g, '""') + '"';
}
function dlExportCSV() {
  var runs = dlView != null ? [dlRuns[dlView]] : (dlActive ? [dlActive] : dlRuns); runs = runs.filter(Boolean);
  if (!runs.length) return banner("No run to export yet.");
  var L = ["IFS Control Suite - plate data with heat + process analysis", ""];
  // ANALYSIS SUMMARY: one row per plate/run - heat (temp) + process (power/energy/vacuum) metrics.
  L.push("ANALYSIS SUMMARY");
  L.push("run,labware,labware_wells,duration_s,plasma_on_s,temp_min_F,temp_max_F,temp_avg_F,peak_temp_at_s,power_peak_W,power_avg_W,energy_J,vacuum_avg_pct,samples");
  runs.forEach(function (r) { var a = dlAnalyze(r), lw = r.labware || null;
    L.push([_dlCell(a.name), _dlCell(lw ? lw.label : ""), _dlCell(lw && lw.wells ? lw.wells : ""),
            a.duration_s, a.plasma_on_s, _dlCell(a.temp_min), _dlCell(a.temp_max), _dlCell(a.temp_avg),
            _dlCell(a.peak_temp_at_s), a.power_peak, _dlCell(a.power_avg), a.energy_J, _dlCell(a.vacuum_avg), a.samples].join(",")); });
  // TIME SERIES: the raw per-second samples behind the analysis.
  L.push("", "TIME SERIES", "run,seconds,temp_F,power_W,vacuum_pct,plasma");
  runs.forEach(function (r) { (r.samples || []).forEach(function (p) {
    L.push([_dlCell(r.name), p.t, _dlCell(p.temp), _dlCell(p.pwr), _dlCell(p.vac), p.plasma ? 1 : 0].join(",")); }); });
  var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([L.join("\n") + "\n"], { type: "text/csv" }));
  var stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  a.download = "ifs_plate_analysis_" + stamp + ".csv"; a.click();
}
if ($("#dl-rec")) $("#dl-rec").onclick = function () { if (dlActive) dlStop(); else dlStart(($("#dl-name") || {}).value); };
if ($("#dl-serial-set")) $("#dl-serial-set").onclick = function () {
  var v = $("#dl-serial"); if (!v) return;
  var n = parseInt(v.value, 10); if (isNaN(n)) return banner("Enter a numeric serial number.");
  send("setserial " + n);   // the Opta is the AUTHORITATIVE store (handles the full serial + persists it)
  // The display's serial is a 16-bit var - it can only hold 0..9999 without wrapping to a garbage
  // negative (that is the -31024). Only mirror short serials into it; the app shows the Opta value
  // regardless, so a real 6-digit serial lives on the Opta and the display simply isn't written.
  if (n >= 0 && n <= 9999) fetch("/api/tc/serial", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ serial: n }) })
      .then(r => r.json()).then(function (r) { if (!r || !r.ok) banner("Controller serial sent, but the display mirror was not accepted" + (r && r.error ? ": " + r.error : ".")); }).catch(function () {});
  ok("Serial " + n + " sent to the controller.");   // "sent": the console ACK returns asynchronously in the serial log
};
if ($("#dl-export")) $("#dl-export").onclick = dlExportCSV;
if ($("#dl-clear")) $("#dl-clear").onclick = function () { if (confirm("Delete all saved runs?")) { dlRuns = []; dlSave(); dlRenderRuns(); dlView = null; dlRedraw(); } };
/* ---------- Labware formats (ANSI/SLAS microplate standard) ----------
   Every gantry / lab-automation vendor builds to the ANSI SLAS footprint standard (SLAS 1-2004
   dimensions, SLAS 4-2004 well positions): a 127.76 x 85.48 mm footprint shared by microplates,
   pin tools and pipette-tip racks. This is the full family a sweep gantry handles. Each format is
   a saved cleaning RECIPE - carriage positions (door / row 1 / last) + plasma time - because the
   station sweeps the plasma knife across the piece; the operator calibrates each format once and
   it is stored per-format. The chosen format also tags the Data Log run and its CSV. */
var LW_FOOT = "127.76 x 85.48 mm";   // ANSI SLAS 1-2004 footprint - common to all SBS labware below
var LABWARE = [
  // --- Microplates (SLAS 4-2004 well densities) ---  rows x cols, well pitch (mm)
  { id: "mp6",    cat: "Microplate", label: "6-well plate",          rows: 2,  cols: 3,  wells: 6,    pitch: 39.12 },
  { id: "mp12",   cat: "Microplate", label: "12-well plate",         rows: 3,  cols: 4,  wells: 12,   pitch: 26.01 },
  { id: "mp24",   cat: "Microplate", label: "24-well plate",         rows: 4,  cols: 6,  wells: 24,   pitch: 19.30 },
  { id: "mp48",   cat: "Microplate", label: "48-well plate",         rows: 6,  cols: 8,  wells: 48,   pitch: 13.00 },
  { id: "mp96",   cat: "Microplate", label: "96-well plate",         rows: 8,  cols: 12, wells: 96,   pitch: 9.00 },
  { id: "mp96dw", cat: "Microplate", label: "96-well deep-well block",rows: 8, cols: 12, wells: 96,   pitch: 9.00,  note: "tall - check knife clearance" },
  { id: "mp96pcr",cat: "Microplate", label: "96-well PCR / low-profile",rows:8,cols: 12, wells: 96,   pitch: 9.00,  note: "low profile" },
  { id: "mp384",  cat: "Microplate", label: "384-well plate",        rows: 16, cols: 24, wells: 384,  pitch: 4.50 },
  { id: "mp384lv",cat: "Microplate", label: "384-well low-volume",   rows: 16, cols: 24, wells: 384,  pitch: 4.50,  note: "low volume" },
  { id: "mp1536", cat: "Microplate", label: "1536-well plate",       rows: 32, cols: 48, wells: 1536, pitch: 2.25 },
  { id: "mp24dw", cat: "Microplate", label: "24-well deep-well block",rows: 4,  cols: 6,  wells: 24,   pitch: 19.30, note: "deep well - check knife clearance" },
  { id: "mp96ha", cat: "Microplate", label: "96-well half-area",     rows: 8,  cols: 12, wells: 96,   pitch: 9.00,  note: "half-area" },
  { id: "mp96flt",cat: "Microplate", label: "96-well filter / membrane",rows:8,cols: 12, wells: 96,   pitch: 9.00,  note: "filter / membrane" },
  { id: "mp96sk", cat: "Microplate", label: "96-well skirted PCR",   rows: 8,  cols: 12, wells: 96,   pitch: 9.00,  note: "full-skirted PCR" },
  { id: "mp8strip",cat:"Microplate", label: "PCR 8-tube strips (in SBS rack)",rows:8,cols:12,wells:96, pitch: 9.00,  note: "8-tube strips" },
  { id: "mp384dw",cat: "Microplate", label: "384-well deep-well",    rows: 16, cols: 24, wells: 384,  pitch: 4.50,  note: "deep well" },
  { id: "mpres",  cat: "Microplate", label: "Reservoir (single-well SBS)",rows:1,cols: 1, wells: 1,   pitch: 0 },
  // --- Pin tools / replicators (pitch matches the plate they mate to) ---
  { id: "pin96",  cat: "Pin tool",   label: "96-pin replicator",     rows: 8,  cols: 12, wells: 96,   pitch: 9.00 },
  { id: "pin384", cat: "Pin tool",   label: "384-pin replicator",    rows: 16, cols: 24, wells: 384,  pitch: 4.50 },
  { id: "pin1536",cat: "Pin tool",   label: "1536-pin replicator",   rows: 32, cols: 48, wells: 1536, pitch: 2.25 },
  // --- Pipette-tip racks (SBS format; tip volume 10-1000 uL shares the rack footprint) ---
  { id: "tip96",  cat: "Tip rack",   label: "96 pipette-tip rack",   rows: 8,  cols: 12, wells: 96,   pitch: 9.00 },
  { id: "tip384", cat: "Tip rack",   label: "384 pipette-tip rack",  rows: 16, cols: 24, wells: 384,  pitch: 4.50 },
  // --- Slides / glass (non-SBS footprints; common plasma-clean targets) ---
  { id: "slide",  cat: "Slide / glass", label: "Microscope slide",   rows: 0,  cols: 0,  wells: 0,    pitch: 0, foot: "75.5 x 25 mm", note: "ISO 8037 plain glass" },
  { id: "sliderack",cat:"Slide / glass",label: "Slide rack (SBS holder)",rows:0,cols: 0, wells: 0,    pitch: 0, note: "holds multiple slides" },
  { id: "coverslip",cat:"Slide / glass",label: "Coverslip",          rows: 0,  cols: 0,  wells: 0,    pitch: 0, foot: "22 x 22 mm", note: "glass" },
  // --- Custom (footprint may differ; positions fully operator-defined) ---
  { id: "custom", cat: "Custom",     label: "Custom / other",        rows: 0,  cols: 0,  wells: 0,    pitch: 0,     note: "operator-defined; footprint may differ from SBS" }
];
function lwById(id) { for (var i = 0; i < LABWARE.length; i++) if (LABWARE[i].id === id) return LABWARE[i]; return null; }
var LW_SEL_KEY = "ifs_labware_sel", LW_REC_KEY = "ifs_labware_recipes", LW_BC_KEY = "ifs_labware_barcodes";
var _lwLastScan = "";
function lwBarcodes() { try { return JSON.parse(localStorage.getItem(LW_BC_KEY) || "{}") || {}; } catch (e) { return {}; } }
function lwSaveBarcodes(o) { try { localStorage.setItem(LW_BC_KEY, JSON.stringify(o)); } catch (e) {} }
function lwScanInfo(msg) { var e = $("#lw-scan-info"); if (e) e.textContent = msg; }
function lwRecipes() { try { return JSON.parse(localStorage.getItem(LW_REC_KEY) || "{}") || {}; } catch (e) { return {}; } }
function lwSaveRecipes(o) { try { localStorage.setItem(LW_REC_KEY, JSON.stringify(o)); } catch (e) {} }
function lwCurrent() {   // {id,label,cat,wells,rows,cols,pitch} of the selected format, or null
  var s = $("#lw-select"); if (!s || !s.value) return null; var d = lwById(s.value); if (!d) return null;
  return { id: d.id, label: d.label, cat: d.cat, wells: d.wells, rows: d.rows, cols: d.cols, pitch: d.pitch };
}
function lwGeom(d) {
  if (!d) return "-";
  if (d.id === "custom") return "Custom / other - footprint and positions are operator-defined.";
  var foot = d.foot || LW_FOOT, std = d.foot ? "" : " (ANSI/SLAS)";
  if (d.wells <= 1) return d.cat + " - " + foot + " footprint" + std + (d.note ? " - " + d.note : "") + ".";
  return d.cat + " - " + d.rows + " x " + d.cols + " (" + d.wells + "), " + d.pitch.toFixed(2) + " mm pitch, " + foot + " footprint" + std + (d.note ? " - " + d.note : "") + ".";
}
function lwRenderInfo() {
  var info = $("#lw-info"), d = lwById(($("#lw-select") || {}).value); if (!info) return;
  if (!d) { info.textContent = ""; return; }      // nothing chosen: say nothing (a lone dash read as a glitch)
  var rec = lwRecipes()[d.id];
  var txt = lwGeom(d);
  if (rec) txt += "  Recipe: door " + rec.door + ", row 1 " + rec.pos1 + ", last " + rec.last + ", plasma " + Math.round((rec.timeMs || 0) / 1000) + " s. Loaded into the fields below - unlock and Apply to send.";
  else txt += "  No recipe saved yet - set the positions and plasma time below, then Save.";
  var bc = lwBarcodes(), codes = Object.keys(bc).filter(function (c) { return bc[c] === d.id; });
  if (codes.length) txt += "  Barcodes: " + codes.slice(0, 4).join(", ") + (codes.length > 4 ? " +" + (codes.length - 4) + " more" : "") + ".";
  info.textContent = txt;
}
function lwApplyRecipeToFields(d) {   // populate the config fields from a saved recipe (positions stay locked; time is appliable)
  var rec = lwRecipes()[d.id]; if (!rec) return;
  var f = function (id, v) { var e = $(id); if (e && v != null) e.value = v; };
  f("#c-door", rec.door); f("#c-pos1", rec.pos1); f("#c-last", rec.last); f("#c-time", rec.timeMs);
}
function lwOnSelect() {
  var s = $("#lw-select"); if (!s) return;
  try { localStorage.setItem(LW_SEL_KEY, s.value); } catch (e) {}
  var d = lwById(s.value); if (d) lwApplyRecipeToFields(d);
  lwRenderInfo();
}
function lwPopulate() {
  var s = $("#lw-select"); if (!s) return;
  var cats = [], byCat = {};
  LABWARE.forEach(function (d) { if (!byCat[d.cat]) { byCat[d.cat] = []; cats.push(d.cat); } byCat[d.cat].push(d); });
  var html = '<option value="">(none selected)</option>';
  cats.forEach(function (c) { html += '<optgroup label="' + c + '">';
    byCat[c].forEach(function (d) { html += '<option value="' + d.id + '">' + d.label + '</option>'; });
    html += "</optgroup>"; });
  s.innerHTML = html;
  try { var sel = localStorage.getItem(LW_SEL_KEY); if (sel && lwById(sel)) s.value = sel; } catch (e) {}
  s.onchange = lwOnSelect;
  if (s.value) { var d = lwById(s.value); if (d) lwApplyRecipeToFields(d); }
  lwRenderInfo();
}
if ($("#lw-save")) $("#lw-save").onclick = function () {
  var s = $("#lw-select"); if (!s || !s.value) return banner("Pick a labware format first.");
  var g = function (id) { var e = $(id); return e ? parseInt(e.value, 10) : NaN; };
  var door = g("#c-door"), pos1 = g("#c-pos1"), last = g("#c-last"), timeMs = g("#c-time");
  if ([door, pos1, last, timeMs].some(function (v) { return isNaN(v); })) return banner("Positions or plasma time are blank - fill them in below first.");
  var o = lwRecipes(); o[s.value] = { door: door, pos1: pos1, last: last, timeMs: timeMs }; lwSaveRecipes(o);
  lwRenderInfo(); ok("Recipe saved for " + (lwById(s.value) || {}).label + ".");
};
if ($("#lw-clear")) $("#lw-clear").onclick = function () {
  var s = $("#lw-select"); if (!s || !s.value) return;
  var o = lwRecipes(); if (o[s.value]) { delete o[s.value]; lwSaveRecipes(o); lwRenderInfo(); ok("Recipe cleared."); }
};
lwPopulate();

/* ---------- Barcode MATCH RULES (map a whole family of plates to a format at once) ----------
   A rule matches by prefix ("starts with") or substring ("contains"). bcOnScan resolves a scan as:
   exact assignment first, then the most-specific (longest-text) matching rule. Lets one rule cover
   every plate whose barcode shares a prefix, instead of assigning each barcode individually. */
var LW_RULE_KEY = "ifs_labware_rules";
function lwRules() { try { return JSON.parse(localStorage.getItem(LW_RULE_KEY) || "[]") || []; } catch (e) { return []; } }
function lwSaveRules(a) { try { localStorage.setItem(LW_RULE_KEY, JSON.stringify(a)); } catch (e) {} }
function lwMatchRule(code) {
  var best = null;
  lwRules().forEach(function (r) {
    if (!r || !r.text || !lwById(r.fid)) return;
    var hit;
    if (r.type === "contains") hit = code.indexOf(r.text) >= 0;
    else if (r.type === "regex") { try { hit = new RegExp(r.text).test(code); } catch (e) { hit = false; } }
    else hit = code.indexOf(r.text) === 0;   // prefix
    if (hit && (!best || r.text.length > best.text.length)) best = r;   // most-specific rule wins
  });
  return best ? best.fid : null;
}
// Opt-in fallback: pull a well-count token out of the barcode when nothing else matched. The number
// must be delimited (string edge or a non-digit on both sides), so an embedded "...0096..." serial
// does NOT false-match; largest counts are tried first.
function lwAutoWells(code) {
  if (!code) return null;
  var m = String(code).match(/(?:^|[^0-9])(1536|384|96|48|24|12|6)(?:[^0-9]|$)/);
  if (!m) return null;
  var id = "mp" + m[1];
  return lwById(id) ? id : null;
}
function lwRenderRules() {
  var el = $("#lw-rule-list"); if (!el) return;
  var rs = lwRules();
  if (!rs.length) { el.textContent = "No match rules yet."; return; }
  el.innerHTML = "Rules: ";
  rs.forEach(function (r, i) {
    var f = lwById(r.fid), span = document.createElement("span");
    span.style = "display:inline-block;border:1px solid var(--line-d);border-radius:2px;padding:1px 6px;margin:0 6px 4px 0";
    span.appendChild(document.createTextNode((r.type === "contains" ? "contains " : "starts ") + '"' + r.text + '" -> ' + (f ? f.label : r.fid) + " "));
    var x = document.createElement("a"); x.href = "#"; x.textContent = "x"; x.style = "margin-left:4px;text-decoration:none;font-weight:600";
    x.onclick = function (e) { e.preventDefault(); var a = lwRules(); a.splice(i, 1); lwSaveRules(a); lwRenderRules(); };
    span.appendChild(x); el.appendChild(span);
  });
}
if ($("#lw-rule-add")) $("#lw-rule-add").onclick = function () {
  var sel = $("#lw-select"); if (!sel || !sel.value) return banner("Pick the labware format first.");
  var text = (($("#lw-rule-text") || {}).value || "").trim(); if (!text) return banner("Enter the text the barcodes share (e.g. a common prefix).");
  var type = ($("#lw-rule-type") || {}).value || "prefix";
  if (type === "regex") { try { new RegExp(text); } catch (e) { return banner("That regex is not valid: " + e.message); } }
  var a = lwRules(); a.push({ type: type, text: text, fid: sel.value }); lwSaveRules(a);
  $("#lw-rule-text").value = ""; lwRenderRules();
  var f = lwById(sel.value); ok("Rule added: " + type + ' "' + text + '" -> ' + (f ? f.label : sel.value) + ".");
};
lwRenderRules();

/* ---------- Export / import the whole labware config (recipes + barcode map + rules) ----------
   For provisioning multiple stations or backing up: one JSON file carries every recipe, barcode
   assignment and match rule so another IFS can import the same setup. */
function lwExportConfig() {
  var cfg = { v: 1, app: "IFS labware config", recipes: lwRecipes(), barcodes: lwBarcodes(), rules: lwRules() };
  var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(cfg, null, 2)], { type: "application/json" }));
  a.download = "ifs_labware_config.json"; a.click();
}
function lwImportConfig(text) {
  var c; try { c = JSON.parse(text); } catch (e) { return banner("Import failed - not valid JSON."); }
  if (!c || typeof c !== "object") return banner("Import failed - unexpected file.");
  if (c.recipes) lwSaveRecipes(c.recipes);
  if (c.barcodes) lwSaveBarcodes(c.barcodes);
  if (c.rules) lwSaveRules(c.rules);
  lwRenderRules(); lwRenderInfo(); ok("Labware config imported (recipes, barcodes and rules).");
}
if ($("#lw-export")) $("#lw-export").onclick = lwExportConfig;
if ($("#lw-import")) $("#lw-import").onclick = function () { var f = $("#lw-import-file"); if (f) f.click(); };
if ($("#lw-import-file")) $("#lw-import-file").onchange = function (e) {
  var file = e.target.files && e.target.files[0]; if (!file) return;
  var rd = new FileReader(); rd.onload = function () { lwImportConfig(String(rd.result)); e.target.value = ""; }; rd.readAsText(file);
};

/* ---------- Built-in barcode scanner (generic USB HID keyboard-wedge) ----------
   Works with virtually any generic USB barcode scanner in its default keyboard/HID mode - no
   vendor driver, no COM port, no configuration. A scanner "types" the barcode as a very fast
   keystroke burst terminated by Enter; humans type far slower. We detect that burst by its
   inter-key speed and route the code to the Data Log run name so a scan tags the plate/run.
   When the operator is in a text field we stay out of the way and let the scanner type into it
   natively (the documented manual flow), so there is never double entry. */
var BC_MAX_GAP = 40;    // ms between keys; slower than this is human typing, not a scanner
var BC_MIN_LEN = 3;     // ignore stray short bursts
var _bcBuf = "", _bcLast = 0, _bcFast = true;
function _bcEnabled() { var c = $("#dl-scan"); return !c || c.checked; }
function _bcEditable(el) {
  if (!el) return false;
  var t = (el.tagName || "").toUpperCase();
  return t === "INPUT" || t === "TEXTAREA" || t === "SELECT" || el.isContentEditable;
}
function bcOnScan(code) {
  code = (code || "").replace(/\s+$/, ""); if (!code) return;
  _lwLastScan = code;
  var nm = $("#dl-name"); if (nm) nm.value = code;                 // tag the run
  var ls = $("#lw-scan-last"); if (ls) ls.value = code;
  // Identify the plate: exact assignment first, then the best match rule, then (opt-in) well-count auto-detect.
  var map = lwBarcodes(), fid = null, via = "";
  if (map[code]) { fid = map[code]; }
  else if (typeof lwMatchRule === "function" && (fid = lwMatchRule(code))) { via = " (matched by rule)"; }
  else { var aw = $("#lw-auto-wells"); if (aw && aw.checked) { fid = lwAutoWells(code); if (fid) via = " (well count detected)"; } }
  var fmt = fid && lwById(fid);
  if (fmt) {
    var s = $("#lw-select"); if (s) { s.value = fid; lwOnSelect(); }
    lwScanInfo("Scanned " + code + " -> " + fmt.label + via + " (format selected, recipe loaded).");
    banner("Plate identified: " + fmt.label);
  } else {
    lwScanInfo("Scanned " + code + " - not assigned to a format yet. Pick the format above, then Assign last scan.");
    banner("Barcode scanned: " + code + " (unassigned)");
  }
  var p = $("#dl-scan-pill"); if (p) { p.style.display = ""; p.className = "pill warn"; p.querySelector("span:last-child").textContent = code.slice(0, 24); }
  var auto = $("#dl-auto");                                        // hands-off: start a tagged run when idle
  if (auto && auto.checked && !dlActive) dlStart(code);
}
document.addEventListener("keydown", function (e) {
  if (!_bcEnabled()) return;
  if (_bcEditable(document.activeElement)) return;          // in a field: let the scanner type natively
  if (e.ctrlKey || e.altKey || e.metaKey) { _bcBuf = ""; return; }
  var now = e.timeStamp || Date.now(), gap = now - _bcLast; _bcLast = now;
  if (e.key === "Enter") {
    if (_bcBuf.length >= BC_MIN_LEN && _bcFast) { var c = _bcBuf; _bcBuf = ""; _bcFast = true; e.preventDefault(); bcOnScan(c); }
    else { _bcBuf = ""; _bcFast = true; }
    return;
  }
  if (e.key && e.key.length === 1) {
    if (_bcBuf.length && gap > BC_MAX_GAP) { _bcBuf = ""; _bcFast = true; }   // too slow -> not a scan; restart
    if (_bcBuf.length) _bcFast = _bcFast && (gap <= BC_MAX_GAP);
    _bcBuf += e.key;
  } else { _bcBuf = ""; _bcFast = true; }                    // any non-character key aborts the burst
}, true);

/* ---------- Scanner connection (serial VCP) + Test / Assign, on the Labware panel ----------
   Serial-mode scanners connect through the backend, which opens the COM port, reads the CR/LF code,
   and reserves the port from device auto-connect. New scans (serial OR USB-HID) run through bcOnScan,
   which identifies the plate from the learned barcode->format map. Test reads the last scan on demand;
   Assign teaches the map. */
var _scanConnected = false, _scanSeenTs = 0;
function _scanPill(on) {
  var p = $("#lw-scan-pill"); if (p) { p.className = "pill " + (on ? "ok" : ""); p.querySelector("span:last-child").textContent = on ? "connected" : "not connected"; }
  var b = $("#lw-scan-conn"); if (b) b.textContent = on ? "Disconnect scanner" : "Connect scanner";
}
if ($("#lw-scan-conn")) $("#lw-scan-conn").onclick = async function () {
  try {
    if (_scanConnected) { await fetch("/api/scanner/disconnect", { method: "POST" }); _scanConnected = false; _scanPill(false); return; }
    var port = ($("#lw-scan-port") || {}).value;
    if (!port) return banner("Pick the scanner's COM port.");
    var r = await (await fetch("/api/scanner/connect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ port: port, baud: 9600 }) })).json();
    if (!r || !r.ok) return banner("Scanner: " + ((r && r.error) || "could not connect."));
    _scanConnected = true; _scanSeenTs = r.ts || 0; _scanPill(true); lwScanInfo("Scanner connected on " + port + ". Scan a plate.");
  } catch (e) { banner("Scanner: " + e); }
};
if ($("#lw-scan-test")) $("#lw-scan-test").onclick = async function () {
  // Read the most recent scan and show what it resolves to, without waiting for the next poll.
  if (_scanConnected) {
    try { var s = await (await fetch("/api/scanner/state")).json();
      if (s && s.last) { _scanSeenTs = s.ts || _scanSeenTs; bcOnScan(s.last); return; } } catch (e) {}
    return lwScanInfo("Scanner connected - scan a plate now; the result shows here.");
  }
  if (_lwLastScan) return bcOnScan(_lwLastScan);   // re-resolve the last HID scan
  lwScanInfo("No scan yet. Scan a plate (USB keyboard-mode scanners need no connection), or connect a serial scanner first.");
};
if ($("#lw-scan-assign")) $("#lw-scan-assign").onclick = function () {
  if (!_lwLastScan) return banner("Scan a barcode first (it appears in Last scan).");
  var sel = $("#lw-select"); if (!sel || !sel.value) return banner("Pick the labware format to assign this barcode to.");
  var o = lwBarcodes(); o[_lwLastScan] = sel.value; lwSaveBarcodes(o);
  var f = lwById(sel.value); lwScanInfo("Assigned " + _lwLastScan + " -> " + (f ? f.label : sel.value) + ". Future scans of this plate select it automatically.");
  ok("Barcode assigned to " + (f ? f.label : sel.value) + ".");
};
if ($("#lw-scan-unassign")) $("#lw-scan-unassign").onclick = function () {
  if (!_lwLastScan) return;
  var o = lwBarcodes(); if (o[_lwLastScan]) { delete o[_lwLastScan]; lwSaveBarcodes(o); lwScanInfo("Unassigned " + _lwLastScan + "."); ok("Barcode unassigned."); }
};
async function scanPoll() {
  if (!_scanConnected) return;
  try {
    var s = await (await fetch("/api/scanner/state")).json();
    if (!s || !s.connected) { _scanConnected = false; _scanPill(false); return; }
    if (s.ts && s.ts > _scanSeenTs) { _scanSeenTs = s.ts; if (s.last) bcOnScan(s.last); }   // new scan -> identify + tag
  } catch (e) {}
}
setInterval(scanPoll, 1000);

dlLoad(); dlRenderRuns();
setInterval(dlSample, 1000);

/* ---------- Tuning page: live Power / electrode Temp / Vacuum from the Tip Charger CSV ----------
   Same idea as the web power/temp scope, but fed from the Tip Charger's USB-RS232 stream. The backend
   already decodes each "Power,Temp,Vac" line into /api/tc/state .csv {power,temp,vac,t}; we poll it,
   append fresh readings, and draw three independently auto-scaled lines with per-second deltas so an
   operator can adjust frequency/voltage and watch the response. */
var tuneBuf = { t: [], power: [], temp: [], vac: [] };
var _tuneLastPushT = 0, TUNE_MAXPTS = 2400;
function tuneReset() { tuneBuf = { t: [], power: [], temp: [], vac: [] }; _tuneLastPushT = 0; tuneReadouts(); tuneDraw(); }
function tuneDelta(arr, tArr) {                       // change per second vs the reading ~1 s ago
  var n = arr.length; if (n < 2) return null;
  var last = arr[n - 1], lastT = tArr[n - 1];
  for (var i = n - 2; i >= 0; i--) { var dt = lastT - tArr[i]; if (dt >= 1.0) return (last == null || arr[i] == null) ? null : (last - arr[i]) / dt; }
  return null;
}
function tuneReadouts() {
  var n = tuneBuf.t.length;
  var put = function (id, val, did, d, unit) {
    var e = $(id); if (e) e.textContent = (n && val != null) ? val : "––";
    var de = $(did); if (de) de.textContent = (d == null) ? "" : ((d >= 0 ? "+" : "") + d.toFixed(1) + unit + "/s");
  };
  put("#tune-power", tuneBuf.power[n - 1], "#tune-power-d", tuneDelta(tuneBuf.power, tuneBuf.t), " W");
  put("#tune-temp",  tuneBuf.temp[n - 1],  "#tune-temp-d",  tuneDelta(tuneBuf.temp, tuneBuf.t), "");
  put("#tune-vac",   tuneBuf.vac[n - 1],   "#tune-vac-d",   tuneDelta(tuneBuf.vac, tuneBuf.t), "");
}
function tuneDraw() {
  var cv = $("#tune-canvas"); if (!cv || !cv.clientWidth) return;
  var dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
  var g = cv.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  var padL = 8, padR = 8, padT = 8, padB = 18;
  g.strokeStyle = "#e6e6e6"; g.lineWidth = 1;
  for (var gi = 0; gi <= 4; gi++) { var yy = padT + gi * (H - padT - padB) / 4; g.beginPath(); g.moveTo(padL, yy); g.lineTo(W - padR, yy); g.stroke(); }
  var win = parseInt(($("#tune-window") || {}).value || "120", 10);
  var now = tuneBuf.t.length ? tuneBuf.t[tuneBuf.t.length - 1] : Date.now() / 1000, t0 = now - win;
  var xOf = function (t) { return padL + (t - t0) / win * (W - padL - padR); };
  var series = function (col, arr) {
    var mn = Infinity, mx = -Infinity, any = false, i, v;
    for (i = 0; i < tuneBuf.t.length; i++) { if (tuneBuf.t[i] < t0) continue; v = arr[i]; if (v == null) continue; any = true; if (v < mn) mn = v; if (v > mx) mx = v; }
    if (!any) return;
    if (mx - mn < 1e-6) { mx = mn + 1; mn = mn - 1; }
    var pd = (mx - mn) * 0.12; mn -= pd; mx += pd;
    var yOf = function (val) { return padT + (1 - (val - mn) / (mx - mn)) * (H - padT - padB); };
    g.strokeStyle = col; g.lineWidth = 1.8; g.beginPath(); var started = false;
    for (i = 0; i < tuneBuf.t.length; i++) { if (tuneBuf.t[i] < t0) continue; v = arr[i]; if (v == null) { started = false; continue; } var X = xOf(tuneBuf.t[i]), Y = yOf(v); if (!started) { g.moveTo(X, Y); started = true; } else g.lineTo(X, Y); }
    g.stroke();
  };
  series(seriesColor("power"), tuneBuf.power); series(seriesColor("temp"), tuneBuf.temp);
  series(seriesColor("vac"), tuneBuf.vac);
  g.fillStyle = "#777"; g.font = "10px ui-monospace,monospace";
  g.textAlign = "left"; g.fillText("-" + win + "s", padL, H - 5);
  g.textAlign = "right"; g.fillText("now", W - padR, H - 5);
}
async function tunePoll() {
  if (!document.querySelector("#view-tune.active")) return;   // only while the Tuning page is open
  try {
    var s = await (await fetch("/api/tc/state")).json();
    var pill = $("#tune-pill"), lab = pill ? pill.querySelector("span:last-child") : null;
    var c = s && s.csv, fresh = c && c.t != null && (Date.now() / 1000 - c.t) < 4;
    if (fresh && c.t !== _tuneLastPushT) {                     // append only a genuinely new reading
      _tuneLastPushT = c.t;
      tuneBuf.t.push(Date.now() / 1000);
      tuneBuf.power.push(c.power == null ? null : c.power);
      tuneBuf.temp.push(c.temp == null ? null : c.temp);
      tuneBuf.vac.push(c.vac == null ? null : c.vac);
      while (tuneBuf.t.length > TUNE_MAXPTS) { tuneBuf.t.shift(); tuneBuf.power.shift(); tuneBuf.temp.shift(); tuneBuf.vac.shift(); }
    }
    if (pill) { if (fresh) { pill.className = "pill warn"; if (lab) lab.textContent = "live"; } else { pill.className = "pill"; if (lab) lab.textContent = (s && s.connected) ? "no data" : "not connected"; } }
    if (typeof tuneTcInfo === "function") tuneTcInfo(s);
    tuneReadouts(); tuneDraw();
  } catch (e) {}
}
/* ---------- Tip Charger USB selector on the Tuning page (pick which one when several are plugged in) ---------- */
async function tuneTcPorts() {
  try {
    var ports = await (await fetch("/api/ports")).json();
    var sel = $("#tune-tc-port"); if (sel) {
      var cur = sel.value; sel.innerHTML = ports.length ? "" : "<option value=''>no USB ports found</option>";
      ports.forEach(function (p) {
        var o = document.createElement("option"); o.value = p.device;
        o.textContent = p.device + (p.desc ? "  (" + p.desc + ")" : "") + (p.opta ? "  [controller]" : "");
        sel.appendChild(o);
      });
      if (cur) for (var i = 0; i < sel.options.length; i++) if (sel.options[i].value === cur) { sel.value = cur; break; }
    }
  } catch (e) {}
  try {   // warn when more than one Tip Charger is present (auto-connect won't guess between them)
    var ac = await (await fetch("/api/autoconnect")).json();
    var amb = (ac && ac.tc && ac.tc.ambiguous) || [];
    var ae = $("#tune-tc-amb");
    if (ae) { if (amb.length > 1) { ae.style.display = "block"; ae.textContent = "More than one Tip Charger is connected (" + amb.join(", ") + ") - auto-connect will not guess. Pick the one you want and press Connect."; } else { ae.style.display = "none"; } }
  } catch (e) {}
}
function tuneTcInfo(s) {
  var info = $("#tune-tc-info"); if (!info) return;
  if (s && s.connected) { info.textContent = "connected " + (s.info || "") + (s.live ? " · live" : " · no data"); info.style.color = s.live ? "var(--ok)" : "var(--warn)"; }
  else { info.textContent = "not connected"; info.style.color = "var(--muted)"; }
}
if ($("#tune-tc-connect")) $("#tune-tc-connect").onclick = async function () {
  var port = ($("#tune-tc-port") || {}).value;
  if (!port) return banner("Pick a Tip Charger USB port first.");
  var b = $("#tune-tc-connect"); b.disabled = true; b.textContent = "Connecting...";
  try {
    var r = await (await fetch("/api/tc/connect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "serial", port: port, baud: 9600 }) })).json();
    if (r && r.ok) ok("Tip Charger connected on " + port + ".");
    else banner("Could not connect " + port + (r && r.error ? ": " + r.error : "."));
  } catch (e) { banner("Connect: " + e); }
  finally { b.disabled = false; b.textContent = "Connect"; }
};
if ($("#tune-tc-rescan")) $("#tune-tc-rescan").onclick = tuneTcPorts;
if ($("#tune-window")) $("#tune-window").onchange = tuneDraw;
if ($("#tune-clear")) $("#tune-clear").onclick = tuneReset;
window.addEventListener("resize", function () { if (document.querySelector("#view-tune.active")) { tuneDraw(); tsDrawCharts(); } });
setInterval(tunePoll, 350);

/* ---------- Frequency tuning session: sweep + automated plasma/temp capture per frequency ----------
   Automates the paper tuning report: for each frequency the operator sets on the panel, Run point reads
   the electrode temperature (INIT), fires plasma for the plasma time while tracking peak wattage, reads
   the temperature again (FINAL -> dT), then cools. The display's own plasma max-on timer is the safety
   backstop; E-STOP cuts plasma + pump immediately via /api/tc/estop. */
var tsFreqs = [], tsIdx = 0, tsRows = [], tsBusy = false, tsAbort = false, tsTimers = [];
function tsG(id) { var e = $(id); return e ? e.value : ""; }
function tsNum(id, d) { var v = parseFloat(tsG(id)); return isFinite(v) ? v : d; }
async function tsReadCsv() { try { var s = await (await fetch("/api/tc/state")).json(); var c = s && s.csv; if (c && c.t != null && (Date.now() / 1000 - c.t) < 4) return c; } catch (e) {} return null; }
function tsSetPill(cls, txt) { var p = $("#ts-pill"); if (p) { p.className = "pill " + (cls || ""); p.querySelector("span:last-child").textContent = txt; } }
function tsSetPhase(label, secs, hide) {
  var p = $("#ts-phase"); if (!p) return;
  if (hide) { p.style.display = "none"; return; }
  p.style.display = ""; p.className = "pill " + (label === "plasma" ? "warn" : "info");
  p.querySelector("span:last-child").textContent = label + " " + secs + "s";
}
function tsUpdateCur() {
  var cf = $("#ts-curfreq"); if (cf) cf.textContent = tsFreqs.length ? tsFreqs[tsIdx] : "––";
  var pr = $("#ts-progress"); if (pr) pr.textContent = tsFreqs.length ? ("point " + (tsIdx + 1) + " of " + tsFreqs.length + " · " + tsRows.length + " captured") : "";
}
function tsBuild() {
  var a = Math.round(tsNum("#ts-start", 6000)), b = Math.round(tsNum("#ts-end", 8000)), st = Math.abs(Math.round(tsNum("#ts-step", 200))) || 200;
  if (b < a) { var t = a; a = b; b = t; }
  if ((b - a) / st > 1000) return banner("That is over 1000 steps - use a bigger step or a smaller range.");   // guard against a UI-freezing sweep from bad input
  tsFreqs = []; for (var f = a; f <= b + 0.001 && tsFreqs.length < 1001; f += st) tsFreqs.push(f);
  tsIdx = 0; tsUpdateCur();
  ok("Sweep built: " + tsFreqs.length + " frequencies (" + a + "-" + b + " Hz, step " + st + ").");
}
async function tsShowFreqScreen() {
  var n = Math.round(tsNum("#ts-freqform", 2));
  try {
    var r = await (await fetch("/api/tc/form", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ form: n }) })).json();
    if (r && r.ok) ok("Panel switched to form " + n + " - set the frequency to " + (tsFreqs.length ? tsFreqs[tsIdx] : "") + " Hz there.");
    else banner("Could not switch the panel" + (r && r.error ? ": " + r.error : ". Check the Freq screen form #."));
  } catch (e) { banner("Freq screen: " + e); }
}
async function tsPlasma(on) { try { var r = await (await fetch("/api/tc/plasma", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: on }) })).json(); return !!(r && r.ok); } catch (e) { return false; } }
function tsWait(secs, label, onTick) {
  return new Promise(function (resolve) {
    var end = Date.now() + secs * 1000;
    var iv = setInterval(async function () {
      if (tsAbort) { clearInterval(iv); resolve(false); return; }
      tsSetPhase(label, Math.max(0, Math.ceil((end - Date.now()) / 1000)));
      if (onTick) { try { await onTick(); } catch (e) {} }
      if (Date.now() >= end) { clearInterval(iv); resolve(true); }
    }, 500);
    tsTimers.push(iv);
  });
}
async function tsRunPoint() {
  if (tsBusy) return;
  if (!tsFreqs.length) return banner("Build the sweep first.");
  tsBusy = true; tsAbort = false; tsSetPill("warn", "running");
  var freq = tsFreqs[tsIdx];
  var initC = await tsReadCsv();
  if (!initC) { banner("No live temperature from the Tip Charger - connect it (the graph should read 'live') before running a point."); tsBusy = false; tsSetPill("", "idle"); return; }
  var initT = initC.temp, peakW = initC.power || 0;
  await tsPlasma(true);
  var done = await tsWait(Math.round(tsNum("#ts-plasma", 15)), "plasma", async function () { var c = await tsReadCsv(); if (c && c.power != null && c.power > peakW) peakW = c.power; });
  // tsPlasma returns whether the STOP was actually accepted. Discarding it meant a failed
  // plasma-off (link dropped, panel out of serial control) sailed on through cooling to
  // "point done" with the arc possibly still lit. Retry once, then stop the sweep and say so
  // - an unacknowledged stop is the one result that must never be reported as success.
  var off = await tsPlasma(false);
  if (!off) off = await tsPlasma(false);
  if (!off) {
    tsAbort = true; tsTimers.forEach(function (t) { clearInterval(t); }); tsTimers = [];
    tsBusy = false; tsSetPhase("", 0, true); tsSetPill("bad", "STOP NOT CONFIRMED");
    banner("Plasma STOP was not acknowledged by the Tip Charger. The sweep is stopped. "
         + "Check the panel now - the arc may still be lit - and kill it at the panel or the E-stop.");
    return;
  }
  if (!done) { tsBusy = false; tsSetPhase("", 0, true); tsSetPill("", "stopped"); return; }
  var fc = await tsReadCsv(), finalT = fc ? fc.temp : null;
  var dt = (finalT != null && initT != null) ? (finalT - initT) : null;
  tsRows.push({ freq: freq, init: initT, final: finalT, dt: dt, watt: peakW, dac: tsG("#ts-dac"), notes: "" });
  tsRenderTable(); tsDrawCharts(); tsReco();
  await tsWait(Math.round(tsNum("#ts-cool", 15)), "cooling");
  if (tsIdx < tsFreqs.length - 1) tsIdx++;
  tsUpdateCur(); tsSetPhase("", 0, true); tsBusy = false; tsSetPill("ok", "point done");
}
async function tsEstop() {
  tsAbort = true; tsTimers.forEach(function (t) { clearInterval(t); }); tsTimers = [];
  var sent = false;
  try { var r = await (await fetch("/api/tc/estop", { method: "POST" })).json(); sent = !!(r && r.ok); } catch (e) {}
  var off = await tsPlasma(false);                 // belt and braces behind the estop route
  if (!off) off = await tsPlasma(false);
  tsBusy = false; tsSetPhase("", 0, true); tsSetPill("bad", "E-STOP");
  // Neither the estop route nor the direct stop was acknowledged: this is the loudest case,
  // because the operator pressed E-STOP and nothing has confirmed the arc is out.
  if (!sent && !off) return banner("E-STOP pressed but NOTHING was acknowledged - the Tip Charger did not answer. "
                                 + "Assume the arc is still lit: kill it at the panel or cut power now.");
  if (sent) banner("E-STOP - plasma and pump commanded off.");
  else banner("E-STOP - the estop route did not answer, but the direct plasma STOP was accepted. "
            + "The pump was NOT commanded off. Confirm at the panel.");
}
function tsRenderTable() {
  var tb = $("#ts-tbody"); if (!tb) return;
  if (!tsRows.length) { tb.innerHTML = '<tr><td colspan="9" class="sub" style="padding:8px">No points yet. Build the sweep, set the frequency on the panel, then Run point.</td></tr>'; return; }
  tb.innerHTML = "";
  tsRows.forEach(function (r, i) {
    var tr = document.createElement("tr"); tr.style = "border-bottom:1px solid var(--line)";
    var cell = function (t) { var td = document.createElement("td"); td.style = "padding:4px 8px;font-family:ui-monospace,monospace"; td.textContent = t; return td; };
    tr.appendChild(cell(i + 1)); tr.appendChild(cell(r.freq));
    tr.appendChild(cell(r.init == null ? "-" : r.init)); tr.appendChild(cell(r.final == null ? "-" : r.final));
    var dtd = cell(r.dt == null ? "-" : (r.dt >= 0 ? "+" : "") + r.dt); dtd.style.fontWeight = "600"; tr.appendChild(dtd);
    tr.appendChild(cell(r.watt == null ? "-" : r.watt)); tr.appendChild(cell(r.dac || "-"));
    var ntd = document.createElement("td"); ntd.style = "padding:2px 8px";
    var ni = document.createElement("input"); ni.type = "text"; ni.value = r.notes || ""; ni.style = "width:120px"; ni.oninput = function () { r.notes = ni.value; }; ntd.appendChild(ni); tr.appendChild(ntd);
    var xtd = document.createElement("td"); var xb = document.createElement("button"); xb.className = "ghost"; xb.textContent = "x"; xb.style = "padding:2px 8px"; xb.onclick = function () { tsRows.splice(i, 1); tsRenderTable(); tsDrawCharts(); tsReco(); }; xtd.appendChild(xb); tr.appendChild(xtd);
    tb.appendChild(tr);
  });
}
function tsChart(cid, pts, col) {
  var cv = $(cid); if (!cv || !cv.clientWidth) return;
  var dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
  var g = cv.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  var padL = 34, padR = 10, padT = 10, padB = 20;
  g.strokeStyle = "#e6e6e6"; g.lineWidth = 1;
  for (var gi = 0; gi <= 4; gi++) { var yy = padT + gi * (H - padT - padB) / 4; g.beginPath(); g.moveTo(padL, yy); g.lineTo(W - padR, yy); g.stroke(); }
  if (pts.length < 2) { g.fillStyle = "#999"; g.font = "11px sans-serif"; g.textAlign = "center"; g.fillText("Enter at least 2 data points", W / 2, H / 2); return; }
  var xs = pts.map(function (p) { return p.x; }), ys = pts.map(function (p) { return p.y; });
  var xmn = Math.min.apply(null, xs), xmx = Math.max.apply(null, xs), ymn = Math.min.apply(null, ys), ymx = Math.max.apply(null, ys);
  if (xmx - xmn < 1e-6) xmx = xmn + 1; if (ymx - ymn < 1e-6) { ymx = ymn + 1; ymn = ymn - 1; }
  var yp = (ymx - ymn) * 0.12; ymn -= yp; ymx += yp;
  var X = function (v) { return padL + (v - xmn) / (xmx - xmn) * (W - padL - padR); };
  var Y = function (v) { return padT + (1 - (v - ymn) / (ymx - ymn)) * (H - padT - padB); };
  g.fillStyle = "#777"; g.font = "9px ui-monospace,monospace"; g.textAlign = "right";
  for (var a = 0; a <= 4; a++) { g.fillText((ymx - (ymx - ymn) * a / 4).toFixed(0), padL - 4, padT + a * (H - padT - padB) / 4 + 3); }
  g.textAlign = "left"; g.fillText(String(Math.round(xmn)), padL, H - 5); g.textAlign = "right"; g.fillText(String(Math.round(xmx)), W - padR, H - 5);
  var sorted = pts.slice().sort(function (p, q) { return p.x - q.x; });
  g.strokeStyle = col; g.lineWidth = 1.8; g.beginPath();
  sorted.forEach(function (p, i) { var x = X(p.x), y = Y(p.y); if (i === 0) g.moveTo(x, y); else g.lineTo(x, y); }); g.stroke();
  g.fillStyle = col; sorted.forEach(function (p) { g.beginPath(); g.arc(X(p.x), Y(p.y), 2.5, 0, 6.283); g.fill(); });
}
function tsDrawCharts() {
  tsChart("#ts-dtchart", tsRows.filter(function (r) { return r.dt != null; }).map(function (r) { return { x: r.freq, y: r.dt }; }), seriesColor("temp"));
  tsChart("#ts-wchart", tsRows.filter(function (r) { return r.watt != null; }).map(function (r) { return { x: r.freq, y: r.watt }; }), seriesColor("power"));
}
function tsReco() {
  var el = $("#ts-reco"); if (!el) return;
  var withDt = tsRows.filter(function (r) { return r.dt != null; });
  if (withDt.length < 2) { el.textContent = "Recommended frequency appears here once at least two points are captured."; return; }
  var best = withDt.reduce(function (a, b) { return b.dt > a.dt ? b : a; });
  el.textContent = "Best: " + best.freq + " Hz  (ΔT " + (best.dt >= 0 ? "+" : "") + best.dt + "°, " + best.watt + " W)";
}
function tsExport() {
  if (!tsRows.length) return banner("No data points to export.");
  var q = function (s) { return JSON.stringify(s == null ? "" : String(s)); };
  var L = ["IonField Systems - Tip Charger Frequency Tuning Report"];
  L.push("session," + q(tsG("#ts-title")) + ",operator," + q(tsG("#ts-op")));
  L.push("unit_serial," + q(tsG("#ts-unit")) + ",controller_serial," + q(tsG("#ts-ctrl")));
  L.push("gap," + q(tsG("#ts-gap")) + ",dac_v," + q(tsG("#ts-dac")));
  L.push("range," + q(tsG("#ts-start") + " to " + tsG("#ts-end") + " step " + tsG("#ts-step")) + ",plasma_s," + tsG("#ts-plasma") + ",cool_s," + tsG("#ts-cool"));
  var withDt = tsRows.filter(function (r) { return r.dt != null; });
  if (withDt.length) { var best = withDt.reduce(function (a, b) { return b.dt > a.dt ? b : a; }); L.push("recommended_frequency_hz," + best.freq); }
  L.push("", "#,freq_hz,init_deg,final_deg,delta_t,wattage,dac_v,notes");
  tsRows.forEach(function (r, i) { L.push([i + 1, r.freq, r.init == null ? "" : r.init, r.final == null ? "" : r.final, r.dt == null ? "" : r.dt, r.watt == null ? "" : r.watt, q(r.dac), q(r.notes)].join(",")); });
  var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([L.join("\n") + "\n"], { type: "text/csv" }));
  a.download = "ifs_tuning_report_" + new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-") + ".csv"; a.click();
}
if ($("#ts-build")) $("#ts-build").onclick = tsBuild;
if ($("#ts-freqscreen")) $("#ts-freqscreen").onclick = tsShowFreqScreen;
if ($("#ts-runpoint")) $("#ts-runpoint").onclick = tsRunPoint;
if ($("#ts-estop")) $("#ts-estop").onclick = tsEstop;
async function tsPump(on) { try { var r = await (await fetch("/api/tc/pump", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: on }) })).json(); return !!(r && r.ok); } catch (e) { return false; } }
var _tcNotConn = "Not sent - the Tip Charger is not connected. Pick it in the USB dropdown and Connect.";
if ($("#ts-plasma-on")) $("#ts-plasma-on").onclick = async function () { (await tsPlasma(true)) ? ok("Start plasma sent (A!).") : banner(_tcNotConn); };
if ($("#ts-plasma-off")) $("#ts-plasma-off").onclick = async function () { (await tsPlasma(false)) ? ok("Stop plasma sent (B!).") : banner(_tcNotConn); };
if ($("#ts-pump-on")) $("#ts-pump-on").onclick = async function () { (await tsPump(true)) ? ok("Start pump sent (b) - needs Serial Control on the panel.") : banner(_tcNotConn); };
if ($("#ts-pump-off")) $("#ts-pump-off").onclick = async function () { (await tsPump(false)) ? ok("Stop pump sent (a) - needs Serial Control on the panel.") : banner(_tcNotConn); };
if ($("#ts-prev")) $("#ts-prev").onclick = function () { if (tsIdx > 0) { tsIdx--; tsUpdateCur(); } };
if ($("#ts-next")) $("#ts-next").onclick = function () { if (tsIdx < tsFreqs.length - 1) { tsIdx++; tsUpdateCur(); } };
if ($("#ts-export")) $("#ts-export").onclick = tsExport;
if ($("#ts-clearsession")) $("#ts-clearsession").onclick = function () { if (confirm("Clear all captured tuning points?")) { tsRows = []; tsRenderTable(); tsDrawCharts(); tsReco(); } };
// ---------------- Live View: the Bioyond cell (the Puretip lane moved to its own page) ----
// The Puretip lane is driven by the SAME console stream the Puretip tab shows:
// "> cmd" lines light a stage, the following OK/ERR settles it. One source of
// truth - anything that sends a command (buttons, Run Cycle, typed) animates.
const PT_STAGES = ["init","load","mist","clean","plasma","unload","home"];
// `clamp` is Open Clamp - a maintenance action, not a cycle stage, so it no longer pretends to
// be one. Plasma is the Tip Charger's own cycle and has no Puretip console command of its own;
// the station is drawn and the preview runs it, but no live stage is faked for it.
const PT_CMD_STAGE = { start:"init", load:"load", mist:"mist", clean:"clean",
                       unload:"unload", home:"home" };
let ptLiveStage = "";
function ptChipsClear(kind) {                     // "run" clears active/err; "all" also clears the ✓s
  document.querySelectorAll("#pt-chips .stagechip").forEach(ch => {
    ch.classList.remove("active", "err");
    if (kind === "all") ch.classList.remove("done");
  });
}
// The machine is a gantry: the head only travels in Z on its column, and the DECK slides in X
// so each station passes underneath. Every move is therefore three ordered steps - lift clear,
// traverse, lower in - which is what ptGoTo sequences. Station centres live on the deck at
// x = 60/160/260/360 and the head is always at x = 230, so deckX = 230 - centre.
// Two stations side by side: Misting (centre 137) and the Tip Charger plasma station (centre 247);
// there is no rinser - cleaning runs at the misting station. The head is at x=185, so
// deckX = 185 - centre. At rest the head sits over the misting station, where a cycle starts.
const PT_DECK_X = { mist: 48, plasma: -62, park: 48 };
const PT_DIP    = 68;                                    // parked tips end at y=98; stations run 136..176
const PT_STAGE_STATION = { mist: "mist", clean: "mist", plasma: "plasma" };
let ptDeckAt = "rack", ptSeq = [];
function ptClearSeq() { ptSeq.forEach(clearTimeout); ptSeq = []; }
function ptSetDeck(x) { const d = $("#pt-deck"); if (d) d.style.transform = "translateX(" + x + "px)"; }
function ptSetHead(y) {
  const h = $("#pt-head"); if (h) h.style.transform = "translateY(" + y + "px)";
  const lane = $("#lane-pt");
  if (lane) lane.classList.toggle("pt-down", y > 0);   // gates the in-station effects
}
function ptGoTo(station, dip) {
  ptClearSeq();
  if (!station) { ptSetHead(0); return; }              // park: just come up
  const x = PT_DECK_X[station];
  if (x === undefined) return;
  if (station === ptDeckAt) {                           // already over it - only the dip changes
    ptSetHead(dip ? PT_DIP : 0);
    return;
  }
  ptSetHead(0);                                         // 1. lift clear of whatever is below
  ptSeq.push(setTimeout(function () {
    ptSetDeck(x); ptDeckAt = station;                   // 2. traverse the deck
    ptSeq.push(setTimeout(function () {
      if (dip) ptSetHead(PT_DIP);                       // 3. lower in
    }, 980));
  }, 460));
}
// The handler sequence, as steps rather than one transition, because the order is the point:
// the head must already be up and holding still before the arm comes anywhere near it.
let ptHandTimers = [];
function ptHandAbort() {
  ptHandTimers.forEach(clearTimeout); ptHandTimers = [];
  const lane = $("#lane-pt"); if (lane) lane.classList.remove("pt-arm-in", "pt-arm-holding");
}
function ptHandover(kind) {
  const lane = $("#lane-pt"); if (!lane) return;
  ptHandAbort();
  const at = (ms, fn) => ptHandTimers.push(setTimeout(fn, ms));
  ptSetHead(0);                                  // never reach in while the head is down
  if (kind === "load") {
    lane.classList.add("pt-arm-holding");        // arrives carrying the tips
    at(60,   () => lane.classList.add("pt-arm-in"));
    at(950,  () => { lane.classList.remove("pt-arm-holding"); lane.classList.add("pt-hastips"); });
    at(1450, () => lane.classList.remove("pt-arm-in"));
  } else {
    at(60,   () => lane.classList.add("pt-arm-in"));       // arrives empty
    at(950,  () => { lane.classList.remove("pt-hastips"); lane.classList.add("pt-arm-holding"); });
    at(1450, () => lane.classList.remove("pt-arm-in"));
    at(2250, () => lane.classList.remove("pt-arm-holding"));
  }
}
function ptLaneStage(stage) {
  const lane = $("#lane-pt"); if (!lane) return;
  PT_STAGES.forEach(s => lane.classList.remove("stage-" + s));
  if (stage) lane.classList.add("stage-" + stage);
  // Tips ride on the head between Load and Unload. There is no load port on this machine: the
  // Bioyond handler drives in and mounts them on the head directly, and comes back for them at
  // the end. So the tips do not simply appear - the arm arrives holding them, the head takes
  // them, and the arm withdraws empty.
  if (stage === "load")   ptHandover("load");
  if (stage === "unload") ptHandover("unload");
  if (stage === "init")   { lane.classList.remove("pt-hastips"); ptHandAbort(); }
  if (!stage || stage === "home" || stage === "init" || stage === "load" || stage === "unload") {
    ptClearSeq(); ptSetHead(0);
    if (!stage) { ptSetDeck(PT_DECK_X.park); ptDeckAt = "mist"; lane.classList.remove("pt-hastips"); }
    return;
  }
  ptGoTo(PT_STAGE_STATION[stage], true);
}
function ptLiveFeed(line) {
  if (!$("#lane-pt")) return;
  if (ptDemoOn) ptDemoEnd();          // real traffic wins; the sample cycle stands down

  const evt = $("#pt-lastevt");
  if (line.indexOf("[CYCLE]") !== -1 && evt) {        // the tablet's own full-cycle progress
    evt.textContent = "Full cycle: " + line.split("[CYCLE]")[1].trim();
    return;
  }
  if (line.startsWith(">")) {
    const cmd = line.slice(1).trim().split(/\s+/)[0].toLowerCase();
    if (cmd === "stop") { ptLiveStage = ""; ptChipsClear("run"); ptLaneStage(""); if (evt) evt.textContent = "STOP pressed"; return; }
    const st = PT_CMD_STAGE[cmd];
    if (!st) return;
    if (st === "init") ptChipsClear("all");       // a fresh cycle resets the checkmarks
    ptLiveStage = st;
    ptChipsClear("run"); ptLaneStage(st);
    const chip = $("#ptc-" + st); if (chip) chip.classList.add("active");
    if (evt) evt.textContent = "running: " + st;
  } else if (/^OK/i.test(line) && ptLiveStage) {
    const chip = $("#ptc-" + ptLiveStage); if (chip) { chip.classList.remove("active"); chip.classList.add("done"); }
    if (evt) evt.textContent = ptLiveStage + " done";
    ptLaneStage(""); ptLiveStage = "";
  } else if (/^ERR/i.test(line) && ptLiveStage) {
    const chip = $("#ptc-" + ptLiveStage); if (chip) { chip.classList.remove("active"); chip.classList.add("err"); }
    if (evt) evt.textContent = ptLiveStage + " FAILED";
    ptLaneStage(""); ptLiveStage = "";
  }
}

// Bioyond lane: poll the read-only robot state and drive the cell animation.
// error beats paused beats running when classes are chosen (worst news wins).
let byConnected = false;
/* getRobotErr answers with a LIST of {errCode, errMsg} (Rob INTF 3.3.5), so the station hands one
   over. Stringifying a list of objects put "[object Object]" in front of the operator, which says
   a fault exists and nothing whatever about it. */
/* Bioyond's own documents give three different addresses for the robot - one in the Rob INTF
   spec, two in the LabGenius manual - so all three are offered, each labelled with where it came
   from. Guessing one for the site would be worse than showing what the manuals say. */
async function byAddresses() {
  const dl = $("#by-addrs"); if (!dl || dl.children.length) return;
  try {
    const r = await (await fetch("/api/bioyond/addresses")).json();
    ((r && r.addresses) || []).forEach(a => {
      const o = document.createElement("option");
      o.value = a.ip; o.label = a.note;
      dl.appendChild(o);
    });
  } catch (e) { /* typing an address by hand still works */ }
}

/* ---------- IFS Suite Pro ----------
   What this station is licensed for. The licence is checked by the station itself, offline, so
   this only ever reports what it found. A station with no licence still runs its instrument, and
   the panel says so rather than implying something is broken. */
function licRender(l) {
  const pill = $("#lic-pill"), t = $("#lic-pill-t"), box = $("#lic-detail");
  if (!pill || !t || !box) return;

  const label = { active: "licensed", expired: "expired", none: "not licensed",
                  wrong_host: "issued to another station", invalid: "not valid",
                  malformed: "unreadable", not_yet: "not started yet",
                  unlicensed: "no key in this build", empty: "grants nothing",
                  error: "could not be read" }[l.state] || l.state;
  pill.className = "pill" + (l.state === "active" ? " ok" : (l.state === "none" ? "" : " warn"));
  t.textContent = label;

  const host = $("#lic-host");
  if (host) host.value = l.host_id || "";

  if (l.state === "active") {
    const rows = [["Issued to", l.issued_to || "not stated"],
                  ["Licence", l.id || "not stated"],
                  ["Tiers", (l.tiers || []).join(", ") || "none"],
                  ["Expires", l.expires || "does not expire"]];
    if (l.days_left !== null && l.days_left !== undefined)
      rows.push(["Days left", String(l.days_left)]);
    if (l.seats) rows.push(["Instruments", String(l.seats)]);
    box.textContent = "";
    rows.forEach(([k, v]) => {
      const d = document.createElement("div");
      const a = document.createElement("div"); a.className = "k"; a.textContent = k;
      const b = document.createElement("div"); b.className = "v"; b.textContent = v;
      d.appendChild(a); d.appendChild(b); box.appendChild(d);
    });
    box.style.display = "";
  } else {
    box.style.display = "none";
  }

  const msg = $("#lic-msg");
  if (msg) {
    // A renewal that is close is worth saying before it lapses, not after.
    if (l.state === "active" && l.days_left !== null && l.days_left !== undefined && l.days_left <= 30) {
      msg.style.display = "block"; msg.className = "warnbox";
      msg.textContent = "This licence ends in " + l.days_left + " day"
        + (l.days_left === 1 ? "" : "s") + ". Pro features lock after that. The instrument is unaffected.";
    } else if (l.state !== "active" && l.reason) {
      msg.style.display = "block"; msg.className = "hint";
      msg.textContent = l.reason;
    } else {
      msg.style.display = "none";
    }
  }
}

async function licLoad(refresh) {
  try {
    const r = await (await fetch("/api/licence" + (refresh ? "?refresh=1" : ""))).json();
    if (r && r.ok) licRender(r.licence);
  } catch (e) { /* the panel simply stays as it was */ }
}

/** Group a key the way a product key is printed, so it can be read back over a phone. */
// A key is exactly 16 letters and digits, shown in fours. Anything past the 16th is dropped as it
// is typed or pasted - a hard stop, not a warning afterwards.
const LIC_LEN = 16;
function licChars(raw) { return (raw || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, LIC_LEN); }
function licFormat(raw) {
  return (licChars(raw).match(/.{1,4}/g) || []).join("-");
}

/* Activating is the ordinary path: type the key, the station sends it with its own id, and the
   licence comes back signed. Nothing to download, nothing to paste. */
async function licActivate() {
  const box = $("#lic-key"), msg = $("#lic-msg"), btn = $("#lic-activate");
  const key = licFormat(box && box.value);
  if (!key) { if (box) box.focus(); return; }
  if (licChars(key).length !== LIC_LEN) {
    if (msg) { msg.style.display = "block"; msg.className = "warnbox";
               msg.textContent = "A licence key is 16 letters and digits; " + licChars(key).length + " entered."; }
    if (box) box.focus();
    return;
  }
  if (btn) { btn.disabled = true; btn.textContent = "Activating..."; }
  try {
    const r = await (await fetch("/api/licence/activate", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key }) })).json();
    if (msg) {
      msg.style.display = "block";
      msg.className = r && r.ok ? "okbox" : "warnbox";
      msg.textContent = r && r.ok
        ? "Licensed to " + (r.licence.issued_to || "this site") + ". "
          + (r.licence.tiers || []).join(", ") + " unlocked."
        : (r && r.error) || "That key was refused.";
    }
    if (r && r.ok) {
      if (box) box.value = "";
      licRender(r.licence);
      if (typeof flGate === "function") flGate();
    }
  } catch (e) {
    if (msg) { msg.style.display = "block"; msg.className = "warnbox";
               msg.textContent = "Could not reach the licence service: " + e; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Activate"; }
  }
}

/* Moving to another PC. The seat is handed back first, so the key can be used there; the licence
   is only removed here once the service has accepted it, and a failed call loses nothing. */
async function licRelease() {
  const msg = $("#lic-msg"), btn = $("#lic-release");
  if (!window.confirm("Release this PC so the key can be used on another?")) return;
  if (btn) { btn.disabled = true; btn.textContent = "Releasing..."; }
  try {
    const r = await (await fetch("/api/licence/release", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (msg) {
      msg.style.display = "block";
      msg.className = r && r.ok ? "okbox" : "warnbox";
      msg.textContent = r && r.ok
        ? "Released. Enter the same key on the other PC."
        : (r && r.error) || "Could not release it.";
    }
    if (r && r.ok) { licLoad(true); if (typeof flGate === "function") flGate(); }
  } catch (e) {
    if (msg) { msg.style.display = "block"; msg.className = "warnbox";
               msg.textContent = "Could not reach the licence service: " + e; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Move to another PC"; }
  }
}

/* The file path, for a station with no way out to the internet. */
async function licInstall() {
  const ta = $("#lic-text"), msg = $("#lic-msg"), btn = $("#lic-install");
  const text = (ta && ta.value || "").trim();
  if (!text) { if (ta) ta.focus(); return; }
  // Somebody pasting a key in here means the key, not a file. Recognise it rather than failing
  // with whatever the JSON parser happens to say.
  if (!text.startsWith("{")) {
    if ($("#lic-key")) $("#lic-key").value = licFormat(text);
    if (ta) ta.value = "";
    return licActivate();
  }
  if (btn) { btn.disabled = true; btn.textContent = "Checking..."; }
  try {
    const r = await (await fetch("/api/licence", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) })).json();
    if (msg) {
      msg.style.display = "block";
      msg.className = r && r.ok ? "okbox" : "warnbox";
      msg.textContent = r && r.ok
        ? "Licensed to " + (r.licence.issued_to || "this site") + "."
        : (r && r.error) || "That licence was refused.";
    }
    if (r && r.ok) { if (ta) ta.value = ""; licRender(r.licence);
                     if (typeof flGate === "function") flGate(); }
  } catch (e) {
    if (msg) { msg.style.display = "block"; msg.className = "warnbox";
               msg.textContent = "Could not install the licence: " + e; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Install file"; }
  }
}

async function licRemove() {
  await fetch("/api/licence", { method: "DELETE" }).catch(() => {});
  licLoad(true);
  if (typeof flGate === "function") flGate();
  const msg = $("#lic-msg");
  if (msg) { msg.style.display = "block"; msg.className = "hint";
             msg.textContent = "Licence removed. It can be installed on another station."; }
}

if ($("#lic-activate")) $("#lic-activate").onclick = licActivate;
if ($("#lic-release"))  $("#lic-release").onclick  = licRelease;
if ($("#lic-install"))  $("#lic-install").onclick  = licInstall;
if ($("#lic-key")) {
  // format as it is typed, and let Enter do the obvious thing
  $("#lic-key").addEventListener("input", (e) => {
    // Keep the caret after the same character it was after, whatever dashes moved around it.
    const el = e.target, before = licChars(el.value.slice(0, el.selectionStart)).length;
    el.value = licFormat(el.value);
    const at = Math.min(el.value.length, before + Math.max(0, Math.floor((before - 1) / 4)) + (before && before % 4 === 0 && before < LIC_LEN ? 1 : 0));
    try { el.setSelectionRange(at, at); } catch (x) {}
  });
  // Full: further letters are refused before they ever appear (a selection can still be typed over).
  $("#lic-key").addEventListener("beforeinput", (e) => {
    const el = e.target;
    if (!e.inputType || !e.inputType.startsWith("insert") || el.selectionStart !== el.selectionEnd) return;
    if (licChars(el.value).length >= LIC_LEN && /[A-Za-z0-9]/.test(e.data || "x")) e.preventDefault();
  });
  $("#lic-key").addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); licActivate(); }
  });
}
if ($("#lic-remove"))  $("#lic-remove").onclick  = licRemove;
if ($("#lic-copy"))    $("#lic-copy").onclick    = function () {
  const h = $("#lic-host"); if (!h || !h.value) return;
  h.select();
  navigator.clipboard.writeText(h.value).catch(() => { try { document.execCommand("copy"); } catch (e) {} });
  const b = $("#lic-copy"); const was = b.textContent;
  b.textContent = "Copied"; setTimeout(() => { b.textContent = was; }, 1200);
};

function byErrText(errs) {
  if (!Array.isArray(errs)) return String(errs).slice(0, 40);
  const first = errs[0] || {};
  const code = (first.errCode === null || first.errCode === undefined) ? "" : String(first.errCode);
  const msg  = String(first.errMsg || "").trim();
  const one  = (code && msg) ? (code + " " + msg) : (code || msg || "reported");
  return (one + (errs.length > 1 ? "  +" + (errs.length - 1) + " more" : "")).slice(0, 46);
}

function byPill(id, cls, txt) {
  const p = $(id); if (!p) return;
  p.className = "pill" + (cls ? " " + cls : "");
  p.querySelector("span:last-child").textContent = txt;
}
/* Draw the tool where the robot says it is.

   The controller reports millimetres in its own base frame and never tells us the cell's
   extents, so we AUTO-FIT: keep the min/max of everything seen and map that envelope onto
   the plan. One full transfer teaches it the cell. Until the envelope has real width the
   marker stays parked at the base rather than jittering on noise.                        */
const BY_PLAN = { x0: 22, y0: 22, x1: 400, y1: 158, bx: 207, by: 96 };
let byEnv = null;                                  // {xmin,xmax,ymin,ymax,zmin,zmax}
function byGrow(e, p) {
  if (!e) return { xmin: p.x, xmax: p.x, ymin: p.y, ymax: p.y, zmin: p.z, zmax: p.z };
  e.xmin = Math.min(e.xmin, p.x); e.xmax = Math.max(e.xmax, p.x);
  e.ymin = Math.min(e.ymin, p.y); e.ymax = Math.max(e.ymax, p.y);
  e.zmin = Math.min(e.zmin, p.z); e.zmax = Math.max(e.zmax, p.z);
  return e;
}
// ---- cell rendering -------------------------------------------------------------
// FRONT ELEVATION. The cell is drawn from the front, the same view as the Puretip One lane,
// because that is the view in which the Z axis is a real direction on screen. The handler rides
// a column; a horizontal arm carries the fork to a station; the Z axis lowers it onto the top
// surface of whatever is actually underneath. Nothing here commands anything; every query behind
// this panel is still a get.
const BY_BENCH_Y = 146;                    // top of the bench the stations stand on
const BY_COL_X   = 161;                    // the column: centred in the first gap between
                                           // stations, so the three line up evenly
const BY_CLEAR_Y = 56;                     // fork height with Z fully up: any higher and
                                           // the carriage rides off the top of the column
const BY_TOOL_X0 = 36, BY_TOOL_X1 = 424;   // the whole bench: the Z gauge is gone
const BY_FX_HMIN = 24, BY_FX_HMAX = 70;    // tallest station tops out at y=82, leaving
                                           // 20px under the fork at full lift
const BY_HOME = { x: BY_COL_X, y: 111 };    // parks over its own column, clear of every station

let byCur = { x: BY_HOME.x, y: BY_HOME.y, z: 0.15, h: BY_CLEAR_Y };   // h is the drawn fork height
let byTgt = { x: BY_HOME.x, y: BY_HOME.y, z: 0.15 };     // where it is heading
let byCarrying = false, byRAF = null, byAnim = null, byFxNodes = null;

// The stored layout is a plan: w is a footprint and h is a depth. Seen from the front a station
// has a HEIGHT instead, so derive one and cap it, or the deepest bay would stand through the arm.
function byFxH(f) {
  return Math.max(BY_FX_HMIN, Math.min(BY_FX_HMAX, f.h || 40));
}
// The surface the fork would land on at this x: the top of the station standing there, or the
// bench. This is what makes the Z honest - it stops ON something, not at a nominal depth.
function bySurfaceY(x) {
  let y = BY_BENCH_Y;
  if (byFx) for (const f of byFx) {
    if (x >= f.x - 2 && x <= f.x + f.w + 2) y = Math.min(y, BY_BENCH_Y - byFxH(f));
  }
  return y;
}
// The highest thing between two x positions - what the fork has to clear to cross.
function byPeakY(x0, x1) {
  const lo = Math.min(x0, x1), hi = Math.max(x0, x1);
  let y = BY_BENCH_Y;
  if (byFx) for (const f of byFx) {
    if (f.x + f.w >= lo - 2 && f.x <= hi + 2) y = Math.min(y, BY_BENCH_Y - byFxH(f));
  }
  return y;
}
// Height for a commanded Z at a given x: 0 is fully lifted, 1 is resting on the surface there.
// Only ever evaluated at the ENDS of a move. Evaluating it every frame is what made the fork jump:
// bySurfaceY steps as the tool crosses a station edge, so at z=0.2 the fork teleported 14px the
// instant it passed the corner. Between the ends, the drawn height is interpolated directly.
function byToolY(x, z) {
  const s = bySurfaceY(x);
  return BY_CLEAR_Y + Math.max(0, Math.min(1, z)) * (s - BY_CLEAR_Y);
}
// The absolute height that clears everything between two x positions, with 12px to spare.
function byTravelH(x0, x1) {
  return Math.max(BY_CLEAR_Y, Math.min(byPeakY(x0, x1) - 12, BY_BENCH_Y));
}
// Keep the tool on the bench and inside the cell.
function byClampPt(x, y) {
  return { x: Math.max(BY_TOOL_X0, Math.min(BY_TOOL_X1, x)), y: y };
}

// Light the station the gripper is actually down in, and nothing else. Called from the frame loop
// AND whenever motion settles - the highlight used to be updated only on a frame, and frames stop
// when the arm parks, so whichever station was lit last stayed lit for good.
function byHighlight(tx, ty) {
  if (!byFxNodes) return;
  for (let i = 0; i < byFxNodes.length; i++) {
    const f = byFx && byFx[i]; if (!f) continue;
    const over = (tx != null) && tx >= f.x && tx <= f.x + f.w;
    const down = (ty != null) && ty > BY_BENCH_Y - byFxH(f) - 14;
    byFxNodes[i].classList.toggle("hot", !!(over && down));
  }
}
function byClearHighlight() { byHighlight(null, null); }

function byRenderCell() {
  const up = $("#by-arm-upper"), fore = $("#by-arm-fore"),
        car = $("#by-carriage"), tag = document.querySelector(".by-cartag"), tool = $("#by-tool");
  if (!up || !tool) return;
  const tx = Math.max(BY_TOOL_X0, Math.min(BY_TOOL_X1, byCur.x));
  const ty = Math.max(BY_CLEAR_Y, Math.min(BY_BENCH_Y, byCur.h));
  const armY = ty - 30;
  // Two stacked members, as on the real arm: the upper one leaves the carriage and the forearm
  // sits under it and carries the gripper. The forearm covers the outer part of the reach, so a
  // long reach shows both and a short one folds them together.
  const dir = (tx >= BY_COL_X) ? 1 : -1;
  const span = Math.abs(tx - BY_COL_X);
  const upLen = Math.max(26, span * 0.55);
  const upX0 = dir > 0 ? BY_COL_X - 8 : BY_COL_X + 8 - upLen;
  up.setAttribute("x", upX0.toFixed(1));
  up.setAttribute("width", (upLen + 8).toFixed(1));
  up.setAttribute("y", (armY - 15).toFixed(1));
  const foreA = dir > 0 ? (BY_COL_X + upLen - 10) : (tx - 8);
  const foreB = dir > 0 ? (tx + 8) : (BY_COL_X - upLen + 10);
  fore.setAttribute("x", Math.min(foreA, foreB).toFixed(1));
  fore.setAttribute("width", Math.abs(foreB - foreA).toFixed(1));
  fore.setAttribute("y", (armY - 1).toFixed(1));
  if (car) car.setAttribute("y", (armY - 19).toFixed(1));
  if (tag) tag.setAttribute("y", (armY - 13).toFixed(1));
  tool.setAttribute("transform", "translate(" + tx.toFixed(1) + "," + ty.toFixed(1) + ")");
  byHighlight(tx, ty);
  const lane = $("#lane-by"); if (lane) lane.classList.toggle("by-carrying", byCarrying);
}
// Motion is a timed ease between two poses, not a per-frame exponential approach. The old
// version moved a fixed fraction of the remaining distance each frame, so it was fast then
// asymptotically slow, never actually arrived, and the next leg fired while it was still
// creeping - which is what made the transfer look like it was lurching. It was also
// frame-rate dependent. This interpolates over a stated duration with an ease in/out, so
// each leg completes exactly when it should.
function byEase(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
function byTick(now) {
  if (byAnim) {
    let t = byAnim.dur > 0 ? (now - byAnim.t0) / byAnim.dur : 1;
    if (t > 1) t = 1;
    byRetarget();                 // the station may have been dragged since this leg began
    const e = byEase(t);
    // Front view: x is a straight run along the bench and h is a straight rise, so a plain
    // interpolation IS the motion - and holding h constant across a travel leg means crossing a
    // station edge changes nothing about the drawn height.
    byCur.x = byAnim.fx + (byAnim.tx - byAnim.fx) * e;
    byCur.h = byAnim.fh + (byAnim.th - byAnim.fh) * e;
    if (t >= 1) { byAnim = null; if (byQueue.length) byNextSeg(); }
  }
  byRenderCell();
  if (byAnim || byQueue.length) { byRAF = requestAnimationFrame(byTick); }
  else { byRAF = null; }            // settled: stop burning frames until the next move
}
function byStartTick() { if (!byRAF) byRAF = requestAnimationFrame(byTick); }
// Crash interlock. The tool is only allowed to be down INSIDE a bay; it must never be dragged
// across the cell at working height, which is how a handler shears a plate off a nest. Any move
// that would do it is split into lift, travel, lower - the same three moves the machine makes.
// Crash interlock. The tool is only allowed to be down INSIDE a bay; it must never be dragged
// across the cell at working height, which is how a handler shears a plate off a nest. Any move
// that would do it is split into lift, travel, lower - the same three the machine makes - and the
// travel leg holds ONE height, clear of the tallest station actually in the way.
//
// Heights here are ABSOLUTE pixels, resolved at the ends of each segment. They used to be a Z
// fraction re-evaluated every frame against the surface under the tool, and bySurfaceY steps as
// the tool crosses a station edge - so at z=0.2 the fork jumped 14px the instant it passed a
// corner. Measured worst vertical step per frame: 18.9px. Interpolating an absolute height means
// a travel leg simply holds its height and crossing an edge changes nothing.
function byTravelH(x0, x1) {
  return Math.max(BY_CLEAR_Y, Math.min(byPeakY(x0, x1) - 12, BY_BENCH_Y));
}
let byQueue = [];
// The centre of a station, read NOW. Drag a station in the editor and this moves with it.
function byFxCentre(i) {
  const f = byFx && byFx[i];
  return f ? f.x + f.w / 2 : BY_COL_X;
}
// Re-aim a segment at the station it is bound to. A move used to carry the x it was given when
// the leg was created, so moving the carousel mid-preview left the arm travelling to where the
// carousel USED TO BE and stopping in mid-air. A segment aimed at a station follows it.
function byRetarget(seg) {
  if (!byAnim || byAnim.aim == null) return;
  const x = byClampPt(byFxCentre(byAnim.aim), 0).x;
  if (Math.abs(x - byAnim.tx) < 0.25) return;
  byAnim.tx = x;
  byAnim.th = byAnim.travel ? byTravelH(byAnim.fx, x) : byToolY(x, byAnim.aimZ);
}
function byNextSeg() {
  const g = byQueue.shift();
  if (!g) { byAnim = null; return; }
  byAnim = { fx: byCur.x, fh: byCur.h, tx: g.x, th: g.h, t0: performance.now(), dur: g.dur,
             aim: (g.aim == null ? null : g.aim), aimZ: g.aimZ, travel: !!g.travel };
  byStartTick();
}
// aim: index of the station this move is going to, or null for a plain coordinate move.
function byGoTo(x, y, z, carrying, dur, aim) {
  const g = byClampPt(x, y);          // a target outside the cell is brought to the wall, not chased through it
  const tz = (typeof z === "number" ? z : byCur.z);
  const d = (dur === undefined ? 900 : dur);
  const hEnd = byToolY(g.x, tz);
  const travelling = Math.abs(g.x - byCur.x) > 0.5;
  const A = (aim == null ? null : aim);
  byQueue = [];
  if (travelling) {
    const h = byTravelH(byCur.x, g.x);
    const lift = Math.max(180, Math.min(320, d * 0.3));
    if (byCur.h > h + 0.5) byQueue.push({ x: byCur.x, h: h, dur: lift, aim: null, aimZ: tz });
    byQueue.push({ x: g.x, h: h,    dur: d,    aim: A, aimZ: tz, travel: true });
    if (hEnd > h + 0.5)    byQueue.push({ x: g.x, h: hEnd, dur: lift, aim: A, aimZ: tz });
  } else {
    byQueue.push({ x: g.x, h: hEnd, dur: d, aim: A, aimZ: tz });
  }
  byCur.z = tz;
  if (carrying !== undefined) byCarrying = !!carrying;
  byNextSeg();
}
function byResetCell() { byCarrying = false; byGoTo(BY_HOME.x, BY_HOME.y, 0.15, false, 700); }

function byDrawPose(p) {
  const out = $("#by-pose");
  if (!$("#by-tool")) return;
  if (!p || typeof p.x !== "number") {             // controller has no pose query
    byResetCell();
    if (out) out.textContent = "No tool position from this controller.";
    return;
  }
  byEnv = byGrow(byEnv, p);
  const spanX = byEnv.xmax - byEnv.xmin, spanY = byEnv.ymax - byEnv.ymin;
  const LEARNED = spanX > 1 && spanY > 1;          // needs real travel before the map means anything
  const fx = LEARNED ? (p.x - byEnv.xmin) / spanX : 0.5;
  const fy = LEARNED ? (p.y - byEnv.ymin) / spanY : 0.5;
  const sx = BY_TOOL_X0 + fx * (BY_TOOL_X1 - BY_TOOL_X0);   // front view: x runs along the bench
  const sy = BY_PLAN.y0 + fy * (BY_PLAN.y1 - BY_PLAN.y0);   // depth, kept for the reported pose
  const spanZ = (byEnv.zmax - byEnv.zmin);
  const fz = spanZ > 1 ? (byEnv.zmax - p.z) / spanZ : 0.15;
  byGoTo(sx, sy, fz, undefined, 2300);   // glide across the poll interval, not a jump
  if (out) out.textContent = LEARNED
    ? ("tool  x " + p.x.toFixed(0) + "  y " + p.y.toFixed(0) + "  z " + p.z.toFixed(0))
    : ("tool  x " + p.x.toFixed(0) + "  y " + p.y.toFixed(0) + "  z " + p.z.toFixed(0)
       + "   (learning the cell)");
}

async function byRefresh() {
  if (!$("#lane-by")) return;
  try {
    const s = await (await fetch("/api/by/state")).json();
    if (byDemoOn && s.connected) byDemoEnd();   // real robot wins over the sample transfer
    byConnected = !!s.connected;
    const lane = $("#lane-by");
    lane.classList.remove("by-off", "by-running", "by-paused", "by-error");
    const btn = $("#byConnectBtn"); if (btn) btn.textContent = byConnected ? "Disconnect" : "Connect";
    if (!byConnected) {
      if (!byDemoOn) lane.classList.add("by-off");   // a running preview must not be re-dimmed
      byPill("#by-link", "bad", s.error ? "no link \u2014 " + String(s.error).slice(0, 40) : "no link");
      byPill("#by-sys", "", "system: \u2014");  byPill("#by-prog", "", "program: \u2014");
      byPill("#by-ctrl", "", "mode: \u2014");   byPill("#by-en", "", "servos: \u2014");
      byPill("#by-app", "", "script: \u2014");
      if (!byDemoOn) {                     // do not fight a preview the operator started
        byResetCell();
        const bp = $("#by-pose");
        if (bp) bp.textContent = "waiting for the robot\u2026";   // not a claim about the controller
      }
      return;
    }
    if (s.ip && $("#by-ip") && document.activeElement !== $("#by-ip")) $("#by-ip").value = s.ip;
    byPill("#by-link", "ok", "linked " + (s.ip || ""));
    byPill("#by-sys",  s.sys  === "error" ? "bad" : (s.sys  === "running" ? "ok" : "warn"), "system: "  + s.sys);
    byPill("#by-prog", s.prog === "error" ? "bad" : (s.prog === "running" ? "ok" : "warn"), "program: " + s.prog);
    byPill("#by-ctrl", "", "mode: " + (s.ctrl || "\u2014"));
    byPill("#by-en", s.enabled === null || s.enabled === undefined ? "" : (s.enabled ? "ok" : "warn"),
           "servos: " + (s.enabled === null || s.enabled === undefined ? "\u2014" : (s.enabled ? "enabled" : "off")));
    // this pill carries the robot ERROR, or the running script - never the program state,
    // which #by-prog already shows. Labelling both "program:" put two identical pills side by side.
    byPill("#by-app", s.roboterr ? "bad" : "",
           s.roboterr ? "error: "  + byErrText(s.roboterr)
                      : "script: " + (s.lua != null ? String(s.lua).slice(0, 30) : "\u2014"));
    byDrawPose(s.pose);
    if (s.sys === "error" || s.prog === "error") lane.classList.add("by-error");
    else if (s.prog === "paused")  lane.classList.add("by-paused");
    else if (s.prog === "running") lane.classList.add("by-running");
  } catch (e) { /* backend unreachable; the global status poll already banners that */ }
}
if ($("#byConnectBtn")) $("#byConnectBtn").onclick = async () => {
  if (byConnected) { try { await fetch("/api/by/disconnect", { method: "POST" }); } catch (e) {} byRefresh(); return; }
  const ip = (($("#by-ip") || {}).value || "").trim();
  try {
    const r = await (await fetch("/api/by/connect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ip }) })).json();
    if (!r.ok) banner(r.error || "Could not reach the robot.");
  } catch (e) { banner("Could not reach the robot: " + e); }
  byRefresh();
};
setInterval(byRefresh, 2500);
byRefresh();

// ---------------- Bioyond cell layout editor ----------------
// The robot never reports where its fixtures are, so this plan is a DRAWING, not telemetry.
// Rather than ship one guess, the operator lays out their own cell: drag to move, corner grip
// to resize, rename, add and delete. Saved on this PC through /api/by/layout so it survives a
// restart. Only the scenery is editable - the arm still follows the robot's reported pose.
// Bumped whenever a change would make an OLDER saved layout draw wrongly - not for every edit.
// Stored alongside the layout, not inside each fixture.
const BY_LAYOUT_V = 5;
// Front elevation, so these are positions ALONG the bench and heights above it. They must not
// sit on the column, and their centres must be inside the arm's reach.
const BY_FX_DEFAULT = [
  { label: "Puretip One", x: 30,  y: 22, w: 104, h: 58 },
  { label: "Outfeed",     x: 300, y: 98, w: 104, h: 42 },
  { label: "Carousel",    x: 188, y: 22, w: 104, h: 70 },
];
let byFx = null, byFxSel = -1, byFxEditing = false, byFxDirty = false;

function byFxSvg() { return document.querySelector("#lane-by svg"); }
// screen px -> SVG user units, so a drag tracks the pointer at any panel width
function byFxPt(evt) {
  const svg = byFxSvg(); if (!svg) return null;
  const pt = svg.createSVGPoint(); pt.x = evt.clientX; pt.y = evt.clientY;
  const m = svg.getScreenCTM(); if (!m) return null;
  return pt.matrixTransform(m.inverse());
}
function byFxRender() {
  const host = $("#by-fixtures"); if (!host || !byFx) return;
  host.textContent = "";
  const NS = "http://www.w3.org/2000/svg";
  const mk = (tag, attrs) => { const n = document.createElementNS(NS, tag);
                               for (const k in attrs) n.setAttribute(k, attrs[k]); return n; };
  byFx.forEach(function (f, i) {
    const hh = byFxH(f), top = BY_BENCH_Y - hh;     // stations STAND on the bench in this view
    const g = mk("g", { "class": "by-fx" + (i === byFxSel ? " sel" : "") });
    g.dataset.i = i;
    g.appendChild(mk("rect", { "class": "fxbox", x: f.x, y: top, width: f.w, height: hh, rx: 4 }));
    // the top surface: the line the fork actually stops on
    g.appendChild(mk("rect", { "class": "fxnest", x: f.x + 6, y: top,
                               width: Math.max(6, f.w - 12), height: 4, rx: 1.5 }));
    const lab = (f.label || "");
    if (/carousel|pin\s*tool|extractor/i.test(lab) && f.w > 40 && hh > 30) {
      // A pin tool carousel: a drum that TURNS about its vertical axis, carrying the pin tools.
      // Rotation is drawn the way a turning cylinder actually looks from the front - ribs sweeping
      // across a fixed body, clipped to it - not as a ring going round, which read as a fairground
      // wheel, and not as a float, which read as a ghost.
      const dx = f.x + 8, dw = f.w - 16, dy = top + 8, dh = 22;
      const cid = "byDrum" + i;
      const cp = mk("clipPath", { id: cid });
      cp.appendChild(mk("rect", { x: dx, y: dy, width: dw, height: dh, rx: 4 }));
      g.appendChild(cp);
      g.appendChild(mk("rect", { "class": "by-drum", x: dx, y: dy, width: dw, height: dh, rx: 4 }));
      const ribs = mk("g", { "class": "by-drumribs", "clip-path": "url(#" + cid + ")" });
      const STEP = 9;
      for (let rx = dx - STEP; rx < dx + dw + STEP; rx += STEP) {
        // ribs fade towards the drum's edges, which is what makes it read as round
        const t = Math.abs((rx - (dx + dw / 2)) / (dw / 2));
        ribs.appendChild(mk("line", { "class": "by-drumrib", x1: rx.toFixed(1), y1: dy + 2,
                                      x2: rx.toFixed(1), y2: dy + dh - 2,
                                      opacity: (0.75 - 0.55 * Math.min(1, t)).toFixed(2) }));
      }
      g.appendChild(ribs);
      // the pin tools it carries, hanging below the drum
      const n = Math.max(6, Math.min(18, Math.floor((dw - 6) / 6)));
      const gap = (dw - 6) / (n - 1);
      for (let k = 0; k < n; k++) {
        const px = (dx + 3 + k * gap).toFixed(1);
        g.appendChild(mk("line", { "class": "by-pt-pin", x1: px, y1: dy + dh,
                                   x2: px, y2: BY_BENCH_Y - 9 }));
      }
    } else if (/outfeed|stack|out/i.test(lab) && hh > 26) {
      // an outfeed holds a stack of finished plates
      const n = Math.max(2, Math.min(5, Math.floor((hh - 12) / 8)));
      for (let k = 0; k < n; k++)
        g.appendChild(mk("rect", { "class": "by-detail", x: f.x + 8, y: BY_BENCH_Y - 10 - k * 8,
                                   width: Math.max(8, f.w - 16), height: 6, rx: 1.5 }));
    } else if (f.w > 30 && hh > 26) {
      // anything else reads as a bay with a plate nest in it
      g.appendChild(mk("rect", { "class": "by-detail", x: f.x + 10, y: top + 14,
                                 width: Math.max(8, f.w - 20), height: Math.max(6, hh - 26), rx: 2 }));
    }
    const t = mk("text", { x: f.x + f.w / 2, "text-anchor": "middle", y: BY_BENCH_Y + 26 });
    t.textContent = lab;                            // textContent: labels are operator input
    g.appendChild(t);
    const grip = mk("rect", { "class": "fxgrip", x: f.x + f.w - 4, y: top - 4,
                              width: 8, height: 8, rx: 2 });
    grip.dataset.grip = "1";
    g.appendChild(grip);
    host.appendChild(g);
  });
  byFxNodes = host.querySelectorAll(".by-fx");   // cached for the animation loop
}
function byFxSelect(i) { byFxSel = i; byFxRender(); byFxSyncTools(); }
// Every .field is a label above a control, but the two were never associated - so a screen
// reader, and anything else that asks the platform for a control's name, saw 12 unnamed inputs.
// Done here rather than by hand in the markup so a field added later is linked automatically.
function linkFieldLabels() {
  let n = 0;
  document.querySelectorAll(".field").forEach(function (f) {
    const lab = f.querySelector(":scope > label");
    if (!lab || lab.getAttribute("for")) return;
    const ctl = f.querySelector("input, select, textarea");
    if (!ctl) return;
    if (!ctl.id) ctl.id = "fld-" + (++n) + "-" + Math.random().toString(36).slice(2, 7);
    lab.setAttribute("for", ctl.id);
  });
  return n;
}

// A greyed-out field with no explanation is just broken-looking. The unlock button says what to
// do; the field itself said nothing, including to anyone who tabbed onto it.
function describeLockedFields() {
  document.querySelectorAll("input.cfg-lock").forEach(function (el) {
    if (el.disabled) el.title = "Locked. Use “unlock to edit” above before changing this.";
    else el.title = "Unlocked – changes here are written to the controller.";
  });
}

function byFxSyncTools() {
  const f = byFx && byFx[byFxSel];
  const lab = $("#by-fx-label"), del = $("#byDelBtn");
  if (lab) { lab.disabled = !f; lab.value = f ? f.label : ""; }
  if (del) del.disabled = !f;
  const save = $("#bySaveBtn"); if (save) save.textContent = byFxDirty ? "Save *" : "Save";
}
function byFxLoad() {
  fetch("/api/by/layout").then(r => r.json()).then(function (d) {
    // A layout drawn for the old top-down plan places two bays at the same x, which in a front
    // elevation is one standing inside the other. Those are dropped for the current defaults;
    // anything saved since is kept exactly as the operator drew it.
    //
    // The version is a property of the LAYOUT and is read from the response, not from each
    // fixture: the per-fixture field was stripped by the endpoint's whitelist, so this test was
    // always false and every saved cell was silently thrown away on load.
    const saved = (d && d.ok && Array.isArray(d.layout) && d.layout.length) ? d.layout : null;
    byFx = (saved && +d.v >= BY_LAYOUT_V)
         ? saved.map(f => ({ label: f.label, x: +f.x, y: +f.y, w: +f.w, h: +f.h }))
         : BY_FX_DEFAULT.map(f => Object.assign({}, f));
    byFxRender();
  }).catch(function () {
    byFx = BY_FX_DEFAULT.map(f => Object.assign({}, f));   // offline backend: still draw something
    byFxRender();
  });
}
function byFxSave() {
  if (!byFx) return;
  fetch("/api/by/layout", { method: "POST", headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ layout: byFx, v: BY_LAYOUT_V }) })
    .then(r => r.json())
    .then(function (d) {
      if (d && d.ok) { byFxDirty = false; byFxSyncTools(); ok("Cell layout saved."); }
      else banner("Could not save the layout: " + ((d && d.error) || "unknown error"));
    })
    .catch(e => banner("Could not save the layout: " + e));
}
function byFxSetEditing(on) {
  byFxEditing = on;
  const lane = $("#lane-by");
  if (lane) lane.classList.toggle("by-editing", on);
  const b = $("#byEditBtn"); if (b) b.textContent = on ? "Done editing" : "Edit layout";
  const tools = $("#by-edit-tools"); if (tools) tools.style.display = on ? "inline-flex" : "none";
  const hint = $("#by-edit-hint");
  if (hint) hint.textContent = on ? "Drag along the bench, top grip to resize."
                                  : "Fixture placement is a sketch \u2014 draw your own cell.";
  if (!on) { byFxSel = -1; byFxRender(); }
  byFxSyncTools();
}

// drag / resize
let byFxDrag = null;
function byFxDown(e) {
  if (!byFxEditing || !byFx) return;
  const g = e.target.closest(".by-fx"); if (!g) return;
  const i = +g.dataset.i; const pt = byFxPt(e); if (!pt) return;
  byFxSelect(i);
  byFxDrag = { i: i, resize: e.target.dataset.grip === "1",
               px: pt.x, py: pt.y, o: Object.assign({}, byFx[i]) };
  e.preventDefault();
}
function byFxMove(e) {
  if (!byFxDrag || !byFx) return;
  const pt = byFxPt(e); if (!pt) return;
  const f = byFx[byFxDrag.i], o = byFxDrag.o;
  const dx = pt.x - byFxDrag.px, dy = pt.y - byFxDrag.py;
  if (byFxDrag.resize) {
    f.w = Math.max(20, Math.round(o.w + dx));       // min size keeps it grabbable after a save
    f.h = Math.max(BY_FX_HMIN, Math.min(BY_FX_HMAX, Math.round(o.h - dy)));   // grip is on TOP now
  } else {
    // Front view: a station slides along the bench. It cannot move up and down - it stands on it.
    f.x = Math.max(16, Math.min(432 - f.w, Math.round(o.x + dx)));
  }
  byFxDirty = true;
  byFxRender(); byFxSyncTools();
}
function byFxUp() { byFxDrag = null; }

linkFieldLabels();
describeLockedFields();

if ($("#lane-by")) {
  byResetCell();          // draw the folded arm immediately; the markup pose is degenerate
  const lane = $("#lane-by");
  lane.addEventListener("pointerdown", byFxDown);
  window.addEventListener("pointermove", byFxMove);
  window.addEventListener("pointerup", byFxUp);
  byFxLoad();
}
if ($("#byEditBtn")) $("#byEditBtn").onclick = () => byFxSetEditing(!byFxEditing);
if ($("#byAddBtn"))  $("#byAddBtn").onclick  = function () {
  if (!byFx) return;
  byFx.push({ label: "New fixture", x: 96, y: 70, w: 70, h: 44 });
  byFxDirty = true; byFxSelect(byFx.length - 1);
};
if ($("#byDelBtn"))  $("#byDelBtn").onclick  = function () {
  if (!byFx || byFxSel < 0) return;
  byFx.splice(byFxSel, 1); byFxDirty = true; byFxSelect(-1);
};
if ($("#by-fx-label")) $("#by-fx-label").oninput = function () {
  if (!byFx || byFxSel < 0) return;
  byFx[byFxSel].label = this.value.slice(0, 28); byFxDirty = true; byFxRender(); 
};
if ($("#bySaveBtn"))  $("#bySaveBtn").onclick  = byFxSave;
if ($("#byResetBtn")) $("#byResetBtn").onclick = function () {
  if (!confirm("Discard your cell layout and go back to the default sketch?")) return;
  fetch("/api/by/layout", { method: "POST", headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ layout: null }) })
    .then(() => { byFx = BY_FX_DEFAULT.map(f => Object.assign({}, f)); byFxDirty = false;
                  byFxSelect(-1); info("Cell layout reset."); })
    .catch(e => banner("Could not reset: " + e));
};

// ---------------- Live View preview animations ----------------
// Same idea as the Chamber's "Show animation": a sample cycle so the graphics can be seen
// working with no tablet and no robot attached. Both guard against the live feed - a preview
// never runs on top of real data, and real data always wins if it arrives.
let ptDemoOn = false, ptDemoTimer = null;
let byDemoOn = false, byDemoRAF = null;   // holds a TIMEOUT id now, not a frame handle

function ptDemoEnd() {
  ptDemoOn = false;
  clearTimeout(ptDemoTimer); ptDemoTimer = null;
  ptLaneStage(""); ptChipsClear("all");
  ptClearSeq(); ptSetHead(0); ptSetDeck(PT_DECK_X.park); ptDeckAt = "mist";   // back to the resting pose
  ptHandAbort();
  var _l = $("#lane-pt"); if (_l) _l.classList.remove("pt-hastips");
  const b = $("#ptDemoBtn"); if (b) b.textContent = "Show animation";
  const e = $("#pt-lastevt"); if (e) e.textContent = "waiting for the Puretip stream\u2026";
}
function ptDemoStart() {
  // walks the real stage list, so what you see here is exactly what a live run draws
  // Timings allow for the full lift-traverse-lower move (~1.9s) plus a beat of dwell, so each
  // stage is actually seen arriving rather than being cut off by the next one.
  const steps = [
    ["init",   1600, "Initialize"],
    ["load",   2600, "tips placed on the head by the Bioyond handler"],
    ["mist",   3200, "Misting"],
    ["clean",  3400, "Rinsing"],
    ["plasma", 3400, "Plasma — Tip Charger station"],
    ["unload", 2400, "tips taken back by the handler"],
    ["home",   1800, "Z-Home"],
  ];
  ptDemoOn = true;
  const b = $("#ptDemoBtn"); if (b) b.textContent = "Stop";
  ptChipsClear("all");
  let i = 0;
  (function next() {
    if (!ptDemoOn) return;
    if (i >= steps.length) {                       // one full pass, then settle
      const e = $("#pt-lastevt"); if (e) e.textContent = "sample cycle complete";
      ptDemoTimer = setTimeout(ptDemoEnd, 1200);
      return;
    }
    const [stage, ms, label] = steps[i];
    ptLaneStage(stage);
    ptChipsClear("run");
    document.querySelectorAll("#pt-chips .stagechip").forEach((ch, n) => {
      if (n < i) ch.classList.add("done");
    });
    const chip = document.querySelectorAll("#pt-chips .stagechip")[i];
    if (chip) chip.classList.add("active");
    const e = $("#pt-lastevt"); if (e) e.textContent = "sample cycle \u2014 " + label;
    i++;
    ptDemoTimer = setTimeout(next, ms);
  })();
}
if ($("#ptDemoBtn")) $("#ptDemoBtn").onclick = () => { if (ptDemoOn) ptDemoEnd(); else ptDemoStart(); };
// Park the gantry the moment the page loads: without this the deck sits at translateX(0), which
// leaves the tip rack off to the left of the head instead of under it.
if ($("#pt-deck")) { ptSetDeck(PT_DECK_X.park); ptDeckAt = "mist"; ptSetHead(0); }

function byDemoEnd() {
  byDemoOn = false;
  byClearHighlight();
  if (byDemoRAF) { clearTimeout(byDemoRAF); byDemoRAF = null; }
  const b = $("#byDemoBtn"); if (b) b.textContent = "Show animation";
  const lane = $("#lane-by");
  if (lane && !byConnected) lane.classList.add("by-off");        // back to dimmed if nothing is linked
  byResetCell();
  const o = $("#by-pose"); if (o) o.textContent = "waiting for the robot\u2026";
}
function byDemoStart() {
  // A plate transfer, driven through the SAME renderer the live pose uses - so the preview and
  // the real thing move identically. Targets only; the arm eases itself there.
  const b = $("#byDemoBtn"); if (b) b.textContent = "Stop";
  const lane = $("#lane-by"); if (lane) lane.classList.remove("by-off");
  byDemoOn = true;
  // Legs name the STATION, not a coordinate. The coordinate is read when the leg starts and then
  // tracked while it runs, so dragging a station in the editor moves the arm's destination with
  // it instead of leaving it travelling to where that station used to be.
  //   [station index or null for home, z, carrying, label, move duration, dwell]
  const legs = [
    [2,    0.15, false, "travelling to the carousel",        1500, 1500],
    [2,    0.92, false, "lowering into the carousel",         700,  700],
    [2,    0.92, true,  "plate gripped",                      200,  600],
    [2,    0.20, true,  "lifting clear",                      700,  700],
    [0,    0.20, true,  "carrying the plate to Puretip One", 1900, 1900],
    [0,    0.92, true,  "lowering onto Puretip One",           700,  700],
    [0,    0.92, false, "plate released",                      200,  600],
    [0,    0.20, false, "lifting clear",                       700,  700],
    [null, 0.15, false, "waiting while the tips are cleaned", 1200, 2600],
    [0,    0.20, false, "returning for the plate",            1500, 1500],
    [0,    0.92, false, "lowering onto the plate",             700,  700],
    [0,    0.92, true,  "plate gripped",                       200,  600],
    [0,    0.20, true,  "lifting clear",                       700,  700],
    [2,    0.20, true,  "carrying it back to the carousel",   1900, 1900],
    [2,    0.92, true,  "lowering into the carousel",          700,  700],
    [2,    0.92, false, "plate returned",                      200,  600],
    [2,    0.20, false, "lifting clear",                       700,  700],
    [null, 0.15, false, "returning to base",                  1600, 1600],
  ];
  let i = 0;
  (function step() {
    if (!byDemoOn) return;
    if (i >= legs.length) {
      const o = $("#by-pose"); if (o) o.textContent = "sample transfer complete";
      byDemoRAF = setTimeout(function () { if (byDemoOn) byDemoEnd(); }, 1200);
      return;
    }
    const [st, z, carry, label, dur, dwell] = legs[i];
    const x = (st == null) ? BY_HOME.x : byFxCentre(st);
    byGoTo(x, 0, z, carry, dur, st);
    const o = $("#by-pose"); if (o) o.textContent = "sample transfer \u2014 " + label;
    i++;
    byDemoRAF = setTimeout(step, dwell);
  })();
}
if ($("#byDemoBtn")) $("#byDemoBtn").onclick = () => { if (byDemoOn) byDemoEnd(); else byDemoStart(); };

// ---------------- station identity (fleet list) ----------------
// The name is what a human reads in the fleet list; the id is what the rows are keyed on and
// never changes. Both live on this PC - the app only ever POSTs them out with the heartbeat.
async function stLoad() {
  try {
    const d = await (await fetch("/api/fleet/whoami")).json();
    if (!d.ok) return;
    const n = $("#st-name"), t = $("#st-telemetry"), i = $("#st-id");
    if (n && document.activeElement !== n) n.value = d.station_name || "";
    if (t) t.checked = d.telemetry !== false;
    if (i) i.textContent = d.station_id || "-";
  } catch (e) { /* backend down; the status poll already says so */ }
}
async function stSave() {
  const n = $("#st-name"), t = $("#st-telemetry");
  if ($("#st-id") && $("#st-id").textContent === "-") {   // never write back a panel we never filled
    await stLoad();
    banner("Station details were not loaded yet - reloaded them. Check the fields and save again.");
    return;
  }
  try {
    const r = await (await fetch("/api/fleet/whoami", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ station_name: n ? n.value : "", telemetry: t ? t.checked : true })
    })).json();
    if (r.ok) ok("Station details saved."); else banner(r.error || "Could not save.");
  } catch (e) { banner("Could not save: " + e); }
}
if ($("#stSaveBtn")) $("#stSaveBtn").onclick = stSave;
if ($("#st-name")) $("#st-name").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); stSave(); } });
if ($("#stCopyId")) $("#stCopyId").onclick = () => {
  const id = $("#st-id") ? $("#st-id").textContent : "";
  if (!id || id === "-") return;
  navigator.clipboard.writeText(id).then(() => ok("Station ID copied.")).catch(() => {});
};
if ($("#st-name")) stLoad();

// ---------------- boot screen ----------------
// Hold the lockup until the app can actually answer, then fade. Capped so a station whose
// backend is slow or unreachable still gets its UI rather than a brand screen forever.
(function () {
  const el = document.getElementById("boot");
  if (!el) return;
  let done = false;
  const finish = function () {
    if (done) return; done = true;
    el.classList.add("gone");
    setTimeout(function () { el.style.display = "none"; }, 500);
  };
  fetch("/api/fleet/whoami")
    .then(r => r.json())
    .then(function (d) {
      const v = document.getElementById("boot-ver");
      if (v && d && d.version) v.textContent = "version " + d.version;
      setTimeout(finish, 650);          // let the version be read rather than flashed
    })
    .catch(function () { finish(); });
  setTimeout(finish, 4000);             // hard cap: never trap the operator behind a splash
})();

/* ---------- signing in ----------
   The station is gated now: nothing behind this page is reachable until someone is in. A person
   belongs to a WORKSPACE - a lab, a bench, a shift - and their protocols and recipes belong to it
   with them, so two teams can share a machine without seeing each other's work.

   The badge reader is a keyboard: it types the number and presses Enter, faster than a person can.
   So a card is recognised by TIMING rather than by focus, and a swipe works without clicking into
   anything first. A password typed by hand is never mistaken for one. */
let whoSession = { id: "", name: "", workspace: "", workspace_name: "" };

function lgMsg(t, bad) {
  const e = $("#lg-msg"); if (!e) return;
  e.textContent = t || "";
  e.style.color = bad ? "var(--bad)" : "var(--muted)";
}
function lgPane(which) {
  [["lg-main", "main"], ["lg-signup-form", "signup"], ["lg-forgot-form", "forgot"], ["lg-first-form", "first"]]
    .forEach(function (p) { const el = $("#" + p[0]); if (el) el.style.display = (p[1] === which) ? "" : "none"; });
  lgMsg("");
}
function lgShow(on) {
  const p = $("#loginPage"); if (p) p.style.display = on ? "flex" : "none";
  if (on) {
    lgPane("main"); lgWorkspaces();
    lgCardState(true, "present a card to sign in");
    setTimeout(function () { const n = $("#lg-name"); if (n) n.focus(); }, 60);
  }
}

async function lgWorkspaces() {
  try {
    const r = await (await fetch("/api/workspaces")).json();
    const ws = (r && r.workspaces) || [];
    ["#lg-ws", "#lg-su-ws", "#lg-fg-ws"].forEach(function (sel) {
      const el = $(sel); if (!el) return;
      const keep = el.value;
      el.textContent = "";
      ws.forEach(function (w) {
        const o = document.createElement("option");
        o.value = w.id;
        o.textContent = w.name + (w.people ? "  (" + w.people + ")" : "");
        el.appendChild(o);
      });
      if (keep) el.value = keep;
    });
  } catch (e) { lgMsg("Cannot reach the station: " + e, true); }
}

function whoRender() {
  const nm = $("#whoName"), btn = $("#whoBtn");
  if (nm) nm.textContent = whoSession.name || "Sign in";
  if (btn) {
    btn.classList.toggle("on", !!whoSession.id);
    btn.title = whoSession.id
      ? (whoSession.name + " · " + (whoSession.workspace_name || "workspace") + " — sign out")
      : "Sign in";
  }
  if (typeof prSyncOwner === "function") prSyncOwner();
}

async function lgLogin() {
  const body = { workspace: ($("#lg-ws").value || ""), name: ($("#lg-name").value || "").trim(),
                 password: ($("#lg-pw").value || "") };
  if (!body.name || !body.password) return lgMsg("Enter a user name and password.", true);
  try {
    const r = await (await fetch("/api/login", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r && r.ok) {
      whoSession = r.session; $("#lg-pw").value = "";
      whoRender(); lgShow(false);
      if (typeof prSyncOwner === "function") prSyncOwner();
      // First sign-in (signing up leads here): offer to connect their AI, once
      if (typeof window.ifsMaybeOfferAiSetup === "function") setTimeout(window.ifsMaybeOfferAiSetup, 600);
    } else if (r && r.must_change) {
      lgFirst = body;                                  // kept in memory only until the change is saved
      lgPane("first");
      const w = $("#lg-fp-admwrap"); if (w) w.style.display = r.admin_default ? "" : "none";
      lgMsg(r.error || "");
      setTimeout(function () { const n = $("#lg-fp-new"); if (n) n.focus(); }, 60);
    } else lgMsg((r && r.error) || "Sign-in failed.", true);
  } catch (e) { lgMsg("Could not sign in: " + e, true); }
}

let lgFirst = null;
async function lgFirstSave() {
  if (!lgFirst) return lgPane("main");
  const nw = $("#lg-fp-new").value || "", again = $("#lg-fp-again").value || "";
  if (nw.length < 6) return lgMsg("Use a password of at least six characters.", true);
  if (nw !== again) return lgMsg("The two passwords do not match.", true);
  const body = { workspace: lgFirst.workspace, name: lgFirst.name, current: lgFirst.password,
                 password: nw, admin_new: ($("#lg-fp-adm").value || "") };
  try {
    const r = await (await fetch("/api/password/first", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r && r.ok) {
      lgFirst = null;
      ["#lg-fp-new", "#lg-fp-again", "#lg-fp-adm", "#lg-pw"].forEach(function (s) { const e = $(s); if (e) e.value = ""; });
      whoSession = r.session; whoRender(); lgShow(false);
      if (typeof prSyncOwner === "function") prSyncOwner();
      if (typeof window.ifsMaybeOfferAiSetup === "function") setTimeout(window.ifsMaybeOfferAiSetup, 600);
    } else {
      if (r && r.admin_default) { const w = $("#lg-fp-admwrap"); if (w) w.style.display = ""; }
      lgMsg((r && r.error) || "Could not save the password.", true);
    }
  } catch (e) { lgMsg("Could not save the password: " + e, true); }
}

/* A workspace is a FOLDER. Offering the places this machine actually has - OneDrive, Dropbox,
   Documents - is what lets the first person decide whether their team's protocols live on this PC
   or somewhere the rest of the team already sees. */
async function lgStorage() {
  lgCardHold((($("#lg-su-card") || {}).dataset || {}).card || "");
  const c = $("#lg-su-card-clear");
  if (c) c.onclick = function () { lgCardHold(""); };
  // A folder is chosen by browsing to it. A list of places this PC happens to have could not
  // reach a mapped drive or a nested folder, which is where a real team keeps its work.
  const el = $("#lg-su-path"); if (!el) return;
  // Documents is where a person expects their own work to be, so a new workspace starts there
  // and lands beside the default one rather than somewhere nobody thinks to look.
  if (!el.dataset.path) {
    try {
      const r = await (await fetch("/api/storage")).json();
      const docs = ((r && r.places) || []).find(function (x) { return x.label === "Documents"; });
      if (docs && docs.path) el.dataset.path = docs.path;
    } catch (e) { /* browsing to one still works */ }
  }
  wsPathSet(el, el.dataset.path || "");
  const note = $("#lg-su-note");
  if (note) note.textContent = "Where this workspace keeps its protocols.";
  const b = $("#lg-su-browse");
  if (b) b.onclick = () => wsBrowse(el.dataset.path || "", p => wsPathSet(el, p));
}

async function lgSignup() {
  const newWs = ($("#lg-su-new").value || "").trim();
  let ws = $("#lg-su-ws").value || "";
  if (newWs) {
    const path = (($("#lg-su-path") || {}).dataset || {}).path || "";
    const w = await (await fetch("/api/workspaces", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newWs, path: path }) })).json();
    if (!w || !w.ok) return lgMsg((w && w.error) || "Workspace could not be created.", true);
    ws = w.id;
  }
  const body = { workspace: ws, name: ($("#lg-su-name").value || "").trim(),
                 password: ($("#lg-su-pw").value || ""),
                 card: (($("#lg-su-card") || {}).dataset || {}).card || "" };
  const r = await (await fetch("/api/signup", { method: "POST",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
  if (r && r.ok) {
    lgCardHold("");
    await lgWorkspaces();
    lgPane("main");
    $("#lg-ws").value = ws; $("#lg-name").value = body.name; $("#lg-pw").value = "";
    lgMsg("Account created. Sign in to continue.");
  } else lgMsg((r && r.error) || "Account could not be created.", true);
}

async function lgReset() {
  const body = { workspace: $("#lg-fg-ws").value || "",
                 name: ($("#lg-fg-name").value || "").trim(),
                 admin: ($("#lg-fg-admin").value || ""),
                 password: ($("#lg-fg-new").value || "") };
  const r = await (await fetch("/api/password/reset", { method: "POST",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
  $("#lg-fg-admin").value = "";
  if (r && r.ok) {
    lgPane("main");
    $("#lg-ws").value = body.workspace; $("#lg-name").value = body.name;
    lgMsg("Password updated. Sign in to continue.");
  } else lgMsg((r && r.error) || "Password reset failed.", true);
}

async function lgCard(code) {
  try {
    const r = await (await fetch("/api/session", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ card: code }) })).json();
    if (r && r.ok) { whoSession = r.session; whoRender(); lgShow(false); return; }
    // A card nobody has claimed is almost always a new person at the bench, so this opens the
    // account form with the card already attached rather than turning them away.
    lgCardState(true, "present a card to sign in");
    lgCardHold(code);
    lgPane("signup"); lgWorkspaces(); lgStorage();
    lgMsg("This card is not registered yet. Create an account and it will be linked to it.");
    setTimeout(function () { const n = $("#lg-su-name"); if (n) n.focus(); }, 60);
  } catch (e) {
    lgCardState(true, "present a card to sign in");
    lgMsg("That card could not be checked: " + e, true);
  }
}

/* The card in hand, shown on the account form so a person can see it is their own badge. */
function lgCardHold(code) {
  const el = $("#lg-su-card"); if (!el) return;
  el.dataset.card = code || "";
  el.textContent = code || "none - swipe a card to link one";
}

/* The state describes what the STATION is doing: while the sign-in page is up it is watching
   every keystroke for a card, so it reads active. It does not claim a reader is plugged in -
   a wedge reader is a keyboard and cannot be detected - only that a card will be acted on. */
function lgCardState(on, hint) {
  const d = $("#lg-card-dot"), st = $("#lg-card-state"), h = $("#lg-card-hint"), box = $("#lg-card");
  if (d) d.classList.toggle("on", !!on);
  if (st) st.textContent = on ? "active" : "inactive";
  if (box) box.classList.toggle("hot", !!on);
  if (h && hint !== undefined) h.textContent = hint;
}

/* A badge reader types far faster than a person, and that is the only way it can be told apart:
   a wedge reader IS a keyboard. Readers vary, so this is deliberately tolerant of them and still
   strict about people - it accepts Enter or Tab as the terminator, allows one slow keystroke in
   four, and ignores anything typed with a modifier held. A password typed by hand never matches. */
const LG_FAST_MS = 90;     // a gap this short is machine speed
const LG_IDLE_MS = 300;    // a longer pause means a new sequence started
const LG_MIN_LEN = 4;

(function lgReader() {
  let buf = "", last = 0, fast = 0, gaps = 0;
  function reset() { buf = ""; fast = 0; gaps = 0; }
  document.addEventListener("keydown", function (e) {
    if (e.ctrlKey || e.altKey || e.metaKey) return reset();
    const now = performance.now(), gap = now - last; last = now;
    if (e.key === "Enter" || e.key === "Tab") {
      // a reader that ends with Tab would otherwise move the focus and lose the swipe
      const swiped = buf.length >= LG_MIN_LEN && gaps > 0 && fast >= Math.ceil(gaps * 0.75);
      if (swiped) {
        e.preventDefault();
        const code = buf.replace(/^[;%]+/, "").replace(/[?]+$/, "");
        reset();
        const su = $("#lg-signup-form");
        if (su && su.style.display !== "none") {
          // already filling in an account: the swipe is enrolling a badge, not signing in
          lgCardState(true, "card held for this account");
          lgCardHold(code);
          lgMsg("Card read. It will be linked when the account is created.");
          return;
        }
        lgCardState(true, "card read, checking it");
        lgCard(code);
        return;
      }
      reset(); return;
    }
    if (e.key.length !== 1) return;
    if (gap > LG_IDLE_MS) reset();
    else { gaps++; if (gap < LG_FAST_MS) fast++; }
    buf += e.key;
    if (buf.length > 64) reset();
  }, true);
})();

async function lgSignOut() {
  await fetch("/api/session", { method: "POST", headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ out: true }) });
  whoSession = { id: "", name: "", workspace: "", workspace_name: "" };
  whoRender(); lgShow(true);
}

if ($("#lg-go"))       $("#lg-go").onclick       = lgLogin;
if ($("#lg-su-go"))    $("#lg-su-go").onclick    = lgSignup;
if ($("#lg-fg-go"))    $("#lg-fg-go").onclick    = lgReset;
if ($("#lg-fp-go"))    $("#lg-fp-go").onclick    = lgFirstSave;
if ($("#lg-fp-back"))  $("#lg-fp-back").onclick  = function () { lgFirst = null; lgPane("main"); };
if ($("#lg-signup"))   $("#lg-signup").onclick   = function () { lgPane("signup"); lgWorkspaces(); lgStorage(); };
if ($("#lg-forgot"))   $("#lg-forgot").onclick   = function () { lgPane("forgot"); lgWorkspaces(); };
if ($("#lg-su-back"))  $("#lg-su-back").onclick  = function () { lgPane("main"); };
if ($("#lg-wsman"))    $("#lg-wsman").onclick    = function () { wsManage(); };
if ($("#lg-fg-back"))  $("#lg-fg-back").onclick  = function () { lgPane("main"); };
if ($("#whoBtn"))      $("#whoBtn").onclick      = function () { if (whoSession.id) lgSignOut(); else lgShow(true); };
["#lg-pw", "#lg-name"].forEach(function (sel) {
  const el = $(sel); if (el) el.addEventListener("keydown", function (e) {
    if (e.key === "Enter") { e.preventDefault(); lgLogin(); } });
});

/* Ask the station who is already signed in - a reload should not throw someone out - and show the
   page only if nobody is. */
(async function lgBoot() {
  try {
    const r = await (await fetch("/api/operators")).json();
    if (r && r.ok && r.session && r.session.id) { whoSession = r.session; whoRender(); lgShow(false); return; }
  } catch (e) { /* fall through to the login page */ }
  whoRender(); lgShow(true);
})();

/* ---------- protocols ----------
   A protocol is a run written down. The catalogue of what a step CAN be comes from the station
   (/api/protocol/ops), so this page can never offer a step the executor does not know how to
   perform. Everything else here is the document: add, reorder, set up, check, save, run.

   The middle column is the run itself and the outer two act on it, so there is one obvious place
   to look for what a step is and one for what it is set to. */
let PR_OPS = {}, PR_STATIONS = [], PR_LINKS = {}, PR_TEMPLATES = [];
let prSteps = [], prSel = -1, prId = "", prDirty = false, prProblems = [];
let prRunning = false, prPaused = false, prRunIdx = -1, prRunAt = -1, prRunTotal = 0;
let prPoll = null, prEta = 0, prDragFrom = -1, prRunDone = new Set(), prRunStarted = 0;

/* Editing without undo makes a long protocol frightening to touch, so every change that alters
   the document records the state before it. Twenty deep is plenty for a hand-built sequence. */
let prUndo = [];
function prMark() {
  prUndo.push(JSON.stringify({ steps: prSteps, sel: prSel }));
  if (prUndo.length > 20) prUndo.shift();
  const b = $("#pr-undo"); if (b) b.disabled = false;
}
function prUndoStep() {
  if (prRunning || !prUndo.length) return;
  const was = JSON.parse(prUndo.pop());
  prSteps = was.steps;
  prSel = Math.min(was.sel, prSteps.length - 1);
  prDirty = true;
  const b = $("#pr-undo"); if (b) b.disabled = !prUndo.length;
  prRender(); prProps(); prCheckNow();
}

function prOp(key) { return PR_OPS[key] || null; }
function prStationLabel(k) { const s = PR_STATIONS.find(x => x.key === k); return s ? s.label : k; }
function prStationColour(k) {
  return { flow: "#6a7178", pt: "#007bc0", opta: "#5b8c3e",
           tc: "#a4681f", by: "#7a5aa8" }[k] || "#007bc0";
}

/* ---- the catalogue, and the palette built from it ---- */
async function prLoadOps() {
  try {
    const r = await (await fetch("/api/protocol/ops")).json();
    if (!r || !r.ok) return;
    PR_OPS = {}; (r.ops || []).forEach(o => { PR_OPS[o.key] = o; });
    PR_STATIONS = r.stations || [];
    PR_LINKS = r.links || {};
    prPalette();
  } catch (e) { /* the palette simply stays as it was */ }
  try {
    const t = await (await fetch("/api/protocol/templates")).json();
    PR_TEMPLATES = (t && t.templates) || [];
    if (!prSteps.length) prRender();
  } catch (e) { /* without templates the empty page simply offers none */ }
}

/* Load a protocol into the editor from any source - a template, a saved one, or a file. The note
   is shown AFTER the check, because the check clears the message area as it reports. */
async function prLoad(name, steps, id, note) {
  prUndo = []; const ub = $("#pr-undo"); if (ub) ub.disabled = true;
  prId = id || "";
  prSteps = JSON.parse(JSON.stringify(steps || []));
  const nm = $("#pr-name"); if (nm) nm.value = name || "";
  prSel = prSteps.length ? 0 : -1;
  prDirty = !id;
  prRender(); prProps();
  await prCheckNow();
  if (note && !prProblems.length) prSay(note);
}

function prPalette() {
  const host = $("#pr-palette"); if (!host) return;
  const find = (($("#pr-find") || {}).value || "").trim().toLowerCase();
  host.textContent = "";
  let shown = 0;
  PR_STATIONS.forEach(st => {
    const ops = Object.values(PR_OPS).filter(o => o.station === st.key
      && (!find || (o.label + " " + o.hint + " " + st.label).toLowerCase().indexOf(find) >= 0));
    if (!ops.length) return;
    shown += ops.length;
    const h = document.createElement("div");
    h.className = "prgrp";
    const d = document.createElement("span");
    d.className = "d" + (st.needs === null ? "" : (PR_LINKS[st.key] ? " up" : " down"));
    if (st.needs !== null) d.title = PR_LINKS[st.key] ? "connected" : "not connected";
    h.appendChild(d);
    h.appendChild(document.createTextNode(st.label));
    host.appendChild(h);
    ops.forEach(o => {
      const b = document.createElement("button");
      b.className = "prbtn"; b.type = "button"; b.title = o.hint;
      const sw = document.createElement("span");
      sw.className = "sw"; sw.style.background = prStationColour(o.station);
      b.appendChild(sw);
      b.appendChild(document.createTextNode(o.label));
      b.onclick = () => prAdd(o.key);
      host.appendChild(b);
    });
  });
  if (!shown) {
    const p = document.createElement("p"); p.className = "hint";
    p.textContent = "No step matches that.";
    host.appendChild(p);
  }
}

/* ---- the document ---- */
function prDefaults(key) {
  const spec = prOp(key), a = {};
  if (spec) spec.fields.forEach(f => {
    a[f.name] = (f.value !== undefined ? f.value : (f.kind === "number" ? 0 : ""));
  });
  return a;
}
function prAdd(key) {
  if (prRunning) return;
  prMark();
  const at = (prSel >= 0 ? prSel + 1 : prSteps.length);
  prSteps.splice(at, 0, { op: key, args: prDefaults(key), off: false, after: 0 });
  prSel = at; prDirty = true; prRender(); prProps(); prValidate();
}
function prRemove(i) {
  if (prRunning) return;
  prMark();
  prSteps.splice(i, 1);
  if (prSel >= prSteps.length) prSel = prSteps.length - 1;
  prDirty = true; prRender(); prProps(); prValidate();
}
function prDup(i) {
  if (prRunning) return;
  prMark();
  prSteps.splice(i + 1, 0, JSON.parse(JSON.stringify(prSteps[i])));
  prSel = i + 1; prDirty = true; prRender(); prProps(); prValidate();
}
function prMove(i, to) {
  if (prRunning || to < 0 || to >= prSteps.length) return;
  prMark();
  const s = prSteps.splice(i, 1)[0];
  prSteps.splice(to, 0, s);
  prSel = to; prDirty = true; prRender(); prProps(); prValidate();
}
function prToggle(i) {
  if (prRunning) return;
  prMark();
  prSteps[i].off = !prSteps[i].off;
  prDirty = true; prRender(); prValidate();
}

/* A step's one-line summary: what it is set to, without opening it. */
function prSummary(st) {
  const spec = prOp(st.op); if (!spec) return "";
  const bits = spec.fields.map(f => {
    const v = st.args[f.name];
    if (f.kind === "choice") {
      const o = (f.options || []).find(x => String(x.v) === String(v));
      return o ? o.label : String(v);
    }
    if (f.kind === "text") return String(v || "").slice(0, 40);
    // the station supplies how a value reads in one line ("up to 300s"), so the summary is
    // written for a person rather than assembled out of a form label
    return f.sum ? f.sum.replace("{v}", v) : (f.label + " " + v);
  }).filter(Boolean);
  if (Number(st.after) > 0) bits.push("then wait " + st.after + "s");
  return bits.join("   ");
}

function prRender() {
  const lane = $("#pr-lane"); if (!lane) return;
  lane.textContent = "";
  if (!prSteps.length) {
    const e = document.createElement("div");
    e.className = "prempty";
    const p = document.createElement("div");
    p.textContent = "No steps yet. Pick one from the left, or start from a run this bench already does.";
    e.appendChild(p);
    if (PR_TEMPLATES.length && !prRunning) {
      const row = document.createElement("div");
      row.className = "prtpl";
      PR_TEMPLATES.forEach(t => {
        const b = document.createElement("button");
        b.className = "ghost"; b.type = "button"; b.title = t.what;
        b.textContent = t.name;
        b.onclick = () => prLoad(t.name, t.steps, "");
        row.appendChild(b);
      });
      e.appendChild(row);
    }
    lane.appendChild(e);
  }
  const badAt = new Set(prProblems.filter(p => p.i >= 0).map(p => p.i));
  // work out which steps sit inside a repeat, so the run's shape is visible without reading it
  const inside = new Array(prSteps.length).fill(0);
  let depth = 0;
  prSteps.forEach((st, i) => {
    if (st.op === "flow.mark") { inside[i] = depth; depth++; return; }
    if (st.op === "flow.repeat") { depth = Math.max(0, depth - 1); inside[i] = depth; return; }
    inside[i] = depth;
  });
  prSteps.forEach((st, i) => {
    if (i) { const a = document.createElement("div"); a.className = "prarrow"; lane.appendChild(a); }
    const spec = prOp(st.op);
    const row = document.createElement("div");
    row.className = "prstep" + (i === prSel ? " sel" : "") + (st.off ? " off" : "")
                  + (badAt.has(i) ? " bad" : "")
                  + (prRunning && i === prRunIdx ? " run" : "")
                  + (prRunning && prRunDone.has(i) && i !== prRunIdx ? " done" : "")
                  + (inside[i] ? " in" : "");
    row.tabIndex = 0;
    row.draggable = !prRunning;
    row.dataset.i = i;

    const grip = document.createElement("span"); grip.className = "grip"; row.appendChild(grip);
    const n = document.createElement("span"); n.className = "n";
    n.textContent = String(i + 1).padStart(2, "0"); row.appendChild(n);
    const sw = document.createElement("span"); sw.className = "sw";
    sw.style.background = prStationColour(spec ? spec.station : "flow"); row.appendChild(sw);
    const nm = document.createElement("span"); nm.className = "nm";
    nm.textContent = spec ? spec.label : st.op; row.appendChild(nm);
    const pm = document.createElement("span"); pm.className = "pm";
    pm.textContent = prSummary(st); row.appendChild(pm);
    const sp = document.createElement("span"); sp.className = "sp"; row.appendChild(sp);

    const acts = document.createElement("span"); acts.className = "acts";
    if (prRunning) acts.style.display = "none";
    [["Up", () => prMove(i, i - 1)], ["Down", () => prMove(i, i + 1)],
     ["Copy", () => prDup(i)], [st.off ? "Include" : "Skip", () => prToggle(i)],
     ["Remove", () => prRemove(i)]].forEach(pair => {
      const b = document.createElement("button");
      b.type = "button"; b.textContent = pair[0]; b.title = pair[0];
      b.onclick = e => { e.stopPropagation(); pair[1](); };
      acts.appendChild(b);
    });
    row.appendChild(acts);

    row.onclick = () => { if (prRunning) return; prSel = i; prRender(); prProps(); };
    row.onkeydown = e => {
      if (e.key === "Delete") { e.preventDefault(); prRemove(i); }
      else if (e.key === "ArrowUp" && e.altKey) { e.preventDefault(); prMove(i, i - 1); prFocus(i - 1); }
      else if (e.key === "ArrowDown" && e.altKey) { e.preventDefault(); prMove(i, i + 1); prFocus(i + 1); }
      else if (e.key === "ArrowUp") { e.preventDefault(); prSel = Math.max(0, i - 1); prRender(); prProps(); prFocus(prSel); }
      else if (e.key === "ArrowDown") { e.preventDefault(); prSel = Math.min(prSteps.length - 1, i + 1); prRender(); prProps(); prFocus(prSel); }
      else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); prSel = i; prRender(); prProps(); }
    };
    row.ondragstart = e => {
      prDragFrom = i; row.classList.add("drag");
      e.dataTransfer.effectAllowed = "move";
      try { e.dataTransfer.setData("text/plain", String(i)); } catch (x) {}
    };
    row.ondragend  = () => { prDragFrom = -1; prRender(); };
    row.ondragover = e => {
      if (prDragFrom < 0) return;
      e.preventDefault();
      const r = row.getBoundingClientRect(), after = (e.clientY - r.top) > r.height / 2;
      row.classList.toggle("dropafter", after);
      row.classList.toggle("dropbefore", !after);
    };
    row.ondragleave = () => row.classList.remove("dropafter", "dropbefore");
    row.ondrop = e => {
      e.preventDefault();
      if (prDragFrom < 0) return;
      const r = row.getBoundingClientRect(), after = (e.clientY - r.top) > r.height / 2;
      let to = i + (after ? 1 : 0);
      if (prDragFrom < to) to--;
      const from = prDragFrom; prDragFrom = -1;
      prMove(from, to);
    };
    lane.appendChild(row);
  });
  if (prRunning && prRunIdx >= 0) {
    const cur = lane.querySelector(".prstep.run");
    if (cur) {
      const lr = lane.getBoundingClientRect(), cr = cur.getBoundingClientRect();
      if (cr.top < lr.top || cr.bottom > lr.bottom) {
        lane.scrollTop += (cr.top - lr.top) - (lr.height - cr.height) / 2;
      }
    }
  }
  prCounts();
}

function prFocus(i) {
  const lane = $("#pr-lane"); if (!lane) return;
  const el = lane.querySelector('.prstep[data-i="' + i + '"]');
  if (el) el.focus();
}

function prDur(s) {
  s = Math.round(s);
  if (s < 60) return s + "s";
  const m = Math.floor(s / 60);
  if (m < 60) return (s % 60) ? m + "m " + (s % 60) + "s" : m + "m";
  return Math.floor(m / 60) + "h " + (m % 60) + "m";
}

function prCounts() {
  const live = prSteps.filter(s => !s.off).length;
  const c = $("#pr-count");
  if (c) c.textContent = prRunning && prRunAt >= 0
        ? "step " + (prRunAt + 1) + " of " + prRunTotal
        : (!prSteps.length ? "no steps"
           : live + " step" + (live === 1 ? "" : "s")
             + (live !== prSteps.length ? ", " + (prSteps.length - live) + " skipped" : ""));
  const e = $("#pr-eta");
  if (e) e.textContent = prRunning && prRunStarted
        ? prDur((Date.now() - prRunStarted) / 1000) + " elapsed"
        : (prEta ? "about " + prDur(prEta) : "");
  const nm = $("#pr-name");
  if (nm) nm.style.borderColor = prDirty ? "var(--warn)" : "";
  const sv = $("#pr-save");
  if (sv) sv.textContent = prDirty ? "Save changes" : "Save";
}

/* ---- the inspector ---- */
function prProps() {
  const host = $("#pr-props"), title = $("#pr-props-title");
  if (!host) return;
  host.textContent = "";
  const at = (prRunning && prRunIdx >= 0 && prRunIdx < prSteps.length) ? prRunIdx : prSel;
  const st = prSteps[at], spec = st && prOp(st.op);
  if (!spec) {
    if (title) title.textContent = "Step";
    const p = document.createElement("p"); p.className = "hint";
    p.textContent = "Pick a step to set it up.";
    host.appendChild(p);
    return;
  }
  if (title) title.textContent = spec.label;

  const who = document.createElement("p");
  who.className = "sub";
  who.textContent = prStationLabel(spec.station) + ". " + spec.hint;
  host.appendChild(who);

  if (spec.danger) {
    const w = document.createElement("div");
    w.className = "warnbox"; w.style.margin = "0 0 12px";
    w.textContent = "This step energises or stops hardware. The station's own interlocks still apply.";
    host.appendChild(w);
  }

  spec.fields.forEach(f => {
    const wrap = document.createElement("div"); wrap.className = "prfield";
    const lab = document.createElement("label");
    lab.textContent = f.label; lab.htmlFor = "prf-" + f.name;
    wrap.appendChild(lab);
    let el;
    if (f.kind === "choice") {
      el = document.createElement("select");
      (f.options || []).forEach(o => {
        const opt = document.createElement("option");
        opt.value = String(o.v); opt.textContent = o.label;
        el.appendChild(opt);
      });
      el.value = String(st.args[f.name]);
      el.onchange = () => {
        const o = (f.options || []).find(x => String(x.v) === el.value);
        st.args[f.name] = o ? o.v : el.value;
        prDirty = true; prRender(); prValidate();
      };
    } else if (f.kind === "number") {
      el = document.createElement("input");
      el.type = "number";
      if (f.min !== undefined) el.min = f.min;
      if (f.max !== undefined) el.max = f.max;
      if (f.step !== undefined) el.step = f.step;
      el.value = st.args[f.name];
      el.oninput = () => {
        st.args[f.name] = el.value === "" ? "" : Number(el.value);
        prDirty = true; prRender(); prValidate();
      };
    } else {
      el = document.createElement("input");
      el.type = "text";
      if (f.max) el.maxLength = f.max;
      el.value = st.args[f.name] || "";
      el.oninput = () => { st.args[f.name] = el.value; prDirty = true; prRender(); prValidate(); };
    }
    el.id = "prf-" + f.name;
    wrap.appendChild(el);
    host.appendChild(wrap);
  });

  // Every step can hold for a moment before the next command goes out, whatever the step is.
  // Some hardware needs it, and this saves putting a Wait between every pair of steps.
  const dw = document.createElement("div"); dw.className = "prfield";
  const dl = document.createElement("label");
  dl.textContent = "Delay after (s)"; dl.htmlFor = "prf-after";
  dw.appendChild(dl);
  const di = document.createElement("input");
  di.type = "number"; di.min = 0; di.max = 3600; di.step = 0.1;
  di.id = "prf-after"; di.value = st.after || 0;
  di.oninput = () => { st.after = di.value === "" ? 0 : Number(di.value);
                       prDirty = true; prRender(); prValidate(); };
  dw.appendChild(di);
  const dh = document.createElement("span");
  dh.className = "hint"; dh.style.marginTop = "4px";
  dh.textContent = "Wait this long after this step before the next command.";
  dw.appendChild(dh);
  host.appendChild(dw);

  if (!spec.fields.length) {
    const p = document.createElement("p"); p.className = "hint";
    p.textContent = "This step has nothing else to set.";
    host.appendChild(p);
  }

  const mine = prProblems.filter(p => p.i === at);
  if (mine.length) {
    const box = document.createElement("div"); box.className = "prprob";
    const b = document.createElement("b"); b.textContent = "This step needs attention";
    box.appendChild(b);
    mine.forEach(p => { const d = document.createElement("div"); d.textContent = p.text; box.appendChild(d); });
    host.appendChild(box);
  }

  // While a run is going the sequence is a record of what is happening, not something to edit.
  if (prRunning) {
    host.querySelectorAll("input,select").forEach(e => { e.disabled = true; });
    const p = document.createElement("p"); p.className = "hint"; p.style.marginTop = "12px";
    p.textContent = "This is the step running now. Stop the run to change it.";
    host.appendChild(p);
    return;
  }
  const row = document.createElement("div");
  row.className = "row"; row.style.marginTop = "14px";
  const skip = document.createElement("button");
  skip.className = "ghost"; skip.type = "button";
  skip.textContent = st.off ? "Include this step" : "Skip this step";
  skip.onclick = () => { prToggle(at); prProps(); };
  const del = document.createElement("button");
  del.className = "ghost"; del.type = "button"; del.textContent = "Remove";
  del.onclick = () => { prRemove(at); };
  row.appendChild(skip); row.appendChild(del);
  host.appendChild(row);
}

/* ---- checking ---- */
let prCheckTimer = null;
function prValidate() {
  clearTimeout(prCheckTimer);
  prCheckTimer = setTimeout(prCheckNow, 220);
}
async function prCheckNow() {
  const box = $("#pr-problems"); if (!box) return;
  if (!prSteps.length) { prProblems = []; prEta = 0; box.textContent = ""; prRender(); return; }
  try {
    const r = await (await fetch("/api/protocols/validate", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ steps: prSteps })
    })).json();
    prProblems = (r && r.problems) || [];
    prEta = (r && r.secs) || 0;
  } catch (e) { prProblems = []; }
  box.textContent = "";
  if (prProblems.length) {
    const d = document.createElement("div"); d.className = "prprob";
    const b = document.createElement("b");
    b.textContent = prProblems.length + " thing" + (prProblems.length === 1 ? "" : "s")
                  + " to fix before this can run";
    d.appendChild(b);
    prProblems.forEach(p => {
      const line = document.createElement("div");
      line.textContent = (p.i >= 0 ? "Step " + (p.i + 1) + ": " : "") + p.text;
      d.appendChild(line);
    });
    box.appendChild(d);
  }
  prRender();
  prProps();
}

/* ---- who it belongs to ---- */
function prSyncOwner() {
  const el = $("#pr-owner"); if (!el) return;
  const on = !!(typeof whoSession === "object" && whoSession && whoSession.id);
  const dot = el.querySelector(".d");
  if (dot) dot.style.background = on ? "var(--ok)" : "var(--muted2)";
  const txt = el.querySelector("span:last-child");
  if (txt) txt.textContent = on
    ? whoSession.name + (whoSession.workspace_name ? ", " + whoSession.workspace_name : "")
    : "not signed in";
}

/* ---- saving and opening ---- */
function prSay(text, bad, keep) {
  const box = $("#pr-problems"); if (!box) return;
  box.textContent = "";
  const d = document.createElement("div");
  d.className = bad ? "prprob" : "okbox";
  d.textContent = text;
  box.appendChild(d);
  // A confirmation fades; a standing fact about the station does not.
  if (!bad && !keep) setTimeout(() => { if (box.firstChild === d) box.textContent = ""; }, 4000);
}

/* "Save as" keeps the one that was opened and writes a second: the way an operator makes a
   variant of a run without losing the run it came from. */
function prSaveAs() {
  const nameEl = $("#pr-name");
  const suggested = ((nameEl.value || "").trim() || "Untitled protocol") + " copy";
  const name = prompt("Save this as", suggested);
  if (name === null) return;
  if (!name.trim()) return prSay("Give the copy a name.", true);
  prId = ""; nameEl.value = name.trim();
  prSave();
}

async function prSave() {
  const nameEl = $("#pr-name"), name = (nameEl.value || "").trim();
  if (!name) { prSay("Give the protocol a name first.", true); nameEl.focus(); return; }
  if (!prSteps.length) { prSay("There are no steps to save.", true); return; }
  try {
    const r = await (await fetch("/api/protocols", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: prId, name: name, steps: prSteps,
                             workspace: (typeof whoSession === "object" && whoSession
                                         && whoSession.workspace) || "" })
    })).json();
    if (r && r.ok) {
      prId = r.id; prDirty = false; prCounts();
      prSay(r.warning ? ("Saved, but " + r.warning) : "Saved.", !!r.warning);
    } else {
      prProblems = (r && r.problems) || [];
      prRender();
      prSay((r && r.error) || "Could not save.", true);
    }
  } catch (e) { prSay("Could not save: " + e, true); }
}

function prSheet(title) { return uiSheet(title); }

async function prOpen() {
  const dlg = prSheet("Open a protocol");
  const list = document.createElement("div"); list.className = "prlist";
  dlg.sheet.appendChild(list);
  const foot = document.createElement("div");
  foot.className = "row"; foot.style.marginTop = "14px";
  const imp = document.createElement("button");
  imp.className = "ghost"; imp.type = "button"; imp.textContent = "Import a file";
  const pick = document.createElement("input");
  pick.type = "file"; pick.accept = ".json,application/json"; pick.style.display = "none";
  pick.onchange = () => { if (pick.files && pick.files[0]) prImport(pick.files[0], dlg.close); };
  imp.onclick = () => pick.click();
  const close = document.createElement("button");
  close.className = "ghost"; close.type = "button"; close.textContent = "Close";
  close.onclick = dlg.close;
  foot.appendChild(imp); foot.appendChild(pick); foot.appendChild(close);
  dlg.sheet.appendChild(foot);

  async function fill() {
    list.textContent = "";
    let items = [];
    const ws = (typeof whoSession === "object" && whoSession && whoSession.workspace) || "";
    try {
      const r = await (await fetch("/api/protocols?workspace=" + encodeURIComponent(ws))).json();
      items = (r && r.protocols) || [];
    } catch (e) { /* an empty list is what the operator sees, and it is honest */ }
    if (!items.length) {
      const p = document.createElement("p"); p.className = "hint";
      p.textContent = "Nothing saved in this workspace yet.";
      list.appendChild(p); return;
    }
    items.forEach(p => {
      const row = document.createElement("div"); row.className = "prrow";
      const col = document.createElement("div");
      const nm = document.createElement("div"); nm.className = "nm"; nm.textContent = p.name;
      const mt = document.createElement("div"); mt.className = "mt";
      mt.textContent = (p.steps || []).length + " steps"
                     + (p.secs ? ", about " + prDur(p.secs) : "")
                     + (p.owner_name ? ", " + p.owner_name : "")
                     + (p.saved ? ", " + p.saved : "");
      col.appendChild(nm); col.appendChild(mt); row.appendChild(col);
      const sp = document.createElement("span"); sp.className = "sp"; row.appendChild(sp);
      const go = document.createElement("button");
      go.className = "btn"; go.type = "button"; go.textContent = "Open";
      go.onclick = () => { dlg.close(); prLoad(p.name, p.steps, p.id); };
      const del = document.createElement("button");
      del.className = "ghost"; del.type = "button"; del.textContent = "Delete";
      del.onclick = async () => {
        del.disabled = true; del.textContent = "Deleting";
        try {
          await fetch("/api/protocols/delete", { method: "POST",
            headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: p.id }) });
        } catch (e) { /* the refresh below shows whether it went */ }
        if (prId === p.id) prId = "";
        fill();
      };
      const ex = document.createElement("button");
      ex.className = "ghost"; ex.type = "button"; ex.textContent = "Export";
      ex.title = "Save this protocol as a file you can carry to another station";
      ex.onclick = () => prExport(p.name, p.steps);
      row.appendChild(go); row.appendChild(ex); row.appendChild(del);
      list.appendChild(row);
    });
  }
  fill();

  if (PR_TEMPLATES.length) {
    const h = document.createElement("div");
    h.className = "prgrp"; h.style.marginTop = "16px";
    h.appendChild(document.createTextNode("Start from"));
    dlg.sheet.insertBefore(h, foot);
    const tl = document.createElement("div"); tl.className = "prlist";
    PR_TEMPLATES.forEach(t => {
      const row = document.createElement("div"); row.className = "prrow";
      const col = document.createElement("div");
      const nm = document.createElement("div"); nm.className = "nm"; nm.textContent = t.name;
      const mt = document.createElement("div"); mt.className = "mt";
      mt.textContent = t.what;
      col.appendChild(nm); col.appendChild(mt); row.appendChild(col);
      const sp = document.createElement("span"); sp.className = "sp"; row.appendChild(sp);
      const go = document.createElement("button");
      go.className = "ghost"; go.type = "button"; go.textContent = "Use";
      go.onclick = () => { dlg.close(); prLoad(t.name, t.steps, ""); };
      row.appendChild(go);
      tl.appendChild(row);
    });
    dlg.sheet.insertBefore(tl, foot);
  }
}

/* A workspace on a shared folder carries protocols on its own. A station that has no share still
   needs a way to hand one over, so a protocol is also a file. */
function prExport(name, steps) {
  const doc = { kind: "ifs-protocol", version: 1, name: name || "Untitled protocol",
                saved: new Date().toISOString().slice(0, 19).replace("T", " "), steps: steps || [] };
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(doc, null, 1)], { type: "application/json" }));
  a.download = (doc.name.replace(/[^A-Za-z0-9 _-]/g, "").trim() || "protocol") + ".ifsproto.json";
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

function prImport(file, done) {
  const rd = new FileReader();
  rd.onload = () => {
    let doc;
    try { doc = JSON.parse(rd.result); }
    catch (e) { prSay("That file is not a protocol.", true); return; }
    if (!doc || doc.kind !== "ifs-protocol" || !Array.isArray(doc.steps)) {
      prSay("That file is not a protocol written by this app.", true); return;
    }
    prLoad(doc.name || "Imported protocol", doc.steps, "",
            "Imported. Check it, then save it into this workspace.");
    if (done) done();
  };
  rd.onerror = () => prSay("That file could not be read.", true);
  rd.readAsText(file);
}

function prNew() {
  if (prRunning) return;
  if (prDirty && prSteps.length && !confirm("Start a new protocol and lose the unsaved changes?")) return;
  prId = ""; prSteps = []; prSel = -1; prDirty = false; prProblems = []; prEta = 0;
  $("#pr-name").value = "";
  prRender(); prProps(); prCheckNow();
}

/* ---- running ---- */
function prRunUI(on) {
  prRunning = on;
  ["pr-run", "pr-dry", "pr-clear", "pr-new", "pr-open", "pr-save"].forEach(id => {
    const b = $("#" + id); if (b) b.disabled = on;
  });
  const p = $("#pr-pause"), s = $("#pr-stop");
  if (p) { p.style.display = on ? "" : "none"; p.textContent = "Pause"; }
  if (s) s.style.display = on ? "" : "none";
  if (!on) {
    prRunIdx = -1;
    const c = $("#pr-confirm"); if (c) c.style.display = "none";
  }
  prRender();
}

function prLogLine(ev) {
  const lg = $("#pr-log"); if (!lg) return;
  const d = document.createElement("div");
  const t = document.createElement("span"); t.className = "k";
  t.textContent = new Date(ev.t * 1000).toLocaleTimeString() + "  ";
  d.appendChild(t);
  const body = document.createElement("span");
  if (ev.kind === "fail") body.className = "fail";
  else if (ev.kind === "ok" || ev.kind === "end") body.className = "ok";
  body.textContent = ((ev.i === null || ev.i === undefined) ? "" : "step " + (ev.i + 1) + "  ") + ev.text;
  d.appendChild(body);
  lg.appendChild(d);
  lg.scrollTop = lg.scrollHeight;
}

async function prStart(dry) {
  const name = ($("#pr-name").value || "").trim() || "Untitled protocol";
  const lg = $("#pr-log");
  if (lg) { lg.textContent = ""; lg.style.display = ""; }
  try {
    const r = await (await fetch("/api/protocols/run", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name, id: prId, dry: !!dry, steps: prSteps })
    })).json();
    if (!r || !r.ok) {
      if (r && r.problems) { prProblems = r.problems; prRender(); }
      prSay((r && r.error) || "Could not start the run.", true);
      if (lg) lg.style.display = "none";
      return;
    }
  } catch (e) {
    prSay("Could not start the run: " + e, true);
    if (lg) lg.style.display = "none";
    return;
  }
  prRunDone = new Set(); prRunStarted = Date.now();
  prRunUI(true);
  prWatch();
}

function prWatch() {
  clearInterval(prPoll);
  let seen = 0;
  prPoll = setInterval(async () => {
    let st;
    try { st = await (await fetch("/api/protocols/run/state")).json(); }
    catch (e) { return; }
    // i is the step as WRITTEN (what to highlight); k is how far through the real run it is,
    // and with a repeat in the protocol those two are deliberately different numbers.
    if (st.i >= 0) prRunDone.add(st.i);
    prRunIdx = st.i; prRunAt = (st.k === undefined ? st.i : st.k); prRunTotal = st.n || 0;
    (st.events || []).slice(seen).forEach(prLogLine);
    seen = (st.events || []).length;
    const c = $("#pr-confirm");
    if (c) {
      c.style.display = st.await_confirm ? "" : "none";
      const t = $("#pr-confirm-text"); if (t) t.textContent = st.await_confirm || "";
    }
    const p = $("#pr-pause");
    if (p) p.textContent = st.paused ? "Resume" : "Pause";
    prPaused = !!st.paused;
    if (!st.active) {
      clearInterval(prPoll); prPoll = null;
      const took = prRunStarted ? " in " + prDur((Date.now() - prRunStarted) / 1000) : "";
      prRunStarted = 0;
      prRunUI(false);
      prSay(st.error ? (st.result + ": " + st.error) : ("Run " + st.result + took + "."), !!st.error);
      prRuns();
    } else {
      prRender(); prProps();
    }
  }, 300);
}

/* ---- the record of what has been run ----
   A protocol is only worth writing down if there is a record that it was performed. The station
   keeps one; this shows it, with who ran it and how it ended. */
/* Empty the run log. It is a record of what this bench has done, so it asks first and says how
   many it removed - "cleared" with nothing to show is indistinguishable from a button that did
   nothing at all. */
async function prRunsClear() {
  const btn = $("#pr-runs-clear");
  if (!window.confirm("Clear the run log? This cannot be undone.")) return;
  if (btn) { btn.disabled = true; btn.textContent = "Clearing..."; }
  try {
    const r = await (await fetch("/api/protocols/runs", { method: "DELETE" })).json();
    const host = $("#pr-runs");
    if (r && r.ok) {
      if (host) {
        const p = document.createElement("p");
        p.className = "hint";
        p.textContent = r.cleared ? "Cleared " + r.cleared + " run"
                                    + (r.cleared === 1 ? "" : "s") + "." : "There was nothing to clear.";
        host.textContent = "";
        host.appendChild(p);
      }
      setTimeout(prRuns, 1400);
    } else if (host) {
      const p = document.createElement("p");
      p.className = "warnbox";
      p.textContent = (r && r.error) || "Could not clear the run log.";
      host.textContent = "";
      host.appendChild(p);
    }
  } catch (e) {
    const host = $("#pr-runs");
    if (host) { const p = document.createElement("p"); p.className = "warnbox";
                p.textContent = "Could not clear the run log: " + e;
                host.textContent = ""; host.appendChild(p); }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Clear"; }
  }
}

async function prRuns() {
  const host = $("#pr-runs"); if (!host) return;
  let runs = [];
  try {
    const r = await (await fetch("/api/protocols/runs")).json();
    runs = (r && r.runs) || [];
  } catch (e) { /* the empty note below is the honest answer */ }
  host.textContent = "";
  if (!runs.length) {
    const p = document.createElement("p"); p.className = "hint";
    p.textContent = "No runs recorded yet.";
    host.appendChild(p); return;
  }
  runs.forEach(r => {
    const row = document.createElement("div"); row.className = "prrun";
    const rs = document.createElement("span");
    rs.className = "rs " + (r.result === "finished" ? "good" : r.result === "failed" ? "bad" : "mid");
    rs.textContent = r.dry ? "dry" : (r.result || "");
    row.appendChild(rs);
    const nm = document.createElement("span"); nm.className = "nm";
    nm.textContent = r.protocol || "Untitled";
    nm.title = (r.error || "") + (r.who ? "  " + r.who : "");
    row.appendChild(nm);
    const mt = document.createElement("span"); mt.className = "mt";
    mt.textContent = (r.who ? r.who + ", " : "") + (r.when || "");
    row.appendChild(mt);
    host.appendChild(row);
  });
}

/* A run belongs to the STATION, not to this page. Reloading the app, or opening it in a second
   window, must therefore pick up a run already going rather than offering to start another one
   (which the station would refuse) and showing a Run button that cannot work. */
async function prResume() {
  let st;
  try { st = await (await fetch("/api/protocols/run/state")).json(); }
  catch (e) { return; }
  if (!st || !st.active || prRunning) return;
  const lg = $("#pr-log");
  if (lg) { lg.textContent = ""; lg.style.display = ""; }
  (st.events || []).forEach(prLogLine);
  prRunDone = new Set();
  prRunStarted = st.started ? st.started * 1000 : Date.now();
  const nm = $("#pr-name");
  if (nm && !nm.value && st.name) nm.value = st.name;
  prRunUI(true);
  prWatch();
  prSay("A run started elsewhere is going on this station.", false, true);
}

/* Asked before the page is left. A run in progress is the stronger reason to stay: stopping it
   from another page is not possible, so leaving would strand it. */
function prLeaving() {
  if (prRunning) return confirm("A run is going. Leave this page anyway? It will keep running.");
  if (prDirty && prSteps.length) return confirm("This protocol has unsaved changes. Leave anyway?");
  return true;
}

/* ---- wiring ---- */
(function prBind() {
  const on = (id, fn) => { const el = $("#" + id); if (el) el.onclick = fn; };
  on("pr-save", prSave);
  on("pr-open", prOpen);
  on("pr-new",  prNew);
  on("pr-run",  () => prStart(false));
  on("pr-dry",  () => prStart(true));
  on("pr-clear", () => {
    if (prRunning) return;
    if (prSteps.length && !confirm("Remove every step?")) return;
    prMark();
    prSteps = []; prSel = -1; prDirty = true; prRender(); prProps(); prCheckNow();
  });
  on("pr-stop", async () => {
    try { await fetch("/api/protocols/run/abort", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: "{}" }); } catch (e) {}
  });
  on("pr-pause", async () => {
    try { await fetch("/api/protocols/run/pause", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ on: !prPaused }) }); } catch (e) {}
  });
  on("pr-confirm-go", async () => {
    try { await fetch("/api/protocols/run/confirm", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: "{}" }); } catch (e) {}
  });
  on("pr-runs-refresh", prRuns);
  on("pr-runs-clear", prRunsClear);
  on("pr-undo",   prUndoStep);
  on("pr-saveas", prSaveAs);
  const find = $("#pr-find");
  if (find) find.oninput = prPalette;
  const nm = $("#pr-name");
  if (nm) nm.oninput = () => { prDirty = true; prCounts(); };
})();

prLoadOps();
prSyncOwner();
prRender();
prRuns();
prResume();

/* The palette's connection dots are only true if they are refreshed - a page left open while
   someone plugs a station in should say so. Only while the page is actually being looked at. */
setInterval(async () => {
  if (typeof currentView !== "undefined" && currentView !== "proto") return;
  try {
    const r = await (await fetch("/api/protocol/ops")).json();
    if (r && r.ok && JSON.stringify(r.links) !== JSON.stringify(PR_LINKS)) {
      PR_LINKS = r.links; prPalette();
    }
  } catch (e) { /* leave the dots as they are */ }
}, 4000);

window.prRender = prRender;
window.prSyncOwner = prSyncOwner;
window.prRuns = prRuns;
window.prLeaving = prLeaving;
window.prResume = prResume;

/* ---------- workspaces ----------
   A workspace is a folder. So choosing one means browsing to it, not picking from a short list of
   places this PC happens to have - a team whose share is a mapped drive or a nested folder could
   not choose it at all before.

   Managing them - rename, move, remove - is administrator work, so the actions that change where a
   team's work lives ask for the administrator password. Removing a workspace never deletes the
   folder: that is the team's own data, possibly shared with other stations. */

/* One sheet, used by everything here and by the protocol editor. */
function uiSheet(title, wide) {
  const bg = document.createElement("div"); bg.className = "sheet-bg";
  const sh = document.createElement("div"); sh.className = "sheet";
  if (wide) sh.style.width = "min(720px,94vw)";
  const h = document.createElement("h2"); h.textContent = title; sh.appendChild(h);
  bg.appendChild(sh);
  function shut() { bg.remove(); document.removeEventListener("keydown", esc); }
  function esc(e) { if (e.key === "Escape") shut(); }
  bg.onclick = e => { if (e.target === bg) shut(); };
  document.addEventListener("keydown", esc);
  document.body.appendChild(bg);
  return { bg: bg, sheet: sh, close: shut };
}

/* Walk the station's filesystem and hand back the folder that was chosen, or nothing. */
function wsBrowse(startAt, onPick) {
  const dlg = uiSheet("Choose a folder");
  const bar = document.createElement("div"); bar.className = "browsebar";
  const list = document.createElement("div"); list.className = "browse";
  const note = document.createElement("p"); note.className = "hint"; note.style.marginTop = "9px";
  dlg.sheet.appendChild(bar); dlg.sheet.appendChild(list); dlg.sheet.appendChild(note);

  const foot = document.createElement("div");
  foot.className = "row"; foot.style.marginTop = "14px";
  const use = document.createElement("button");
  use.className = "btn"; use.type = "button"; use.textContent = "Use this folder"; use.disabled = true;
  const cancel = document.createElement("button");
  cancel.className = "ghost"; cancel.type = "button"; cancel.textContent = "Cancel";
  cancel.onclick = dlg.close;
  foot.appendChild(use); foot.appendChild(cancel); dlg.sheet.appendChild(foot);

  let here = "";
  async function go(path) {
    let r;
    try { r = await (await fetch("/api/browse?path=" + encodeURIComponent(path || ""))).json(); }
    catch (e) { note.textContent = "The station could not read that folder."; return; }
    if (!r || !r.ok) { note.textContent = (r && r.error) || "That folder cannot be opened."; return; }
    here = r.path || "";
    bar.textContent = here || "This computer";
    note.textContent = !here ? "Pick a drive or a place to start from."
                     : r.writable ? (r.truncated ? "Showing the first folders only." : "")
                     : "This folder cannot be written, so a workspace cannot be kept here.";
    use.disabled = !here || !r.writable;
    list.textContent = "";
    const add = (label, path, up) => {
      const b = document.createElement("button");
      b.type = "button"; if (up) b.className = "up";
      const ic = document.createElement("span"); ic.className = "ic"; b.appendChild(ic);
      b.appendChild(document.createTextNode(label));
      b.onclick = () => go(path);
      list.appendChild(b);
    };
    if (here) add("Up one level", r.parent || "", true);
    if (!here && r.native) {
      // macOS: the Finder panel. On a Mac App Store copy it is the ONLY way to reach a folder -
      // the sandbox grants access to what the operator picks there, and the app remembers it.
      const fb = document.createElement("button");
      fb.type = "button";
      const ic = document.createElement("span"); ic.className = "ic"; fb.appendChild(ic);
      fb.appendChild(document.createTextNode("Choose in Finder…"));
      fb.onclick = async () => {
        let p;
        try {
          p = await (await fetch("/api/browse/native", {method: "POST", headers: {"Content-Type": "application/json"},
                                                         body: JSON.stringify({path: here})})).json();
        } catch (e) { note.textContent = "The Finder panel could not be opened."; return; }
        if (!p || !p.ok) { note.textContent = (p && p.error) || "The Finder panel could not be opened."; return; }
        if (p.path) go(p.path);
      };
      list.appendChild(fb);
    }
    if (!here) (r.roots || []).forEach(x => add(x.name + (x.note ? "   " + x.note : ""), x.path));
    (r.folders || []).forEach(f => add(f.name, f.path));
    if (here && !(r.folders || []).length) {
      const p = document.createElement("div");
      p.style.cssText = "padding:10px 11px;color:var(--muted2);font-size:12.5px";
      p.textContent = "No folders inside this one.";
      list.appendChild(p);
    }
  }
  use.onclick = () => { dlg.close(); if (onPick) onPick(here); };
  go(startAt || "");
}

/* The data location on the sign-up pane: browse to it, and see what was chosen. */
function wsPathSet(el, path) {
  if (!el) return;
  el.dataset.path = path || "";
  el.textContent = path || "This station only";
  el.title = path || "Kept inside the app's own folder on this PC";
}

/* ---- the management sheet ---- */
async function wsManage() {
  const dlg = uiSheet("Workspaces", true);
  const sub = document.createElement("p");
  sub.className = "sub";
  sub.textContent = "A workspace is a folder. Its protocols live where it points.";
  dlg.sheet.appendChild(sub);
  const list = document.createElement("div"); list.className = "prlist";
  dlg.sheet.appendChild(list);
  const msg = document.createElement("div"); msg.style.marginTop = "10px";
  dlg.sheet.appendChild(msg);

  const foot = document.createElement("div");
  foot.className = "row"; foot.style.marginTop = "14px";
  const mk = document.createElement("button");
  mk.className = "btn"; mk.type = "button"; mk.textContent = "New workspace";
  const close = document.createElement("button");
  close.className = "ghost"; close.type = "button"; close.textContent = "Close";
  close.onclick = dlg.close;
  foot.appendChild(mk); foot.appendChild(close);
  dlg.sheet.appendChild(foot);

  function say(text, bad) {
    msg.textContent = "";
    if (!text) return;
    const d = document.createElement("div");
    d.className = bad ? "prprob" : "okbox";
    d.textContent = text;
    msg.appendChild(d);
  }
  function ask(what) {
    const p = prompt(what + "\n\nAdministrator password:");
    return p === null ? null : p;
  }

  async function fill() {
    list.textContent = "";
    let ws = [], cur = "";
    try {
      const r = await (await fetch("/api/workspaces/detail")).json();
      ws = (r && r.workspaces) || []; cur = (r && r.current) || "";
    } catch (e) { say("The station could not list the workspaces.", true); return; }
    ws.forEach(w => {
      const row = document.createElement("div");
      row.className = "wsrow" + (w.id === cur ? " cur" : "");
      const col = document.createElement("div"); col.style.minWidth = "0";
      const nm = document.createElement("div"); nm.className = "nm";
      nm.textContent = w.name + (w.id === cur ? "   signed in here" : "");
      const mt = document.createElement("div"); mt.className = "mt";
      mt.textContent = w.people + (w.people === 1 ? " account" : " accounts")
                     + ", " + w.protocols + (w.protocols === 1 ? " protocol" : " protocols")
                     + "   " + (w.folder ? w.folder : "this station only")
                     + (w.folder && !w.exists ? "   folder is missing"
                        : (w.folder && !w.writable ? "   folder cannot be written" : ""));
      mt.title = w.folder || "Kept inside the app's own folder on this PC";
      col.appendChild(nm); col.appendChild(mt); row.appendChild(col);
      const sp = document.createElement("span"); sp.className = "sp"; row.appendChild(sp);

      const acts = document.createElement("span"); acts.className = "acts";
      const btn = (label, title, fn, cls) => {
        const b = document.createElement("button");
        b.className = cls || "ghost"; b.type = "button"; b.textContent = label; b.title = title;
        b.onclick = fn; acts.appendChild(b); return b;
      };

      btn("Rename", "Change what this workspace is called", async () => {
        const name = prompt("Rename this workspace", w.name);
        if (name === null || !name.trim()) return;
        const r = await (await fetch("/api/workspaces/update", { method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: w.id, name: name.trim() }) })).json();
        if (r && r.ok) { say("Renamed."); fill(); if (typeof whoRender === "function") whoRender(); }
        else say((r && r.error) || "Could not rename it.", true);
      });

      btn("Folder", "Move where this workspace keeps its protocols", () => {
        wsBrowse(w.folder || "", async where => {
          const admin = ask("Moving " + w.name + " to:\n" + where);
          if (admin === null) return;
          const r = await (await fetch("/api/workspaces/update", { method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: w.id, path: where, admin: admin }) })).json();
          if (r && r.ok) {
            say("Moved" + (r.carried ? ", carrying " + r.carried + " protocol"
                                       + (r.carried === 1 ? "" : "s") : "")
                + (r.warning ? " - " + r.warning : "") + ".", !!r.warning);
            fill();
          } else say((r && r.error) || "Could not move it.", true);
        });
      });

      btn("Remove", "Remove this workspace from the station", async () => {
        const admin = ask("Remove the workspace " + w.name + ".\nThe folder on disk is left alone.");
        if (admin === null) return;
        const send = force => fetch("/api/workspaces/delete", { method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: w.id, admin: admin, force: !!force }) }).then(x => x.json());
        let r = await send(false);
        if (!r.ok && r.holds) {
          if (!confirm(r.error + "\n\nRemove it and them anyway?")) { say("Left alone."); return; }
          r = await send(true);
        }
        if (r && r.ok) {
          say("Removed. The folder " + (r.folder || "on this station") + " was left as it is.");
          fill();
          if (typeof lgWorkspaces === "function") lgWorkspaces();
          if (typeof whoRender === "function") whoRender();
        } else say((r && r.error) || "Could not remove it.", true);
      }, "bad");

      row.appendChild(acts);
      list.appendChild(row);
    });
    if (!ws.length) {
      const p = document.createElement("p"); p.className = "hint";
      p.textContent = "No workspaces yet.";
      list.appendChild(p);
    }
  }

  mk.onclick = () => {
    const name = prompt("Name the new workspace");
    if (name === null || !name.trim()) return;
    wsBrowse("", async where => {
      const r = await (await fetch("/api/workspaces", { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), path: where }) })).json();
      if (r && r.ok) {
        say("Created.");
        fill();
        if (typeof lgWorkspaces === "function") lgWorkspaces();
      } else say((r && r.error) || "Could not create it.", true);
    });
  };

  fill();
}

/* Where a signed-in person's work is actually being kept, said plainly on the page that owns
   the station's settings. */
async function wsHere() {
  const el = $("#cfg-ws-here"); if (!el) return;
  const wid = (typeof whoSession === "object" && whoSession && whoSession.workspace) || "";
  if (!wid) { el.textContent = "Sign in to see which workspace this station is using."; return; }
  try {
    const r = await (await fetch("/api/workspaces/detail")).json();
    const w = ((r && r.workspaces) || []).find(x => x.id === wid);
    el.textContent = w ? (w.name + " keeps its protocols in "
                          + (w.folder || "this station only")
                          + (w.folder && !w.exists ? ", which is missing"
                             : (w.folder && !w.writable ? ", which cannot be written" : "")))
                       : "";
  } catch (e) { el.textContent = ""; }
}
if ($("#cfgWsBtn")) $("#cfgWsBtn").onclick = wsManage;

window.wsHere = wsHere;
window.wsManage = wsManage;
window.wsBrowse = wsBrowse;
window.uiSheet = uiSheet;


// Open-source notices: the bundled licence texts, in an overlay so the app keeps its place.
function ossNotices() {
  if (document.getElementById("ossBox")) return;
  const box = document.createElement("div"); box.id = "ossBox";
  box.style.cssText = "position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.35);display:flex;align-items:center;justify-content:center";
  box.innerHTML = '<div style="background:var(--surface,#fff);border-radius:10px;width:min(820px,92vw);height:min(640px,86vh);display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25)">' +
    '<div style="display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid var(--line,#e5e7eb)"><strong style="flex:1">Open-source notices</strong>' +
    '<button class="ghost" id="ossClose">Close</button></div>' +
    '<iframe src="/notices" style="flex:1;border:0;width:100%;background:#fff" title="Open-source notices"></iframe></div>';
  document.body.appendChild(box);
  const close = function () { box.remove(); };
  box.addEventListener("click", function (e) { if (e.target === box) close(); });
  document.getElementById("ossClose").onclick = close;
}
