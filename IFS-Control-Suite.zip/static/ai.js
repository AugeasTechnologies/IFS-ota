/* IFS AI, on every screen.
 *
 * A floating button, bottom right, that opens a panel over whatever you are looking at. It knows
 * which screen you are on and can take you to another one.
 *
 * WHAT IT CAN DO, and why the list stops where it does.
 *
 * It reads the station's recorded history, it reads the live status, and it can navigate between
 * screens. Navigation is inert - a view is a view, nothing happens because you looked at it.
 *
 * It cannot move the carriage, open the actuator, strike plasma, start or abort a cycle, or flash
 * firmware. Not behind a confirmation dialog: those are not tools it has. This is a high voltage
 * instrument with a door, and the assistant's context contains text from the lab's own MCP
 * services - systems Augeas does not control and cannot audit. Anything reachable from the tool
 * list is reachable by a sentence that arrives in that text. So the dangerous things are not on
 * the list, and a confirmation prompt is not treated as a substitute for that.
 *
 * What it does instead, for work that changes something: it tells you where the control is and
 * takes you to the screen. The hand on the button stays yours.
 */
(function () {
  "use strict";

  var $ = function (q) { return document.querySelector(q); };
  var es = null;
  var open = false;
  var booted = false;

  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // ---------------------------------------------------------------- the panel
  function build() {
    var el = document.createElement("div");
    el.id = "aiDock";
    el.innerHTML =
      '<button class="aibtn" id="aiOpen" title="IFS AI" aria-label="IFS AI">' +
      '<span class="blobmark" aria-hidden="true">' +
      '<span class="goo"><i></i><i></i><i></i><i></i></span></span></button>' +
      '<section class="aipanel" id="aiPanel" aria-label="IFS AI" hidden>' +
      '  <header>' +
      '    <span class="blobmini" aria-hidden="true"></span><b>IFS AI</b>' +
      '    <span class="aiwhere" id="aiWhere"></span>' +
      '    <span style="flex:1"></span>' +
      '    <button class="ghost" id="aiNew">New</button>' +
      '    <button class="ghost" id="aiFloat" title="Float the assistant in its own window you can move and resize">Pop out</button>' +
      '    <button class="ghost" id="aiClose" aria-label="Close">Close</button>' +
      '  </header>' +
      '  <div class="aithread" id="aiThread"></div>' +
      '  <div class="aifoot">' +
      '    <div class="airow">' +
      '      <input type="text" id="aiQ" placeholder="Ask about this screen">' +
      '      <button class="btn" id="aiSend">Ask</button>' +
      '    </div>' +
      '    <div class="aimodel" id="aiModel"></div>' +
      '  </div>' +
      '  <i class="aigrip n" data-e="n"></i><i class="aigrip s" data-e="s"></i>' +
      '  <i class="aigrip e" data-e="e"></i><i class="aigrip w" data-e="w"></i>' +
      '  <i class="aigrip ne" data-e="ne"></i><i class="aigrip nw" data-e="nw"></i>' +
      '  <i class="aigrip se" data-e="se"></i><i class="aigrip sw" data-e="sw"></i>' +
      "</section>";
    document.body.appendChild(el);
    // The panel is a grid column of .app, not a floating box on the body - that is what makes
    // the application give up room for it instead of being covered by it.
    var app = document.querySelector(".app");
    var panel = el.querySelector("#aiPanel");
    if (app && panel) app.appendChild(panel);

    $("#aiOpen").onclick = toggle;
    $("#aiClose").onclick = toggle;
    $("#aiNew").onclick = newChat;
    $("#aiFloat").onclick = function () { setFloat(!floating); };
    floatWire(panel);
    $("#aiSend").onclick = ask;
    $("#aiQ").onkeydown = function (ev) { if (ev.key === "Enter") ask(); };
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && open) toggle();
    });
  }

  // The screens, in the words an operator would use rather than the route names.
  var WHERE = {
    home: "Home", fleet: "Fleet", insight: "Insight", dash: "Plasma StandAlone overview",
    mon: "Serial Monitor", log: "Data Log", tune: "Tuning", cfg: "Configuration",
    ctl: "Control", fw: "Firmware", tc: "Tip Charger settings", pt: "Puretip One",
    live: "Live View", proto: "Protocol"
  };

  var QUICK = {
    _: ["What is this screen for?", "Is anything wrong right now?"],
    insight: ["What changed before the failures?", "How many hours did it run?"],
    dash: ["What is the controller doing right now?", "Why is it not connected?"],
    cfg: ["What does plasma time do?", "Where do I set the display IP?"],
    proto: ["What steps are available?", "How do I add a wait?"],
    log: ["What does this chart show?"],
    fw: ["Is this firmware current?"]
  };

  function view() {
    // Read it off the sidebar rather than a global: app.js keeps currentView module-scoped, so
    // window.currentView is undefined and every question arrived claiming to be about Home.
    var on = document.querySelector(".navitem.active");
    return (on && on.dataset.v) || "home";
  }

  function refreshContext() {
    var v = view();
    // Was being cut mid-word - "Se" where "Serial Monitor" should be - because the header had no
    // rule for it and it was simply overflowing. It shrinks and ellipsises now.
    $("#aiWhere").textContent = WHERE[v] || v;
    $("#aiWhere").title = WHERE[v] || v;
  }

  // ---------------------------------------------------------------- floating window
  // Docked, the assistant is a column the screen makes room for. Floating, it is a window over
  // the screen that can be moved and resized anywhere, and docked again with one press. Where it
  // was and how big are remembered on this PC.
  var floating = false, frect = null;
  try {
    floating = localStorage.getItem("ifsAiFloat") === "1";
    frect = JSON.parse(localStorage.getItem("ifsAiRect") || "null");
  } catch (e) {}
  var MINW = 300, MINH = 320;

  function fit(r) {
    var vw = window.innerWidth, vh = window.innerHeight;
    r = r || { w: 400, h: Math.min(620, vh - 120) };
    var w = Math.max(MINW, Math.min(r.w || 400, vw - 16));
    var h = Math.max(MINH, Math.min(r.h || 560, vh - 16));
    var x = r.x == null ? vw - w - 24 : r.x, y = r.y == null ? vh - h - 24 : r.y;
    x = Math.max(8, Math.min(x, vw - w - 8));      // never lost off the edge of the window
    y = Math.max(8, Math.min(y, vh - h - 8));
    return { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) };
  }
  function place() {
    var p = $("#aiPanel"); if (!p) return;
    if (!floating) { p.style.left = p.style.top = p.style.width = p.style.height = ""; return; }
    frect = fit(frect);
    p.style.left = frect.x + "px"; p.style.top = frect.y + "px";
    p.style.width = frect.w + "px"; p.style.height = frect.h + "px";
  }
  function saveRect() { try { localStorage.setItem("ifsAiRect", JSON.stringify(frect)); } catch (e) {} }
  function layout() {
    var app = document.querySelector(".app");
    var docked = open && !floating;
    if (app) app.classList.toggle("ai-open", docked);
    // The orb lives on the body, outside the grid, so the body carries the state too - without
    // it the orb stays where it was and the rail opens on top of it.
    document.body.classList.toggle("ai-open", docked);
    document.body.classList.toggle("ai-float", open && floating);
    $("#aiPanel").classList.toggle("floating", floating);
    $("#aiFloat").textContent = floating ? "Dock" : "Pop out";
    $("#aiFloat").title = floating ? "Put the assistant back at the side of the screen"
                                   : "Float the assistant in its own window you can move and resize";
    place();
  }
  function setFloat(on) {
    floating = !!on;
    try { localStorage.setItem("ifsAiFloat", floating ? "1" : "0"); } catch (e) {}
    layout();
  }
  function floatWire(panel) {
    var head = panel.querySelector("header");
    function drag(ev, edge) {
      if (!floating || ev.button !== 0) return;
      ev.preventDefault();
      var sx = ev.clientX, sy = ev.clientY, r0 = fit(frect);
      document.body.classList.add("ai-dragging");
      function move(e) {
        var dx = e.clientX - sx, dy = e.clientY - sy, r = { x: r0.x, y: r0.y, w: r0.w, h: r0.h };
        if (!edge) { r.x += dx; r.y += dy; }
        else {
          if (edge.indexOf("e") >= 0) r.w = Math.max(MINW, r0.w + dx);
          if (edge.indexOf("s") >= 0) r.h = Math.max(MINH, r0.h + dy);
          if (edge.indexOf("w") >= 0) { r.w = Math.max(MINW, r0.w - dx); r.x = r0.x + r0.w - r.w; }
          if (edge.indexOf("n") >= 0) { r.h = Math.max(MINH, r0.h - dy); r.y = r0.y + r0.h - r.h; }
        }
        frect = fit(r); place();
      }
      function up() {
        document.removeEventListener("pointermove", move);
        document.removeEventListener("pointerup", up);
        document.body.classList.remove("ai-dragging");
        frect = fit(frect); place(); saveRect();
      }
      document.addEventListener("pointermove", move);
      document.addEventListener("pointerup", up);
    }
    head.addEventListener("pointerdown", function (ev) {
      if (ev.target.closest("button")) return;      // its buttons stay buttons
      drag(ev, null);
    });
    head.addEventListener("dblclick", function (ev) {
      if (!ev.target.closest("button")) setFloat(!floating);
    });
    Array.prototype.forEach.call(panel.querySelectorAll(".aigrip"), function (g) {
      g.addEventListener("pointerdown", function (ev) { drag(ev, g.dataset.e); });
    });
    window.addEventListener("resize", function () { if (floating && open) place(); });
  }

  function toggle() {
    open = !open;
    $("#aiPanel").hidden = !open;
    $("#aiOpen").classList.toggle("on", open);
    layout();
    if (open) {
      refreshContext();
      loadModel();
      // Load the model while they are still reading the panel. On a 35B this is the difference
      // between the first answer taking ten seconds and taking one.
      fetch("/api/insight/warm", { method: "POST" }).catch(function () {});
      setTimeout(function () { $("#aiQ").focus(); }, 60);
    }
  }

  window.ifsAiReload = function () { loadModel(); };
  function loadModel() {
    fetch("/api/insight/summary?days=7").then(function (r) { return r.json(); })
      .then(function (d) {
        var ai = d.ai || {};
        var el = $("#aiModel");
        // The box stays usable either way. Greyed out, it read as broken; now asking explains
        // exactly what is missing and offers the way to fix it.
        $("#aiSend").disabled = false; $("#aiQ").disabled = false;
        if (!ai.pro) {
          blocked = "pro";
          el.textContent = "IFS AI is part of IFS Suite Pro.";
        } else if (!ai.available || ai.reachable === false) {
          blocked = ai.reachable === false ? "down" : "model";
          el.textContent = ai.reachable === false ? "Not answering: the model on your network (" + (ai.url || "") + ")."
                                                  : "No AI connected yet.";
        } else {
          blocked = null;
          provider = ai.provider || "local";
          cloudReady = !!ai.cloud_ready;
          el.textContent = ai.provider === "both"
            ? (ai.model || "") + " on this network, with Anthropic a click away"
            : (ai.provider === "local" ? "On this network: " : ai.provider === "openai" ? "OpenAI: " : "Anthropic: ") + (ai.model || "");
          $("#aiSend").disabled = false; $("#aiQ").disabled = false;
        }
      }).catch(function () {});
  }

  // ---------------------------------------------------------------- the thread
  function bubble(who, text) {
    var el = document.createElement("div");
    el.className = "msg " + who;
    el.innerHTML = (who === "ai"
                    ? '<div class="av blobav" aria-hidden="true"></div>'
                    : '<div class="av">YOU</div>') +
                   '<div class="b"></div>';
    el.querySelector(".b").textContent = text || "";
    var t = $("#aiThread");
    t.appendChild(el);
    t.scrollTop = t.scrollHeight;
    return el;
  }

  // The model writes light markdown no matter what the prompt says, and textContent prints the
  // asterisks. This renders the three things it actually uses and nothing else. ESCAPED FIRST:
  // an answer can carry rows straight out of the database, and a database is not a thing to hand
  // to innerHTML.
  function md(t) {
    var h = esc(t || "");
    h = h.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
    h = h.replace(/(^|\n)\s*[-*]\s+/g, "$1\u2022 ");
    h = h.replace(/\n{2,}/g, "<br><br>").replace(/\n/g, "<br>");
    return h;
  }

  function thinking(el, word) {
    el.querySelector(".b").innerHTML =
      '<span class="blob"><i></i><i></i><i></i></span>' +
      '<span class="chatstatus">' + esc(word || "Thinking") + "</span>";
  }

  var provider = "local", cloudReady = false, blocked = null;

  // Asked while the assistant cannot answer: say why in the thread, with the way to fix it.
  function explainBlocked() {
    var el = bubble("ai", "");
    var body = el.querySelector(".b");
    var p = document.createElement("div");
    var b = document.createElement("button");
    b.className = "btn";
    if (blocked === "pro") {
      p.textContent = "IFS AI needs an IFS Suite Pro licence, and this station has none installed yet. " +
                      "You can connect your AI now; it answers once a licence is installed under Configuration.";
    } else if (blocked === "down") {
      p.textContent = "The model on your network is not answering. Start it on that computer, or " +
                      "connect a different AI - the setup checks it works before it finishes.";
    } else {
      p.textContent = "IFS AI needs an AI to answer with: your Anthropic or OpenAI account, or a model " +
                      "on your network. The setup takes a minute and checks it works.";
    }
    b.textContent = "Connect your AI";
    b.onclick = function () { if (window.openAiWizard) window.openAiWizard(); };
    p.style.margin = "0 0 12px"; p.style.lineHeight = "1.5";        // room between the words and the button
    b.style.marginTop = "2px";
    body.appendChild(p); body.appendChild(b);
    $("#aiThread").scrollTop = $("#aiThread").scrollHeight;
  }

  // Everything the assistant is allowed to see of the form state. Passwords and keys are not on
  // that list and never reach the server: dropped here, at the source, rather than filtered
  // somewhere downstream where forgetting to filter is a quiet leak.
  var SECRET = /pw|pass|secret|token|key|licen|auth|cred/i;

  function snapshot() {
    var out = {};
    var els = document.querySelectorAll("input[id],select[id],textarea[id]");
    Array.prototype.forEach.call(els, function (el) {
      if (el.type === "password" || SECRET.test(el.id)) return;
      var v = el.type === "checkbox" ? (el.checked ? "on" : "off") : el.value;
      if (v == null) return;
      out[el.id] = String(v).slice(0, 200);
    });
    return fetch("/api/insight/state", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ values: out }),
    }).catch(function () {});
  }

  function ask(force, reuse) {
    var q = reuse || ($("#aiQ").value || "").trim();
    if (blocked) { if (q) { $("#aiQ").value = ""; bubble("me", q); } explainBlocked(); return; }
    if (!q || es) return;
    if (!reuse) { $("#aiQ").value = ""; bubble("me", q); }
    var el = bubble("ai", "");
    thinking(el, "Reading the history");
    var body = el.querySelector(".b");
    var answer = "", queries = [], did = [];
    $("#aiSend").disabled = true;
    $("#aiOpen").classList.add("busy");

    var started = false;
    function begin() {
      if (started) return;
      started = true;
      es = new EventSource("/api/insight/chat?view=" + encodeURIComponent(view()) +
                           (force ? "&engine=" + force : "") +
                           "&q=" + encodeURIComponent(q));
      wire();
    }
    // Posted first, so read_screen answers about the screen as it is now rather than as it was
    // at the last question. Capped, because a question that never starts is worse than one
    // answered from a snapshot a moment old.
    snapshot().then(begin);
    setTimeout(begin, 700);
    function wire() {
    var engine = force || "local";
    es.addEventListener("engine", function (e) { engine = JSON.parse(e.data); });

    es.addEventListener("status", function (e) {
      if (!answer) thinking(el, JSON.parse(e.data));
    });
    es.addEventListener("query", function (e) { queries.push(JSON.parse(e.data)); });
    es.addEventListener("delta", function (e) {
      answer += JSON.parse(e.data);
      body.textContent = answer;
      $("#aiThread").scrollTop = $("#aiThread").scrollHeight;
    });
    // It can drive the view and press the application's controls. The server has already
    // decided each one: inert ones arrive as press/set_field, anything that acts on the
    // instrument arrives as confirm unless the owner switched "operate" on.
    es.addEventListener("view", function (e) {
      var v = JSON.parse(e.data) || {};
      var say = applyView(v);
      if (say) did.push(say);
    });
    es.addEventListener("done", function () { finish(el, body, answer, queries, did, engine, q); });
    es.addEventListener("error", function (e) {
      var msg = "";
      try { msg = JSON.parse(e.data); } catch (x) { msg = ""; }
      if (msg) finish(el, body, msg, queries, did, engine, q);
      else if (es) finish(el, body, answer || "The connection dropped before it finished.",
                          queries, did, engine, q);
    });
    }
  }

  // Each action is applied here and reported back in words, so the thread says what it changed
  // rather than leaving the operator to notice. Shared with the chat on the Insight screen, which
  // used to report presses as done without applying them.
  window.ifsApplyView = function (v) { return applyView(v); };
  function applyView(v) {
    switch (v.action) {
      case "go_to_screen":
        if (WHERE[v.screen] && go(v.screen)) {
          return "Took you to " + WHERE[v.screen] + ".";
        }
        return "";
      case "set_range":
        return setControl("#in-days", v.days, "Set the window to " + v.days + " days.");
      case "set_heatmap":
        return setControl("#in-heat-metric", v.metric,
                          "Switched the heatmap to " +
                          (v.metric === "fail" ? "failures" : "hours running") + ".");
      case "set_spread":
        return setControl("#in-dist-field", v.field, "Switched the spread to " + v.field + ".");
      // It presses this itself: the server already decided the button is inert or is a stop.
      case "press":
        return clickById(v.el, v.say);

      // Typing into a box. The server has already decided this one does not feed the instrument.
      case "set_field":
        return setField(v.el, v.value, v.say);

      // And one that does: the operator presses it.
      case "confirm_field":
        pendingConfirm = { el: v.el, label: v.label, value: v.value, field: true };
        return "";

      // It may only set this one up. The operator closes the circuit.
      case "confirm":
        pendingConfirm = { el: v.el, label: v.label };
        return "";

      case "refresh":
        var r = $("#in-refresh");
        if (r) { r.click(); return "Redrew the page."; }
        return "";
      default:
        return "";
    }
  }

  var pendingConfirm = null;

  // A button only exists while its screen is built, so find it and say plainly when it is not
  // there rather than reporting a press that did not land.
  // Set it the way a person would, and tell the page about it: a value assigned straight onto
  // .value fires nothing, so anything listening for a change never hears one and the application
  // keeps the old number while the box shows the new one.
  function setField(id, value, say) {
    var el = document.getElementById(id);
    if (!el || el.disabled) return "";
    if (el.type === "checkbox") {
      el.checked = (value === "on" || value === "true" || value === "1");
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.classList.add("ai-touched");
    setTimeout(function () { el.classList.remove("ai-touched"); }, 1600);
    return say || "";
  }

  function clickById(id, say) {
    var el = document.getElementById(id);
    if (!el || el.disabled) return "";
    el.click();
    return say || "";
  }

  // The Insight controls only exist while that screen is built, so a change aimed at them takes
  // the operator there first - otherwise the assistant reports doing something invisible.
  // One way to change screen. showView swaps the visible section; syncStreams is what starts
  // that view's streams and loads its data, so navigating without it lands on an empty page.
  function go(v) {
    if (typeof showView !== "function") return false;
    showView(v);
    if (typeof syncStreams === "function") syncStreams(v);
    refreshContext();
    return true;
  }

  function setControl(sel, value, say) {
    go("insight");
    var el = $(sel);
    if (!el) return "";
    if (el.classList.contains("seg")) {
      var b = el.querySelector('[data-d="' + value + '"]');
      if (!b) return "";
      b.click();
    } else {
      el.value = value;
      el.dispatchEvent(new Event("change"));
    }
    return say;
  }

  function finish(el, body, answer, queries, did, engine, asked) {
    if (es) { es.close(); es = null; }
    $("#aiSend").disabled = false;
    $("#aiOpen").classList.remove("busy");
    body.innerHTML = answer ? md(answer) : "No answer came back.";
    if (did && did.length) {
      var n = document.createElement("div");
      n.className = "chatstatus";
      n.style.marginLeft = "0";
      n.style.marginTop = "6px";
      n.textContent = did.join(" ");
      body.appendChild(n);
    }
    // The assistant set something up but may not press it. This is where the operator does.
    if (pendingConfirm) {
      var c = pendingConfirm;
      pendingConfirm = null;
      var wrap = document.createElement("div");
      wrap.className = "confirmrow";
      var btn = document.createElement("button");
      btn.className = "btn";
      btn.textContent = c.label;
      btn.onclick = function () {
        var el = document.getElementById(c.el);
        if (!el || el.disabled) {
          wrap.textContent = "That control is not available on this screen now.";
          return;
        }
        if (c.field) {
          setField(c.el, c.value, "");
          wrap.textContent = "Done. " + c.label;
        } else {
          el.click();
          wrap.textContent = "You pressed " + c.label + ".";
        }
      };
      var note = document.createElement("span");
      note.className = "chatstatus";
      note.textContent = "needs you";
      wrap.appendChild(btn);
      wrap.appendChild(note);
      body.appendChild(wrap);
    }
    if (queries.length) {
      var d = document.createElement("details");
      d.className = "work";
      d.innerHTML = "<summary>" + queries.length +
        (queries.length === 1 ? " query" : " queries") + "</summary><pre></pre>";
      d.querySelector("pre").textContent = queries.map(function (x) {
        return x.sql + "\n  " + (x.error ? "error: " + x.error : x.rows + " rows");
      }).join("\n\n");
      body.appendChild(d);
    }
    // Which model answered, and - in Both - the offer of the other one. A footnote, because the
    // answer is the thing and this is about the answer.
    if (engine && provider === "both") {
      var row = document.createElement("div");
      row.className = "engineline";
      var who = document.createElement("span");
      who.textContent = engine === "cloud" ? "Answered by Anthropic" : "Answered on this network";
      row.appendChild(who);
      if (engine === "local" && cloudReady && asked) {
        var again = document.createElement("button");
        again.textContent = "Ask Anthropic";
        again.onclick = function () {
          again.disabled = true;
          ask("cloud", asked);        // ask() makes its own bubble; a second one spun for ever
        };
        row.appendChild(again);
      }
      body.appendChild(row);
    }
    $("#aiThread").scrollTop = $("#aiThread").scrollHeight;
  }

  function newChat() {
    if (es) { es.close(); es = null; }
    $("#aiSend").disabled = false;
    $("#aiOpen").classList.remove("busy");
    fetch("/api/insight/chat/reset", { method: "POST" })
      .then(function () { $("#aiThread").innerHTML = ""; })
      .catch(function () { $("#aiThread").innerHTML = ""; });
  }

  // The dock sits above everything, including the sign-in overlay. Left alone it floats over the
  // login screen, so the assistant is usable before anybody has signed in - and any screen it
  // changes, it changes behind the overlay, where nothing can be seen. That is exactly the
  // "it says it opened the screen but it never opens" report.
  function gate() {
    var lp = document.getElementById("loginPage");
    // getComputedStyle, not offsetParent: the overlay is position:fixed, and a fixed element's
    // offsetParent is ALWAYS null, so that check reported "not visible" every time and the dock
    // stayed on top of the sign-in screen.
    var locked = !!(lp && getComputedStyle(lp).display !== "none");
    var dock = document.getElementById("aiDock");
    if (!dock) return;
    dock.style.display = locked ? "none" : "";
    if (locked && open) {
      open = false;
      var panel = document.getElementById("aiPanel");
      if (panel) panel.hidden = true;
      var app = document.querySelector(".app");
      if (app) app.classList.remove("ai-open");
      document.body.classList.remove("ai-open");
      document.body.classList.remove("ai-float");
    }
  }

  function boot() {
    if (booted) return;
    booted = true;
    build();
    gate();
    // The overlay is shown and hidden by app.js setting an inline style, so watch the attribute
    // rather than trying to hook a sign-in that happens in another file.
    var lp = document.getElementById("loginPage");
    if (lp && window.MutationObserver) {
      new MutationObserver(gate).observe(lp, { attributes: true,
                                               attributeFilter: ["style", "class"] });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
  // The dock follows navigation, so the chips and the "where" label match the screen behind it.
  window.aiOnView = refreshContext;
  // Opens the rail and asks, so anything on a screen can hand a question to the assistant.
  window.aiAsk = function (q) {
    if (!open) toggle();
    $("#aiQ").value = q;
    ask();
  };
})();
