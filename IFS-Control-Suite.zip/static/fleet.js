/* The fleet map.

   One block per PC, the instruments plugged into it beside it, and a wire between them. It speaks
   the same visual language as the topology picture on Home: a softly tinted card for something
   that is talking, a dash travelling along a live wire, a slow breath on the dot, and never an
   arrowhead. Every line is a right angle - a trunk out of the PC and a stub to each instrument -
   so it reads as wiring rather than as scribble.

   Stations are dragged to arrange, and snap to a grid so a floor plan stays tidy without anyone
   lining things up by eye. Where they are put is kept for the whole site, not for one browser. */

const FL = {
  PC_W: 212, PC_H: 88,          // the station card
  DEV_W: 182, DEV_H: 56,        // one instrument
  DEV_GAP: 12,
  TRUNK: 26,
  STUB: 22,
  PAD: 30,
  GRID: 26,                     // the dotted background, and what dragging snaps to
  GAP_X: 68, GAP_Y: 56,         // between stations when they are packed automatically
  BADGE: 38, BADGE_SM: 30,      // the rounded square each icon sits in
  R: 16, R_SM: 13, R_BADGE: 11, R_BADGE_SM: 9,
};

let flData = [];
let flSel = null;
let flDrag = null;
let flZoom = 1;                 // 0.4 to 2, or Fit
const FL_ZOOMS = [0.4, 0.5, 0.65, 0.8, 1, 1.25, 1.5, 2];

const flSvg = () => document.getElementById("fleet-map");
/* How much room there is to lay out in. Not the SVG: that grows to fit whatever has been drawn,
   so asking it how wide it is returns the last drawing rather than the window. */
const flRoom = () => {
  const wrap = document.querySelector(".fleetwrap");
  return Math.max(420, (wrap ? wrap.clientWidth : 1200) - 12);
};
const snap = (n) => Math.round(n / FL.GRID) * FL.GRID;
let flContent = { w: 0, h: 0 };

/** Scale the drawing and size the canvas to match, so the scrollbars stay honest. */
function flApplyZoom() {
  const svg = flSvg();
  const root = document.getElementById("fl-root");
  if (!svg || !root) return;
  root.setAttribute("transform", "scale(" + flZoom + ")");
  svg.setAttribute("width", Math.max(svg.clientWidth || 0, Math.round(flContent.w * flZoom)));
  svg.setAttribute("height", Math.max(340, Math.round(flContent.h * flZoom)));
  const pct = document.getElementById("fleet-pct");
  if (pct) pct.textContent = Math.round(flZoom * 100) + "%";
}

function flZoomBy(dir) {
  const i = FL_ZOOMS.reduce((best, z, n) =>
    Math.abs(z - flZoom) < Math.abs(FL_ZOOMS[best] - flZoom) ? n : best, 0);
  flZoom = FL_ZOOMS[Math.min(FL_ZOOMS.length - 1, Math.max(0, i + dir))];
  flApplyZoom();
}

/** Fit the whole fleet in the window, never magnifying past its true size. */
function flFit() {
  const svg = flSvg();
  if (!svg || !flContent.w) return;
  flZoom = Math.min(1, Math.max(0.4, flRoom() / flContent.w));
  flApplyZoom();
}

function el(tag, attrs, parent) {
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const k in attrs) if (attrs[k] !== null && attrs[k] !== undefined) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}

/* Icons, drawn rather than fetched, so the map needs nothing from the network and scales cleanly.
   Each is drawn on a 20x20 grid and centred in its badge. */
const ICONS = {
  pc:   ["M3.5 5h13v8.5h-13z", "M7.5 17h5", "M10 13.5V17"],
  disp: ["M4.5 3.5h11v13h-11z", "M7.5 7.5h5", "M7.5 10.5h5", "M7.5 13.5h2.5"],
  pt:   ["M6.5 3.5h7v4.5l-1.8 8h-3.4l-1.8-8z", "M6.5 8h7"],
  opta: ["M4.5 7h11v6h-11z", "M7 7V4.5", "M13 7V4.5", "M7 13v2.5", "M13 13v2.5"],
  by:   ["M4 16.5h12", "M6.5 16.5V9.5l4-3.5 4 3.5", "M10.5 6V3.5"],
};

/** A rounded-square badge with the icon centred in it, the way Home draws an accessory. */
function badge(kind, parent, x, y, size, radius) {
  const g = el("g", { transform: `translate(${x},${y})` }, parent);
  el("rect", { class: "fl-badge", width: size, height: size, rx: radius }, g);
  const k = size / 20 * 0.62;                       // the glyph sits at 62% of the badge
  const off = (size - 20 * k) / 2;
  const inner = el("g", { class: "fl-glyph", transform: `translate(${off},${off}) scale(${k})` }, g);
  (ICONS[kind] || ICONS.pc).forEach(d => el("path", { d }, inner));
  return g;
}

/* Where every station goes. Anything the site has placed stays where it was put; the rest are
   packed onto shelves by their real size, so a bench with no instruments takes the room of a
   bench with no instruments rather than a full row.

   A placed station is an obstacle, not a gap. Packing around only the auto-placed ones let a
   fresh station land on top of one somebody had already dragged somewhere. */
/* Arrange a set of stations into a grid of equal cells.

   Every station is centred in its cell. A card is already centred against its own instruments, so
   centring the station in a uniform cell puts every card on the same line across a row - which is
   what makes a row read as a row rather than as a shelf things were stacked on. */
function flGrid(list, originY, avail) {
  if (!list.length) return 0;
  const cellW = Math.max.apply(null, list.map(flWidth)) + FL.GAP_X;
  const perRow = Math.max(1, Math.floor((avail - FL.PAD) / cellW));

  // Each row is as tall as the tallest station IN THAT ROW, not the tallest anywhere: a row of
  // small benches should not pay for the one big bench two rows down.
  let y = originY, used = 0;
  for (let i = 0; i < list.length; i += perRow) {
    const row = list.slice(i, i + perRow);
    const rowH = Math.max.apply(null, row.map(flHeight));
    row.forEach((st, c) => {
      st._pos = {
        x: Math.round(FL.PAD + c * cellW),
        y: Math.round(y + (rowH - flHeight(st)) / 2),   // centred, so every card sits on one line
      };
    });
    y += rowH + FL.GAP_Y;
    used += rowH + FL.GAP_Y;
  }
  return used;
}

/** Benches first, in cells of one size; then the machines with nothing attached, in cells of
    their own, because they are a third of the width and do not belong in bench-sized ones. */
function flArrange(list, avail) {
  const benches = list.filter(s => s.kit.length);
  const bare = list.filter(s => !s.kit.length);
  let y = FL.PAD;
  y += flGrid(benches, y, avail);
  if (benches.length && bare.length) y += FL.GAP_Y * 0.4;   // a clear break between the two
  flGrid(bare, y, avail);
}

/* A placed station is an obstacle, not a gap: arranging around only the automatic ones let a fresh
   station land on top of one somebody had already dragged somewhere. */
function flOverlaps(a, b) {
  return a.x < b.x + b.w + FL.GAP_X * 0.5 && a.x + a.w + FL.GAP_X * 0.5 > b.x &&
         a.y < b.y + b.h + FL.GAP_Y * 0.5 && a.y + a.h + FL.GAP_Y * 0.5 > b.y;
}

function flLayout() {
  const avail = flRoom() - FL.PAD;
  const taken = [], loose = [];
  flData.forEach((st) => {
    if (st.x !== null && st.x !== undefined && st.y !== null && st.y !== undefined) {
      st._pos = { x: st.x, y: st.y };
      taken.push({ x: st.x, y: st.y, w: flWidth(st), h: flHeight(st) });
    } else {
      loose.push(st);
    }
  });
  if (!loose.length) return;

  flArrange(loose, avail);
  loose.forEach((st) => {
    const box = { x: st._pos.x, y: st._pos.y, w: flWidth(st), h: flHeight(st) };
    let guard = 0;
    let clash = taken.find(t => flOverlaps(box, t));
    while (clash && ++guard < 200) {
      box.x = snap(clash.x + clash.w + FL.GAP_X);
      if (box.x + box.w > avail) { box.x = FL.PAD; box.y = snap(box.y + box.h + FL.GAP_Y); }
      clash = taken.find(t => flOverlaps(box, t));
    }
    st._pos = { x: box.x, y: box.y };
    taken.push(box);
  });
}


function flHeight(st) {
  const n = st.kit.length;
  return Math.max(FL.PC_H, n ? n * FL.DEV_H + (n - 1) * FL.DEV_GAP : FL.PC_H);
}

function flWidth(st) {
  return st.kit.length ? FL.PC_W + FL.TRUNK + FL.STUB + FL.DEV_W : FL.PC_W;
}

function flDrawStation(svg, st, pos) {
  const cls = ["fl-pc"];
  if (flSel === st.station_id) cls.push("sel");
  cls.push(st.online ? "up" : "stale");
  const g = el("g", { class: cls.join(" "), transform: `translate(${pos.x},${pos.y})`,
                      "data-id": st.station_id }, svg);

  const h = flHeight(st);
  const pcY = Math.round((h - FL.PC_H) / 2);

  // the card floats on its shadow; the ring only appears when it is the one being looked at
  el("rect", { class: "fl-card", x: 0, y: pcY, width: FL.PC_W, height: FL.PC_H, rx: FL.R }, g);
  el("rect", { class: "fl-ring", x: 0, y: pcY, width: FL.PC_W, height: FL.PC_H, rx: FL.R }, g);

  badge("pc", g, 16, pcY + 16, FL.BADGE, FL.R_BADGE);

  const nm = el("text", { class: "fl-name", x: 66, y: pcY + 33 }, g);
  nm.textContent = st.name.length > 17 ? st.name.slice(0, 16) + "\u2026" : st.name;

  const state = el("text", { class: "fl-state", x: 66, y: pcY + 52 }, g);
  state.textContent = st.online ? "Online"
    : st.minutes_ago === null ? "Never seen"
    : st.minutes_ago < 90 ? st.minutes_ago + " min ago"
    : st.minutes_ago < 2880 ? Math.round(st.minutes_ago / 60) + " h ago"
    : Math.round(st.minutes_ago / 1440) + " d ago";

  const meta = el("text", { class: "fl-meta", x: 66, y: pcY + 70 }, g);
  meta.textContent = "v" + (st.version || "?");

  if (st.me) {
    const t = el("text", { class: "fl-here", x: FL.PC_W - 16, y: pcY + 70, "text-anchor": "end" }, g);
    t.textContent = "THIS PC";
  }

  if (!st.kit.length) return g;      // a card on its own already says nothing is connected

  // the trunk, then one right-angled stub per instrument
  const trunkX = FL.PC_W + FL.TRUNK;
  const devX = trunkX + FL.STUB;
  const ys = st.kit.map((_, i) => i * (FL.DEV_H + FL.DEV_GAP) + FL.DEV_H / 2);
  // An instrument is only shown as live while its station is. The links in a heartbeat describe
  // the moment it was sent; drawing them green an hour later would say a bench is running when
  // nobody has heard from it, which is worse than saying nothing.
  const live = (k) => k.up && st.online;
  const anyUp = st.online && st.kit.some(k => k.up);

  el("path", { class: "fl-wire" + (anyUp ? " up" : ""),
               d: `M${FL.PC_W} ${pcY + FL.PC_H / 2} H${trunkX}` }, g);
  if (ys.length > 1) {
    el("path", { class: "fl-wire" + (anyUp ? " up" : ""),
                 d: `M${trunkX} ${ys[0]} V${ys[ys.length - 1]}` }, g);
  }

  st.kit.forEach((k, i) => {
    const y = ys[i];
    el("path", { class: "fl-wire" + (live(k) ? " up" : ""), d: `M${trunkX} ${y} H${devX}` }, g);
    const d = el("g", { class: "fl-dev" + (live(k) ? " up" : "") }, g);
    el("rect", { class: "tile", x: devX, y: y - FL.DEV_H / 2, width: FL.DEV_W, height: FL.DEV_H,
                 rx: FL.R_SM }, d);
    badge(k.id, d, devX + 13, y - FL.BADGE_SM / 2, FL.BADGE_SM, FL.R_BADGE_SM);
    if (st.online) {
      const t = el("text", { x: devX + 53, y: y - 1 }, d);
      t.textContent = k.name;
      const st2 = el("text", { class: "fl-state", x: devX + 53, y: y + 15 }, d);
      st2.textContent = live(k) ? "On" : "Off";
    } else {
      // The card beside these already says nobody has heard from the bench. Repeating "Off" on
      // every tile is noise, not information.
      const t = el("text", { x: devX + 53, y: y + 5 }, d);
      t.textContent = k.name;
    }
  });
  return g;
}

function flRender() {
  const svg = flSvg();
  if (!svg) return;
  svg.textContent = "";

  // The shadows the cards float on. Two depths: one at rest, a deeper one under the pointer and
  // under whatever is selected, which is what makes a card feel picked up rather than outlined.
  const defs = el("defs", {}, svg);
  const shadow = (id, dy, blur, op) => {
    const f = el("filter", { id, x: "-40%", y: "-40%", width: "180%", height: "180%" }, defs);
    el("feDropShadow", { dx: 0, dy, stdDeviation: blur, "flood-color": "#0b1620",
                         "flood-opacity": op }, f);
  };
  shadow("fl-shadow", 1.5, 3, 0.10);
  shadow("fl-shadow-hi", 4, 7, 0.16);
  shadow("fl-shadow-sm", 1, 2.5, 0.08);

  // Everything is drawn into one group and that group is scaled, so zoom costs one attribute
  // rather than a redraw, and the coordinates dragging works in never change.
  const root = el("g", { id: "fl-root" }, svg);

  flLayout();
  let maxX = 0, maxY = 0;
  flData.forEach((st) => {
    flDrawStation(root, st, st._pos);
    maxX = Math.max(maxX, st._pos.x + flWidth(st));
    maxY = Math.max(maxY, st._pos.y + flHeight(st));
  });
  flContent = { w: maxX + FL.PAD * 2, h: maxY + FL.PAD * 2 };
  flApplyZoom();

  const c = document.getElementById("fleet-count");
  if (c) {
    const on = flData.filter(s => s.online).length;
    c.className = "pill" + (on ? " ok" : "");
    c.lastElementChild.textContent =
      flData.length + " station" + (flData.length === 1 ? "" : "s") + ", " + on + " online";
  }
  const kit = document.getElementById("fleet-kit");
  if (kit) {
    const n = {};
    flData.forEach(s => { if (!s.online) return;
      s.kit.forEach(k => { if (k.up) n[k.name] = (n[k.name] || 0) + 1; }); });
    const parts = Object.keys(n).sort().map(k => n[k] + " " + k + (n[k] === 1 ? "" : "s"));
    kit.textContent = parts.length ? parts.join(", ") : "nothing live";
  }
}

function flShowProps(id) {
  flSel = id;
  const st = flData.find(s => s.station_id === id);
  const panel = document.getElementById("fleet-props");
  if (!st || !panel) { if (panel) panel.style.display = "none"; flRender(); return; }
  panel.style.display = "";
  document.getElementById("fleet-props-t").textContent = st.name;
  const nameIn = document.getElementById("fleet-name");
  if (nameIn) nameIn.value = st.name;

  const rows = [
    ["Status", st.online ? "online" : st.minutes_ago === null ? "never seen"
      : st.minutes_ago + " min ago"],
    ["Software", "v" + (st.version || "?")],
    ["Licence", st.licence === "active"
      ? "active" + (st.licence_days != null ? ", " + st.licence_days + " days left" : "")
      : st.licence || "none"],
    ["Station id", st.station_id],
    ["Computer", st.host || "\u2013"],
    // A Mac station reports platform.platform() as "macOS-..."; every other station is Windows.
    [/^macOS/i.test(st.os || "") ? "macOS" : "Windows", (st.os || "").replace(/-/g, " ").slice(0, 32) || "\u2013"],
  ];
  // The station's own row already says whether it is online, so a reading does not need to
  // explain itself again.
  st.kit.forEach(k => rows.push([k.name, k.up ? "on" : "off"]));
  if (!st.kit.length) rows.push(["Instruments", "none"]);
  if (st.reported_name && st.renamed) rows.push(["Reports itself as", st.reported_name]);

  const box = document.getElementById("fleet-detail");
  box.textContent = "";
  rows.forEach(([k, v]) => {
    const d = document.createElement("div");
    const a = document.createElement("div"); a.className = "k"; a.textContent = k;
    const b = document.createElement("div"); b.className = "v"; b.textContent = v;
    d.appendChild(a); d.appendChild(b); box.appendChild(d);
  });
  flRender();
}

async function flLoad() {
  const locked = document.getElementById("fleet-locked");
  const panel = document.getElementById("fleet-panel");
  // The fleet lives in the cloud, so this takes a couple of seconds on a good connection and
  // longer on a bad one. Without something on screen the page is simply blank for that time,
  // which does not read as "loading" - it reads as broken.
  const count = document.getElementById("fleet-count");
  if (count && !flData.length) {
    count.innerHTML = '<span class="d"></span><span>reading the fleet</span>';
    if (panel) panel.style.display = "";
    if (locked) locked.style.display = "none";
  }
  try {
    const r = await (await fetch("/api/fleet/map")).json();
    if (!r.ok) {
      if (locked) {
        locked.style.display = "";
        const why = document.getElementById("fleet-lockwhy");
        if (why) why.textContent = r.error || "";
      }
      if (panel) panel.style.display = "none";
      const props = document.getElementById("fleet-props");
      if (props) props.style.display = "none";
      return;
    }
    if (locked) locked.style.display = "none";
    if (panel) panel.style.display = "";
    flData = (r.stations || []).map(s => ({ ...s, me: s.station_id === r.me }));
    flRender();
    if (flSel) flShowProps(flSel);
  } catch (e) {
    if (locked) {
      locked.style.display = "";
      const why = document.getElementById("fleet-lockwhy");
      if (why) why.textContent = "Cannot read the fleet: " + e;
    }
  }
}

/* Dragging. The position is saved once, when the station is let go, and snaps to the same grid the
   background is drawn on, so a floor plan stays tidy without anyone lining things up by eye. */
function flDragStart(ev) {
  const g = ev.target.closest(".fl-pc");
  if (!g) return;
  const st = flData.find(s => s.station_id === g.dataset.id);
  if (!st) return;
  const box = flSvg().getBoundingClientRect();
  // the pointer moves in screen pixels, the drawing in its own units
  flDrag = { st, g, dx: (ev.clientX - box.left) / flZoom - st._pos.x,
             dy: (ev.clientY - box.top) / flZoom - st._pos.y, moved: false };
  g.classList.add("drag");
  g.parentNode.appendChild(g);          // the one being moved rides above the rest
  ev.preventDefault();
}

function flDragMove(ev) {
  if (!flDrag) return;
  const box = flSvg().getBoundingClientRect();
  const x = Math.max(0, snap((ev.clientX - box.left) / flZoom - flDrag.dx));
  const y = Math.max(0, snap((ev.clientY - box.top) / flZoom - flDrag.dy));
  if (x !== flDrag.st._pos.x || y !== flDrag.st._pos.y) flDrag.moved = true;
  flDrag.st._pos = { x, y };
  flDrag.g.setAttribute("transform", `translate(${x},${y})`);
}

async function flDragEnd() {
  if (!flDrag) return;
  const { st, g, moved } = flDrag;
  g.classList.remove("drag");
  flDrag = null;
  if (!moved) { flShowProps(st.station_id); return; }
  st.x = st._pos.x; st.y = st._pos.y;
  await fetch("/api/fleet/station", { method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "move", station_id: st.station_id, x: st.x, y: st.y })
  }).catch(() => {});
}

/** Lay the whole fleet out again: benches first, then the machines with nothing attached. */
async function flTidy() {
  // The ones doing something come first, and the busiest of those before the rest.
  flData.sort((a, b) =>
    (b.online - a.online) ||
    (b.kit.length - a.kit.length) ||
    a.name.localeCompare(b.name));
  flData.forEach(st => { st.x = null; st.y = null; });

  flArrange(flData, flRoom() - FL.PAD);
  for (const st of flData) {
    st.x = st._pos.x; st.y = st._pos.y;
    await fetch("/api/fleet/station", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "move", station_id: st.station_id, x: st.x, y: st.y })
    }).catch(() => {});
  }
  flRender();
  const wrap = document.querySelector(".fleetwrap");
  if (wrap) { wrap.scrollTop = 0; wrap.scrollLeft = 0; }
  flSay("Arranged.", false);
}


/* Save the layout to a file. Plain text that can be read and edited, because the point of it is
   to be carried somewhere else and trusted when it arrives. */
function flSave() {
  const doc = {
    what: "IFS fleet layout",
    saved: new Date().toISOString().slice(0, 16).replace("T", " "),
    stations: flData.map(s => ({
      station_id: s.station_id,
      name: s.name,
      x: s._pos ? s._pos.x : s.x,
      y: s._pos ? s._pos.y : s.y,
    })),
  };
  const blob = new Blob([JSON.stringify(doc, null, 2) + "\n"], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "IFS-fleet-layout-" + new Date().toISOString().slice(0, 10) + ".txt";
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  flSay("Layout saved.", false);
}

function flSay(text, bad) {
  const m = document.getElementById("fleet-msg");
  if (!m) return;
  m.style.display = "block";
  m.className = bad ? "warnbox" : "okbox";
  m.textContent = text;
  clearTimeout(flSay._t);
  flSay._t = setTimeout(() => { m.style.display = "none"; }, 6000);
}

/* Load a saved layout. Only stations this fleet already knows are moved: a file naming a station
   that has never reported here would otherwise put a marker on the map for a machine nobody can
   see. What it does not recognise, it says. */
async function flOpen(file) {
  let doc;
  try {
    doc = JSON.parse(await file.text());
  } catch (e) {
    return flSay("That file is not a saved layout.", true);
  }
  const rows = (doc && doc.stations) || [];
  if (!Array.isArray(rows) || !rows.length) {
    return flSay("That file has no stations in it.", true);
  }
  const known = new Map(flData.map(s => [s.station_id, s]));
  let moved = 0, renamed = 0, unknown = 0;
  for (const r of rows) {
    const st = known.get(String(r.station_id || "").toLowerCase());
    if (!st) { unknown++; continue; }
    if (Number.isFinite(r.x) && Number.isFinite(r.y)) {
      st.x = Math.round(r.x); st.y = Math.round(r.y);
      await fetch("/api/fleet/station", { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "move", station_id: st.station_id, x: st.x, y: st.y })
      }).catch(() => {});
      moved++;
    }
    if (r.name && r.name !== st.name) {
      await fetch("/api/fleet/station", { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "rename", station_id: st.station_id, name: r.name })
      }).catch(() => {});
      renamed++;
    }
  }
  await flLoad();
  const bits = [];
  if (moved) bits.push(moved + " moved");
  if (renamed) bits.push(renamed + " renamed");
  if (unknown) bits.push(unknown + " not on this fleet");
  flSay(bits.length ? bits.join(", ") + "." : "Nothing to change.", !moved && !renamed);
}

async function flRename() {
  if (!flSel) return;
  const name = (document.getElementById("fleet-name").value || "").trim();
  if (!name) return;
  await fetch("/api/fleet/station", { method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "rename", station_id: flSel, name })
  }).catch(() => {});
  await flLoad();
}

async function flForget() {
  if (!flSel) return;
  const st = flData.find(s => s.station_id === flSel);
  if (!st) return;
  if (!window.confirm("Forget " + st.name + "? It returns if it reports in.")) return;
  await fetch("/api/fleet/station", { method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "forget", station_id: flSel })
  }).catch(() => {});
  flSel = null;
  document.getElementById("fleet-props").style.display = "none";
  await flLoad();
}

/* The tab itself is part of Pro. Without a licence there is no Fleet in the sidebar at all,
   rather than a tab that opens onto a locked panel. Re-checked whenever a licence changes. */
async function flGate() {
  const tab = document.getElementById("nav-fleet");
  if (!tab) return false;
  let on = false;
  try {
    const r = await (await fetch("/api/licence")).json();
    on = !!(r && r.ok && (r.licence.features || []).includes("fleet_dashboard"));
  } catch (e) { on = false; }
  tab.style.display = on ? "" : "none";
  if (!on && tab.classList.contains("active")) {
    const home = document.querySelector('.navitem[data-v="home"]');
    if (home) home.click();
  }
  return on;
}

/* How tall the map was left. A per-PC convenience, so it is kept in the browser rather than sent
   to the fleet: one bench liking a tall map says nothing about another. Every read and write is
   guarded, because storage can be blocked or cleared and a map that will not draw is worse than a
   map at its default height. */
const FL_H_KEY = "ifs.fleet.height";

function flRestoreHeight() {
  const wrap = document.querySelector(".fleetwrap");
  if (!wrap) return;
  try {
    const h = parseInt(localStorage.getItem(FL_H_KEY), 10);
    if (h >= 240 && h <= 4000) wrap.style.height = h + "px";
  } catch (e) { /* default height */ }

  if (typeof ResizeObserver === "function") {
    let t = null;
    new ResizeObserver(() => {
      clearTimeout(t);
      t = setTimeout(() => {
        try { localStorage.setItem(FL_H_KEY, String(Math.round(wrap.getBoundingClientRect().height))); }
        catch (e) { /* not remembered; the map still works */ }
        flApplyZoom();          // the canvas floor is the panel, which just changed
      }, 250);
    }).observe(wrap);
  }
}

(function flWire() {
  const svg = flSvg();
  if (svg) {
    svg.addEventListener("mousedown", flDragStart);
    window.addEventListener("mousemove", flDragMove);
    window.addEventListener("mouseup", flDragEnd);
  }
  if (svg) {
    // Ctrl and the wheel, the way every drawing tool does it. Plain scrolling still scrolls.
    svg.parentNode.addEventListener("wheel", (e) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      flZoomBy(e.deltaY < 0 ? 1 : -1);
    }, { passive: false });
  }
  const on = (id, fn) => { const e = document.getElementById(id); if (e) e.onclick = fn; };
  on("fleet-in", () => flZoomBy(1));
  on("fleet-out", () => flZoomBy(-1));
  on("fleet-pct", flFit);
  on("fleet-refresh", flLoad);
  on("fleet-save", flSave);
  on("fleet-open", () => { const f = document.getElementById("fleet-file"); if (f) f.click(); });
  const file = document.getElementById("fleet-file");
  if (file) file.onchange = () => {
    if (file.files && file.files[0]) flOpen(file.files[0]);
    file.value = "";                     // so the same file can be opened twice
  };
  on("fleet-tidy", flTidy);
  on("fleet-rename", flRename);
  on("fleet-forget", flForget);
  const n = document.getElementById("fleet-name");
  if (n) n.addEventListener("keydown", e => {
    if (e.key === "Enter") { e.preventDefault(); flRename(); }
  });
  flRestoreHeight();
  flGate();
})();
