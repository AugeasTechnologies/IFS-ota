/* Augeas Insight - the view over what this station has recorded about itself.
 *
 * Everything here reads. There is no control on this page, by design: the one screen that
 * analyses the machine's past should not also be a place anyone can move it.
 *
 * The charts are drawn by hand. A library would be a megabyte to draw a line, and this has to
 * work on a bench PC with no internet. The specs they follow are fixed rather than chosen per
 * chart: 2px lines, 8px markers with a 2px surface ring, hairline solid gridlines one step off
 * the surface, a 2px gap between touching marks, and values on the axis and in the tooltip
 * rather than printed on every point.
 *
 * Two colour decisions were computed, not eyeballed:
 *
 *   The good-against-bad comparison uses #007bc0 and #9a6700. The obvious choice - the app's
 *   own green and red - measures delta-E 2.5 under deuteranopia, which is invisible. These two
 *   measure 23.2, and both are already tokens here.
 *
 *   The heatmap ramp is one hue, light to dark, whose lightest step still clears 2:1 against
 *   white. A paler light end looks better on a mock and makes a quiet-but-occupied cell
 *   indistinguishable from an empty one.
 */
(function () {
  "use strict";

  var $ = function (q) { return document.querySelector(q); };
  var days = function () { return parseInt(($("#in-days") || {}).dataset.v || "28", 10); };
  var loaded = false;

  // One hue, light to dark; the light end clears the surface at 2:1.
  var RAMP = ["#8abddd", "#5ba2cd", "#3186bb", "#1169a0", "#004c78"];
  var GOOD = "#007bc0", BAD = "#9a6700";
  var DOW = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function pct(v) { return v == null ? "--" : v.toFixed(1) + "%"; }
  function num(v) { return v == null ? "--" : Number(v).toLocaleString(); }

  // ---------------------------------------------------------------- the shared tooltip
  var tip;
  function tipShow(ev, html) {
    if (!tip) { tip = document.createElement("div"); tip.className = "vtip"; document.body.appendChild(tip); }
    tip.innerHTML = html;
    tip.classList.add("on");
    var r = tip.getBoundingClientRect();
    var x = ev.clientX + 14, y = ev.clientY - r.height - 10;
    if (x + r.width > innerWidth - 8) x = ev.clientX - r.width - 14;
    if (y < 8) y = ev.clientY + 16;
    tip.style.left = x + "px";
    tip.style.top = y + "px";
  }
  function tipHide() { if (tip) tip.classList.remove("on"); }
  // Any element carrying data-tip gets the tooltip, so each chart only has to set an attribute.
  document.addEventListener("mouseover", function (e) {
    var t = e.target.closest && e.target.closest("[data-tip]");
    if (t) tipShow(e, t.dataset.tip);
  });
  document.addEventListener("mousemove", function (e) {
    var t = e.target.closest && e.target.closest("[data-tip]");
    if (t) tipShow(e, t.dataset.tip); else tipHide();
  });
  document.addEventListener("mouseleave", tipHide, true);

  // ---------------------------------------------------------------- score and tiles
  // A 270-degree arc, starting bottom-left. The fill carries severity and the track is a lighter
  // step of the same hue, so the bar reads as a whole rather than stopping where the fill does.
  function arc(frac) {
    var cx = 60, cy = 60, r = 48, start = 135, sweep = 270 * Math.max(0, Math.min(1, frac));
    if (sweep <= 0) return "";
    var rad = function (a) { return (a * Math.PI) / 180; };
    var x1 = cx + r * Math.cos(rad(start)), y1 = cy + r * Math.sin(rad(start));
    var x2 = cx + r * Math.cos(rad(start + sweep)), y2 = cy + r * Math.sin(rad(start + sweep));
    return "M" + x1.toFixed(2) + " " + y1.toFixed(2) + " A" + r + " " + r + " 0 " +
           (sweep > 180 ? 1 : 0) + " 1 " + x2.toFixed(2) + " " + y2.toFixed(2);
  }

  var STILL = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Count a figure up to its value. Not decoration: a number that lands instantly is read as a
  // label, and one that climbs is read as a measurement. It parses the formatting out of the
  // final string rather than being told it, so "1,284", "43s", "12.5h" and "--" all work and
  // nothing has to be passed through twice.
  function countUp(el, text) {
    var m = /^(-?[\d,]+(?:\.\d+)?)/.exec(text || "");
    if (STILL || !m) { el.textContent = text; return; }
    var raw = m[1], rest = text.slice(raw.length);
    var comma = raw.indexOf(",") >= 0;
    var dot = raw.indexOf(".");
    var dec = dot < 0 ? 0 : raw.length - dot - 1;
    var end = parseFloat(raw.replace(/,/g, ""));
    if (!isFinite(end)) { el.textContent = text; return; }
    var t0 = 0, ms = 520;
    function fmt(v) {
      var out = v.toFixed(dec);
      if (comma) {
        var parts = out.split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        out = parts.join(".");
      }
      return out + rest;
    }
    function step(now) {
      if (!t0) t0 = now;
      var k = Math.min(1, (now - t0) / ms);
      var e = 1 - Math.pow(1 - k, 3);          // ease-out: fast first, settles on the figure
      el.textContent = k >= 1 ? text : fmt(end * e);
      if (k < 1) requestAnimationFrame(step);
    }
    el.textContent = fmt(0);
    requestAnimationFrame(step);
  }

  function drawGauge(score) {
    var track = $("#in-gauge-track"), fill = $("#in-gauge-fill");
    if (!track || !fill) return;
    track.setAttribute("d", arc(1));
    track.setAttribute("stroke", "rgba(100,116,139,.14)");
    fill.setAttribute("d", score == null ? "" : arc(score / 100));
    // pathLength normalises the arc to 1 whatever its real length, so one dash covers it and the
    // offset is just "how much of the score is not drawn yet".
    fill.setAttribute("pathLength", "1");
    fill.setAttribute("stroke-dasharray", "1");
    fill.style.strokeDashoffset = "0";
    // Animated outright rather than by flipping a property and hoping a transition catches it.
    // The d, the dash array and the offset all change in the same tick here, and whichever
    // reflow is forced between them Chromium still resolves the start and the end in one pass,
    // so the arc arrives already drawn. An explicit animation has no start state to lose.
    if (!STILL && score != null && fill.animate) {
      fill.animate([{ strokeDashoffset: 1 }, { strokeDashoffset: 0 }],
                   { duration: 900, easing: "cubic-bezier(.22,.61,.36,1)" });
    }
    // Severity on the fill; the number sits inside it, so colour is never the only channel.
    fill.setAttribute("stroke", score == null ? "transparent"
                      : score < 50 ? "url(#in-g-bad)" : score < 70 ? "url(#in-g-warn)" : "url(#in-g-good)");
  }

  function drawSummary(d) {
    countUp($("#in-score"), d.score == null ? "--" : String(d.score));
    drawGauge(d.score);
    var sp = d.span || {};
    var note;
    if (!sp.n) {
      note = "No history yet. The station records a sample every 30 seconds while this " +
             "application is open; come back once it has been running a while.";
    } else {
      var hrs = (sp.b - sp.a) / 3600.0;
      note = sp.n.toLocaleString() + " samples over " +
             (hrs < 48 ? hrs.toFixed(1) + " hours" : (hrs / 24).toFixed(1) + " days") + ".";
      if (hrs < 24 * 7) note += " Findings need a few weeks before they mean much.";
    }
    $("#in-span").textContent = note;

    var parts = [
      ["Utilisation", d.score_parts.utilisation, "share of recorded time running a cycle"],
      ["Quality", d.score_parts.quality, "cycles that finished, of those that ran"],
      ["Availability", d.score_parts.availability, "time with the instrument links up"]
    ];
    $("#in-parts").innerHTML = parts.map(function (p) {
      var v = p[1] == null ? 0 : p[1];
      return '<div class="scorepart"><div class="k">' + esc(p[0]) + '</div>' +
             '<div class="v">' + pct(p[1]) + '</div>' +
             '<div class="bar"><i style="width:' + v.toFixed(1) + '%"></i></div>' +
             '<div class="k" style="margin-top:5px;text-transform:none;letter-spacing:0">' +
             esc(p[2]) + '</div></div>';
    }).join("");

    var ai = d.ai || {}, note2 = $("#in-ai-note"), ask = $("#in-ask"), q = $("#in-q");
    if (!ai.pro) {
      note2.textContent = "IFS AI is part of IFS Suite Pro. Add a key in Configuration. " +
                          "Everything else on this page works without one.";
      ask.disabled = true; q.disabled = true;
    } else if (!ai.available) {
      note2.textContent = "IFS AI needs an Anthropic API key on this station.";
      ask.disabled = true; q.disabled = true;
    } else {
      note2.textContent = "Ask about this station in plain language. It answers by querying the " +
                          "history, and shows the queries it ran.";
      ask.disabled = false; q.disabled = false;
    }
  }

  // Twelve points is a direction, not a chart. The last segment carries the accent so the
  // current period is distinguishable from the lead-up without a second colour.
  function spark(vals) {
    if (!vals || vals.length < 2) return "";
    var W = 120, H = 22, lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
    if (hi === lo) return "";            // flat: "no change" says it; a lone line under it read as a glitch
    var x = function (i) { return (i / (vals.length - 1)) * W; };
    var y = function (v) { return H - 2 - ((v - lo) / (hi - lo)) * (H - 4); };
    var d = vals.map(function (v, i) {
      return (i ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1);
    }).join(" ");
    var n = vals.length - 1;
    var tail = "M" + x(n - 1).toFixed(1) + " " + y(vals[n - 1]).toFixed(1) +
               " L" + x(n).toFixed(1) + " " + y(vals[n]).toFixed(1);
    return '<svg viewBox="0 0 ' + W + " " + H + '" preserveAspectRatio="none">' +
           '<path class="sl" pathLength="1" d="' + d + '"/>' +
           '<path class="sl sl-now" pathLength="1" d="' + tail + '"/></svg>';
  }

  function delta(now, was, upIsGood, fmt) {
    if (now == null || was == null) return "";
    var diff = now - was;
    if (Math.abs(diff) < 1e-9) return '<span class="d flat">no change</span>';
    var better = (diff > 0) === upIsGood;
    return '<span class="d ' + (better ? "up" : "down") + '">' +
           (diff > 0 ? "+" : "-") + fmt(Math.abs(diff)) + "</span>";
  }

  function drawTiles(d) {
    var p = d.prev || {}, g = d.up_is_good || {}, sp = d.spark || {};
    var one = function (v) { return v.toFixed(0); };
    var dec = function (v) { return v.toFixed(1); };
    var t = [
      ["Cycles", num(d.cycles), "on hardware",
       delta(d.cycles, p.cycles, g.cycles, one), sp.cycles],
      ["Failures", num(d.failures),
       d.cycles ? (100 * d.failures / d.cycles).toFixed(1) + "% of cycles" : "",
       delta(d.failures, p.failures, g.failures, one), sp.failures],
      ["Hours run", d.hours_run == null ? "--" : d.hours_run.toFixed(1),
       "of " + d.hours_recorded.toFixed(0) + " recorded",
       delta(d.hours_run, p.hours_run, g.hours_run, dec), sp.hours_run],
      ["Mean cycle", d.avg_cycle_secs == null ? "--" : d.avg_cycle_secs.toFixed(0) + "s",
       "when it finished",
       delta(d.avg_cycle_secs, p.avg_cycle_secs, g.avg_cycle_secs, one), null],
      ["MTBF", d.mtbf_hours == null ? "--" : d.mtbf_hours.toFixed(1) + "h",
       "running time per failure",
       delta(d.mtbf_hours, p.mtbf_hours, g.mtbf_hours, dec), null]
    ];
    var since = "vs the " + d.days + " days before";
    $("#in-tiles").innerHTML = t.map(function (x) {
      var tip = x[3] ? "<b>" + esc(x[0]) + "</b><br>" + esc(since) : "";
      return '<div class="tile"' + (tip ? ' data-tip="' + esc(tip) + '"' : "") + '>' +
             '<div class="k">' + esc(x[0]) + "</div>" +
             '<div class="v"><span class="n">' + esc(x[1]) + "</span>" + x[3] + "</div>" +
             '<div class="u">' + esc(x[2]) + "</div>" + spark(x[4]) + "</div>";
    }).join("");
    Array.prototype.forEach.call($("#in-tiles").querySelectorAll(".v .n"), function (n) {
      countUp(n, n.textContent);
    });
  }

  // ---------------------------------------------------------------- findings
  function drawFindings(d) {
    var el = $("#in-findings");
    if (!d.ready) {
      el.innerHTML = '<p class="hint">Not enough to compare yet. This needs at least ' +
        d.need + ' good and ' + d.need + ' bad outcomes in the window; there are ' +
        d.good + ' and ' + d.bad + '. Until then there is nothing here worth reading.</p>';
      return;
    }
    if (!d.items.length) {
      el.innerHTML = '<p class="hint">Nothing stood out. Across ' + d.good + ' good and ' +
        d.bad + ' bad outcomes, no condition differed enough to be worth acting on.</p>';
      return;
    }
    el.innerHTML = d.items.map(function (f) {
      var strength = Math.abs(f.effect) >= 1.2 ? "a large difference"
                   : Math.abs(f.effect) >= 0.8 ? "a clear difference" : "a modest difference";
      return '<div class="finding"><b>' + esc(f.label) + ' ran ' + esc(f.direction) +
        ' before failures.</b><div class="n">' +
        f.bad_mean + esc(f.unit) + ' before the ' + f.n_bad + ' bad outcomes, against ' +
        f.good_mean + esc(f.unit) + ' before the ' + f.n_good + ' good ones. That is ' +
        strength + '. It does not prove one caused the other.</div></div>';
    }).join("");
  }

  // ---------------------------------------------------------------- small multiples
  var MULT = [
    ["temp_f", "Electrode temperature", "F"],
    ["power", "Power", ""],
    ["vacuum", "Vacuum", ""],
    ["busy", "Running", ""]
  ];

  function sparkline(pts, unit) {
    var W = 300, H = 84, pad = 5;
    if (!pts.length) {
      return '<svg viewBox="0 0 ' + W + ' ' + H + '"><text x="' + (W / 2) + '" y="' + (H / 2) +
             '" text-anchor="middle" fill="#6a7178" font-size="11">no data</text></svg>';
    }
    var vs = pts.map(function (p) { return p.v; });
    var lo = Math.min.apply(null, vs), hi = Math.max.apply(null, vs);
    var flat = hi === lo;
    if (flat) { hi = lo + 1; lo = lo - 1; }
    var t0 = pts[0].t, t1 = pts[pts.length - 1].t;
    var x = function (t) { return pad + (t - t0) / ((t1 - t0) || 1) * (W - pad * 2); };
    var y = function (v) { return H - pad - (v - lo) / (hi - lo) * (H - pad * 2); };
    var line = pts.map(function (p, i) {
      return (i ? "L" : "M") + x(p.t).toFixed(1) + " " + y(p.v).toFixed(1);
    }).join(" ");
    var area = "M" + x(t0).toFixed(1) + " " + (H - pad) + " " + line.slice(1) +
               " L" + x(t1).toFixed(1) + " " + (H - pad) + " Z";
    var last = pts[pts.length - 1];
    // Hairline baseline, solid, one step off the surface. The value lives on the heading and in
    // the tooltip; printing it on every point would be chaos and go unread.
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none">' +
      '<line class="gr" x1="' + pad + '" y1="' + (H - pad) + '" x2="' + (W - pad) + '" y2="' + (H - pad) + '"/>' +
      (flat ? "" : '<path class="ar" d="' + area + '"/>') +          // a flat run filled in looked like a solid bar
      '<path class="ln" pathLength="1" d="' + line + '"/>' +
      '<circle class="dot" cx="' + x(last.t).toFixed(1) + '" cy="' + y(last.v).toFixed(1) + '" r="4"/>' +
      '</svg>';
  }

  function drawMult() {
    var host = $("#in-mult");
    host.innerHTML = MULT.map(function (m) {
      return '<div class="sm" data-f="' + m[0] + '"><div class="t">' + esc(m[1]) +
             '</div><div class="r">loading</div></div>';
    }).join("");
    MULT.forEach(function (m) {
      fetch("/api/insight/series?days=" + days() + "&field=" + m[0])
        .then(function (r) { return r.json(); })
        .then(function (d) {
          var cell = host.querySelector('.sm[data-f="' + m[0] + '"]');
          if (!cell) return;
          var pts = d.points || [];
          var rng = "Nothing recorded in this window yet";
          if (!pts.length) { cell.classList.add("empty"); cell.querySelector(".r").textContent = rng; return; }
          if (pts.length) {
            var vs = pts.map(function (p) { return p.v; });
            var lo = Math.min.apply(null, vs), hi = Math.max.apply(null, vs);
            rng = lo.toFixed(1) + " to " + hi.toFixed(1) + m[2] +
                  ", now " + pts[pts.length - 1].v.toFixed(1) + m[2];
          }
          cell.querySelector(".r").textContent = rng;
          cell.insertAdjacentHTML("beforeend", sparkline(pts, m[2]));
          var svg = cell.querySelector("svg");
          if (svg && pts.length) {
            svg.setAttribute("data-tip", "<b>" + esc(m[1]) + "</b><br>" + esc(rng) +
                                         "<br>" + pts.length + " buckets over " + days() + " days");
          }
        }).catch(function () {});
    });
  }

  // ---------------------------------------------------------------- heatmap
  function drawHeat(d) {
    var host = $("#in-heat"), grid = d.grid || [], peak = d.peak || 0;
    if (!peak) {
      host.innerHTML = '<p class="hint in-empty">Nothing recorded in this window yet. The grid fills in as the station runs, one square per hour of the week.</p>';
      return;
    }
    var h = ['<div class="heatwrap"><div class="heat">'];
    h.push('<div></div>');
    for (var hr = 0; hr < 24; hr++) {
      h.push('<div class="hh">' + (hr % 3 === 0 ? hr : "") + "</div>");
    }
    // Monday first: a working week does not start on Sunday.
    var order = [1, 2, 3, 4, 5, 6, 0];
    order.forEach(function (di) {
      h.push('<div class="lab">' + DOW[di].slice(0, 3) + "</div>");
      for (var k = 0; k < 24; k++) {
        var v = (grid[di] || [])[k] || 0;
        var style = "", tipv;
        if (v > 0 && peak > 0) {
          var step = Math.min(RAMP.length - 1, Math.floor((v / peak) * RAMP.length));
          style = 'background:' + RAMP[step];
        }
        tipv = "<b>" + DOW[di] + ", " + String(k).padStart(2, "0") + ":00</b><br>" +
               (v > 0 ? v.toFixed(2) + " " + d.unit : "nothing recorded");
        h.push('<div class="c" style="' + style + (style ? ";" : "") + "--d:" + (k * 11) +
               'ms" data-tip="' + esc(tipv) + '"></div>');
      }
    });
    h.push("</div></div>");
    h.push('<div class="heatkey"><span>less</span>' +
           RAMP.map(function (c) { return '<i style="background:' + c + '"></i>'; }).join("") +
           "<span>more</span><span style=\"margin-left:10px\">peak " +
           (peak ? peak.toFixed(2) : "0") + " " + esc(d.unit) + " in one hour</span></div>");
    host.innerHTML = h.join("");
  }

  // ---------------------------------------------------------------- distribution
  function drawDist(d) {
    var host = $("#in-dist");
    if (!d.ok) {
      host.innerHTML = '<p class="hint">Not enough outcomes recorded to show a spread yet.</p>';
      return;
    }
    var w = (d.hi - d.lo) / d.bins;
    var peak = Math.max.apply(null, d.good.concat(d.bad)) || 1;

    function row(hist, colour, title, n, mean) {
      var W = 600, H = 80, gap = 2;
      var bw = (W - gap * (d.bins - 1)) / d.bins;
      var bars = hist.map(function (c, i) {
        var bh = c / peak * (H - 4);
        var x = i * (bw + gap), y = H - bh;
        var a = (d.lo + i * w).toFixed(1), b = (d.lo + (i + 1) * w).toFixed(1);
        var t = "<b>" + esc(title) + "</b><br>" + a + " to " + b + esc(d.unit) +
                "<br>" + c + (c === 1 ? " run" : " runs");
        // 4px rounded data-end, square at the baseline; a 2px gap, not a stroke, separates them.
        return '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + bw.toFixed(1) +
               '" height="' + Math.max(bh, c ? 1.5 : 0).toFixed(1) + '" rx="2" fill="' + colour +
               '" style="--d:' + (i * 22) + 'ms" data-tip="' + esc(t) + '"></rect>';
      }).join("");
      var mx = mean == null ? null : ((mean - d.lo) / (d.hi - d.lo)) * W;
      var meanMark = mx == null ? "" :
        '<line x1="' + mx.toFixed(1) + '" y1="0" x2="' + mx.toFixed(1) + '" y2="' + H +
        '" stroke="' + colour + '" stroke-width="2" stroke-dasharray="3 3" opacity=".75"/>';
      return '<div class="distrow"><div class="h">' +
        '<i style="width:9px;height:9px;border-radius:2px;background:' + colour +
        ';display:inline-block"></i>' +
        '<b>' + esc(title) + '</b><span>' + n + (n === 1 ? " run" : " runs") +
        (mean == null ? "" : ", mean " + mean + esc(d.unit)) + '</span></div>' +
        '<svg viewBox="0 0 600 80" preserveAspectRatio="none">' + bars + meanMark + "</svg></div>";
    }

    host.innerHTML =
      '<div class="dist">' +
      row(d.good, GOOD, "Ran well", d.n_good, d.good_mean) +
      row(d.bad, BAD, "Failed", d.n_bad, d.bad_mean) +
      '<div class="distaxis"><span>' + d.lo.toFixed(1) + esc(d.unit) + "</span><span>" +
      ((d.lo + d.hi) / 2).toFixed(1) + esc(d.unit) + "</span><span>" +
      d.hi.toFixed(1) + esc(d.unit) + "</span></div></div>";
  }

  // ---------------------------------------------------------------- tables
  function drawDaily(items) {
    var t = $("#in-daily");
    if (!items.length) {
      t.innerHTML = '<tr><td class="empty">Nothing recorded in this window.</td></tr>';
      return;
    }
    t.innerHTML =
      '<thead><tr><th>Day</th><th class="n">Hours run</th><th class="n">Recorded</th>' +
      '<th class="n">Cycles</th><th class="n">Failed</th><th class="n">Electrode temp</th>' +
      "</tr></thead><tbody>" +
      items.map(function (r) {
        return "<tr><td>" + esc(r.day) + '</td><td class="n">' + r.hours.toFixed(2) +
          '</td><td class="n">' + r.recorded.toFixed(1) + '</td><td class="n">' +
          (r.good + r.bad) + '</td><td class="n">' + (r.bad || "") + '</td><td class="n">' +
          (r.temp == null ? "" : r.temp.toFixed(1)) + "</td></tr>";
      }).join("") + "</tbody>";
  }

  var SEV = { info: "#1a7f37", warn: "#9a6700", bad: "#b21f2b" };

  function drawEvents(items) {
    var t = $("#in-events");
    $("#in-ev-count").textContent = items.length ? items.length + " most recent" : "";
    if (!items.length) {
      t.innerHTML = '<tr><td class="empty">Nothing recorded in this window.</td></tr>';
      return;
    }
    t.innerHTML =
      '<thead><tr><th>When</th><th>What</th><th>Where</th><th>Detail</th><th class="n">Took</th>' +
      "</tr></thead><tbody>" +
      items.map(function (r) {
        var when = new Date(r.ts * 1000);
        // The dot repeats what the word already says; it never carries the meaning alone.
        return "<tr><td>" + esc(when.toLocaleString(undefined, {
          month: "short", day: "numeric", hour: "2-digit", minute: "2-digit"
        })) + '</td><td><span class="sev"><i style="background:' +
          (SEV[r.severity] || "#6a7178") + '"></i>' + esc(r.kind.replace(/_/g, " ")) +
          "</span></td><td>" + esc(r.source || "") + "</td><td>" + esc(r.label || "") +
          '</td><td class="n">' + (r.secs == null ? "" : r.secs.toFixed(0) + "s") + "</td></tr>";
      }).join("") + "</tbody>";
  }

  // ---------------------------------------------------------------- load
  function j(url) { return fetch(url).then(function (r) { return r.json(); }); }

  function load() {
    var n = days();
    j("/api/insight/summary?days=" + n).then(drawSummary).catch(function () {});
    j("/api/insight/tiles?days=" + n).then(drawTiles).catch(function () {});
    j("/api/insight/findings?days=" + n).then(drawFindings).catch(function () {});
    j("/api/insight/daily?days=" + n).then(function (d) { drawDaily(d.items || []); }).catch(function () {});
    j("/api/insight/events?days=" + n).then(function (d) { drawEvents(d.items || []); }).catch(function () {});
    drawMult();
    loadHeat();
    loadDist();
    loadMcp();
    loadKey();
    loadProvider();
    loadOperate();
  }

  function loadHeat() {
    j("/api/insight/heat?days=" + days() + "&metric=" + $("#in-heat-metric").value)
      .then(drawHeat).catch(function () {});
  }
  function loadDist() {
    j("/api/insight/dist?days=" + days() + "&field=" + $("#in-dist-field").value)
      .then(drawDist).catch(function () {});
  }

  // ---------------------------------------------------------------- the conversation
  var es = null;          // the open stream, so a second question cannot race the first

  function bubble(who, text) {
    var el = document.createElement("div");
    el.className = "msg " + who;
    el.innerHTML = '<div class="av">' + (who === "ai" ? "AT" : "YOU") + "</div>" +
                   '<div class="b"></div>';
    el.querySelector(".b").textContent = text || "";
    $("#in-chat").appendChild(el);
    el.scrollIntoView({ block: "nearest", behavior: "smooth" });
    return el;
  }

  function thinking(el, word) {
    // Dots alone tell nobody whether anything is happening, so the blob carries the word for
    // what it is doing right now.
    el.querySelector(".b").innerHTML =
      '<span class="blob"><i></i><i></i><i></i></span>' +
      '<span class="chatstatus">' + esc(word || "Thinking") + "</span>";
  }

  function ask() {
    var q = ($("#in-q").value || "").trim();
    if (!q || es) return;
    $("#in-q").value = "";
    bubble("me", q);

    var el = bubble("ai", "");
    thinking(el, "Reading the history");
    var body = el.querySelector(".b");
    var answer = "", queries = [], needs = [];
    $("#in-ask").disabled = true;

    es = new EventSource("/api/insight/chat?q=" + encodeURIComponent(q));

    var paint = function () {
      body.textContent = answer;
      el.scrollIntoView({ block: "nearest" });
    };

    es.addEventListener("status", function (e) {
      if (!answer) thinking(el, JSON.parse(e.data));
    });
    es.addEventListener("query", function (e) {
      queries.push(JSON.parse(e.data));
    });
    // The same actions the rail applies. Without this a press was logged and announced here and
    // never happened.
    es.addEventListener("view", function (e) {
      var v = {};
      try { v = JSON.parse(e.data) || {}; } catch (x) { v = {}; }
      if (v.action === "confirm" || v.action === "confirm_field") {
        // The approve button lives in the assistant rail; here it is said, not set up.
        needs.push(v.label || v.el);
        return;
      }
      if (window.ifsApplyView) window.ifsApplyView(v);
    });
    es.addEventListener("delta", function (e) {
      answer += JSON.parse(e.data);
      paint();
    });
    es.addEventListener("done", function (e) {
      var u = JSON.parse(e.data) || {};
      if (needs.length) {
        answer += (answer ? "\n\n" : "") + "Needs you: " + needs.join(", ") +
                  ". Nothing was pressed - do it on its screen, or ask in the assistant rail.";
      }
      finish(el, body, answer, queries, u);
    });
    es.addEventListener("error", function (e) {
      // An SSE 'error' with data is ours; one without is the socket dropping.
      var msg = "";
      try { msg = JSON.parse(e.data); } catch (x) { msg = ""; }
      if (msg) {
        answer = answer || msg;
        finish(el, body, answer, queries, null, msg);
      } else if (es) {
        finish(el, body, answer || "The connection dropped before it finished.", queries, null);
      }
    });
  }

  function finish(el, body, answer, queries, usage, errorMsg) {
    if (es) { es.close(); es = null; }
    $("#in-ask").disabled = false;
    body.textContent = answer || "No answer came back.";
    if (errorMsg && answer === errorMsg) el.classList.add("err");
    if (queries.length) {
      // The working, under every answer. An answer whose SQL is on screen is one an engineer
      // can check, which is the whole reason to trust it.
      var d = document.createElement("details");
      d.className = "work";
      d.innerHTML = "<summary>" + queries.length +
        (queries.length === 1 ? " query" : " queries") + "</summary><pre></pre>";
      d.querySelector("pre").textContent = queries.map(function (x) {
        return x.sql + "\n  " + (x.error ? "error: " + x.error : x.rows + " rows");
      }).join("\n\n");
      el.querySelector(".b").appendChild(d);
    }
    if (usage && (usage["in"] || usage.out)) {
      var t = document.createElement("div");
      t.className = "chatstatus";
      t.style.marginLeft = "0";
      t.style.marginTop = "6px";
      t.textContent = (usage["in"] + usage.out).toLocaleString() + " tokens";
      el.querySelector(".b").appendChild(t);
    }
  }

  function newChat() {
    if (es) { es.close(); es = null; }
    $("#in-ask").disabled = false;
    fetch("/api/insight/chat/reset", { method: "POST" })
      .then(function () { $("#in-chat").innerHTML = ""; })
      .catch(function () { $("#in-chat").innerHTML = ""; });
  }

  // ---------------------------------------------------------------- which model answers
  function showProv(p) {
    $("#in-prov").dataset.v = p;
    [].forEach.call($("#in-prov").children, function (b) {
      b.classList.toggle("on", b.dataset.p === p);
    });
    $("#in-localrow").style.display = p === "local" ? "flex" : "none";
    $("#in-provnote").textContent = p === "local"
      ? "A model on your own network. Nothing leaves the site and there is no cost per question."
      : "Anthropic's models. Needs internet and an API key, and costs a few cents a question.";
  }

  function loadProvider() {
    j("/api/insight/provider").then(function (d) {
      showProv(d.provider);
      $("#in-ourl").value = d.url || "";
      if (d.model) {
        $("#in-omodel").innerHTML = '<option>' + esc(d.model) + "</option>";
      }
      $("#in-keyrow").style.display = (d.provider === "anthropic" && !d.key_set) ? "flex" : "none";
      if (d.provider === "anthropic" && !d.key_set) {
        $("#in-keynote").textContent =
          "Your own Anthropic API key, from console.anthropic.com. It stays on this station and " +
          "is sent nowhere but Anthropic.";
      }
    }).catch(function () {});
  }

  function probeModels() {
    var url = ($("#in-ourl").value || "").trim();
    $("#in-onote").textContent = "Looking at " + url + "...";
    j("/api/insight/provider?probe=1&url=" + encodeURIComponent(url)).then(function (d) {
      // The probe reads the SAVED address, so save first and then list what that host runs.
      return fetch("/api/insight/provider", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider: "local", url: url,
                               model: $("#in-omodel").value || "" })
      }).then(function () { return j("/api/insight/provider?probe=1"); });
    }).then(function (d) {
      var ms = d.models || [];
      if (!ms.length) {
        $("#in-onote").textContent = d.probe_error ||
          "No models there. Is Ollama running on that machine?";
        return;
      }
      $("#in-omodel").innerHTML = ms.map(function (m) {
        return '<option' + (m === d.model ? " selected" : "") + ">" + esc(m) + "</option>";
      }).join("");
      $("#in-onote").textContent = ms.length + " model" + (ms.length === 1 ? "" : "s") +
        " on that machine. Pick one and press Use this.";
    }).catch(function (e) { $("#in-onote").textContent = String(e); });
  }

  function saveProvider(p) {
    var body = { provider: p, url: ($("#in-ourl").value || "").trim(),
                 model: $("#in-omodel").value || "" };
    return fetch("/api/insight/provider", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) { $("#in-onote").textContent = d.error || "That did not save."; return; }
      $("#in-onote").textContent = p === "local"
        ? "Connected. IFS AI now answers from " + body.model + " on " + body.url + "."
        : "";
      showProv(p);
      load();
    });
  }

  // ---------------------------------------------------------------- may it work the instrument
  function loadOperate() {
    j("/api/insight/operate").then(function (d) {
      $("#in-operate").checked = !!d.on;
      $("#in-operate-why").textContent = d.on && !d.effective
        ? "On, but an MCP service is enabled - instrument actions still ask, because text from a "
          + "service we do not control reaches the model."
        : d.on
          ? "On. It starts, moves and flashes without asking. Every action is in the event log."
          : "Off: it asks before anything starts, moves or flashes. On: it does those itself. "
            + "Everything it does is written to the event log either way.";
    }).catch(function () {});
  }

  function saveOperate() {
    fetch("/api/insight/operate", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ on: $("#in-operate").checked })
    }).then(function (r) { return r.json(); }).then(loadOperate).catch(function () {});
  }

  // ---------------------------------------------------------------- the key
  function loadKey() {
    j("/api/insight/key").then(function (d) {
      var row = $("#in-keyrow");
      if (d.set || d.env) {
        row.style.display = "none";
        return;
      }
      row.style.display = "flex";
      $("#in-keynote").textContent =
        "Your own Anthropic API key, from console.anthropic.com. It stays on this station and " +
        "is sent nowhere but Anthropic.";
    }).catch(function () {});
  }

  function saveKey() {
    var k = ($("#in-key").value || "").trim();
    fetch("/api/insight/key", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: k })
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) { $("#in-keynote").textContent = d.error || "That did not save."; return; }
      $("#in-key").value = "";
      $("#in-keyrow").style.display = "none";
      load();
    }).catch(function () {});
  }

  // ---------------------------------------------------------------- MCP services
  function loadMcp() {
    j("/api/insight/mcp").then(function (d) { drawMcp(d.items || []); }).catch(function () {});
  }

  function drawMcp(items) {
    var el = $("#in-mcp");
    if (!items.length) { el.innerHTML = '<p class="hint">None yet.</p>'; return; }
    el.innerHTML = items.map(function (m) {
      return '<div class="mcprow" data-id="' + esc(m.id) + '">' +
        '<label style="display:flex;align-items:center;gap:7px">' +
        '<input type="checkbox" class="mcp-on"' + (m.enabled ? " checked" : "") + '>' +
        '<span class="nm">' + esc(m.name) + "</span></label>" +
        '<span class="u">' + esc(m.url) + "</span>" +
        (m.has_token ? '<span class="pill">key set</span>' : "") +
        '<button class="ghost mcp-edit">Edit</button>' +
        '<button class="ghost mcp-del">Remove</button></div>';
    }).join("");
  }

  function mcpSave(row) {
    return fetch("/api/insight/mcp", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(row)
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (d.items) drawMcp(d.items);
      return d;
    });
  }

  function mcpPrompt(existing) {
    var e = existing || {};
    var name = prompt("A short name for the service. Letters and numbers.", e.name || "");
    if (!name) return;
    var url = prompt("Its MCP address (https).", e.url || "https://");
    if (!url) return;
    var tok = prompt("Access token, if it needs one. Leave blank to keep what is stored.", "");
    mcpSave({ id: e.id || "", name: name, url: url, token: tok || "",
              enabled: e.enabled === undefined ? false : e.enabled })
      .then(function (d) { if (!d.ok) alert(d.error || "That did not save."); });
  }

  // ---------------------------------------------------------------- wiring
  function init() {
    $("#in-refresh").onclick = load;
    $("#in-days").addEventListener("click", function (ev) {
      if (ev.target.tagName !== "BUTTON") return;
      $("#in-days").dataset.v = ev.target.dataset.d;
      [].forEach.call(this.children, function (b) { b.classList.toggle("on", b === ev.target); });
      load();
    });
    $("#in-heat-metric").onchange = loadHeat;
    $("#in-dist-field").onchange = loadDist;
    $("#in-ask").onclick = ask;
    $("#in-q").onkeydown = function (ev) { if (ev.key === "Enter") ask(); };
    $("#in-newchat").onclick = newChat;
    $("#in-keysave").onclick = saveKey;
    $("#in-operate").onchange = saveOperate;
    // Explain hands the question to the assistant rather than printing a paragraph nobody reads
    // twice. The answer is about THIS station's data, which the sentence never could be.
    document.addEventListener("click", function (ev) {
      var b = ev.target.closest && ev.target.closest(".explain");
      if (!b) return;
      if (typeof aiAsk === "function") {
        // Pointed on purpose. "Explain the heatmap" gets an explanation of heatmaps; what is
        // wanted is what THIS one says, which means reading the figures behind it.
        aiAsk("Look at " + b.dataset.topic + " on this screen and tell me what it says about this "
              + "station. Read the actual figures. Not what the chart type is for.");
      }
    });

    $("#in-prov").addEventListener("click", function (ev) {
      if (ev.target.tagName !== "BUTTON") return;
      var p = ev.target.dataset.p;
      showProv(p);
      if (p === "anthropic") saveProvider("anthropic");
      // Local waits for an address and a model before it is saved.
    });
    $("#in-oprobe").onclick = probeModels;
    $("#in-osave").onclick = function () { saveProvider("local"); };
    $("#in-key").onkeydown = function (ev) { if (ev.key === "Enter") saveKey(); };
    $("#in-mcp-add").onclick = function () { mcpPrompt(null); };

    $("#in-mcp").addEventListener("click", function (ev) {
      var row = ev.target.closest(".mcprow");
      if (!row) return;
      var id = row.dataset.id;
      if (ev.target.classList.contains("mcp-del")) {
        if (!confirm("Remove this service?")) return;
        fetch("/api/insight/mcp?id=" + encodeURIComponent(id), { method: "DELETE" })
          .then(function (r) { return r.json(); })
          .then(function (d) { drawMcp(d.items || []); });
      } else if (ev.target.classList.contains("mcp-edit")) {
        mcpPrompt({ id: id, name: row.querySelector(".nm").textContent,
                    url: row.querySelector(".u").textContent,
                    enabled: row.querySelector(".mcp-on").checked });
      }
    });
    $("#in-mcp").addEventListener("change", function (ev) {
      if (!ev.target.classList.contains("mcp-on")) return;
      var row = ev.target.closest(".mcprow");
      if (ev.target.checked &&
          !confirm("Questions and their context will be sent to this service when IFS AI " +
                   "decides it is relevant. Turn it on?")) {
        ev.target.checked = false;
        return;
      }
      mcpSave({ id: row.dataset.id, name: row.querySelector(".nm").textContent,
                url: row.querySelector(".u").textContent, enabled: ev.target.checked });
    });

    var ex = ["What failed in the last week?", "Does temperature differ on the bad runs?",
              "How many hours was this station actually running?"];
    $("#in-examples").innerHTML = ex.map(function (t) {
      return '<button class="ghost">' + esc(t) + "</button>";
    }).join("");
    $("#in-examples").addEventListener("click", function (ev) {
      if (ev.target.tagName !== "BUTTON") return;
      $("#in-q").value = ev.target.textContent;
      ask();
    });
  }

  // The view only loads when somebody opens it: this page runs SQL, and a station that never
  // looks at it should never pay for that.
  window.insightOpen = function () {
    if (!loaded) { init(); loaded = true; }
    load();
  };
})();
