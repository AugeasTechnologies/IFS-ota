/* Connect your AI - a guided setup for IFS AI.
 *
 * The customer brings their own AI: an Anthropic key, an OpenAI (or compatible) key, or a model
 * running on their own network. Nothing of Augeas's is used. Each choice is tested before the
 * wizard calls it done, so "set up" means "answered a question", not "a box was filled in".
 * Offered once at a person's first sign-in, and any time from the assistant or the Insight screen.
 */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var KEY_PAGES = {
    anthropic: "https://console.anthropic.com/settings/keys",
    openai: "https://platform.openai.com/api-keys"
  };
  var st = { step: 0, source: null };

  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  async function j(url, opts) {
    var r = await fetch(url, opts);
    try { return await r.json(); } catch (e) { return { ok: false, error: "No answer (" + r.status + ")" }; }
  }
  function post(url, body) {
    return j(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  }
  function openExternal(url) {
    // the desktop window hands this to the system browser
    try { window.open(url, "_blank", "noopener"); } catch (e) {}
  }

  function shell() {
    var el = $("#aiwiz");
    if (el) return el;
    el = document.createElement("div");
    el.id = "aiwiz";
    el.className = "aiwiz";
    el.innerHTML =
      '<div class="aiwiz-card" role="dialog" aria-modal="true" aria-label="Connect your AI">' +
      '  <div class="aiwiz-head"><div class="aiwiz-title"><b>Connect your AI</b><span>Use your own AI with IFS. It takes a minute, and it is tested before it says done.</span></div>' +
      '    <button class="aiwiz-x" id="aiwizClose">Not now</button></div>' +
      '  <div class="aiwiz-steps" id="aiwizSteps"></div>' +
      '  <div class="aiwiz-body" id="aiwizBody"></div>' +
      '  <div class="aiwiz-msg" id="aiwizMsg"></div>' +
      '  <div class="aiwiz-foot"><button class="ghost" id="aiwizBack">Back</button><span style="flex:1"></span>' +
      '    <button class="btn" id="aiwizNext">Next</button></div>' +
      '</div>';
    document.body.appendChild(el);
    $("#aiwizClose").onclick = function () { close(true); };
    $("#aiwizBack").onclick = function () { go(st.step - 1); };
    el.addEventListener("keydown", function (e) { if (e.key === "Escape") close(true); });
    return el;
  }
  function msg(t, kind) { var m = $("#aiwizMsg"); m.textContent = t || ""; m.className = "aiwiz-msg" + (kind ? " " + kind : ""); }
  function close(markSeen) {
    var el = $("#aiwiz"); if (el) el.remove();
    if (markSeen) post("/api/insight/setup", {});
    if (typeof window.ifsAiReload === "function") window.ifsAiReload();
    if (typeof window.ifsAiStatus === "function") window.ifsAiStatus();
  }
  function steps(names, at) {
    $("#aiwizSteps").innerHTML = names.map(function (n, i) {
      var cls = i === at ? "on" : i < at ? "done" : "";
      return (i ? '<span class="ln ' + (i <= at ? "done" : "") + '"></span>' : "") +
             '<span class="st ' + cls + '"><i>' + (i < at ? "&#10003;" : i + 1) + "</i><span>" + esc(n) + "</span></span>";
    }).join("");
  }
  var NAMES = ["Licence", "Your AI", "Connect", "Services", "Test"];

  async function go(n) {
    st.step = Math.max(0, Math.min(4, n));
    msg("");
    steps(NAMES, st.step);
    $("#aiwizBack").style.visibility = st.step === 0 ? "hidden" : "visible";
    var b = $("#aiwizBody"), next = $("#aiwizNext");
    next.disabled = false; next.textContent = "Next";
    if (st.step === 0) return stepLicence(b, next);
    if (st.step === 1) return stepSource(b, next);
    if (st.step === 2) return stepConnect(b, next);
    if (st.step === 3) return stepServices(b, next);
    return stepTest(b, next);
  }

  // 1. Licence ---------------------------------------------------------------------------------
  async function stepLicence(b, next) {
    var s = await j("/api/insight/setup");
    if (s.pro) {
      b.innerHTML = '<p class="aiwiz-lead">IFS AI is included in this station\'s IFS Suite Pro licence.</p>' +
        '<p class="hint">Next, choose the AI it should use. You bring your own: an Anthropic or OpenAI account, or a model running on your own network.</p>';
    } else {
      b.innerHTML = '<p class="aiwiz-lead">First, a word about the licence</p>' +
        '<div class="aiwiz-note">IFS AI is part of IFS Suite Pro, and this station has no licence installed yet. You can connect your AI now; it starts answering as soon as a licence is installed under Configuration.</div>' +
        '<button class="wbtn" id="aiwizLic" style="margin-top:12px">Open Configuration</button>';
      $("#aiwizLic").onclick = function () { close(false); var n = document.querySelector('.navitem[data-v="cfg"]'); if (n) n.click(); };
    }
    next.onclick = function () { go(1); };
  }

  // 2. Which AI ------------------------------------------------------------------------------
  function stepSource(b, next) {
    b.innerHTML =
      '<p class="aiwiz-lead">Which AI should IFS use?</p>' +
      '<div class="aiwiz-choices">' +
      '  <button class="aiwiz-choice" data-s="anthropic"><span class="bd a">A</span><span><b>Anthropic (Claude)</b><span class="d">Sign in to your Anthropic account and create an API key.</span></span><span class="rd"></span></button>' +
      '  <button class="aiwiz-choice" data-s="openai"><span class="bd o">O</span><span><b>OpenAI</b><span class="d">Sign in to your OpenAI account and create an API key. Also works with Azure OpenAI and other compatible services.</span></span><span class="rd"></span></button>' +
      '  <button class="aiwiz-choice" data-s="local"><span class="bd l"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></span><span><b>A model on your network</b><span class="d">A computer in your lab running Ollama. Nothing leaves your network.</span></span><span class="rd"></span></button>' +
      "</div>";
    b.querySelectorAll(".aiwiz-choice").forEach(function (c) {
      c.classList.toggle("on", c.dataset.s === st.source);
      c.onclick = function () { st.source = c.dataset.s; go(2); };
    });
    next.onclick = function () { if (!st.source) return msg("Choose one to continue.", "err"); go(2); };
  }

  // 3. Connect -------------------------------------------------------------------------------
  async function stepConnect(b, next) {
    if (!st.source) return go(1);
    if (st.source === "anthropic") {
      var k = await j("/api/insight/key");
      b.innerHTML =
        '<p class="aiwiz-lead">Connect your Anthropic account</p>' +
        '<ol class="aiwiz-ol"><li><i>1</i><span><button class="wbtn" id="aiwizGet">Open the Anthropic Console<small>in your browser</small></button> and sign in.</span></li>' +
        "<li><i>2</i><span>Create an API key and copy it.</span></li><li><i>3</i><span>Paste it below.</span></li></ol>" +
        '<input type="password" id="aiwizKey" placeholder="' + (k.set ? "Saved key ending " + esc(k.tail) + " - paste a new one to replace it" : "sk-ant-...") + '" autocomplete="off">' +
        '<p class="hint">The key stays on this PC. It is never shown again or sent anywhere except Anthropic.</p>';
      $("#aiwizGet").onclick = function () { openExternal(KEY_PAGES.anthropic); };
      next.textContent = "Save and continue";
      next.onclick = async function () {
        var v = ($("#aiwizKey").value || "").trim();
        if (v) { var r = await post("/api/insight/key", { key: v }); if (!r.ok) return msg(r.error, "err"); }
        else if (!k.set) return msg("Paste your key first.", "err");
        var p = await post("/api/insight/provider", { provider: "anthropic" });
        if (!p.ok) return msg(p.error, "err");
        go(3);
      };
    } else if (st.source === "openai") {
      var o = await j("/api/insight/openai");
      b.innerHTML =
        '<p class="aiwiz-lead">Connect your OpenAI account</p>' +
        '<ol class="aiwiz-ol"><li><i>1</i><span><button class="wbtn" id="aiwizGet">Open OpenAI API keys<small>in your browser</small></button> and sign in.</span></li>' +
        "<li><i>2</i><span>Create a secret key and copy it.</span></li><li><i>3</i><span>Paste it below, then choose a model.</span></li></ol>" +
        '<input type="password" id="aiwizKey" placeholder="' + (o.set ? "Saved key ending " + esc(o.tail) + " - paste a new one to replace it" : "sk-...") + '" autocomplete="off">' +
        '<div class="aiwiz-row"><button class="wbtn" id="aiwizModels">Find my models</button>' +
        '<select id="aiwizModel"><option value="">' + (o.model ? esc(o.model) : "choose a model") + "</option></select></div>" +
        '<details class="aiwiz-adv"><summary>Using Azure OpenAI or another compatible service?</summary>' +
        '<input id="aiwizUrl" value="' + esc(o.url) + '"><p class="hint">The address of its OpenAI-compatible API (ending in /v1 for most services).</p></details>';
      $("#aiwizGet").onclick = function () { openExternal(KEY_PAGES.openai); };
      if (o.model) $("#aiwizModel").value = "";
      var saveKey = async function () {
        var body = { url: ($("#aiwizUrl").value || "").trim() };
        var v = ($("#aiwizKey").value || "").trim();
        if (v) body.key = v;
        else if (!o.set) { msg("Paste your key first.", "err"); return false; }
        var r = await post("/api/insight/openai", body);
        if (!r.ok) { msg(r.error, "err"); return false; }
        o.set = true; return true;
      };
      $("#aiwizModels").onclick = async function () {
        if (!(await saveKey())) return;
        msg("Asking for your models...");
        var r = await j("/api/insight/openai/models");
        if (!r.ok) return msg(r.error, "err");
        var sel = $("#aiwizModel");
        sel.innerHTML = r.models.map(function (m) { return '<option value="' + esc(m) + '">' + esc(m) + "</option>"; }).join("");
        if (o.model && r.models.indexOf(o.model) >= 0) sel.value = o.model;
        msg(r.models.length + " models available to this key. Choose one.", "ok");
      };
      next.textContent = "Save and continue";
      next.onclick = async function () {
        if (!(await saveKey())) return;
        var m = $("#aiwizModel").value || o.model;
        if (!m) return msg("Press Find my models, then choose one.", "err");
        var r = await post("/api/insight/openai", { model: m });
        if (!r.ok) return msg(r.error, "err");
        var p = await post("/api/insight/provider", { provider: "openai" });
        if (!p.ok) return msg(p.error, "err");
        go(4);                                    // services (MCP) are an Anthropic feature
      };
    } else {
      var pr = await j("/api/insight/provider");
      b.innerHTML =
        '<p class="aiwiz-lead">Connect a model on your network</p>' +
        '<p class="hint">The computer running Ollama, as http://its-address:11434. On this PC it is http://127.0.0.1:11434.</p>' +
        '<input id="aiwizUrl" value="' + esc(pr.url || "http://127.0.0.1:11434") + '">' +
        '<div class="aiwiz-row"><button class="wbtn" id="aiwizModels">Find its models</button>' +
        '<select id="aiwizModel"><option value="">' + esc(pr.model || "choose a model") + "</option></select></div>";
      $("#aiwizModels").onclick = async function () {
        var url = ($("#aiwizUrl").value || "").trim();
        var r = await post("/api/insight/provider", { provider: "local", url: url, model: pr.model || "" });
        if (!r.ok) return msg(r.error, "err");
        msg("Looking for models at " + url + "...");
        var d = await j("/api/insight/provider?probe=1");
        if (d.probe_error || !(d.models || []).length) return msg(d.probe_error || "No models found there. Pull one with: ollama pull qwen3.6:35b", "err");
        $("#aiwizModel").innerHTML = d.models.map(function (m) { return '<option value="' + esc(m) + '">' + esc(m) + "</option>"; }).join("");
        if (pr.model && d.models.indexOf(pr.model) >= 0) $("#aiwizModel").value = pr.model;
        msg(d.models.length + " models found. Choose one.", "ok");
      };
      next.textContent = "Save and continue";
      next.onclick = async function () {
        var m = $("#aiwizModel").value || pr.model;
        if (!m) return msg("Press Find its models, then choose one.", "err");
        var r = await post("/api/insight/provider", { provider: "local", url: ($("#aiwizUrl").value || "").trim(), model: m });
        if (!r.ok) return msg(r.error, "err");
        go(4);                                    // services (MCP) need the Anthropic route
      };
    }
  }

  // 4. Your services (MCP) - Anthropic only -----------------------------------------------------
  async function stepServices(b, next) {
    if (st.source !== "anthropic") return go(4);
    var d = await j("/api/insight/mcp");
    var rows = (d.items || []).map(function (s) {
      return '<li><b>' + esc(s.name) + "</b> " + esc(s.url) + (s.enabled ? "" : " (off)") + "</li>";
    }).join("");
    b.innerHTML =
      '<p class="aiwiz-lead">Connect your own services (optional)</p>' +
      '<p class="hint">MCP services let the assistant look things up in your lab\'s own systems - a LIMS, a ticket queue, an inventory. Anthropic connects to them, so each needs an https address reachable from the internet. Skip this if you have none.</p>' +
      (rows ? '<ul class="aiwiz-list">' + rows + "</ul>" : "") +
      '<div class="aiwiz-grid"><input id="aiwizMName" placeholder="Name, e.g. LIMS"><input id="aiwizMUrl" placeholder="https://..."><input type="password" id="aiwizMTok" placeholder="Access token (if it needs one)"></div>' +
      '<button class="wbtn" id="aiwizMAdd">Add this service</button>';
    $("#aiwizMAdd").onclick = async function () {
      var r = await post("/api/insight/mcp", { name: $("#aiwizMName").value.trim(), url: $("#aiwizMUrl").value.trim(),
                                               token: $("#aiwizMTok").value, enabled: true });
      if (!r.ok) return msg(r.error, "err");
      msg("Added. Add another, or press Next.", "ok"); stepServices(b, next);
    };
    next.textContent = "Next";
    next.onclick = function () { go(4); };
  }

  // 5. Test ------------------------------------------------------------------------------------
  async function stepTest(b, next) {
    b.innerHTML = '<p class="aiwiz-lead">Checking it answers</p><p class="hint" id="aiwizTestOut">Asking your AI a one-word question...</p>';
    next.disabled = true; next.textContent = "Done";
    var r = await post("/api/insight/test", {});
    var out = $("#aiwizTestOut");
    if (r.ok) {
      out.className = "aiwiz-ok";
      out.innerHTML = "It answered in " + (r.ms / 1000).toFixed(1) + " s: <b>" + esc(r.reply) + "</b>. IFS AI is ready - open it from the button in the corner.";
      msg("Connected.", "ok");
      next.disabled = false;
      next.onclick = function () { close(true); };
    } else {
      out.className = "aiwiz-bad";
      out.textContent = r.error || "It did not answer.";
      msg("Not connected yet. Go back and check the details, or try again.", "err");
      next.disabled = false; next.textContent = "Try again";
      next.onclick = function () { stepTest(b, next); };
    }
  }

  // The status line on the Insight screen: can IFS AI answer, and with what.
  var NAMES_P = { anthropic: "Anthropic", openai: "OpenAI", local: "a model on your network", both: "a model on your network, with Anthropic on request" };
  window.ifsAiStatus = async function () {
    var sum = $("#in-aisum"); if (!sum) return;
    var d; try { d = await j("/api/insight/summary?days=7"); } catch (e) { return; }
    var ai = (d && d.ai) || {};
    var dot = $("#in-aidot"), sub = $("#in-aisub"), btn = $("#in-aiconnect");
    var who = (NAMES_P[ai.provider] || ai.provider) + (ai.model ? " \u00b7 " + ai.model : "");
    var lt = ai.last_test;
    var local = ai.provider === "local" || ai.provider === "both";
    // "Connected" only when it is true: a network model that answers, or a cloud account whose
    // last test answered. Configured-but-unproven says so.
    var proven = local ? ai.reachable === true : !!(lt && lt.ok);
    var broken = local ? ai.reachable === false : !!(lt && !lt.ok);
    if (ai.available && proven) {
      dot.className = "aist-dot " + (ai.pro ? "on" : "warn");
      sum.textContent = "Connected: " + who;
      sub.textContent = ai.pro ? (lt && lt.ok ? "Answered a test " + ago(lt.t) + "." : "Answering at " + (ai.url || "") + ".")
                               : "It answers once an IFS Suite Pro licence is installed under Configuration.";
      btn.textContent = "Change";
    } else if (ai.available && broken) {
      dot.className = "aist-dot bad";
      sum.textContent = "Not answering: " + who;
      sub.textContent = local ? "Nothing answered at " + ai.url + ". Start the model there, or connect a different AI."
                              : (lt.error || "The last test did not get an answer.");
      btn.textContent = "Fix";
    } else if (ai.available) {
      dot.className = "aist-dot warn";
      sum.textContent = "Set up: " + who;
      sub.textContent = "Not tested yet. Run Connect your AI to check it answers.";
      btn.textContent = "Test";
    } else {
      sum.textContent = "Not connected";
      sub.textContent = "Use your own AI: an Anthropic or OpenAI account, or a model on your network.";
      btn.textContent = "Connect your AI";
    }
  };
  function ago(t) {
    var s = Math.max(0, Date.now() / 1000 - (t || 0));
    if (s < 90) return "just now";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " h ago";
    return Math.round(s / 86400) + " days ago";
  }
  setTimeout(function () { window.ifsAiStatus(); }, 800);
  setInterval(function () { var s = $("#in-aisum"); if (s && s.offsetParent) window.ifsAiStatus(); }, 6000);

  window.openAiWizard = function (source) {
    shell();
    st.source = source || st.source;
    go(0);
  };

  // Offered once, at a person's first sign-in (signing up leads straight to signing in).
  window.ifsMaybeOfferAiSetup = async function () {
    try {
      var s = await j("/api/insight/setup");
      if (s.ok && !s.seen && !s.ready) window.openAiWizard();
    } catch (e) {}
  };
})();
