"""IFS Control Suite launcher.

Puts a splash on screen the moment the shortcut is clicked, then starts the app behind it and
closes the splash once the app is actually answering - the way Altium and its kind behave.

This exists because the PyInstaller boot splash only lives inside the packaged exe. When the
app is started any other way (a per-user install, a dev run, or a machine where Smart App
Control refuses the exe) there was nothing on screen for the several seconds Python, Flask and
WebView2 take to come up, and a double-click looked like it had done nothing.

Run with pythonw.exe so no console window appears.
"""
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

# tkinter is imported lazily. The embeddable Python runtime we ship does not include it, and an
# import at module scope killed the launcher outright - no splash AND no app, from a shortcut that
# looked like it did nothing. The splash is a nicety; starting the app is not.
try:
    import tkinter
except Exception:
    tkinter = None

BASE = os.path.dirname(os.path.abspath(__file__))
SPLASH = os.path.join(BASE, "installer", "splash.png")
SPLASH2X = os.path.join(BASE, "installer", "splash@2x.png")
APP = os.path.join(BASE, "backend.py")
PORT = 8765
MAX_WAIT = 40.0          # never sit on the splash forever if the app cannot start
MIN_SHOW = 1.0           # just enough that it cannot flash past unread


def dpi_scale():
    """The display's scale factor, and make this process DPI-aware first.

    Without this the process is virtualised: Tk lays the window out in 96-dpi units and Windows
    then stretches the result, so a 780x460 splash is blown up to 1560x920 blurry physical pixels
    on a 200% display. Aware + the 2x artwork gives the same physical size at real resolution.
    """
    if sys.platform != "win32":
        return 1.0
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor v1
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()           # older Windows
        dc = ctypes.windll.user32.GetDC(0)
        try:
            dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)     # LOGPIXELSX
        finally:
            ctypes.windll.user32.ReleaseDC(0, dc)
        return max(1.0, dpi / 96.0)
    except Exception:
        return 1.0


def app_is_up():
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=0.4):
            return True
    except OSError:
        return False


WINDOW_TITLE = "IFS Control Suite"


def find_window(title=WINDOW_TITLE):
    """Handle of the app's own window, or None. Used both to know when the app is really on
    screen and to raise it when it already is."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def each(hwnd, _):
            if not u.IsWindowVisible(hwnd):
                return True
            n = u.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.strip() == title:
                    found.append(hwnd)
                    return False
            return True

        u.EnumWindows(each, 0)
        return found[0] if found else None
    except Exception:
        return None


def window_exists(title=WINDOW_TITLE):
    return find_window(title) is not None


def raise_existing_window(title=WINDOW_TITLE):
    """Bring the running app's window to the front. Returns True if one was found.

    Clicking the shortcut while IFS is already open used to do NOTHING visible: the launcher saw
    the port was up, showed a splash for a few seconds and exited, leaving the existing window
    wherever it was - behind other windows, or minimised. From the operator's side the app simply
    did not open, so they clicked again, and again.
    """
    hwnd = find_window(title)
    if hwnd is None:
        return False
    try:
        import ctypes
        u = ctypes.windll.user32
        if u.IsIconic(hwnd):
            u.ShowWindow(hwnd, 9)                 # SW_RESTORE
        # SetForegroundWindow is refused unless the caller owns the foreground, so borrow the
        # input state of whatever does for the moment it takes to raise the window.
        try:
            fg = u.GetForegroundWindow()
            cur = ctypes.windll.kernel32.GetCurrentThreadId()
            other = u.GetWindowThreadProcessId(fg, None)
            u.AttachThreadInput(other, cur, True)
            u.BringWindowToTop(hwnd)
            u.SetForegroundWindow(hwnd)
            u.AttachThreadInput(other, cur, False)
        except Exception:
            u.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def proc_start():
    """Start backend.py on the SAME interpreter this launcher is running on, windowless."""
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.exists(pyw):
        pyw = sys.executable
    creation = 0x08000000 if sys.platform == "win32" else 0   # CREATE_NO_WINDOW
    try:
        return subprocess.Popen([pyw, APP], cwd=BASE, creationflags=creation)
    except Exception:
        return None


def ask_running_app_to_quit(timeout=8.0):
    """Tell a windowless instance to shut down, and wait for the port to come free.

    A server with no window is a zombie: the browser fallback opened a page, the page was closed,
    and the process stayed. It holds 8765 and the serial ports, so the next click could never
    produce an app - only another web page. Ending it is what lets the shortcut work again."""
    try:
        req = urllib.request.Request("http://127.0.0.1:%d/api/quit" % PORT,
                                     data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=2.0).read()
    except Exception:
        pass                                    # it may die before it can answer; that is fine
    end = time.time() + timeout
    while time.time() < end:
        if not app_is_up():
            return True
        time.sleep(0.2)
    return not app_is_up()


def main():
    # Already running? Then the job is to show the window that exists, not to start a second
    # server or sit behind a splash.
    if app_is_up():
        if raise_existing_window():
            return
        # Serving, but there is no window. That is a leftover - the browser fallback keeps a
        # server alive after its page is closed - and opening another web page would only repeat
        # the thing the operator did not want. End it and start the app properly.
        if not ask_running_app_to_quit():
            # It will not go. Rather than leave the click doing nothing at all, show its page.
            try:
                webbrowser.open("http://127.0.0.1:%d/" % PORT)
            except Exception:
                pass
            return

    scale = dpi_scale()
    art = SPLASH2X if (scale >= 1.5 and os.path.exists(SPLASH2X)) else SPLASH

    if tkinter is None:
        # No Tk in this runtime: start the app and let its own window be the feedback.
        if proc_start() is None:
            return
        return

    root = tkinter.Tk()
    root.overrideredirect(True)                 # borderless, like a real splash
    root.attributes("-topmost", True)
    try:
        img = tkinter.PhotoImage(file=art)      # Tk 8.6 reads PNG natively
        w, h = img.width(), img.height()
        tkinter.Label(root, image=img, borderwidth=0, highlightthickness=0).pack()
    except Exception:
        img = None                              # no artwork: a small plain panel still says something
        w, h = 360, 120
        tkinter.Label(root, text="IFS Control Suite\nstarting…", font=("Segoe UI", 13),
                      bg="white", fg="#1b2733", width=30, height=4).pack()
        root.configure(bg="white")
    root.geometry("%dx%d+%d+%d" % (w, h,
                                   (root.winfo_screenwidth() - w) // 2,
                                   (root.winfo_screenheight() - h) // 2))

    proc = proc_start()

    state = {"done": False}

    def watch():
        # Wait for the app's WINDOW, not just its port. The port opens well before the window is
        # painted, and the old code then sat on a fixed floor on top of that - so the splash stayed
        # up for seconds AFTER the real window had already appeared behind it. Now the splash goes
        # the moment the window exists, and the floor only applies while there is still nothing to
        # show.
        t0 = time.time()
        end = t0 + MAX_WAIT
        ready = False
        while time.time() < end:
            if window_exists():
                ready = True
                break
            if proc is not None and proc.poll() is not None:
                break                 # the app exited on its own; stop waiting on it
            time.sleep(0.15)
        if not ready:
            # No window (headless run, or a browser fallback): fall back to the port being up.
            while time.time() < end and not app_is_up():
                time.sleep(0.15)
        held = time.time() - t0
        if held < MIN_SHOW:
            time.sleep(MIN_SHOW - held)
        state["done"] = True

    threading.Thread(target=watch, daemon=True).start()

    def poll():
        if state["done"]:
            root.destroy()
            return
        root.after(120, poll)

    root.after(120, poll)
    root.mainloop()


if __name__ == "__main__":
    main()
