"""Signed OTA manifests.

Every manifest on the public IFS-ota channel (app, Mac app, Opta firmware, display firmware)
carries an Ed25519 signature made with a private key that never leaves Augeas. IFS refuses any
manifest that is not signed by one of the public keys below, so somebody who gains write access to
the channel - or to the GitHub account behind it - still cannot push an update or firmware to a
station. The SHA-256 checksums inside a manifest then tie each downloaded file to that signature.

Ed25519 is implemented here directly from RFC 8032 (section 6, the reference code) so IFS needs no
extra crypto package on Windows or macOS. Verifying one manifest takes a few milliseconds.

Signed form: the manifest JSON with a "sig" member {"alg": "ed25519", "key": <key id>, "value":
<base64 signature>}. The signed bytes are a fixed prefix plus the manifest WITHOUT "sig", dumped
with sorted keys and no whitespace, so re-indenting the file does not break the signature but
changing any value does.
"""
import base64
import hashlib
import json

# key id -> 32-byte public key (hex). "ota-1" signs releases; "ota-2" is an offline backup key so a
# lost or leaked primary can be retired without stranding every installed copy.
PUBLIC_KEYS = {
    "ota-1": "2ca248312a32de90b34b3c483eb4cc83dcbc577d63c0dfeed8186463b87fb44d",
    "ota-2": "7f7c0a291bb3dc2240dd21ab5c1ceaf03de7a18380f2fa812e381cb3cd577d8d",
}
PREFIX = b"IFS-OTA-manifest-v1\n"

# ------------------------------------------------------------------ RFC 8032 Ed25519
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x):
    return pow(x, _p - 2, _p)


_d = -121665 * _inv(121666) % _p
_sqrt_m1 = pow(2, (_p - 1) // 4, _p)


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F, G * H, F * G, E * H)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y, sign):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _sqrt_m1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P):
    zi = _inv(P[2])
    x, y = P[0] * zi % _p, P[1] * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)


def _h(m):
    return int.from_bytes(hashlib.sha512(m).digest(), "little") % _q


def _expand(seed):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= (1 << 254)
    return a, h[32:]


def public_from_seed(seed):
    a, _ = _expand(seed)
    return _compress(_mul(a, _G))


def sign(seed, msg):
    a, prefix = _expand(seed)
    A = _compress(_mul(a, _G))
    r = _h(prefix + msg)
    R = _compress(_mul(r, _G))
    s = (r + _h(R + A + msg) * a) % _q
    return R + int.to_bytes(s, 32, "little")


def verify(public, msg, sig):
    if len(public) != 32 or len(sig) != 64:
        return False
    A = _decompress(public)
    R = _decompress(sig[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(sig[32:], "little")
    if s >= _q:
        return False
    return _equal(_mul(s, _G), _add(R, _mul(_h(sig[:32] + public + msg), A)))


# ------------------------------------------------------------------ manifests
def signed_bytes(manifest):
    body = {k: v for k, v in manifest.items() if k != "sig"}
    return PREFIX + json.dumps(body, sort_keys=True, separators=(",", ":"),
                               ensure_ascii=True).encode("ascii")


def sign_manifest(manifest, seed, key_id="ota-1"):
    out = {k: v for k, v in manifest.items() if k != "sig"}
    if public_from_seed(seed).hex() != PUBLIC_KEYS.get(key_id):
        raise ValueError("this private key does not match public key %s" % key_id)
    out["sig"] = {"alg": "ed25519", "key": key_id,
                  "value": base64.b64encode(sign(seed, signed_bytes(out))).decode("ascii")}
    return out


def check_manifest(manifest):
    """Raise ValueError unless the manifest carries a valid signature from a known key."""
    if not isinstance(manifest, dict):
        raise ValueError("the update channel returned something that is not a manifest")
    sig = manifest.get("sig")
    if not isinstance(sig, dict) or sig.get("alg") != "ed25519":
        raise ValueError("the update manifest is not signed - refusing it")
    pub = PUBLIC_KEYS.get(sig.get("key"))
    if not pub or pub.startswith("__"):
        raise ValueError("the update manifest is signed with an unknown key - refusing it")
    try:
        raw = base64.b64decode(sig.get("value") or "", validate=True)
    except Exception:
        raise ValueError("the update manifest signature is malformed - refusing it")
    if not verify(bytes.fromhex(pub), signed_bytes(manifest), raw):
        raise ValueError("the update manifest signature does not match - refusing it")
    return manifest
